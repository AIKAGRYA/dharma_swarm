from __future__ import annotations

import hashlib
import json
from pathlib import Path

from scripts.governance import a2a_onboard
from scripts.governance import a2a_semantic_task_packet as task_packet


def test_semantic_task_packet_is_hash_bound_to_locked_spec(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for semantic packet\n", encoding="utf-8")
    locked_sha = hashlib.sha256(locked_spec.read_bytes()).hexdigest()

    payload, exit_code = task_packet.render_packets(
        repo_root=repo_root,
        packet_dir=repo_root / "reports/a2a/semantic_tasks",
        receipt_dir=repo_root / "reports/a2a/semantic_task_packets",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == 0
    assert payload["schema_version"] == task_packet.SEMANTIC_TASK_PACKET_SCHEMA
    assert payload["locked_spec_sha256"] == locked_sha
    assert payload["counted_agents"] == ["codex_composer"]
    row = payload["rows"][0]
    packet_path = repo_root / row["packet_path"]
    packet_text = packet_path.read_text(encoding="utf-8")
    assert "`failure_digest`" in packet_text
    assert task_packet.REQUIRED_FAILURE_DIGEST_PROMPT in packet_text
    assert task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA in packet_text
    assert a2a_onboard.SEMANTIC_RECEIPT_SCHEMA in packet_text
    assert locked_sha in packet_text
    assert row["packet_sha256"] == hashlib.sha256(packet_text.encode("utf-8")).hexdigest()
    assert row["task_hash"] == f"sha256:{row['packet_sha256']}"
    assert Path(repo_root / payload["receipt_path"]).is_file()


def test_semantic_task_packet_renders_all_counted_agents(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for all counted agents\n", encoding="utf-8")

    payload, exit_code = task_packet.render_packets(
        repo_root=repo_root,
        packet_dir=repo_root / "reports/a2a/semantic_tasks",
        receipt_dir=repo_root / "reports/a2a/semantic_task_packets",
        agent="seed",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == 0
    assert payload["counted_agents"] == list(a2a_onboard.COUNTED_AGENT_UIDS)
    assert len(payload["rows"]) == len(a2a_onboard.COUNTED_AGENT_UIDS)
    for row in payload["rows"]:
        packet_path = repo_root / row["packet_path"]
        assert packet_path.is_file()
        body = packet_path.read_text(encoding="utf-8")
        assert f"Target agent: `{row['agent_uid']}`" in body
        assert f'"authored_by": "{row["agent_uid"]}"' in body


def test_semantic_task_packet_receipt_has_required_schema_fields(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for receipt schema fields\n", encoding="utf-8")

    payload, _exit_code = task_packet.render_packets(
        repo_root=repo_root,
        packet_dir=repo_root / "reports/a2a/semantic_tasks",
        receipt_dir=repo_root / "reports/a2a/semantic_task_packets",
        agent="hermes-m5",
        broker="agni",
        mode="prevalidate",
    )
    receipt = json.loads((repo_root / payload["receipt_path"]).read_text(encoding="utf-8"))

    assert receipt["required_reply_artifact_schema"] == task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA
    assert receipt["required_semantic_receipt_schema"] == a2a_onboard.SEMANTIC_RECEIPT_SCHEMA
    assert receipt["required_failure_digest_prompt"] == task_packet.REQUIRED_FAILURE_DIGEST_PROMPT
    assert receipt["rows"][0]["required_failure_digest_prompt"] == task_packet.REQUIRED_FAILURE_DIGEST_PROMPT
