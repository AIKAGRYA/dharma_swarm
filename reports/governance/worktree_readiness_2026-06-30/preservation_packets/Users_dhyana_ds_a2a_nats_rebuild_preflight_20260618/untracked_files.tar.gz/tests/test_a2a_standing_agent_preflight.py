from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from scripts.governance import a2a_onboard
from scripts.governance import a2a_standing_agent_preflight as standing


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _write_agents(root: Path, entry: dict[str, object]) -> None:
    _write_json(root / "agents.json", {"agents": {"codex_composer": entry}})


def _write_worker_heartbeat(root: Path) -> None:
    now = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    _write_json(
        root / "worker_heartbeats/codex_composer.json",
        {
            "schema_version": "dharma.a2a.standing_wake_loop_heartbeat.v1",
            "agent_uid": "codex_composer",
            "timestamp": now,
            "wake_loop_active": True,
            "standing_semantic_loop": True,
            "lease": {"lease_id": "test-lease"},
            "circuit_breaker": {"state": "closed"},
            "target_owned_claim": True,
        },
    )


def _write_semantic_source_artifact(repo_root: Path) -> str:
    path = repo_root / "reports/a2a/domain_reply_artifacts/test.json"
    _write_json(
        path,
        {
            "schema_version": "dharma.a2a.domain_reply_artifact.v1",
            "summary": "test semantic source artifact",
        },
    )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_domain_receipt(repo_root: Path) -> None:
    _write_json(
        repo_root / "reports/a2a/reply_receipts/20260619T000000Z-codex_composer-domain.json",
        {
            "schema_version": "dharma.a2a.reply_capture_receipt.v1",
            "timestamp": "2026-06-19T00:00:00Z",
            "status": a2a_onboard.DOMAIN_RECEIPTED,
            "domain_receipt_claim": True,
            "semantic_reply_claim": False,
        },
    )


def _write_semantic_receipt(repo_root: Path, locked_sha: str, source_hash: str) -> None:
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-semantic.json",
        {
            "schema_version": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
            "timestamp": "2026-06-19T00:00:00Z",
            "status": a2a_onboard.SEMANTIC_SIGNED,
            "agent_uid": "codex_composer",
            "locked_spec_sha256": locked_sha,
            "task_hash": "sha256:test-task",
            "model_identity": "test/model",
            "peer_model_processed_claim": True,
            "semantic_reply_claim": True,
            "confidence": 0.91,
            "evidence_refs": ["reports/a2a/domain_reply_artifacts/test.json"],
            "failure_digest": "confused: none; tried: read spec; failed: none; worked: verified",
            "source_artifact_path": "reports/a2a/domain_reply_artifacts/test.json",
            "source_artifact_sha256": source_hash,
        },
    )


def test_standing_agent_preflight_flags_session_scoped_evidence_only_agent(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(
        bus_root,
        {
            "authority": "external_worker_evidence_only",
            "type": "codex-cli",
            "dispatch_enabled": False,
        },
    )
    before = (bus_root / "agents.json").read_text(encoding="utf-8")

    payload, exit_code = standing.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/standing_agent_preflight",
        agent="codex_composer",
        broker="agni",
    )

    row = payload["rows"][0]
    assert exit_code == 1
    assert payload["passed"] is False
    assert row["session_scoped"] is True
    assert row["dispatch_enabled"] is False
    assert "agent is session/evidence scoped" in row["blockers"]
    assert "dispatch is disabled" in row["blockers"]
    assert any("target-owned standing loop" in item for item in row["required_promotions"])
    assert (bus_root / "agents.json").read_text(encoding="utf-8") == before
    assert (repo_root / payload["receipt_path"]).exists()


def test_standing_agent_preflight_requires_domain_and_semantic_evidence(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(
        bus_root,
        {
            "authority_status": "standing",
            "type": "standing-worker",
            "wake_loop_active": True,
        },
    )
    _write_worker_heartbeat(bus_root)

    payload, exit_code = standing.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/standing_agent_preflight",
        agent="codex_composer",
        broker="agni",
    )

    row = payload["rows"][0]
    assert exit_code == 1
    assert row["session_scoped"] is False
    assert row["worker_heartbeat_present"] is True
    assert "missing target-owned DOMAIN_RECEIPTED evidence" in row["blockers"]
    assert "missing current SEMANTIC_SIGNED evidence" in row["blockers"]


def test_standing_agent_preflight_accepts_fully_evidenced_standing_agent(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for test\n", encoding="utf-8")
    locked_sha = hashlib.sha256(locked_spec.read_bytes()).hexdigest()
    monkeypatch.setattr(a2a_onboard, "LOCKED_SPEC_SHA256", locked_sha)
    _write_agents(
        bus_root,
        {
            "authority_status": "standing",
            "type": "standing-worker",
            "wake_loop_active": True,
            "dispatch_enabled": True,
        },
    )
    _write_worker_heartbeat(bus_root)
    _write_domain_receipt(repo_root)
    _write_semantic_receipt(
        repo_root,
        locked_sha,
        _write_semantic_source_artifact(repo_root),
    )

    payload, exit_code = standing.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/standing_agent_preflight",
        agent="codex_composer",
        broker="agni",
    )

    row = payload["rows"][0]
    assert exit_code == 0
    assert payload["passed"] is True
    assert row["final_state"] == standing.READY_STANDING_AGENT
    assert row["blockers"] == ()
    assert row["semantic_receipt_path"].endswith("codex_composer-semantic.json")
