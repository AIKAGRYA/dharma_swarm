from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from scripts.governance import check_a2a_onboard_contract as verifier
from scripts.governance.check_a2a_onboard_contract import run_verifier


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _domain_receipt(agent_uid: str, *, timestamp: str | None = None) -> dict[str, object]:
    return {
        "schema_version": "dharma.a2a.domain_receipt.v1",
        "status": "DOMAIN_RECEIPTED",
        "reply_evidence_tier": "DOMAIN_RECEIPTED",
        "contact_evidence_tier": "DOMAIN_RECEIPTED",
        "domain_receipt_claim": True,
        "agent_uid": agent_uid,
        "locked_spec_path": verifier.LOCKED_SPEC_PATH,
        "locked_spec_sha256": verifier.LOCKED_SPEC_SHA256,
        "broker": "agni",
        "mode": "prevalidate",
        "timestamp": timestamp or datetime.now(UTC).isoformat(),
    }


def test_handler_ack_does_not_satisfy_domain_receipt(tmp_path: Path) -> None:
    _write_json(
        tmp_path / "reports/a2a/reply_receipts/handler.json",
        {
            "schema_version": "dharma.a2a.reply_capture_receipt.v1",
            "status": "HANDLER_ACKED",
            "contact_evidence_tier": "HANDLER_ACKED",
            "domain_receipt_claim": False,
        },
    )

    result = run_verifier(
        repo_root=tmp_path,
        agent="seed",
        broker="agni",
        mode="prevalidate",
        timeout_s=1,
        max_evidence_age_s=600,
        evidence_globs=["reports/a2a/reply_receipts/*.json"],
        skip_make=True,
    )

    assert result.passed is False
    assert "only HANDLER_ACKED evidence was found" in result.failures[0]


def test_typed_domain_receipts_satisfy_all_agent_evidence_gate(tmp_path: Path) -> None:
    for agent_uid in verifier.COUNTED_AGENT_UIDS:
        _write_json(
            tmp_path / f"reports/a2a/reply_receipts/{agent_uid}.json",
            _domain_receipt(agent_uid),
        )

    result = run_verifier(
        repo_root=tmp_path,
        agent="seed",
        broker="agni",
        mode="prevalidate",
        timeout_s=1,
        max_evidence_age_s=600,
        evidence_globs=["reports/a2a/reply_receipts/*.json"],
        skip_make=True,
    )

    assert result.passed is True
    assert result.evidence_agents == sorted(verifier.COUNTED_AGENT_UIDS)


def test_all_agent_gate_rejects_single_domain_receipt(tmp_path: Path) -> None:
    _write_json(
        tmp_path / "reports/a2a/reply_receipts/domain.json",
        _domain_receipt("codex_composer"),
    )

    result = run_verifier(
        repo_root=tmp_path,
        agent="seed",
        broker="agni",
        mode="prevalidate",
        timeout_s=1,
        max_evidence_age_s=600,
        evidence_globs=["reports/a2a/reply_receipts/*.json"],
        skip_make=True,
    )

    assert result.passed is False
    assert "missing DOMAIN_RECEIPTED evidence for agents:" in result.failures[-1]


def test_fake_domain_schema_is_rejected(tmp_path: Path) -> None:
    _write_json(
        tmp_path / "reports/a2a/reply_receipts/fake.json",
        {
            "status": "DOMAIN_RECEIPTED",
            "reply_evidence_tier": "DOMAIN_RECEIPTED",
            "contact_evidence_tier": "DOMAIN_RECEIPTED",
            "domain_receipt_claim": True,
            "reply_schema": "dharma.a2a.fake.v1",
            "locked_spec_path": verifier.LOCKED_SPEC_PATH,
            "locked_spec_sha256": verifier.LOCKED_SPEC_SHA256,
            "broker": "agni",
            "mode": "prevalidate",
            "timestamp": datetime.now(UTC).isoformat(),
        },
    )

    result = run_verifier(
        repo_root=tmp_path,
        agent="seed",
        broker="agni",
        mode="prevalidate",
        timeout_s=1,
        max_evidence_age_s=600,
        evidence_globs=["reports/a2a/reply_receipts/*.json"],
        skip_make=True,
    )

    assert result.passed is False
    assert "no DOMAIN_RECEIPTED evidence receipt found" in result.failures


def test_stale_domain_receipt_is_rejected(tmp_path: Path) -> None:
    _write_json(
        tmp_path / "reports/a2a/reply_receipts/stale.json",
        {
            **_domain_receipt(
                "codex_composer",
                timestamp=(datetime.now(UTC) - timedelta(hours=1)).isoformat(),
            ),
        },
    )

    result = run_verifier(
        repo_root=tmp_path,
        agent="seed",
        broker="agni",
        mode="prevalidate",
        timeout_s=1,
        max_evidence_age_s=60,
        evidence_globs=["reports/a2a/reply_receipts/*.json"],
        skip_make=True,
    )

    assert result.passed is False


def test_wrong_locked_spec_hash_is_rejected(tmp_path: Path) -> None:
    _write_json(
        tmp_path / "reports/a2a/reply_receipts/wrong-spec.json",
        {
            **_domain_receipt("codex_composer"),
            "locked_spec_sha256": "0" * 64,
        },
    )

    result = run_verifier(
        repo_root=tmp_path,
        agent="seed",
        broker="agni",
        mode="prevalidate",
        timeout_s=1,
        max_evidence_age_s=600,
        evidence_globs=["reports/a2a/reply_receipts/*.json"],
        skip_make=True,
    )

    assert result.passed is False
