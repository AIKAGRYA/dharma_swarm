from __future__ import annotations

import hashlib
import json
from pathlib import Path

from scripts.governance import a2a_domain_reply_artifact_preflight
from scripts.governance import a2a_domain_reply_request
from scripts.governance import a2a_onboard
from scripts.governance import a2a_semantic_task_packet


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _semantic_packet_receipt(repo_root: Path, agent_uid: str) -> tuple[Path, dict[str, object], dict[str, object]]:
    packet_path = repo_root / f"reports/a2a/semantic_tasks/{agent_uid}-packet.md"
    packet_path.parent.mkdir(parents=True, exist_ok=True)
    body = "\n".join(
        [
            a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
            a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
            a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
            a2a_onboard.LOCKED_SPEC_SHA256,
            "failure_digest",
            f"Target agent: `{agent_uid}`",
            "",
        ]
    )
    packet_path.write_text(body, encoding="utf-8")
    packet_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
    row: dict[str, object] = {
        "agent_uid": agent_uid,
        "packet_id": f"packet-{agent_uid}",
        "packet_path": str(packet_path.relative_to(repo_root)),
        "packet_sha256": packet_sha,
        "task_hash": f"sha256:{packet_sha}",
        "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
    }
    payload: dict[str, object] = {
        "schema_version": a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
        "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
        "counted_agents": [agent_uid],
        "rows": [row],
    }
    receipt_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        payload,
    )
    return receipt_path, payload, row


def _write_send_receipt(
    repo_root: Path,
    row: dict[str, object],
    *,
    task_hash: str | None = None,
) -> Path:
    agent_uid = str(row["agent_uid"])
    packet_id = str(row["packet_id"])
    receipt = {
        "schema_version": a2a_domain_reply_artifact_preflight.SEND_RECEIPT_SCHEMA,
        "target_uid": agent_uid,
        "packet_id": packet_id,
        "reply_subject": f"dharma.agent.{agent_uid}.inbox.reply.{packet_id}",
        "task_hash": task_hash or str(row["task_hash"]),
        "locked_spec_sha256": str(row["locked_spec_sha256"]),
    }
    return _write_json(
        repo_root / f"reports/a2a/send_receipts/20260619T000000Z-{agent_uid}-{packet_id}.json",
        receipt,
    )


def test_domain_reply_request_renders_request_without_target_outbox_mutation(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    agent_uid = "codex_composer"
    semantic_path, _payload, row = _semantic_packet_receipt(repo_root, agent_uid)
    send_path = _write_send_receipt(repo_root, row)
    outbox_root = tmp_path / "outboxes"

    payload, exit_code = a2a_domain_reply_request.run_requests(
        repo_root=repo_root,
        request_dir=repo_root / "reports/a2a/domain_reply_requests",
        receipt_dir=repo_root / "reports/a2a/domain_reply_requests",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=outbox_root,
        agent=agent_uid,
    )

    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["target_outbox_mutation_performed"] is False
    rows = payload["rows"]
    assert isinstance(rows, list)
    result = rows[0]
    assert result["final_state"] == a2a_domain_reply_request.READY_DOMAIN_REPLY_REQUEST
    assert result["target_owned_write_required"] is True
    assert result["send_receipt_path"] == str(send_path.relative_to(repo_root))
    request_path = repo_root / str(result["request_path"])
    assert request_path.is_file()
    assert str(request_path).startswith(str(repo_root / "reports/a2a/domain_reply_requests"))
    assert not (outbox_root / agent_uid / f"{row['packet_id']}.json").exists()
    body = request_path.read_text(encoding="utf-8")
    assert a2a_domain_reply_request.DOMAIN_REPLY_REQUEST_SCHEMA in body
    assert "This request is not the reply artifact" in body
    assert "peer_model_processed_claim" in body
    assert "semantic_reply_claim" in body
    assert "failure_digest" in body
    assert str(outbox_root / agent_uid / f"{row['packet_id']}.json") in body


def test_domain_reply_request_blocks_when_send_receipt_missing(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    agent_uid = "codex_composer"
    semantic_path, _payload, row = _semantic_packet_receipt(repo_root, agent_uid)

    payload, exit_code = a2a_domain_reply_request.run_requests(
        repo_root=repo_root,
        request_dir=repo_root / "reports/a2a/domain_reply_requests",
        receipt_dir=repo_root / "reports/a2a/domain_reply_requests",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=tmp_path / "outboxes",
        agent=agent_uid,
    )

    assert exit_code == 1
    assert payload["passed"] is False
    rows = payload["rows"]
    assert isinstance(rows, list)
    result = rows[0]
    assert result["final_state"] == a2a_domain_reply_request.BLOCKED_DOMAIN_REPLY_REQUEST
    assert "missing semantic task send receipt" in result["blockers"]
    assert not (repo_root / str(result["request_path"])).exists()
    assert not (tmp_path / "outboxes" / agent_uid / f"{row['packet_id']}.json").exists()


def test_domain_reply_request_blocks_on_send_receipt_hash_mismatch(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    agent_uid = "codex_composer"
    semantic_path, _payload, row = _semantic_packet_receipt(repo_root, agent_uid)
    _write_send_receipt(repo_root, row, task_hash="sha256:" + "0" * 64)

    payload, exit_code = a2a_domain_reply_request.run_requests(
        repo_root=repo_root,
        request_dir=repo_root / "reports/a2a/domain_reply_requests",
        receipt_dir=repo_root / "reports/a2a/domain_reply_requests",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=tmp_path / "outboxes",
        agent=agent_uid,
    )

    assert exit_code == 1
    rows = payload["rows"]
    assert isinstance(rows, list)
    result = rows[0]
    assert "send receipt task_hash mismatch" in result["blockers"]
    assert not (repo_root / str(result["request_path"])).exists()
