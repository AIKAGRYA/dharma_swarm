from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from scripts.governance import a2a_onboard


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _prepare_repo_and_bus(
    tmp_path: Path,
    monkeypatch,
    *,
    agents: dict[str, dict[str, object]],
) -> tuple[Path, Path, str]:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for test\n", encoding="utf-8")
    locked_sha = hashlib.sha256(locked_spec.read_bytes()).hexdigest()
    monkeypatch.setattr(a2a_onboard, "LOCKED_SPEC_SHA256", locked_sha)
    monkeypatch.setenv("NATS_CONTEXT", "agni-wss")

    a2a_bus_root = tmp_path / "a2a_bus"
    now = datetime.now(UTC).isoformat()
    _write_json(a2a_bus_root / "agents.json", {"agents": agents})
    _write_json(
        a2a_bus_root / "heartbeats.json",
        {"agents": {uid: {"status": "active", "last_seen": now} for uid in agents}},
    )
    return repo_root, a2a_bus_root, locked_sha


def _write_semantic_source_artifact(repo_root: Path) -> str:
    path = repo_root / "reports/a2a/domain_reply_artifacts/test.json"
    _write_json(
        path,
        {
            "schema_version": "dharma.a2a.domain_reply_artifact.v1",
            "summary": "test semantic source artifact",
        },
    )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _valid_a2a_semantic_receipt(
    agent_uid: str,
    locked_sha: str,
    *,
    source_artifact_sha256: str,
) -> dict[str, object]:
    return {
        "schema_version": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
        "timestamp": "2026-06-19T00:00:00Z",
        "status": a2a_onboard.SEMANTIC_SIGNED,
        "proof_tier": a2a_onboard.SEMANTIC_SIGNED,
        "agent_uid": agent_uid,
        "from_agent": agent_uid,
        "to_agent": "operator",
        "packet_id": "packet-semantic-test",
        "reply_subject": "_INBOX.a2a.test",
        "peer_model_processed_claim": True,
        "semantic_reply_claim": True,
        "model_identity": "test-provider/test-model",
        "task_hash": "sha256:test-task",
        "locked_spec_sha256": locked_sha,
        "verdict": "approve",
        "confidence": 0.91,
        "failure_digest": "confusion: none; tried: validated receipt; failed: none; worked: current semantic signoff",
        "evidence_refs": ["reports/a2a/domain_reply_artifacts/test.json"],
        "blockers": [],
        "domain_receipt_schema": a2a_onboard.DOMAIN_RECEIPT_SCHEMA,
        "domain_receipt_sha256": "ab" * 32,
        "source_artifact_path": "reports/a2a/domain_reply_artifacts/test.json",
        "source_artifact_sha256": source_artifact_sha256,
    }


def _write_valid_domain_effect_receipt(repo_root: Path, agent_uid: str) -> Path:
    path = repo_root / f"reports/a2a/reply_receipts/20260619T000000Z-{agent_uid}-domain-effect.json"
    _write_json(
        path,
        {
            "schema_version": "dharma.a2a.reply_capture_receipt.v1",
            "timestamp": "2026-06-19T00:00:00Z",
            "status": a2a_onboard.DOMAIN_RECEIPTED,
            "reply_evidence_tier": a2a_onboard.DOMAIN_RECEIPTED,
            "contact_evidence_tier": a2a_onboard.DOMAIN_RECEIPTED,
            "to": agent_uid,
            "target_uid": agent_uid,
            "packet_id": "packet-domain-test",
            "reply_subject": f"dharma.agent.{agent_uid}.inbox.reply.packet-domain-test",
            "domain_receipt_claim": True,
            "semantic_reply_claim": False,
        },
    )
    return path


def test_a2a_onboard_writes_per_agent_domain_receipts(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for test\n", encoding="utf-8")
    monkeypatch.setattr(
        a2a_onboard,
        "LOCKED_SPEC_SHA256",
        hashlib.sha256(locked_spec.read_bytes()).hexdigest(),
    )
    for name in a2a_onboard.BROKER_PROFILES["agni"]["secret_env"]:
        monkeypatch.delenv(name, raising=False)

    a2a_bus_root = tmp_path / "a2a_bus"
    now = datetime.now(UTC).isoformat()
    _write_json(
        a2a_bus_root / "agents.json",
        {
            "agents": {
                uid: {"status": "active", "last_seen": now, "wake_loop_active": True}
                for uid in a2a_onboard.COUNTED_AGENT_UIDS
            }
        },
    )
    _write_json(
        a2a_bus_root / "heartbeats.json",
        {
            "agents": {
                uid: {"status": "active", "last_seen": now}
                for uid in a2a_onboard.COUNTED_AGENT_UIDS
            }
        },
    )

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="seed",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == a2a_onboard.EXIT_CODES["BLOCKED_SECRET_REFERENCE"]
    assert payload["counted_agents"] == list(a2a_onboard.COUNTED_AGENT_UIDS)
    assert "dharma.a2a.semantic_receipt.v1" in payload["receipt_schemas"]
    assert len(payload["presence_projection"]) == len(a2a_onboard.COUNTED_AGENT_UIDS)
    assert payload["presence_projection"][0]["transport_state"] == "TRANSPORT_CONFIG_VALID"
    assert payload["presence_projection"][0]["semantic_receipt_state"] == "REQUIRED_NOT_BUILT"
    assert "BLOCKED_SECRET_REFERENCE" in payload["presence_projection"][0]["failure_states"]
    commands = payload["rows"][0]["operator_commands"]
    assert "a2a_send.py --route agent-inbox" in commands["send_hot_contact"]
    assert "make a2a-semantic-task-packet" in commands["render_semantic_task_packet"]
    assert "make a2a-identity-reconcile" in commands["identity_reconcile"]
    assert "make a2a-presence-projector" in commands["project_presence"]
    assert "--write-projections" in commands["write_presence_projection"]
    assert "make a2a-presence-preflight" in commands["presence_preflight"]
    assert "make a2a-wake-loop-preflight" in commands["wake_loop_preflight"]
    assert "make a2a-standing-agent-preflight" in commands["standing_agent_preflight"]
    assert "A2A_STANDING_WAKE_LOOP_AGENT=" in commands["start_standing_wake_loop"]
    assert "make a2a-standing-wake-loop" in commands["start_standing_wake_loop"]
    assert "a2a_reply_capture.py --send-receipt" in commands["capture_reply"]
    assert "--stream A2A_INBOX" in commands["capture_reply"]
    assert "make a2a-domain-reply-request" in commands["render_domain_reply_request"]
    assert "A2A_DOMAIN_REPLY_ARTIFACT_AGENT=" in commands["write_domain_reply_artifact"]
    assert "make a2a-domain-reply-artifact" in commands["write_domain_reply_artifact"]
    assert "make a2a-domain-reply-artifact-preflight" in commands["preflight_domain_reply_artifact"]
    assert "a2a_domain_reply_worker.py --send-receipt" in commands["publish_domain_receipt"]
    assert "A2A_LIVE_ACL_PROBE=approved-live-acl-probe" in commands["prove_live_acl"]
    assert payload["presence_projection"][0]["operator_commands"] == commands
    assert len(payload["domain_receipt_paths"]) == len(a2a_onboard.COUNTED_AGENT_UIDS)
    for rel_path in payload["domain_receipt_paths"]:
        receipt = json.loads((repo_root / rel_path).read_text(encoding="utf-8"))
        assert receipt["schema_version"] == a2a_onboard.DOMAIN_RECEIPT_SCHEMA
        assert receipt["domain_receipt_claim"] is True
        assert receipt["semantic_receipt_schema"] == a2a_onboard.SEMANTIC_RECEIPT_SCHEMA
        assert receipt["onboard_run_id"] == payload["onboard_run_id"]
        assert receipt["final_state"] == "BLOCKED_SECRET_REFERENCE"
        assert "BLOCKED_SECRET_REFERENCE" in receipt["failure_states"]
        assert receipt["principal"] == a2a_onboard.principal_for_agent(receipt["agent_uid"])
        assert receipt["principal"].startswith("a2a_")


def test_a2a_onboard_live_mode_requires_operator_approval(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for test\n", encoding="utf-8")
    monkeypatch.setattr(
        a2a_onboard,
        "LOCKED_SPEC_SHA256",
        hashlib.sha256(locked_spec.read_bytes()).hexdigest(),
    )
    monkeypatch.setenv("AGNI_NATS_URL", "nats://agni.example:4222")
    monkeypatch.delenv(a2a_onboard.LIVE_APPROVAL_ENV, raising=False)

    a2a_bus_root = tmp_path / "a2a_bus"
    now = datetime.now(UTC).isoformat()
    _write_json(
        a2a_bus_root / "agents.json",
        {
            "agents": {
                uid: {"status": "active", "last_seen": now, "wake_loop_active": True}
                for uid in a2a_onboard.COUNTED_AGENT_UIDS
            }
        },
    )
    _write_json(
        a2a_bus_root / "heartbeats.json",
        {
            "agents": {
                uid: {"status": "active", "last_seen": now}
                for uid in a2a_onboard.COUNTED_AGENT_UIDS
            }
        },
    )

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="seed",
        broker="agni",
        mode="live",
    )

    assert exit_code == a2a_onboard.EXIT_CODES["BLOCKED_LIVE_CALL_FORBIDDEN"]
    assert all(row["final_state"] == "BLOCKED_LIVE_CALL_FORBIDDEN" for row in payload["rows"])


def test_a2a_onboard_accepts_selected_nats_context_as_credential_reference(
    tmp_path: Path, monkeypatch
) -> None:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for test\n", encoding="utf-8")
    monkeypatch.setattr(
        a2a_onboard,
        "LOCKED_SPEC_SHA256",
        hashlib.sha256(locked_spec.read_bytes()).hexdigest(),
    )
    for name in a2a_onboard.BROKER_PROFILES["agni"]["secret_env"]:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("NATS_CONTEXT", "agni-wss")

    a2a_bus_root = tmp_path / "a2a_bus"
    now = datetime.now(UTC).isoformat()
    _write_json(
        a2a_bus_root / "agents.json",
        {
            "agents": {
                "codex_composer": {
                    "status": "active",
                    "last_seen": now,
                    "wake_loop_active": True,
                }
            }
        },
    )
    _write_json(
        a2a_bus_root / "heartbeats.json",
        {"agents": {"codex_composer": {"status": "active", "last_seen": now}}},
    )

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == a2a_onboard.EXIT_CODES["BLOCKED_DOMAIN_RECEIPT"]
    assert payload["rows"][0]["final_state"] == "BLOCKED_DOMAIN_RECEIPT"
    assert payload["rows"][0]["failure_states"] == (
        "BLOCKED_DOMAIN_RECEIPT",
        "BLOCKED_SEMANTIC_RECEIPT",
    )


def test_a2a_onboard_ignores_malformed_semantic_receipt_file_presence(
    tmp_path: Path, monkeypatch
) -> None:
    now = datetime.now(UTC).isoformat()
    repo_root, a2a_bus_root, locked_sha = _prepare_repo_and_bus(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "active",
                "last_seen": now,
                "wake_loop_active": True,
            }
        },
    )
    malformed = _valid_a2a_semantic_receipt(
        "codex_composer",
        locked_sha,
        source_artifact_sha256=_write_semantic_source_artifact(repo_root),
    )
    malformed["locked_spec_sha256"] = "wrong"
    malformed["peer_model_processed_claim"] = False
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-bad-semantic.json",
        malformed,
    )
    _write_valid_domain_effect_receipt(repo_root, "codex_composer")

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == a2a_onboard.EXIT_CODES["BLOCKED_SEMANTIC_RECEIPT"]
    assert payload["rows"][0]["semantic_receipt_state"] == "REQUIRED_NOT_BUILT"
    assert payload["rows"][0]["last_semantic_receipt"] == ""


def test_a2a_onboard_accepts_valid_current_semantic_receipt(
    tmp_path: Path, monkeypatch
) -> None:
    now = datetime.now(UTC).isoformat()
    repo_root, a2a_bus_root, locked_sha = _prepare_repo_and_bus(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "active",
                "last_seen": now,
                "wake_loop_active": True,
            }
        },
    )
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-good-semantic.json",
        _valid_a2a_semantic_receipt(
            "codex_composer",
            locked_sha,
            source_artifact_sha256=_write_semantic_source_artifact(repo_root),
        ),
    )
    _write_valid_domain_effect_receipt(repo_root, "codex_composer")

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == 0
    assert payload["rows"][0]["final_state"] == "READY_PREVALIDATED"
    assert payload["rows"][0]["failure_states"] == ()
    assert payload["rows"][0]["semantic_receipt_state"] == a2a_onboard.SEMANTIC_SIGNED


def test_a2a_onboard_preserves_session_scope_blocker_with_valid_semantic_receipt(
    tmp_path: Path, monkeypatch
) -> None:
    now = datetime.now(UTC).isoformat()
    repo_root, a2a_bus_root, locked_sha = _prepare_repo_and_bus(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "active",
                "last_seen": now,
                "wake_loop_active": True,
                "type": "codex-cli",
            }
        },
    )
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-good-semantic.json",
        _valid_a2a_semantic_receipt(
            "codex_composer",
            locked_sha,
            source_artifact_sha256=_write_semantic_source_artifact(repo_root),
        ),
    )
    _write_valid_domain_effect_receipt(repo_root, "codex_composer")

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == a2a_onboard.EXIT_CODES["DEGRADED_SESSION_SCOPED"]
    row = payload["rows"][0]
    assert row["semantic_receipt_state"] == a2a_onboard.SEMANTIC_SIGNED
    assert row["final_state"] == "DEGRADED_SESSION_SCOPED"
    assert row["failure_states"] == ("DEGRADED_SESSION_SCOPED",)
    assert payload["presence_projection"][0]["peer_model_processed_claim"] is True
    assert payload["presence_projection"][0]["failure_states"] == ["DEGRADED_SESSION_SCOPED"]


def test_a2a_onboard_rejects_semantic_receipt_with_mismatched_source_hash(
    tmp_path: Path, monkeypatch
) -> None:
    now = datetime.now(UTC).isoformat()
    repo_root, a2a_bus_root, locked_sha = _prepare_repo_and_bus(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "active",
                "last_seen": now,
                "wake_loop_active": True,
            }
        },
    )
    _write_semantic_source_artifact(repo_root)
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-bad-source-hash.json",
        _valid_a2a_semantic_receipt(
            "codex_composer",
            locked_sha,
            source_artifact_sha256="00" * 32,
        ),
    )
    _write_valid_domain_effect_receipt(repo_root, "codex_composer")

    payload, exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert exit_code == a2a_onboard.EXIT_CODES["BLOCKED_SEMANTIC_RECEIPT"]
    assert payload["rows"][0]["semantic_receipt_state"] == "REQUIRED_NOT_BUILT"
    assert payload["rows"][0]["last_semantic_receipt"] == ""


def test_a2a_onboard_rejects_semantic_receipt_without_failure_digest(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root, a2a_bus_root, locked_sha = _prepare_repo_and_bus(
        tmp_path,
        monkeypatch,
        agents={"codex_composer": {"status": "wake_loop_active", "wake_loop_active": True}},
    )
    source_hash = _write_semantic_source_artifact(repo_root)
    receipt = _valid_a2a_semantic_receipt(
        "codex_composer",
        locked_sha,
        source_artifact_sha256=source_hash,
    )
    receipt.pop("failure_digest")
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-no-digest.json",
        receipt,
    )

    payload, _exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=repo_root / "reports/a2a",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    assert payload["rows"][0]["semantic_receipt_state"] == "REQUIRED_NOT_BUILT"
    assert payload["rows"][0]["last_semantic_receipt"] == ""
