from __future__ import annotations

import json
from pathlib import Path

from scripts.governance import a2a_identity_reconcile as reconcile


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _write_agents(root: Path, *, collision: bool = True) -> None:
    agents: dict[str, object] = {
        "opus_composer": {
            "aliases": ["claude-opus"] if collision else ["opus-composer"],
            "authority_status": "standing",
            "status": "ready",
        },
        "claude-opus": {
            "capabilities": ["reasoning", "review"],
            "status": "legacy",
        },
    }
    _write_json(root / "agents.json", {"agents": agents})


def test_identity_reconcile_dry_run_plans_alias_removal_without_write(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root, collision=True)
    before = (bus_root / "agents.json").read_text(encoding="utf-8")

    payload, exit_code = reconcile.run_reconcile(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/identity_reconcile",
        agent="opus_composer",
        write_registry=False,
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert payload["mutation_performed"] is False
    assert payload["proposed_changes"] == [
        {
            "op": "remove_alias",
            "agent_uid": "opus_composer",
            "alias": "claude-opus",
            "canonical_owner": "claude-opus",
            "reason": (
                "alias claude-opus is also a top-level registry uid; keep "
                "claude-opus as canonical owner and remove it from opus_composer.aliases"
            ),
        }
    ]
    assert payload["rows"][0]["would_pass_after_plan"] is True
    assert (bus_root / "agents.json").read_text(encoding="utf-8") == before
    assert (repo_root / payload["receipt_path"]).exists()


def test_identity_reconcile_write_requires_approval_env(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root, collision=True)
    monkeypatch.delenv(reconcile.WRITE_APPROVAL_ENV, raising=False)

    payload, exit_code = reconcile.run_reconcile(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/identity_reconcile",
        agent="opus_composer",
        write_registry=True,
    )

    registry = json.loads((bus_root / "agents.json").read_text(encoding="utf-8"))
    assert payload["mutation_requested"] is True
    assert payload["mutation_performed"] is False
    assert "missing approval env" in payload["write_status"]
    assert registry["agents"]["opus_composer"]["aliases"] == ["claude-opus"]


def test_identity_reconcile_write_with_approval_removes_alias_only(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root, collision=True)
    monkeypatch.setenv(reconcile.WRITE_APPROVAL_ENV, reconcile.WRITE_APPROVAL_VALUE)

    payload, exit_code = reconcile.run_reconcile(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/identity_reconcile",
        agent="opus_composer",
        write_registry=True,
    )

    registry = json.loads((bus_root / "agents.json").read_text(encoding="utf-8"))
    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["mutation_performed"] is True
    assert payload["write_status"] == "registry write performed"
    assert payload["rows_before"][0]["final_state"] == reconcile.BLOCKED_IDENTITY_COLLISION
    assert payload["rows"][0]["final_state"] == reconcile.READY_IDENTITY_CANONICAL
    assert registry["agents"]["opus_composer"]["aliases"] == []
    assert "claude-opus" in registry["agents"]


def test_identity_reconcile_passes_clean_identity(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root, collision=False)

    payload, exit_code = reconcile.run_reconcile(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/identity_reconcile",
        agent="opus_composer",
        write_registry=False,
    )

    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["rows"][0]["final_state"] == reconcile.READY_IDENTITY_CANONICAL
    assert payload["proposed_changes"] == []
