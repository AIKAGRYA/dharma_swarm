from __future__ import annotations

import json
import sys
from pathlib import Path

from scripts.runtime import a2a_model_reply_capture


def _delivery_record(tmp_path: Path) -> Path:
    path = tmp_path / "delivery.json"
    path.write_text(
        json.dumps(
            {
                "schema_version": "dharma.a2a.inbox_delivery.v1",
                "agent_uid": "hermes-m5",
                "bridge_kind": "filesystem_delivery_handler",
                "source_subject": "dharma.agent.hermes-m5.inbox",
                "envelope_sha256": "abc123",
                "envelope": {
                    "packet_id": "packet-1",
                    "reply_subject": "dharma.agent.hermes-m5.inbox.reply.packet-1",
                    "target_uid": "hermes-m5",
                },
            },
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    return path


def _send_receipt(tmp_path: Path) -> Path:
    path = tmp_path / "send.json"
    path.write_text(
        json.dumps(
            {
                "schema_version": "dharma.a2a.send_receipt.v1",
                "packet_id": "packet-1",
                "target_uid": "hermes-m5",
                "reply_subject": "dharma.agent.hermes-m5.inbox.reply.packet-1",
                "task_hash": "sha256:" + "a" * 64,
                "locked_spec_sha256": "b" * 64,
            },
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    return path


def _model_command(payload: dict[str, object]) -> list[str]:
    script = "import json; print(json.dumps(" + repr(payload) + ", sort_keys=True))"
    return [sys.executable, "-c", script]


def _valid_artifact(send_path: Path) -> dict[str, object]:
    return {
        "schema_version": "dharma.a2a.domain_reply_artifact.v1",
        "authored_by": "hermes-m5",
        "agent_uid": "hermes-m5",
        "packet_id": "packet-1",
        "reply_subject": "dharma.agent.hermes-m5.inbox.reply.packet-1",
        "send_receipt_path": str(send_path.resolve()),
        "verdict": "approve",
        "summary": "Hermes model processed the semantic task packet.",
        "evidence_refs": ["docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md"],
        "peer_model_processed_claim": True,
        "semantic_reply_claim": True,
        "model_identity": "hermes-m5/test-model",
        "task_hash": "sha256:" + "a" * 64,
        "locked_spec_sha256": "b" * 64,
        "confidence": 0.91,
        "failure_digest": (
            "confused: none; tried: packet and spec; failed: none; "
            "worked: semantic reply"
        ),
        "blockers": [],
    }


def test_model_reply_capture_writes_validated_artifact(tmp_path: Path, capsys) -> None:
    delivery = _delivery_record(tmp_path)
    send = _send_receipt(tmp_path)
    outbox = tmp_path / "outboxes"
    receipts = tmp_path / "receipts"

    code = a2a_model_reply_capture.main(
        [
            "--agent-uid",
            "hermes-m5",
            "--delivery-record",
            str(delivery),
            "--send-receipt",
            str(send),
            "--outbox-root",
            str(outbox),
            "--receipt-dir",
            str(receipts),
            "--json",
            "--command",
            *_model_command(_valid_artifact(send)),
        ]
    )

    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    artifact_path = Path(payload["artifact_path"])
    assert artifact_path == outbox / "hermes-m5" / "packet-1.json"
    artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
    assert artifact["authored_by"] == "hermes-m5"
    assert artifact["author_kind"] == "target_model_stdout_capture"
    assert artifact["model_stdout_sha256"]
    assert artifact["peer_model_processed_claim"] is True
    assert (
        payload["status"]
        == a2a_model_reply_capture.STATUS_MODEL_REPLY_ARTIFACT_WRITTEN
    )
    assert Path(payload["receipt_path"]).is_file()


def test_model_reply_capture_rejects_wrong_actor(tmp_path: Path, capsys) -> None:
    delivery = _delivery_record(tmp_path)
    send = _send_receipt(tmp_path)
    artifact = _valid_artifact(send)
    artifact["authored_by"] = "codex_composer"

    code = a2a_model_reply_capture.main(
        [
            "--agent-uid",
            "hermes-m5",
            "--delivery-record",
            str(delivery),
            "--send-receipt",
            str(send),
            "--outbox-root",
            str(tmp_path / "outboxes"),
            "--receipt-dir",
            str(tmp_path / "receipts"),
            "--json",
            "--command",
            *_model_command(artifact),
        ]
    )

    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert (
        payload["status"]
        == a2a_model_reply_capture.STATUS_ARTIFACT_VALIDATION_FAILED
    )
    assert "artifact actor does not match target agent" in payload["blockers"]
    assert not Path(payload["artifact_path"]).exists()


def test_model_reply_capture_records_stdout_tail_on_command_failure(
    tmp_path: Path,
    capsys,
) -> None:
    delivery = _delivery_record(tmp_path)
    send = _send_receipt(tmp_path)
    script = "print('Credit balance is too low'); raise SystemExit(1)"

    code = a2a_model_reply_capture.main(
        [
            "--agent-uid",
            "hermes-m5",
            "--delivery-record",
            str(delivery),
            "--send-receipt",
            str(send),
            "--outbox-root",
            str(tmp_path / "outboxes"),
            "--receipt-dir",
            str(tmp_path / "receipts"),
            "--json",
            "--command",
            "--",
            sys.executable,
            "-c",
            script,
        ]
    )

    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == a2a_model_reply_capture.STATUS_MODEL_COMMAND_FAILED
    assert payload["stdout_tail"].strip() == "Credit balance is too low"
    assert payload["command"][0] == sys.executable
    assert not Path(payload["artifact_path"]).exists()


def test_model_reply_capture_command_separator_works_from_sys_argv(
    tmp_path: Path,
    capsys,
    monkeypatch,
) -> None:
    delivery = _delivery_record(tmp_path)
    send = _send_receipt(tmp_path)
    script = "print('stdout-only failure'); raise SystemExit(1)"
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "a2a_model_reply_capture.py",
            "--agent-uid",
            "hermes-m5",
            "--delivery-record",
            str(delivery),
            "--send-receipt",
            str(send),
            "--outbox-root",
            str(tmp_path / "outboxes"),
            "--receipt-dir",
            str(tmp_path / "receipts"),
            "--json",
            "--command",
            "--",
            sys.executable,
            "-c",
            script,
        ],
    )

    code = a2a_model_reply_capture.main()

    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["command"][:3] == [sys.executable, "-c", script]
    assert payload["stdout_tail"].strip() == "stdout-only failure"
