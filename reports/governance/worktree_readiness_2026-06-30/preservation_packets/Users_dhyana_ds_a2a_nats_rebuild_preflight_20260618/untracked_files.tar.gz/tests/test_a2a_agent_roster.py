from __future__ import annotations

import json
from pathlib import Path

from dharma_swarm.a2a.agent_roster import SEED_AGENT_UIDS, resolve_agent_selection


def _write_roster(a2a_bus_root: Path, agents: dict[str, dict[str, object]]) -> None:
    path = a2a_bus_root / "agents.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"agents": agents}), encoding="utf-8")


def test_seed_selector_is_fixed_even_with_custom_roster(tmp_path: Path) -> None:
    _write_roster(
        tmp_path,
        {
            "future_worker": {
                "type": "claude-code",
                "capabilities": ["code_review"],
            }
        },
    )

    selection = resolve_agent_selection("seed", a2a_bus_root=tmp_path)

    assert selection.agent_uids == SEED_AGENT_UIDS
    assert selection.required_agent_count == len(SEED_AGENT_UIDS)
    assert selection.strict is True


def test_all_selector_uses_dynamic_available_roster_entries(tmp_path: Path) -> None:
    _write_roster(
        tmp_path,
        {
            "claude_code_now": {
                "type": "claude-code",
                "provider": "anthropic",
                "capabilities": ["code_review", "reasoning"],
            },
            "devin_rate_limited": {
                "type": "devin",
                "capabilities": ["code_review"],
                "quota_state": "rate_limited",
            },
            "qwen_disabled": {
                "type": "qwen-code",
                "capabilities": ["code_review"],
                "dispatch_enabled": False,
            },
        },
    )

    selection = resolve_agent_selection("all", a2a_bus_root=tmp_path)

    assert selection.agent_uids == ("claude_code_now",)
    assert selection.excluded_agent_uids == ("devin_rate_limited", "qwen_disabled")
    assert selection.selection_kind == "dynamic_all_ready"


def test_capability_selector_supports_quorum_requirement(tmp_path: Path) -> None:
    _write_roster(
        tmp_path,
        {
            "agent_a": {"type": "codex-cli", "capabilities": ["code_review"]},
            "agent_b": {"type": "claude-code", "capabilities": ["code_review"]},
            "agent_c": {"type": "hermes", "capabilities": ["memory"]},
        },
    )

    selection = resolve_agent_selection(
        "capability:code_review",
        a2a_bus_root=tmp_path,
        min_agents=1,
    )

    assert selection.agent_uids == ("agent_a", "agent_b")
    assert selection.required_agent_count == 1
    assert selection.strict is False

