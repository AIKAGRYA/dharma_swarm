from __future__ import annotations

import subprocess
from pathlib import Path

from scripts.governance import a2a_live_acl_probe as live_acl


def _fake_result(command: tuple[str, ...], returncode: int) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(
        list(command),
        returncode,
        stdout="",
        stderr="",
    )


def _expected_returncode(command: tuple[str, ...]) -> int:
    if "a2a_forbidden_other_agent_inbox" in command:
        return 1
    if "dharma.a2a.>" in command:
        return 1
    if "stream" in command and "add" in command:
        return 1
    if "--tlsca" in command:
        return 1
    return 0


def test_live_acl_probe_dry_run_writes_fail_closed_receipt(tmp_path: Path) -> None:
    payload, exit_code = live_acl.run_probe(
        receipt_dir=tmp_path,
        agent="seed",
        context_template="{principal}",
        execute=False,
        timeout_s=1,
    )

    assert exit_code == 1
    assert payload["schema_version"] == live_acl.LIVE_ACL_PROBE_SCHEMA
    assert payload["passed"] is False
    assert payload["execution_requested"] is False
    assert payload["execution_approved"] is False
    assert payload["counted_agents"] == list(live_acl.COUNTED_AGENT_UIDS)
    assert len(payload["planned_probes"]) == len(live_acl.COUNTED_AGENT_UIDS) * 8
    assert payload["probe_results"] == []
    assert "dry-run rendered planned probes only" in payload["failures"][0]
    assert Path(payload["receipt_path"]).is_file()


def test_live_acl_probe_execute_without_approval_does_not_run_commands(
    tmp_path: Path,
    monkeypatch,
) -> None:
    def fail_if_called(*_args, **_kwargs):
        raise AssertionError("live command should not run without approval")

    monkeypatch.delenv(live_acl.LIVE_ACL_PROBE_ENV, raising=False)
    monkeypatch.setattr(live_acl, "_run_command", fail_if_called)

    payload, exit_code = live_acl.run_probe(
        receipt_dir=tmp_path,
        agent="codex_composer",
        context_template="{principal}",
        execute=True,
        timeout_s=1,
    )

    assert exit_code == 1
    assert payload["execution_requested"] is True
    assert payload["execution_approved"] is False
    assert payload["probe_results"] == []
    assert any(live_acl.LIVE_ACL_PROBE_ENV in failure for failure in payload["failures"])


def test_live_acl_probe_execute_with_approval_accepts_expected_returncodes(
    tmp_path: Path,
    monkeypatch,
) -> None:
    def fake_run(command: tuple[str, ...], *, timeout_s: int) -> subprocess.CompletedProcess[str]:
        return _fake_result(command, _expected_returncode(command))

    monkeypatch.setenv(live_acl.LIVE_ACL_PROBE_ENV, live_acl.LIVE_ACL_PROBE_VALUE)
    monkeypatch.setattr(live_acl, "_run_command", fake_run)

    payload, exit_code = live_acl.run_probe(
        receipt_dir=tmp_path,
        agent="codex_composer",
        context_template="{principal}",
        execute=True,
        timeout_s=1,
    )

    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["execution_approved"] is True
    assert len(payload["probe_results"]) == 8
    assert all(result["passed"] for result in payload["probe_results"])


def test_live_acl_probe_fails_when_negative_probe_is_allowed(
    tmp_path: Path,
    monkeypatch,
) -> None:
    def fake_run(command: tuple[str, ...], *, timeout_s: int) -> subprocess.CompletedProcess[str]:
        if "dharma.a2a.>" in command:
            return _fake_result(command, 0)
        return _fake_result(command, _expected_returncode(command))

    monkeypatch.setenv(live_acl.LIVE_ACL_PROBE_ENV, live_acl.LIVE_ACL_PROBE_VALUE)
    monkeypatch.setattr(live_acl, "_run_command", fake_run)

    payload, exit_code = live_acl.run_probe(
        receipt_dir=tmp_path,
        agent="codex_composer",
        context_template="{principal}",
        execute=True,
        timeout_s=1,
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert any("deny_subscribe_broad_fleet_subjects" in failure for failure in payload["failures"])
