from __future__ import annotations

import hashlib
import json
from pathlib import Path

from scripts.governance import a2a_onboard
from scripts.governance import a2a_wake_loop_preflight as wake_preflight


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _prepare(
    tmp_path: Path,
    monkeypatch,
    *,
    agents: dict[str, dict[str, object]],
) -> tuple[Path, Path, str]:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for wake-loop tests\n", encoding="utf-8")
    locked_sha = hashlib.sha256(locked_spec.read_bytes()).hexdigest()
    monkeypatch.setattr(a2a_onboard, "LOCKED_SPEC_SHA256", locked_sha)
    producer = repo_root / "scripts/runtime/a2a_domain_reply_worker.py"
    producer.parent.mkdir(parents=True, exist_ok=True)
    producer.write_text("SEMANTIC_RECEIPT_SCHEMA = 'dharma.a2a.semantic_receipt.v1'\n", encoding="utf-8")

    a2a_bus_root = tmp_path / "a2a_bus"
    _write_json(a2a_bus_root / "agents.json", {"agents": agents})
    return repo_root, a2a_bus_root, locked_sha


def _write_domain_and_semantic_receipts(
    repo_root: Path,
    *,
    agent_uid: str,
    locked_sha: str,
) -> None:
    artifact = repo_root / "reports/a2a/domain_reply_artifacts/source.json"
    _write_json(
        artifact,
        {
            "schema_version": "dharma.a2a.domain_reply_artifact.v1",
            "summary": "wake preflight source",
        },
    )
    source_hash = hashlib.sha256(artifact.read_bytes()).hexdigest()
    _write_json(
        repo_root / f"reports/a2a/reply_receipts/20260619T000000Z-{agent_uid}-domain.json",
        {
            "schema_version": "dharma.a2a.reply_capture_receipt.v1",
            "status": a2a_onboard.DOMAIN_RECEIPTED,
            "reply_evidence_tier": a2a_onboard.DOMAIN_RECEIPTED,
            "contact_evidence_tier": a2a_onboard.DOMAIN_RECEIPTED,
            "agent_uid": agent_uid,
            "target_uid": agent_uid,
            "domain_receipt_claim": True,
        },
    )
    _write_json(
        repo_root / f"reports/a2a/semantic_receipts/20260619T000000Z-{agent_uid}-semantic.json",
        {
            "schema_version": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
            "status": a2a_onboard.SEMANTIC_SIGNED,
            "agent_uid": agent_uid,
            "locked_spec_sha256": locked_sha,
            "task_hash": "sha256:wake-test",
            "model_identity": "test-provider/test-model",
            "peer_model_processed_claim": True,
            "semantic_reply_claim": True,
            "confidence": 0.95,
            "failure_digest": "confusion: none; tried: wake preflight; failed: none; worked: semantic receipt",
            "evidence_refs": ["reports/a2a/domain_reply_artifacts/source.json"],
            "source_artifact_path": "reports/a2a/domain_reply_artifacts/source.json",
            "source_artifact_sha256": source_hash,
        },
    )


def test_wake_loop_preflight_fails_closed_without_standing_loop(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root, a2a_bus_root, _locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={"codex_composer": {"status": "active"}},
    )

    payload, exit_code = wake_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=repo_root / "reports/a2a/wake_loop_preflight",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    row = payload["rows"][0]
    assert exit_code == 1
    assert payload["schema_version"] == wake_preflight.WAKE_LOOP_PREFLIGHT_SCHEMA
    assert row["final_state"] == "BLOCKED_WAKE_LOOP"
    assert "BLOCKED_WAKE_LOOP" in row["blockers"]
    assert "BLOCKED_DOMAIN_RECEIPT" in row["blockers"]
    assert "BLOCKED_SEMANTIC_RECEIPT" in row["blockers"]
    assert "make a2a-wake-loop-preflight" in row["operator_commands"]["wake_loop_preflight"]
    assert Path(repo_root / payload["receipt_path"]).is_file()


def test_wake_loop_preflight_surfaces_latest_standing_wake_loop_attempt(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root, a2a_bus_root, _locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "wake_loop_active",
                "type": "codex-cli",
            }
        },
    )
    attempt_path = repo_root / (
        "reports/a2a/standing_wake_loop/"
        "20260619T000000Z-codex_composer-standing-wake-loop.json"
    )
    _write_json(
        attempt_path,
        {
            "schema_version": "dharma.a2a.standing_wake_loop_receipt.v1",
            "status": "DEGRADED_SESSION_SCOPED",
            "agent_uid": "codex_composer",
            "session_scoped": True,
            "wrote_heartbeat": False,
            "blockers": ["DEGRADED_SESSION_SCOPED"],
        },
    )

    payload, exit_code = wake_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=repo_root / "reports/a2a/wake_loop_preflight",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    row = payload["rows"][0]
    assert exit_code == 1
    assert row["latest_standing_wake_loop_status"] == "DEGRADED_SESSION_SCOPED"
    assert tuple(row["latest_standing_wake_loop_blockers"]) == (
        "DEGRADED_SESSION_SCOPED",
    )
    assert row["latest_standing_wake_loop_wrote_heartbeat"] is False
    assert row["latest_standing_wake_loop_session_scoped"] is True
    assert str(attempt_path.relative_to(repo_root)) in row["evidence_paths"]
    assert any(
        "latest standing wake-loop status is DEGRADED_SESSION_SCOPED" in blocker
        for blocker in payload["blockers"]
    )


def test_wake_loop_preflight_accepts_standing_semantic_loop(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root, a2a_bus_root, locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "wake_loop_active",
                "wake_loop_active": True,
                "standing_semantic_loop": True,
                "lease": {"owner": "codex_composer"},
                "circuit_breaker": {"status": "closed"},
            }
        },
    )
    _write_json(
        a2a_bus_root / "worker_heartbeats/codex_composer.json",
        {
            "status": "active",
            "peer_model_processed_claim": True,
            "lease_refs": [{"status": "leased", "wake_id": "wake-1"}],
            "circuit_breaker": {"status": "closed"},
        },
    )
    _write_domain_and_semantic_receipts(
        repo_root,
        agent_uid="codex_composer",
        locked_sha=locked_sha,
    )

    payload, exit_code = wake_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=repo_root / "reports/a2a/wake_loop_preflight",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    row = payload["rows"][0]
    assert exit_code == 0
    assert payload["passed"] is True
    assert row["final_state"] == wake_preflight.READY_WAKE_LOOP_PREVALIDATED
    assert row["blockers"] == ()
    assert row["semantic_loop_present"] is True
    assert all(surface["present"] for surface in row["contract_surfaces"].values())


def test_wake_loop_preflight_refuses_session_scoped_promotion(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root, a2a_bus_root, locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "wake_loop_active",
                "wake_loop_active": True,
                "standing_semantic_loop": True,
                "type": "codex-cli",
                "lease": {"owner": "codex_composer"},
                "circuit_breaker": {"status": "closed"},
            }
        },
    )
    _write_json(
        a2a_bus_root / "worker_heartbeats/codex_composer.json",
        {
            "status": "active",
            "peer_model_processed_claim": True,
            "lease_refs": [{"status": "leased", "wake_id": "wake-1"}],
            "circuit_breaker": {"status": "closed"},
        },
    )
    _write_domain_and_semantic_receipts(
        repo_root,
        agent_uid="codex_composer",
        locked_sha=locked_sha,
    )

    payload, exit_code = wake_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=repo_root / "reports/a2a/wake_loop_preflight",
        agent="codex_composer",
        broker="agni",
        mode="prevalidate",
    )

    row = payload["rows"][0]
    assert exit_code == 1
    assert row["final_state"] == "DEGRADED_SESSION_SCOPED"
    assert row["session_scoped"] is True
    assert row["semantic_loop_present"] is False
    assert "DEGRADED_SESSION_SCOPED" in row["blockers"]
