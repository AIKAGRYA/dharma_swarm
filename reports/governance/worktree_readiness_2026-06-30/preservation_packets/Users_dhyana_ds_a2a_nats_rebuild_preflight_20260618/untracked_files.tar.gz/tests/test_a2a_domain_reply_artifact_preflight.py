from __future__ import annotations

import json
from pathlib import Path

from scripts.governance import a2a_domain_reply_artifact_preflight as preflight
from scripts.governance import a2a_onboard
from scripts.governance import a2a_semantic_task_packet


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _semantic_task_packet_receipt(repo_root: Path, *, agent_uid: str = "codex_composer") -> Path:
    packet_path = repo_root / f"reports/a2a/semantic_tasks/{agent_uid}-packet.md"
    packet_path.parent.mkdir(parents=True, exist_ok=True)
    packet_path.write_text("semantic packet", encoding="utf-8")
    row = {
        "agent_uid": agent_uid,
        "packet_id": f"packet-{agent_uid}",
        "packet_path": f"reports/a2a/semantic_tasks/{agent_uid}-packet.md",
        "packet_sha256": "a" * 64,
        "task_hash": "sha256:" + "b" * 64,
        "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
        "required_reply_artifact_schema": a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
        "required_semantic_receipt_schema": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
    }
    return _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        {
            "schema_version": a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
            "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
            "counted_agents": [agent_uid],
            "rows": [row],
        },
    )


def _send_receipt(
    repo_root: Path,
    *,
    agent_uid: str = "codex_composer",
) -> Path:
    packet_id = f"packet-{agent_uid}"
    return _write_json(
        repo_root / f"reports/a2a/send_receipts/20260619T000000Z-{agent_uid}-{packet_id}.json",
        {
            "schema_version": "dharma.a2a.send_receipt.v1",
            "packet_id": packet_id,
            "target_uid": agent_uid,
            "route": "agent-inbox",
            "subject": f"dharma.agent.{agent_uid}.inbox",
            "reply_subject": f"dharma.agent.{agent_uid}.inbox.reply.{packet_id}",
            "status": "PUBLISH_ACKED",
            "ack_tier": "PUBLISH_ACCEPTED",
            "semantic_task_packet_sha256": "a" * 64,
            "task_hash": "sha256:" + "b" * 64,
            "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
        },
    )


def _reply_artifact(
    path: Path,
    *,
    send_receipt_path: Path,
    agent_uid: str = "codex_composer",
    model_identity: str = "codex-composer/test-model",
) -> Path:
    packet_id = f"packet-{agent_uid}"
    return _write_json(
        path,
        {
            "schema_version": "dharma.a2a.domain_reply_artifact.v1",
            "authored_by": agent_uid,
            "packet_id": packet_id,
            "reply_subject": f"dharma.agent.{agent_uid}.inbox.reply.{packet_id}",
            "send_receipt_path": str(send_receipt_path.resolve()),
            "summary": "target model processed the semantic packet",
            "verdict": "accepted",
            "peer_model_processed_claim": True,
            "semantic_reply_claim": True,
            "model_identity": model_identity,
            "task_hash": "sha256:" + "b" * 64,
            "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
            "confidence": 0.82,
            "evidence_refs": ["reports/a2a/semantic_tasks/codex_composer-packet.md"],
            "failure_digest": "confused: none; tried: parsed packet; failed: none; worked: validated reply",
        },
    )


def test_domain_reply_artifact_preflight_fails_without_target_owned_artifact(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    semantic_path = _semantic_task_packet_receipt(repo_root)
    _send_receipt(repo_root)
    outbox_root = tmp_path / "outboxes"

    payload, exit_code = preflight.run_preflight(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/domain_reply_artifact_preflight",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=outbox_root,
        agent="codex_composer",
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert payload["rows"][0]["artifact_present"] is False
    assert "missing target-owned domain reply artifact" in payload["blockers"][0]
    assert not (outbox_root / "codex_composer/packet-codex_composer.json").exists()


def test_domain_reply_artifact_preflight_surfaces_latest_model_capture_failure(
    tmp_path: Path,
) -> None:
    repo_root = tmp_path / "repo"
    semantic_path = _semantic_task_packet_receipt(repo_root)
    _send_receipt(repo_root)
    outbox_root = tmp_path / "outboxes"
    capture_path = repo_root / (
        "reports/a2a/model_reply_captures/"
        "20260619T000001Z-codex_composer-packet-codex_composer.json"
    )
    _write_json(
        capture_path,
        {
            "schema_version": "dharma.a2a.model_reply_capture_receipt.v1",
            "status": "MODEL_COMMAND_FAILED",
            "agent_uid": "codex_composer",
            "packet_id": "packet-codex_composer",
            "wrote_artifact": False,
            "blockers": ["model command exited 1"],
            "stdout_tail": "Credit balance is too low\n",
            "stderr_tail": "",
        },
    )

    payload, exit_code = preflight.run_preflight(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/domain_reply_artifact_preflight",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=outbox_root,
        agent="codex_composer",
    )

    assert exit_code == 1
    row = payload["rows"][0]
    assert row["latest_model_capture_status"] == "MODEL_COMMAND_FAILED"
    assert tuple(row["latest_model_capture_blockers"]) == ("model command exited 1",)
    assert row["latest_model_capture_stdout_tail"] == "Credit balance is too low\n"
    assert row["latest_model_capture_wrote_artifact"] is False
    assert str(capture_path.relative_to(repo_root)) in row["evidence_paths"]
    assert any(
        "latest target model capture status is MODEL_COMMAND_FAILED" in blocker
        for blocker in payload["blockers"]
    )
    assert any(
        "latest target model capture blocker: model command exited 1" in blocker
        for blocker in payload["blockers"]
    )


def test_domain_reply_artifact_preflight_accepts_valid_semantic_artifact(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    semantic_path = _semantic_task_packet_receipt(repo_root)
    send_path = _send_receipt(repo_root)
    outbox_root = tmp_path / "outboxes"
    artifact_path = outbox_root / "codex_composer/packet-codex_composer.json"
    _reply_artifact(artifact_path, send_receipt_path=send_path)

    payload, exit_code = preflight.run_preflight(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/domain_reply_artifact_preflight",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=outbox_root,
        agent="codex_composer",
    )

    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["rows"][0]["final_state"] == preflight.READY_DOMAIN_REPLY_ARTIFACT
    assert payload["rows"][0]["semantic_reply_claim"] is True
    assert payload["rows"][0]["peer_model_processed_claim"] is True


def test_domain_reply_artifact_preflight_rejects_placeholder_semantic_claim(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    semantic_path = _semantic_task_packet_receipt(repo_root)
    send_path = _send_receipt(repo_root)
    outbox_root = tmp_path / "outboxes"
    artifact_path = outbox_root / "codex_composer/packet-codex_composer.json"
    _reply_artifact(artifact_path, send_receipt_path=send_path, model_identity="<model>")

    payload, exit_code = preflight.run_preflight(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/domain_reply_artifact_preflight",
        semantic_task_packet_receipt_path=semantic_path,
        send_receipt_root=repo_root / "reports/a2a/send_receipts",
        outbox_root=outbox_root,
        agent="codex_composer",
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert any("model_identity is still a placeholder" in blocker for blocker in payload["blockers"])
