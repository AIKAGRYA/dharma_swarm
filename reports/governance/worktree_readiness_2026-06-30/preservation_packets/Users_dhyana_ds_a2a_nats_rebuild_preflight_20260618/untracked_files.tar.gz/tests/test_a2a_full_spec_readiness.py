from __future__ import annotations

import json
import hashlib
from datetime import UTC, datetime, timedelta
from pathlib import Path

from dharma_swarm.a2a.jetstream_topology import acl_probe_specs
from scripts.governance import a2a_domain_reply_artifact_preflight
from scripts.governance import a2a_domain_reply_request
from scripts.governance import a2a_identity_reconcile
from scripts.governance import a2a_live_acl_probe
from scripts.governance import a2a_full_spec_readiness as readiness
from scripts.governance import a2a_onboard
from scripts.governance import a2a_presence_preflight
from scripts.governance import a2a_semantic_task_packet
from scripts.governance import a2a_standing_agent_preflight
from scripts.governance import a2a_wake_loop_preflight


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _topology_receipt(*, passed: bool) -> dict[str, object]:
    verification = {
        "observed_streams": ["A2A_INBOX", "A2A_DLQ"],
        "missing_streams": ["A2A_TASKS", "A2A_RECEIPTS"],
        "legacy_streams": ["DHARMA_A2A"],
        "overlapping_subjects": [
            "DHARMA_A2A:dharma.a2a.> overlaps canonical dharma.a2a.task.>"
        ],
    }
    if passed:
        verification = {
            "observed_streams": ["A2A_INBOX", "A2A_TASKS", "A2A_RECEIPTS", "A2A_DLQ"],
            "missing_streams": [],
            "legacy_streams": [],
            "overlapping_subjects": [],
        }
    return {
        "schema_version": "dharma.a2a.live_topology_probe.v1",
        "passed": passed,
        "failures": [] if passed else ["missing live canonical streams: A2A_RECEIPTS, A2A_TASKS"],
        "verification": verification,
        "cutover_transaction_plan": {
            "mutation_gate": "A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover",
            "post_cutover_steps_after_legacy_cutover": [{"step_id": "add_A2A_TASKS"}],
            "post_cutover_compensation_plan": [{"step_id": "add_A2A_TASKS"}],
        },
    }


def _onboard_receipt(*, ready: bool) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for agent_uid in a2a_onboard.COUNTED_AGENT_UIDS:
        if ready:
            rows.append(
                {
                    "agent_uid": agent_uid,
                    "final_state": "READY_PREVALIDATED",
                    "failure_states": [],
                    "domain_receipt_state": a2a_onboard.DOMAIN_RECEIPTED,
                    "semantic_receipt_state": a2a_onboard.SEMANTIC_SIGNED,
                    "handler_ack_state": "HANDLER_ACKED",
                    "last_domain_receipt": f"reports/a2a/reply_receipts/{agent_uid}.json",
                    "last_semantic_receipt": f"reports/a2a/semantic_receipts/{agent_uid}.json",
                }
            )
            continue
        failure_states = ["BLOCKED_SEMANTIC_RECEIPT"]
        if agent_uid == "qwen_code":
            failure_states = ["BLOCKED_WAKE_LOOP", "DEGRADED_SESSION_SCOPED", "BLOCKED_SEMANTIC_RECEIPT"]
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": failure_states[0],
                "failure_states": failure_states,
                "domain_receipt_state": "REQUIRED_NOT_BUILT",
                "semantic_receipt_state": "REQUIRED_NOT_BUILT",
                "handler_ack_state": "NO_HANDLER_ACK",
                "last_domain_receipt": "",
                "last_semantic_receipt": "",
            }
        )
    return {
        "schema_version": a2a_onboard.ONBOARD_RECEIPT_SCHEMA,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "rows": rows,
    }


def _topology_acl_receipt(*, ready: bool) -> dict[str, object]:
    specs = [spec.to_dict() for spec in acl_probe_specs(a2a_onboard.COUNTED_AGENT_UIDS)]
    return {
        "schema_version": "dharma.a2a.jetstream_topology_verifier.v1",
        "passed": ready,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "acl_probe_specs": specs,
        "acl_probe_verification": {
            "passed": ready,
            "failures": [] if ready else ["ACL probe specs must match counted agent denominator exactly"],
            "checked_principals": [spec["principal"] for spec in specs],
        },
    }


def _live_acl_receipt(*, passed: bool) -> dict[str, object]:
    return {
        "schema_version": a2a_live_acl_probe.LIVE_ACL_PROBE_SCHEMA,
        "passed": passed,
        "failures": [] if passed else ["codex_composer:deny_subscribe_broad_fleet_subjects expected returncode_nonzero but got returncode 0"],
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "live_acl_probe_verification": {
            "passed": passed,
            "failures": [] if passed else ["codex_composer: deny_subscribe_broad_fleet_subjects allowed"],
            "positive_probes": ["publish_own_presence", "pull_own_inbox_consumer"],
            "negative_probes": ["deny_subscribe_broad_fleet_subjects", "deny_mutate_streams_or_consumers"],
        },
    }


def _semantic_task_packet_receipt(repo_root: Path, *, ready: bool) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for agent_uid in a2a_onboard.COUNTED_AGENT_UIDS:
        packet_path = repo_root / f"reports/a2a/semantic_tasks/{agent_uid}-packet.md"
        packet_path.parent.mkdir(parents=True, exist_ok=True)
        body = "\n".join(
            [
                a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
                a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
                a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
                a2a_onboard.LOCKED_SPEC_SHA256,
                "failure_digest",
                f"Target agent: `{agent_uid}`",
                "",
            ]
        )
        packet_path.write_text(body, encoding="utf-8")
        packet_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
        rows.append(
            {
                "agent_uid": agent_uid,
                "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
                "packet_id": f"packet-{agent_uid}",
                "packet_path": f"reports/a2a/semantic_tasks/{agent_uid}-packet.md",
                "packet_sha256": packet_sha if ready else "bad",
                "task_hash": f"sha256:{packet_sha}",
                "required_reply_artifact_schema": a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
                "required_semantic_receipt_schema": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
                "required_failure_digest_prompt": a2a_semantic_task_packet.REQUIRED_FAILURE_DIGEST_PROMPT,
            }
        )
    return {
        "schema_version": a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
        "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "rows": rows,
    }


def _write_semantic_send_receipts(
    repo_root: Path,
    semantic_payload: dict[str, object],
    *,
    ready: bool = True,
) -> Path:
    receipt_dir = repo_root / "reports/a2a/send_receipts"
    receipt_dir.mkdir(parents=True, exist_ok=True)
    rows = semantic_payload["rows"]
    assert isinstance(rows, list)
    for row in rows:
        assert isinstance(row, dict)
        agent_uid = str(row["agent_uid"])
        packet_id = str(row["packet_id"])
        packet_sha = str(row["packet_sha256"])
        task_hash = str(row["task_hash"])
        locked_spec = str(row["locked_spec_sha256"])
        if not ready and agent_uid == "hermes-m5":
            task_hash = "sha256:" + "0" * 64
        receipt = {
            "schema_version": "dharma.a2a.send_receipt.v1",
            "packet_id": packet_id,
            "timestamp": "2026-06-19T00:00:00Z",
            "to": agent_uid,
            "route": "agent-inbox",
            "target_uid": agent_uid,
            "subject": f"dharma.agent.{agent_uid}.inbox",
            "ack_subject": f"dharma.agent.{agent_uid}.inbox.ack.{packet_id}",
            "reply_subject": f"dharma.agent.{agent_uid}.inbox.reply.{packet_id}",
            "file": str(row["packet_path"]),
            "sha256": packet_sha,
            "status": "PUBLISH_ACKED",
            "ack_tier": "PUBLISH_ACCEPTED",
            "semantic_task_packet": {
                "schema_version": a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
                "packet_id": packet_id,
                "agent_uid": agent_uid,
                "packet_path": str(row["packet_path"]),
                "packet_sha256": packet_sha,
                "task_hash": task_hash,
                "locked_spec_sha256": locked_spec,
            },
            "semantic_task_packet_path": str(row["packet_path"]),
            "semantic_task_packet_sha256": packet_sha,
            "task_hash": task_hash,
            "locked_spec_sha256": locked_spec,
        }
        _write_json(
            receipt_dir / f"20260619T000000Z-{agent_uid}-{packet_id}.json",
            receipt,
        )
    return receipt_dir


def _domain_reply_artifact_preflight_receipt(
    semantic_payload: dict[str, object],
    *,
    ready: bool = True,
) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    semantic_rows = semantic_payload["rows"]
    assert isinstance(semantic_rows, list)
    for row in semantic_rows:
        assert isinstance(row, dict)
        agent_uid = str(row["agent_uid"])
        packet_id = str(row["packet_id"])
        blockers: list[str] = []
        evidence_paths: list[str] = []
        if not ready and agent_uid == "hermes-m5":
            blockers = ["missing target-owned domain reply artifact"]
            evidence_paths = [
                "reports/a2a/model_reply_captures/hermes-m5-capture-failed.json"
            ]
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_domain_reply_artifact_preflight.READY_DOMAIN_REPLY_ARTIFACT
                if not blockers
                else a2a_domain_reply_artifact_preflight.BLOCKED_DOMAIN_REPLY_ARTIFACT,
                "blockers": blockers,
                "packet_id": packet_id,
                "task_hash": str(row["task_hash"]),
                "locked_spec_sha256": str(row["locked_spec_sha256"]),
                "send_receipt_path": f"reports/a2a/send_receipts/{agent_uid}-{packet_id}.json",
                "send_receipt_present": True,
                "expected_artifact_path": f"/tmp/outboxes/{agent_uid}/{packet_id}.json",
                "artifact_present": not blockers,
                "artifact_sha256": "0" * 64 if not blockers else "",
                "semantic_reply_claim": not blockers,
                "peer_model_processed_claim": not blockers,
                "latest_model_capture_receipt_path": evidence_paths[0]
                if evidence_paths
                else "",
                "latest_model_capture_status": "MODEL_COMMAND_FAILED"
                if evidence_paths
                else "",
                "latest_model_capture_blockers": ["model command exited 1"]
                if evidence_paths
                else [],
                "latest_model_capture_stdout_tail": "",
                "latest_model_capture_stderr_tail": "rate limit",
                "latest_model_capture_wrote_artifact": False
                if evidence_paths
                else None,
                "evidence_paths": evidence_paths,
            }
        )
    blockers = [f"{row['agent_uid']}: {blocker}" for row in rows for blocker in row["blockers"]]
    return {
        "schema_version": a2a_domain_reply_artifact_preflight.DOMAIN_REPLY_ARTIFACT_PREFLIGHT_SCHEMA,
        "passed": not blockers,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "rows": rows,
        "blockers": blockers,
    }


def _write_domain_reply_artifact_preflight_receipt(
    repo_root: Path,
    semantic_payload: dict[str, object],
    *,
    ready: bool = True,
) -> Path:
    return _write_json(
        repo_root / "reports/a2a/domain_reply_artifact_preflight/20260619T000000Z-a2a-domain-reply-artifact-preflight.json",
        _domain_reply_artifact_preflight_receipt(semantic_payload, ready=ready),
    )


def _domain_reply_request_receipt(semantic_payload: dict[str, object]) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    semantic_rows = semantic_payload["rows"]
    assert isinstance(semantic_rows, list)
    for row in semantic_rows:
        assert isinstance(row, dict)
        agent_uid = str(row["agent_uid"])
        packet_id = str(row["packet_id"])
        request_path = f"reports/a2a/domain_reply_requests/{agent_uid}-{packet_id}-domain-reply-request.md"
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_domain_reply_request.READY_DOMAIN_REPLY_REQUEST,
                "blockers": [],
                "packet_id": packet_id,
                "task_hash": str(row["task_hash"]),
                "locked_spec_sha256": str(row["locked_spec_sha256"]),
                "send_receipt_path": f"reports/a2a/send_receipts/{agent_uid}-{packet_id}.json",
                "reply_subject": f"dharma.agent.{agent_uid}.inbox.reply.{packet_id}",
                "expected_artifact_path": f"/tmp/outboxes/{agent_uid}/{packet_id}.json",
                "request_path": request_path,
                "request_sha256": "1" * 64,
                "target_owned_write_required": True,
                "evidence_paths": [request_path],
            }
        )
    return {
        "schema_version": a2a_domain_reply_request.DOMAIN_REPLY_REQUEST_SCHEMA,
        "passed": True,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "target_outbox_mutation_performed": False,
        "rows": rows,
        "blockers": [],
    }


def _write_domain_reply_request_receipt(repo_root: Path, semantic_payload: dict[str, object]) -> Path:
    return _write_json(
        repo_root / "reports/a2a/domain_reply_requests/20260619T000000Z-a2a-domain-reply-request.json",
        _domain_reply_request_receipt(semantic_payload),
    )


def _presence_preflight_receipt(*, ready: bool) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    now = datetime.now(UTC)
    expires_at = now + timedelta(minutes=30)
    for agent_uid in a2a_onboard.COUNTED_AGENT_UIDS:
        blockers: list[str] = []
        if not ready:
            blockers = ["missing presence projection"]
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_presence_preflight.READY_PRESENCE_PREVALIDATED
                if not blockers
                else "BLOCKED_PRESENCE",
                "blockers": blockers,
                "registry_entry_present": True,
                "principal": f"a2a_{agent_uid}",
                "aliases": [],
                "alias_collisions": [],
                "presence_projection_present": not blockers,
                "presence_source_path": f"presence/{agent_uid}.json" if not blockers else "",
                "missing_presence_fields": [],
                "stale_presence": bool(blockers),
                "expired_presence": bool(blockers),
                "presence_age_seconds": 0.0 if not blockers else None,
                "expires_at": expires_at.isoformat().replace("+00:00", "Z"),
                "inbox_subject": f"dharma.agent.{agent_uid}.inbox",
                "durable_consumer": f"a2a_{agent_uid}_inbox",
                "transport_state": "HANDLER_ACKED" if not blockers else "",
                "model_state": "SEMANTIC_SIGNED" if not blockers else "",
                "peer_model_processed_claim": True if not blockers else None,
                "evidence_paths": [],
                "operator_commands": {},
            }
        )
    blockers = [f"{row['agent_uid']}: {blocker}" for row in rows for blocker in row["blockers"]]
    return {
        "schema_version": a2a_presence_preflight.PRESENCE_PREFLIGHT_SCHEMA,
        "passed": not blockers,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "required_presence_fields": list(a2a_presence_preflight.REQUIRED_PRESENCE_FIELDS),
        "rows": rows,
        "blockers": blockers,
    }


def _write_presence_preflight_receipt(repo_root: Path, *, ready: bool = True) -> Path:
    return _write_json(
        repo_root / "reports/a2a/presence_preflight/20260619T000000Z-a2a-presence-preflight.json",
        _presence_preflight_receipt(ready=ready),
    )


def _write_identity_reconcile_receipt(repo_root: Path) -> Path:
    return _write_json(
        repo_root / "reports/a2a/identity_reconcile/20260619T000000Z-a2a-identity-reconcile.json",
        {
            "schema_version": a2a_identity_reconcile.IDENTITY_RECONCILE_SCHEMA,
            "passed": False,
            "proposed_changes": [
                {
                    "op": "remove_alias",
                    "agent_uid": "opus_composer",
                    "alias": "claude-opus",
                    "canonical_owner": "claude-opus",
                    "reason": "test fixture",
                }
            ],
            "rows": [],
        },
    )


def _write_standing_agent_preflight_receipt(repo_root: Path) -> Path:
    return _write_json(
        repo_root / "reports/a2a/standing_agent_preflight/20260619T000000Z-a2a-standing-agent-preflight.json",
        {
            "schema_version": a2a_standing_agent_preflight.STANDING_AGENT_PREFLIGHT_SCHEMA,
            "passed": False,
            "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
            "rows": [],
            "blockers": ["qwen_code: agent is session/evidence scoped"],
        },
    )


def _wake_loop_receipt(*, ready: bool) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for agent_uid in a2a_onboard.COUNTED_AGENT_UIDS:
        surfaces = {
            surface: {
                "present": ready,
                "evidence": f"synthetic {surface}",
            }
            for surface in a2a_wake_loop_preflight.REQUIRED_CONTRACT_SURFACES
        }
        blockers: list[str] = []
        evidence_paths: list[str] = []
        if not ready:
            surfaces["StandingWakeLoop"]["present"] = False
            surfaces["WakeLease"]["present"] = False
            surfaces["WakeCircuitBreaker"]["present"] = False
            evidence_paths = [
                f"reports/a2a/standing_wake_loop/{agent_uid}-attempt.json"
            ]
            blockers = [
                "BLOCKED_WAKE_LOOP",
                "missing StandingWakeLoop",
                "missing WakeLease",
                "missing WakeCircuitBreaker",
            ]
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_wake_loop_preflight.READY_WAKE_LOOP_PREVALIDATED
                if ready
                else "BLOCKED_WAKE_LOOP",
                "blockers": blockers,
                "session_scoped": False,
                "contract_surfaces": surfaces,
                "latest_standing_wake_loop_receipt_path": evidence_paths[0]
                if evidence_paths
                else "",
                "latest_standing_wake_loop_status": "BLOCKED_WAKE_LOOP"
                if evidence_paths
                else "",
                "latest_standing_wake_loop_blockers": ["BLOCKED_WAKE_LOOP"]
                if evidence_paths
                else [],
                "latest_standing_wake_loop_wrote_heartbeat": False
                if evidence_paths
                else None,
                "latest_standing_wake_loop_session_scoped": False
                if evidence_paths
                else None,
                "evidence_paths": evidence_paths,
            }
        )
    return {
        "schema_version": a2a_wake_loop_preflight.WAKE_LOOP_PREFLIGHT_SCHEMA,
        "passed": ready,
        "counted_agents": list(a2a_onboard.COUNTED_AGENT_UIDS),
        "required_contract_surfaces": list(a2a_wake_loop_preflight.REQUIRED_CONTRACT_SURFACES),
        "rows": rows,
        "blockers": [f"{row['agent_uid']}: {blocker}" for row in rows for blocker in row["blockers"]],
    }


def _live_ready_onboard_receipt() -> dict[str, object]:
    payload = _onboard_receipt(ready=True)
    for row in payload["rows"]:  # type: ignore[index]
        row["final_state"] = "READY_LIVE"
    return payload


def test_full_spec_readiness_fails_on_topology_and_agent_blockers(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=False),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _onboard_receipt(ready=False),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=False),
    )
    standing_path = _write_standing_agent_preflight_receipt(repo_root)
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    presence_path = _write_presence_preflight_receipt(repo_root, ready=False)
    identity_path = _write_identity_reconcile_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload, ready=False)
    domain_reply_request_path = _write_domain_reply_request_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        domain_reply_request_receipt_path=domain_reply_request_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert payload["full_spec_ready"] is False
    assert payload["readiness_score"] == 20
    assert any("canonical subject overlaps remain" in blocker for blocker in payload["blockers"])
    assert any("qwen_code: wake loop is blocked" in blocker for blocker in payload["blockers"])
    assert any("missing StandingWakeLoop" in blocker for blocker in payload["blockers"])
    assert any("missing current SEMANTIC_SIGNED" in blocker for blocker in payload["blockers"])
    assert any("cutover transaction plan missing rollback plan" in blocker for blocker in payload["blockers"])
    topology_component = next(component for component in payload["components"] if component["name"] == "live_topology")
    assert str(topology_path.relative_to(repo_root)) in topology_component["evidence_paths"]
    cutover_component = next(component for component in payload["components"] if component["name"] == "cutover_completion")
    assert str(topology_path.relative_to(repo_root)) in cutover_component["evidence_paths"]
    identity_component = next(component for component in payload["components"] if component["name"] == "identity_presence")
    assert str(identity_path.relative_to(repo_root)) in identity_component["evidence_paths"]
    wake_component = next(component for component in payload["components"] if component["name"] == "wake_loop_preflight")
    assert str(standing_path.relative_to(repo_root)) in wake_component["evidence_paths"]
    assert (
        "reports/a2a/standing_wake_loop/qwen_code-attempt.json"
        in wake_component["evidence_paths"]
    )
    domain_component = next(component for component in payload["components"] if component["name"] == "domain_reply_artifacts")
    assert str(domain_reply_request_path.relative_to(repo_root)) in domain_component["evidence_paths"]
    assert (
        "reports/a2a/model_reply_captures/hermes-m5-capture-failed.json"
        in domain_component["evidence_paths"]
    )
    assert domain_component["passed"] is False


def test_full_spec_readiness_passes_only_when_all_components_green(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _onboard_receipt(ready=True),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == 0
    assert payload["full_spec_ready"] is True
    assert payload["readiness_score"] == 100
    assert payload["blockers"] == []
    assert Path(repo_root / payload["receipt_path"]).is_file()


def test_full_spec_readiness_rejects_counted_denominator_drift(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard = _onboard_receipt(ready=True)
    onboard["counted_agents"] = ["codex_composer"]
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        onboard,
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert any("counted agent denominator mismatch" in blocker for blocker in payload["blockers"])


def test_full_spec_readiness_rejects_acl_denominator_drift(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _onboard_receipt(ready=True),
    )
    topology = _topology_acl_receipt(ready=True)
    topology["counted_agents"] = ["codex_composer"]
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        topology,
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert any("ACL counted agent denominator mismatch" in blocker for blocker in payload["blockers"])


def test_full_spec_readiness_rejects_semantic_task_packet_hash_mismatch(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _onboard_receipt(ready=True),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=False)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert payload["readiness_score"] == 95
    assert any("semantic task packet hash mismatch" in blocker for blocker in payload["blockers"])


def test_full_spec_readiness_rejects_semantic_send_receipt_hash_mismatch(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _onboard_receipt(ready=True),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload, ready=False)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert payload["readiness_score"] == 95
    assert any("semantic send receipt task_hash mismatch" in blocker for blocker in payload["blockers"])


def test_full_spec_readiness_live_mode_requires_live_acl_probe_evidence(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _live_ready_onboard_receipt(),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="live",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert any("missing live ACL probe receipt" in blocker for blocker in payload["blockers"])


def test_full_spec_readiness_live_mode_rejects_failed_live_acl_probe_evidence(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _live_ready_onboard_receipt(),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    live_acl_path = _write_json(
        repo_root / "reports/a2a/live_acl/20260619T000000Z-a2a-live-acl-probe.json",
        _live_acl_receipt(passed=False),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="live",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        live_acl_receipt_path=live_acl_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == readiness.EXIT_NOT_READY
    assert any("live ACL probe failure" in blocker for blocker in payload["blockers"])


def test_full_spec_readiness_live_mode_accepts_live_acl_probe_evidence(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _live_ready_onboard_receipt(),
    )
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        _topology_acl_receipt(ready=True),
    )
    live_acl_path = _write_json(
        repo_root / "reports/a2a/live_acl/20260619T000000Z-a2a-live-acl-probe.json",
        _live_acl_receipt(passed=True),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _wake_loop_receipt(ready=True),
    )
    semantic_payload = _semantic_task_packet_receipt(repo_root, ready=True)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    presence_path = _write_presence_preflight_receipt(repo_root)
    domain_reply_path = _write_domain_reply_artifact_preflight_receipt(repo_root, semantic_payload)

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="seed",
        broker="agni",
        mode="live",
        a2a_bus_root=tmp_path / "a2a_bus",
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        live_acl_receipt_path=live_acl_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == 0
    assert payload["full_spec_ready"] is True


def _dynamic_semantic_task_packet_receipt(
    repo_root: Path,
    agent_uids: tuple[str, ...],
) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for agent_uid in agent_uids:
        packet_path = repo_root / f"reports/a2a/semantic_tasks/{agent_uid}-packet.md"
        packet_path.parent.mkdir(parents=True, exist_ok=True)
        body = "\n".join(
            [
                a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
                a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
                a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
                a2a_onboard.LOCKED_SPEC_SHA256,
                "failure_digest",
                f"Target agent: `{agent_uid}`",
                "",
            ]
        )
        packet_path.write_text(body, encoding="utf-8")
        packet_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
        rows.append(
            {
                "agent_uid": agent_uid,
                "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
                "packet_id": f"packet-{agent_uid}",
                "packet_path": f"reports/a2a/semantic_tasks/{agent_uid}-packet.md",
                "packet_sha256": packet_sha,
                "task_hash": f"sha256:{packet_sha}",
                "required_reply_artifact_schema": a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
                "required_semantic_receipt_schema": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
                "required_failure_digest_prompt": a2a_semantic_task_packet.REQUIRED_FAILURE_DIGEST_PROMPT,
            }
        )
    return {
        "schema_version": a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
        "locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
        "counted_agents": list(agent_uids),
        "rows": rows,
    }


def _dynamic_onboard_receipt(agent_uids: tuple[str, ...], *, passing_agent: str) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for agent_uid in agent_uids:
        ready = agent_uid == passing_agent
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": "READY_PREVALIDATED" if ready else "BLOCKED_DOMAIN_RECEIPT",
                "failure_states": [] if ready else ["BLOCKED_DOMAIN_RECEIPT"],
                "domain_receipt_state": a2a_onboard.DOMAIN_RECEIPTED if ready else "REQUIRED_NOT_BUILT",
                "semantic_receipt_state": a2a_onboard.SEMANTIC_SIGNED if ready else "REQUIRED_NOT_BUILT",
                "handler_ack_state": "HANDLER_ACKED" if ready else "NO_HANDLER_ACK",
                "last_domain_receipt": f"reports/a2a/reply_receipts/{agent_uid}.json" if ready else "",
                "last_semantic_receipt": f"reports/a2a/semantic_receipts/{agent_uid}.json" if ready else "",
            }
        )
    return {
        "schema_version": a2a_onboard.ONBOARD_RECEIPT_SCHEMA,
        "counted_agents": list(agent_uids),
        "rows": rows,
    }


def _dynamic_presence_receipt(agent_uids: tuple[str, ...], *, passing_agent: str) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    now = datetime.now(UTC)
    expires_at = now + timedelta(minutes=30)
    for agent_uid in agent_uids:
        ready = agent_uid == passing_agent
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_presence_preflight.READY_PRESENCE_PREVALIDATED
                if ready
                else "BLOCKED_PRESENCE",
                "blockers": [] if ready else ["missing presence projection"],
                "registry_entry_present": True,
                "principal": f"a2a_{agent_uid}",
                "aliases": [],
                "alias_collisions": [],
                "presence_projection_present": ready,
                "presence_source_path": f"presence/{agent_uid}.json" if ready else "",
                "missing_presence_fields": [],
                "stale_presence": not ready,
                "expired_presence": not ready,
                "presence_age_seconds": 0.0 if ready else None,
                "expires_at": expires_at.isoformat().replace("+00:00", "Z"),
                "inbox_subject": f"dharma.agent.{agent_uid}.inbox",
                "durable_consumer": f"a2a_{agent_uid}_inbox",
                "transport_state": "HANDLER_ACKED" if ready else "",
                "model_state": "SEMANTIC_SIGNED" if ready else "",
                "peer_model_processed_claim": True if ready else None,
                "evidence_paths": [],
                "operator_commands": {},
            }
        )
    return {
        "schema_version": a2a_presence_preflight.PRESENCE_PREFLIGHT_SCHEMA,
        "passed": False,
        "counted_agents": list(agent_uids),
        "required_presence_fields": list(a2a_presence_preflight.REQUIRED_PRESENCE_FIELDS),
        "rows": rows,
        "blockers": [f"{row['agent_uid']}: {blocker}" for row in rows for blocker in row["blockers"]],
    }


def _dynamic_domain_reply_artifact_receipt(
    semantic_payload: dict[str, object],
    *,
    passing_agent: str,
) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    semantic_rows = semantic_payload["rows"]
    assert isinstance(semantic_rows, list)
    for row in semantic_rows:
        assert isinstance(row, dict)
        agent_uid = str(row["agent_uid"])
        ready = agent_uid == passing_agent
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_domain_reply_artifact_preflight.READY_DOMAIN_REPLY_ARTIFACT
                if ready
                else a2a_domain_reply_artifact_preflight.BLOCKED_DOMAIN_REPLY_ARTIFACT,
                "blockers": [] if ready else ["missing target-owned domain reply artifact"],
                "packet_id": str(row["packet_id"]),
                "task_hash": str(row["task_hash"]),
                "locked_spec_sha256": str(row["locked_spec_sha256"]),
                "send_receipt_path": f"reports/a2a/send_receipts/{agent_uid}-{row['packet_id']}.json",
                "send_receipt_present": True,
                "expected_artifact_path": f"/tmp/outboxes/{agent_uid}/{row['packet_id']}.json",
                "artifact_present": ready,
                "artifact_sha256": "0" * 64 if ready else "",
                "semantic_reply_claim": ready,
                "peer_model_processed_claim": ready,
                "latest_model_capture_receipt_path": "",
                "latest_model_capture_status": "",
                "latest_model_capture_blockers": [],
                "latest_model_capture_stdout_tail": "",
                "latest_model_capture_stderr_tail": "",
                "latest_model_capture_wrote_artifact": None,
                "evidence_paths": [],
            }
        )
    return {
        "schema_version": a2a_domain_reply_artifact_preflight.DOMAIN_REPLY_ARTIFACT_PREFLIGHT_SCHEMA,
        "passed": False,
        "counted_agents": list(semantic_payload["counted_agents"]),
        "rows": rows,
        "blockers": [f"{row['agent_uid']}: {blocker}" for row in rows for blocker in row["blockers"]],
    }


def _dynamic_wake_loop_receipt(agent_uids: tuple[str, ...], *, passing_agent: str) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for agent_uid in agent_uids:
        ready = agent_uid == passing_agent
        surfaces = {
            surface: {"present": ready, "evidence": f"synthetic {surface}"}
            for surface in a2a_wake_loop_preflight.REQUIRED_CONTRACT_SURFACES
        }
        rows.append(
            {
                "agent_uid": agent_uid,
                "final_state": a2a_wake_loop_preflight.READY_WAKE_LOOP_PREVALIDATED
                if ready
                else "BLOCKED_WAKE_LOOP",
                "blockers": [] if ready else ["missing StandingWakeLoop"],
                "session_scoped": False,
                "contract_surfaces": surfaces,
                "evidence_paths": [],
            }
        )
    return {
        "schema_version": a2a_wake_loop_preflight.WAKE_LOOP_PREFLIGHT_SCHEMA,
        "passed": False,
        "counted_agents": list(agent_uids),
        "required_contract_surfaces": list(a2a_wake_loop_preflight.REQUIRED_CONTRACT_SURFACES),
        "rows": rows,
        "blockers": [f"{row['agent_uid']}: {blocker}" for row in rows for blocker in row["blockers"]],
    }


def test_full_spec_readiness_capability_quorum_ignores_unavailable_substitutes(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    a2a_bus_root = tmp_path / "a2a_bus"
    _write_json(
        a2a_bus_root / "agents.json",
        {
            "agents": {
                "alt_code_worker": {
                    "type": "codex-cli",
                    "provider": "openai",
                    "capabilities": ["code_review"],
                },
                "claude_code_now": {
                    "type": "claude-code",
                    "provider": "anthropic",
                    "capabilities": ["code_review"],
                },
                "devin_rate_limited": {
                    "type": "devin",
                    "capabilities": ["code_review"],
                    "quota_state": "rate_limited",
                },
            }
        },
    )
    agent_uids = ("alt_code_worker", "claude_code_now")
    passing_agent = "alt_code_worker"
    live_path = _write_json(
        repo_root / "reports/a2a/live_topology/20260619T000000Z-a2a-live-topology-probe.json",
        _topology_receipt(passed=True),
    )
    specs = [spec.to_dict() for spec in acl_probe_specs(agent_uids)]
    topology_path = _write_json(
        repo_root / "reports/a2a/topology/20260619T000000Z-a2a-jetstream-topology.json",
        {
            "schema_version": "dharma.a2a.jetstream_topology_verifier.v1",
            "passed": True,
            "counted_agents": list(agent_uids),
            "acl_probe_specs": specs,
            "acl_probe_verification": {
                "passed": True,
                "failures": [],
                "checked_principals": [spec["principal"] for spec in specs],
            },
        },
    )
    semantic_payload = _dynamic_semantic_task_packet_receipt(repo_root, agent_uids)
    semantic_packet_path = _write_json(
        repo_root / "reports/a2a/semantic_task_packets/20260619T000000Z-a2a-semantic-task-packet.json",
        semantic_payload,
    )
    _write_semantic_send_receipts(repo_root, semantic_payload)
    onboard_path = _write_json(
        repo_root / "reports/a2a/onboard_receipts/20260619T000000Z-a2a-onboard.json",
        _dynamic_onboard_receipt(agent_uids, passing_agent=passing_agent),
    )
    presence_path = _write_json(
        repo_root / "reports/a2a/presence_preflight/20260619T000000Z-a2a-presence-preflight.json",
        _dynamic_presence_receipt(agent_uids, passing_agent=passing_agent),
    )
    domain_reply_path = _write_json(
        repo_root / "reports/a2a/domain_reply_artifact_preflight/20260619T000000Z-a2a-domain-reply-artifact-preflight.json",
        _dynamic_domain_reply_artifact_receipt(semantic_payload, passing_agent=passing_agent),
    )
    wake_loop_path = _write_json(
        repo_root / "reports/a2a/wake_loop_preflight/20260619T000000Z-a2a-wake-loop-preflight.json",
        _dynamic_wake_loop_receipt(agent_uids, passing_agent=passing_agent),
    )

    payload, exit_code = readiness.run_readiness(
        repo_root=repo_root,
        receipt_dir=repo_root / "reports/a2a/full_spec_readiness",
        agent="capability:code_review",
        min_agents=1,
        broker="agni",
        mode="prevalidate",
        a2a_bus_root=a2a_bus_root,
        context="agni-wss",
        run_onboard=False,
        run_live_probe=False,
        onboard_receipt_path=onboard_path,
        live_topology_receipt_path=live_path,
        topology_receipt_path=topology_path,
        semantic_task_packet_receipt_path=semantic_packet_path,
        presence_receipt_path=presence_path,
        domain_reply_artifact_receipt_path=domain_reply_path,
        wake_loop_receipt_path=wake_loop_path,
    )

    assert exit_code == 0
    assert payload["full_spec_ready"] is True
    assert payload["readiness_score"] == 100
    assert payload["cohort_selection"]["agent_uids"] == list(agent_uids)
    assert payload["cohort_selection"]["required_agent_count"] == 1
    assert "devin_rate_limited" in payload["cohort_selection"]["excluded_agent_uids"]
    onboard_component = next(
        component for component in payload["components"] if component["name"] == "counted_agent_readiness"
    )
    assert onboard_component["details"]["passed_agents"] == [passing_agent]
    assert onboard_component["details"]["failed_agents"] == ["claude_code_now"]
