from __future__ import annotations

from pathlib import Path

from dharma_swarm.a2a import jetstream_topology as topo
from scripts.governance import a2a_live_topology_probe as live_probe


def _legacy_streams() -> tuple[topo.LiveStreamObservation, ...]:
    return (
        topo.LiveStreamObservation(
            name="DHARMA_A2A",
            subjects=("dharma.a2a.>",),
            active_subjects=("dharma.a2a.devin",),
        ),
    )


def _migration_plan() -> topo.TopologyMigrationPlan:
    return topo.plan_live_topology_migration(
        streams=_legacy_streams(),
        kv_buckets=(),
        context="agni-wss",
    )


def test_cutover_topology_requires_explicit_approval(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.delenv(live_probe.CUTOVER_TOPOLOGY_ENV, raising=False)

    results = live_probe._run_cutover_topology(
        context="agni-wss",
        receipt_dir=tmp_path,
        migration_plan=_migration_plan(),
        timeout_s=5,
        dry_run=False,
    )

    assert results[0]["passed"] is False
    assert results[0]["returncode"] == 17
    assert live_probe.CUTOVER_TOPOLOGY_ENV in results[0]["stderr"]


def test_cutover_topology_dry_run_uses_stream_edit_dry_run(
    tmp_path: Path, monkeypatch
) -> None:
    seen: list[str] = []

    def fake_run(command: str, *, timeout_s: int) -> dict[str, object]:
        seen.append(command)
        return {
            "command": command,
            "returncode": 0,
            "stdout": "",
            "stderr": "",
            "passed": True,
        }

    monkeypatch.setattr(live_probe, "_run_plan_step", fake_run)

    results = live_probe._run_cutover_topology(
        context="agni-wss",
        receipt_dir=tmp_path,
        migration_plan=_migration_plan(),
        timeout_s=5,
        dry_run=True,
    )

    assert results[0]["passed"] is True
    assert "--dry-run" in seen[0]
    assert "--context 'agni-wss'" in seen[0]
    assert "stream edit DHARMA_A2A" in seen[0]


def test_cutover_topology_dry_run_accepts_stream_edit_diff_exit(
    tmp_path: Path, monkeypatch
) -> None:
    def fake_run(command: str, *, timeout_s: int) -> dict[str, object]:
        return {
            "command": command,
            "returncode": 1,
            "stdout": "Differences (-old +new)\n- Subjects: dharma.a2a.>",
            "stderr": "",
            "passed": False,
        }

    monkeypatch.setattr(live_probe, "_run_plan_step", fake_run)

    results = live_probe._run_cutover_topology(
        context="agni-wss",
        receipt_dir=tmp_path,
        migration_plan=_migration_plan(),
        timeout_s=5,
        dry_run=True,
    )

    assert results[0]["passed"] is True
    assert results[0]["returncode"] == 1
    assert results[0]["effective_returncode"] == 0
    assert results[0]["dry_run_diff_detected"] is True


def test_cutover_rollback_plan_restores_pre_cutover_subjects() -> None:
    rollback_plan = live_probe._cutover_rollback_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        migration_plan=_migration_plan(),
    )

    rollback = rollback_plan["cutover_DHARMA_A2A"]
    assert rollback["available"] is True
    assert rollback["original_subjects"] == ["dharma.a2a.>"]
    assert "stream edit DHARMA_A2A" in rollback["command"]
    assert "--subjects 'dharma.a2a.>'" in rollback["command"]
    assert "agni-wss" in rollback["command"]


def test_cutover_result_includes_rollback_plan(tmp_path: Path, monkeypatch) -> None:
    def fake_run(command: str, *, timeout_s: int) -> dict[str, object]:
        return {
            "command": command,
            "returncode": 0,
            "stdout": "",
            "stderr": "",
            "passed": True,
        }

    monkeypatch.setattr(live_probe, "_run_plan_step", fake_run)
    rollback_plan = live_probe._cutover_rollback_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        migration_plan=_migration_plan(),
    )

    results = live_probe._run_cutover_topology(
        context="agni-wss",
        receipt_dir=tmp_path,
        migration_plan=_migration_plan(),
        cutover_rollback_plan=rollback_plan,
        timeout_s=5,
        dry_run=True,
    )

    assert results[0]["passed"] is True
    assert results[0]["rollback"]["available"] is True
    assert "--subjects 'dharma.a2a.>'" in results[0]["rollback"]["command"]


def test_cutover_transaction_plan_simulates_unblocked_followup_steps() -> None:
    migration_plan = _migration_plan()
    rollback_plan = live_probe._cutover_rollback_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        migration_plan=migration_plan,
    )

    transaction_plan = live_probe._cutover_transaction_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        kv_buckets=(),
        consumers=(),
        migration_plan=migration_plan,
        rollback_plan=rollback_plan,
    )

    post_step_ids = {
        step["step_id"]
        for step in transaction_plan["post_cutover_steps_after_legacy_cutover"]
    }
    assert "add_A2A_TASKS" in post_step_ids
    assert "add_A2A_RECEIPTS" in post_step_ids
    assert "add_consumer_a2a_task_claimant" in post_step_ids
    assert "add_consumer_a2a_task_closer" in post_step_ids
    assert "add_consumer_a2a_receipt_indexer" in post_step_ids
    assert transaction_plan["rollback_plan"]["cutover_DHARMA_A2A"]["available"] is True
    assert live_probe.CUTOVER_TOPOLOGY_ENV in transaction_plan["mutation_gate"]


def test_cutover_transaction_plan_previews_exact_consumer_config() -> None:
    migration_plan = _migration_plan()
    rollback_plan = live_probe._cutover_rollback_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        migration_plan=migration_plan,
    )

    transaction_plan = live_probe._cutover_transaction_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        kv_buckets=(),
        consumers=(),
        migration_plan=migration_plan,
        rollback_plan=rollback_plan,
    )
    steps = {
        step["step_id"]: step
        for step in transaction_plan["post_cutover_steps_after_legacy_cutover"]
    }
    receipt_indexer = steps["add_consumer_a2a_receipt_indexer"]

    assert receipt_indexer["execution_uses_exact_config"] is True
    assert "--backoff linear" in receipt_indexer["planner_command"]
    assert "--backoff linear" not in receipt_indexer["execution_command_template"]
    assert receipt_indexer["desired_consumer_config"]["backoff"] == [
        5_000_000_000,
        30_000_000_000,
        120_000_000_000,
        600_000_000_000,
    ]


def test_cutover_transaction_plan_includes_reverse_compensation_plan() -> None:
    migration_plan = _migration_plan()
    rollback_plan = live_probe._cutover_rollback_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        migration_plan=migration_plan,
    )

    transaction_plan = live_probe._cutover_transaction_plan(
        context="agni-wss",
        streams=_legacy_streams(),
        kv_buckets=(),
        consumers=(),
        migration_plan=migration_plan,
        rollback_plan=rollback_plan,
    )
    compensation_by_step = {
        item["step_id"]: item
        for item in transaction_plan["post_cutover_compensation_plan"]
    }

    receipt_indexer = compensation_by_step["add_consumer_a2a_receipt_indexer"]
    assert receipt_indexer["available"] is True
    assert receipt_indexer["kind"] == "consumer"
    assert receipt_indexer["order_basis"] == "reverse_post_cutover_order"
    assert "consumer rm A2A_RECEIPTS a2a_receipt_indexer --force" in receipt_indexer["command"]
    assert receipt_indexer["execution"] == "explicit_operator_action"

    tasks_stream = compensation_by_step["add_A2A_TASKS"]
    assert tasks_stream["available"] is True
    assert tasks_stream["kind"] == "stream"
    assert "stream rm A2A_TASKS --force" in tasks_stream["command"]


def test_cutover_followup_preview_includes_compensation_command() -> None:
    step = topo.TopologyMigrationStep(
        step_id="add_consumer_a2a_task_claimant",
        phase="cutover",
        action="add durable consumer a2a_task_claimant",
        command="nats --context 'agni-wss' consumer add A2A_TASKS a2a_task_claimant --defaults",
        mutates=True,
        requires_approval=True,
        blocked=False,
    )

    preview = live_probe._cutover_followup_step_preview(context="agni-wss", step=step)

    assert preview["compensation"]["available"] is True
    assert preview["compensation"]["resource"] == "A2A_TASKS/a2a_task_claimant"
    assert "consumer rm A2A_TASKS a2a_task_claimant --force" in preview["compensation"]["command"]


def test_subjects_from_step_command_handles_quoted_subjects() -> None:
    step = topo.TopologyMigrationStep(
        step_id="cutover_DHARMA_A2A",
        phase="cutover",
        action="narrow legacy stream",
        command=(
            "nats --context 'agni-wss' stream edit DHARMA_A2A "
            "--subjects 'dharma.a2a.devin' --subjects 'dharma.a2a.hermes' --force"
        ),
        mutates=True,
        requires_approval=True,
        blocked=False,
    )

    assert live_probe._subjects_from_step_command(step) == (
        "dharma.a2a.devin",
        "dharma.a2a.hermes",
    )


def test_cutover_consumer_followup_uses_exact_config(tmp_path: Path) -> None:
    step = topo.TopologyMigrationStep(
        step_id="add_consumer_a2a_receipt_indexer",
        phase="cutover",
        action="add durable consumer a2a_receipt_indexer",
        command="nats --context 'agni-wss' consumer add A2A_RECEIPTS a2a_receipt_indexer --defaults",
        mutates=True,
        requires_approval=True,
        blocked=False,
    )

    command, config_path = live_probe._cutover_followup_consumer_command(
        context="agni-wss",
        receipt_dir=tmp_path,
        step=step,
    )

    assert "--config" in command
    assert "--backoff linear" not in command
    assert Path(config_path).is_file()
    assert "a2a_receipt_indexer" in Path(config_path).read_text(encoding="utf-8")


def test_cutover_followup_result_includes_compensation(
    tmp_path: Path, monkeypatch
) -> None:
    def fake_run(command: str, *, timeout_s: int) -> dict[str, object]:
        return {
            "command": command,
            "returncode": 0,
            "stdout": "",
            "stderr": "",
            "passed": True,
        }

    monkeypatch.setattr(live_probe, "_run_plan_step", fake_run)
    step = topo.TopologyMigrationStep(
        step_id="add_consumer_a2a_receipt_indexer",
        phase="cutover",
        action="add durable consumer a2a_receipt_indexer",
        command="nats --context 'agni-wss' consumer add A2A_RECEIPTS a2a_receipt_indexer --defaults",
        mutates=True,
        requires_approval=True,
        blocked=False,
    )

    result = live_probe._run_cutover_step(
        context="agni-wss",
        receipt_dir=tmp_path,
        step=step,
        timeout_s=5,
        dry_run=True,
    )

    assert result["passed"] is True
    assert result["compensation"]["available"] is True
    assert "consumer rm A2A_RECEIPTS a2a_receipt_indexer --force" in result["compensation"]["command"]
