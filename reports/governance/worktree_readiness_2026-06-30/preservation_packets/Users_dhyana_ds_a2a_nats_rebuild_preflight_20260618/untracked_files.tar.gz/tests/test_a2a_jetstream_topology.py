from __future__ import annotations

import pytest

from dharma_swarm.a2a import jetstream_topology as topo


def test_canonical_topology_declares_required_streams_and_aliases() -> None:
    plan = topo.canonical_topology_plan()

    streams = {stream.name: stream for stream in plan.streams}
    assert set(streams) == {topo.A2A_INBOX, topo.A2A_TASKS, topo.A2A_RECEIPTS, topo.A2A_DLQ}
    assert all(stream.duplicate_window_s == 600 for stream in streams.values())
    assert streams[topo.A2A_TASKS].subjects == ("dharma.a2a.task.>",)
    assert streams[topo.A2A_DLQ].subjects == ("dharma.dlq.>",)
    assert plan.migration_aliases["DHARMA_A2A"] == topo.A2A_TASKS
    assert plan.migration_aliases["DHARMA_FLEET"] == topo.A2A_RECEIPTS
    assert plan.presence_bucket == topo.PRESENCE_BUCKET


def test_canonical_topology_has_one_durable_inbox_consumer_per_counted_agent() -> None:
    plan = topo.canonical_topology_plan()
    consumers = {consumer.durable: consumer for consumer in plan.consumers}

    for agent_uid in topo.COUNTED_AGENT_UIDS:
        durable = f"a2a_{topo.safe_durable_token(agent_uid)}_inbox"
        consumer = consumers[durable]
        assert consumer.stream == topo.A2A_INBOX
        assert consumer.filter_subject == f"dharma.agent.{agent_uid}.inbox"
        assert consumer.max_deliver == 5
        assert consumer.max_ack_pending == 20
        assert consumer.deliver_policy == "new"


def test_acl_probe_specs_cover_positive_and_negative_permissions_per_agent() -> None:
    specs = topo.acl_probe_specs()
    by_agent = {spec.agent_uid: spec for spec in specs}

    assert set(by_agent) == set(topo.COUNTED_AGENT_UIDS)
    for agent_uid, spec in by_agent.items():
        assert spec.principal == topo.principal_for_agent(agent_uid)
        assert spec.principal.startswith("a2a_")
        assert f"dharma.presence.{agent_uid}" in spec.allow_publish
        assert f"dharma.a2a.receipt.{agent_uid}" in spec.allow_publish
        assert f"dharma.agent.{agent_uid}.inbox" in spec.allow_subscribe
        assert f"A2A_INBOX/a2a_{topo.safe_durable_token(agent_uid)}_inbox" in spec.allow_jetstream_pull
        assert "dharma.agent.*.inbox.>" in spec.deny_subjects
        assert "dharma.a2a.>" in spec.deny_subjects
        assert "$JS.API.STREAM.>" in spec.deny_subjects
        assert "publish_own_presence" in spec.positive_probes
        assert "pull_own_inbox_consumer" in spec.positive_probes
        assert "deny_pull_other_agent_inbox" in spec.negative_probes
        assert "deny_insecure_tls_on_agni" in spec.negative_probes


def test_acl_probe_verifier_rejects_missing_negative_probe() -> None:
    spec = topo.acl_probe_specs(("codex_composer",))[0]
    broken = topo.AclProbeSpec(
        agent_uid=spec.agent_uid,
        principal=spec.principal,
        allow_publish=spec.allow_publish,
        allow_subscribe=spec.allow_subscribe,
        allow_jetstream_pull=spec.allow_jetstream_pull,
        deny_subjects=tuple(item for item in spec.deny_subjects if item != "dharma.a2a.>"),
        deny_operations=spec.deny_operations,
        positive_probes=spec.positive_probes,
        negative_probes=spec.negative_probes,
    )

    result = topo.verify_acl_probe_specs((broken,), counted_agent_uids=("codex_composer",))

    assert result.passed is False
    assert any("broad fleet subjects" in failure for failure in result.failures)


def test_live_topology_verifier_flags_legacy_stream_overlap() -> None:
    result = topo.verify_live_topology_observation(
        streams=(
            topo.LiveStreamObservation(name="DHARMA_A2A", subjects=("dharma.a2a.>",)),
            topo.LiveStreamObservation(name=topo.A2A_INBOX, subjects=("dharma.agent.*.inbox",)),
        ),
        kv_buckets=(),
    )

    assert result.passed is False
    assert topo.A2A_TASKS in result.missing_streams
    assert "DHARMA_A2A" in result.legacy_streams
    assert any("overlaps canonical dharma.a2a.task.>" in item for item in result.overlapping_subjects)
    assert "missing live KV bucket: PRESENCE" in result.failures


def test_live_topology_verifier_accepts_canonical_streams_and_presence_bucket() -> None:
    plan = topo.canonical_topology_plan()
    result = topo.verify_live_topology_observation(
        streams=(
            topo.LiveStreamObservation(name=stream.name, subjects=stream.subjects)
            for stream in plan.streams
        ),
        kv_buckets=(topo.PRESENCE_BUCKET,),
        consumers=(
            topo.LiveConsumerObservation(
                stream=consumer.stream,
                durable=consumer.durable,
                filter_subject=consumer.filter_subject,
                ack_policy=consumer.ack_policy,
                deliver_policy=consumer.deliver_policy,
                ack_wait_ns=consumer.ack_wait_s * 1_000_000_000,
                max_deliver=consumer.max_deliver,
                backoff_ns=tuple(value * 1_000_000_000 for value in consumer.backoff_s),
                max_ack_pending=consumer.max_ack_pending,
            )
            for consumer in plan.consumers
        ),
        plan=plan,
    )

    assert result.passed is True
    assert result.failures == ()
    assert result.missing_streams == ()
    assert result.missing_consumers == ()
    assert result.drifted_consumers == ()


def test_live_topology_verifier_flags_exact_consumer_backoff_drift() -> None:
    plan = topo.canonical_topology_plan(("codex_composer",))
    consumer = plan.consumers[0]
    observed = topo.LiveConsumerObservation(
        stream=consumer.stream,
        durable=consumer.durable,
        filter_subject=consumer.filter_subject,
        ack_policy=consumer.ack_policy,
        deliver_policy=consumer.deliver_policy,
        ack_wait_ns=5_000_000_000,
        max_deliver=consumer.max_deliver,
        backoff_ns=(
            5_000_000_000,
            153_750_000_000,
            302_500_000_000,
            451_250_000_000,
        ),
        max_ack_pending=consumer.max_ack_pending,
    )

    result = topo.verify_live_topology_observation(
        streams=(
            topo.LiveStreamObservation(name=stream.name, subjects=stream.subjects)
            for stream in plan.streams
        ),
        kv_buckets=(topo.PRESENCE_BUCKET,),
        consumers=(observed,),
        plan=plan,
    )

    assert result.passed is False
    assert any("backoff_ns" in drift for drift in result.drifted_consumers)
    assert any("live canonical consumer config drift" in failure for failure in result.failures)


def test_live_topology_migration_plan_separates_additive_and_cutover_steps() -> None:
    plan = topo.plan_live_topology_migration(
        streams=(
            topo.LiveStreamObservation(
                name="DHARMA_A2A",
                subjects=("dharma.a2a.>",),
                active_subjects=("dharma.a2a.fleet", "dharma.a2a.devin"),
            ),
            topo.LiveStreamObservation(name="DHARMA_TEST", subjects=("dharma.test.>",)),
        ),
        kv_buckets=(),
        context="agni-wss",
    )
    steps = {step.step_id: step for step in plan.steps}

    assert plan.can_apply_additive is True
    assert plan.can_apply_cutover is False
    assert steps["add_A2A_INBOX"].phase == "additive"
    assert steps["add_A2A_DLQ"].phase == "additive"
    assert steps["add_kv_PRESENCE"].phase == "additive"
    assert steps["blocked_add_A2A_TASKS"].blocked is True
    assert steps["blocked_add_A2A_RECEIPTS"].blocked is True
    assert steps["cutover_DHARMA_A2A"].requires_approval is True
    assert "--subjects 'dharma.a2a.devin'" in steps["cutover_DHARMA_A2A"].command
    assert "--context 'agni-wss'" in steps["add_A2A_INBOX"].command


def test_live_topology_cutover_preserves_dormant_legacy_consumer_filters() -> None:
    plan = topo.plan_live_topology_migration(
        streams=(
            topo.LiveStreamObservation(
                name="DHARMA_A2A",
                subjects=("dharma.a2a.>",),
                active_subjects=("dharma.a2a.devin",),
            ),
        ),
        kv_buckets=(),
        consumers=(
            topo.LiveConsumerObservation(
                stream="DHARMA_A2A",
                durable="hermes_inbox",
                filter_subject="dharma.a2a.hermes",
            ),
            topo.LiveConsumerObservation(
                stream="DHARMA_A2A",
                durable="task_claim_legacy",
                filter_subject="dharma.a2a.task.claim",
            ),
        ),
        context="agni-wss",
    )
    step = {step.step_id: step for step in plan.steps}["cutover_DHARMA_A2A"]

    assert "--subjects 'dharma.a2a.devin'" in step.command
    assert "--subjects 'dharma.a2a.hermes'" in step.command
    assert "dharma.a2a.task.claim" not in step.command


def test_live_topology_migration_plan_skips_existing_consumers() -> None:
    plan = topo.plan_live_topology_migration(
        streams=(
            topo.LiveStreamObservation(name=topo.A2A_INBOX, subjects=("dharma.agent.*.inbox",)),
        ),
        kv_buckets=(),
        consumers=(
            topo.LiveConsumerObservation(
                stream=topo.A2A_INBOX,
                durable="a2a_codex_composer_inbox",
            ),
        ),
    )

    assert "add_consumer_a2a_codex_composer_inbox" not in {step.step_id for step in plan.steps}


def test_rendered_nats_cli_commands_quote_wildcard_subjects_and_use_cli_flags() -> None:
    commands = topo.render_nats_cli_commands()

    assert any("--subjects 'dharma.agent.*.inbox'" in command for command in commands)
    assert any("--retention work " in command for command in commands)
    assert any("--wait 5s" in command for command in commands)
    assert all("--ack-wait" not in command for command in commands)
    assert all("--max-ack-pending" not in command for command in commands)


def test_rendered_nats_consumer_configs_preserve_exact_backoff() -> None:
    configs = topo.render_nats_consumer_configs(topo.canonical_topology_plan(("codex_composer",)))
    config = configs["A2A_INBOX/a2a_codex_composer_inbox"]

    assert config["ack_wait"] == 5_000_000_000
    assert config["backoff"] == [
        5_000_000_000,
        30_000_000_000,
        120_000_000_000,
        600_000_000_000,
    ]
    assert config["durable_name"] == "a2a_codex_composer_inbox"


def test_topology_verifier_rejects_unbounded_max_deliver() -> None:
    plan = topo.canonical_topology_plan()
    broken = topo.with_replaced_consumer(plan, "a2a_codex_composer_inbox", max_deliver=-1)

    result = topo.verify_topology_plan(broken)

    assert result.passed is False
    assert any("unbounded MaxDeliver" in failure for failure in result.failures)


def test_topology_verifier_rejects_backoff_count_at_or_above_max_deliver() -> None:
    plan = topo.canonical_topology_plan()
    broken = topo.with_replaced_consumer(
        plan,
        "a2a_codex_composer_inbox",
        max_deliver=3,
        backoff_s=(5, 30, 120),
    )

    result = topo.verify_topology_plan(broken)

    assert result.passed is False
    assert any("backoff count" in failure for failure in result.failures)


def test_topology_verifier_requires_ack_wait_to_match_first_backoff() -> None:
    plan = topo.canonical_topology_plan()
    broken = topo.with_replaced_consumer(plan, "a2a_codex_composer_inbox", ack_wait_s=30)

    result = topo.verify_topology_plan(broken)

    assert result.passed is False
    assert any("first backoff interval" in failure for failure in result.failures)


def test_topology_verifier_rejects_missing_migration_alias() -> None:
    plan = topo.canonical_topology_plan()
    broken = topo.TopologyPlan(
        streams=plan.streams,
        consumers=plan.consumers,
        migration_aliases={"DHARMA_A2A": topo.A2A_TASKS},
        presence_bucket=plan.presence_bucket,
    )

    result = topo.verify_topology_plan(broken)

    assert result.passed is False
    assert "missing migration alias DHARMA_FLEET" in result.failures


@pytest.mark.asyncio
async def test_install_topology_uses_injected_admin_client() -> None:
    class FakeJetStreamAdmin:
        def __init__(self) -> None:
            self.streams: list[dict[str, object]] = []
            self.consumers: list[tuple[str, dict[str, object]]] = []

        async def add_stream(self, config: dict[str, object]) -> None:
            self.streams.append(config)

        async def add_consumer(self, stream: str, config: dict[str, object]) -> None:
            self.consumers.append((stream, config))

    fake = FakeJetStreamAdmin()
    result = await topo.install_topology(fake)

    assert result["installed"] is True
    assert {stream["name"] for stream in fake.streams} == {
        topo.A2A_INBOX,
        topo.A2A_TASKS,
        topo.A2A_RECEIPTS,
        topo.A2A_DLQ,
    }
    assert any(config["durable_name"] == "a2a_qwen_code_inbox" for _, config in fake.consumers)
    assert any(config.get("ack_wait") == 5_000_000_000 for _, config in fake.consumers)
