from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from scripts.governance import a2a_presence_preflight as presence


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _write_agents(root: Path, *, alias_collision: bool = False) -> None:
    agents: dict[str, object] = {
        "codex_composer": {
            "aliases": ["codex_composer", "codex-5.5"],
            "authority_status": "standing",
            "status": "ready",
            "type": "codex-agent",
        }
    }
    if alias_collision:
        agents["shadow_codex"] = {
            "aliases": ["codex_composer"],
            "authority_status": "shadow",
            "status": "blocked",
        }
    _write_json(root / "agents.json", {"agents": agents})


def _fresh_presence(*, stale: bool = False, expired: bool = False) -> dict[str, object]:
    now = datetime.now(UTC)
    heartbeat = now - timedelta(hours=3 if stale else 0)
    expires = now - timedelta(minutes=1) if expired else now + timedelta(minutes=30)
    return {
        "agent_uid": "codex_composer",
        "broker": "agni",
        "domain": "agni",
        "inbox_subject": "dharma.agent.codex_composer.inbox",
        "durable_consumer": "a2a_codex_composer_inbox",
        "transport_state": "HANDLER_ACKED",
        "model_state": "SEMANTIC_SIGNED",
        "tempo_tier": "warm",
        "authority_status": "standing",
        "last_heartbeat_at": heartbeat.isoformat().replace("+00:00", "Z"),
        "last_handler_ack_at": heartbeat.isoformat().replace("+00:00", "Z"),
        "last_domain_receipt_at": heartbeat.isoformat().replace("+00:00", "Z"),
        "last_semantic_receipt_at": heartbeat.isoformat().replace("+00:00", "Z"),
        "peer_model_processed_claim": True,
        "last_error": "",
        "expires_at": expires.isoformat().replace("+00:00", "Z"),
    }


def test_presence_preflight_accepts_fresh_canonical_projection(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root)
    _write_json(bus_root / "presence/codex_composer.json", _fresh_presence())

    payload, exit_code = presence.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_preflight",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
    )

    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["rows"][0]["final_state"] == presence.READY_PRESENCE_PREVALIDATED
    assert payload["rows"][0]["peer_model_processed_claim"] is True
    assert "a2a-identity-reconcile" in payload["rows"][0]["operator_commands"]["identity_reconcile"]


def test_presence_preflight_accepts_latest_projector_receipt_projection(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root)
    _write_json(
        repo_root / "reports/a2a/presence_projection/20260619T000000Z-a2a-presence-projector.json",
        {
            "schema_version": presence.PRESENCE_PROJECTOR_SCHEMA,
            "rows": [
                {
                    "agent_uid": "codex_composer",
                    "final_state": "READY_PRESENCE_PROJECTED",
                    "projection": {
                        **_fresh_presence(),
                        "schema_version": presence.PRESENCE_PROJECTION_SCHEMA,
                        "presence_evidence_tier": "BRIDGE_HEARTBEAT",
                        "target_owned_claim": False,
                    },
                }
            ],
        },
    )

    payload, exit_code = presence.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_preflight",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
    )

    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["rows"][0]["presence_source_path"].endswith("a2a-presence-projector.json")
    assert not (bus_root / "presence/codex_composer.json").exists()


def test_presence_preflight_fails_closed_on_stale_or_expired_projection(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root)
    _write_json(bus_root / "presence/codex_composer.json", _fresh_presence(stale=True, expired=True))

    payload, exit_code = presence.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_preflight",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert any("presence is stale" in blocker for blocker in payload["blockers"])
    assert any("presence is expired" in blocker for blocker in payload["blockers"])


def test_presence_preflight_rejects_alias_collision(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    _write_agents(bus_root, alias_collision=True)
    _write_json(bus_root / "presence/codex_composer.json", _fresh_presence())

    payload, exit_code = presence.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_preflight",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert any("maps to multiple agents" in blocker for blocker in payload["blockers"])
