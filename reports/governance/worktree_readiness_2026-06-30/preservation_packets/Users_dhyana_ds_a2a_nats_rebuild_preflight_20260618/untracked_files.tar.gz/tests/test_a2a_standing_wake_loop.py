from __future__ import annotations

import hashlib
import json
from pathlib import Path

from scripts.governance import a2a_onboard
from scripts.governance import a2a_wake_loop_preflight as wake_preflight
from scripts.runtime import a2a_standing_wake_loop as standing_loop


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _prepare(
    tmp_path: Path,
    monkeypatch,
    *,
    agents: dict[str, dict[str, object]],
) -> tuple[Path, Path, str]:
    repo_root = tmp_path / "repo"
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for standing wake loop tests\n", encoding="utf-8")
    locked_sha = hashlib.sha256(locked_spec.read_bytes()).hexdigest()
    monkeypatch.setattr(a2a_onboard, "LOCKED_SPEC_SHA256", locked_sha)
    producer = repo_root / "scripts/runtime/a2a_domain_reply_worker.py"
    producer.parent.mkdir(parents=True, exist_ok=True)
    producer.write_text("SEMANTIC_RECEIPT_SCHEMA = 'dharma.a2a.semantic_receipt.v1'\n", encoding="utf-8")

    a2a_bus_root = tmp_path / "a2a_bus"
    _write_json(a2a_bus_root / "agents.json", {"agents": agents})
    return repo_root, a2a_bus_root, locked_sha


def _write_domain_and_semantic_receipts(
    repo_root: Path,
    *,
    agent_uid: str,
    locked_sha: str,
) -> None:
    artifact = repo_root / "reports/a2a/domain_reply_artifacts/source.json"
    _write_json(
        artifact,
        {
            "schema_version": "dharma.a2a.domain_reply_artifact.v1",
            "summary": "standing wake loop source",
        },
    )
    source_hash = hashlib.sha256(artifact.read_bytes()).hexdigest()
    _write_json(
        repo_root / f"reports/a2a/reply_receipts/20260619T000000Z-{agent_uid}-domain.json",
        {
            "schema_version": "dharma.a2a.reply_capture_receipt.v1",
            "status": a2a_onboard.DOMAIN_RECEIPTED,
            "reply_evidence_tier": a2a_onboard.DOMAIN_RECEIPTED,
            "contact_evidence_tier": a2a_onboard.DOMAIN_RECEIPTED,
            "agent_uid": agent_uid,
            "target_uid": agent_uid,
            "domain_receipt_claim": True,
        },
    )
    _write_json(
        repo_root / f"reports/a2a/semantic_receipts/20260619T000000Z-{agent_uid}-semantic.json",
        {
            "schema_version": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
            "status": a2a_onboard.SEMANTIC_SIGNED,
            "agent_uid": agent_uid,
            "locked_spec_sha256": locked_sha,
            "task_hash": "sha256:standing-wake-loop-test",
            "model_identity": "test-provider/test-model",
            "peer_model_processed_claim": True,
            "semantic_reply_claim": True,
            "confidence": 0.95,
            "failure_digest": "confusion: none; tried: standing wake loop; failed: none; worked: semantic receipt",
            "evidence_refs": ["reports/a2a/domain_reply_artifacts/source.json"],
            "source_artifact_path": "reports/a2a/domain_reply_artifacts/source.json",
            "source_artifact_sha256": source_hash,
        },
    )


def _config(
    *,
    agent_uid: str,
    a2a_bus_root: Path,
    receipt_dir: Path,
    dry_run: bool = False,
) -> standing_loop.StandingWakeLoopConfig:
    return standing_loop.StandingWakeLoopConfig(
        agent_uid=agent_uid,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=receipt_dir,
        lease_seconds=300,
        failure_count=0,
        failure_threshold=3,
        dry_run=dry_run,
    )


def test_standing_wake_loop_writes_target_owned_heartbeat_and_satisfies_preflight(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root, a2a_bus_root, locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={"hermes-m5": {"status": "operational", "type": "hermes"}},
    )
    monkeypatch.setenv(standing_loop.OWNER_ENV, "hermes-m5")
    _write_domain_and_semantic_receipts(repo_root, agent_uid="hermes-m5", locked_sha=locked_sha)

    payload, exit_code = standing_loop.run_once(
        config=_config(
            agent_uid="hermes-m5",
            a2a_bus_root=a2a_bus_root,
            receipt_dir=repo_root / "reports/a2a/standing_wake_loop",
        ),
        repo_root=repo_root,
    )

    assert exit_code == 0
    assert payload["status"] == standing_loop.STATUS_HEARTBEAT_WRITTEN
    assert payload["wrote_heartbeat"] is True
    heartbeat_path = a2a_bus_root / "worker_heartbeats/hermes-m5.json"
    heartbeat = json.loads(heartbeat_path.read_text(encoding="utf-8"))
    assert heartbeat["schema_version"] == standing_loop.HEARTBEAT_SCHEMA
    assert heartbeat["standing_semantic_loop"] is True
    assert heartbeat["lease_refs"][0]["lease_owner"] == "hermes-m5"
    assert heartbeat["circuit_breaker"]["state"] == "closed"

    preflight, preflight_exit = wake_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=repo_root / "reports/a2a/wake_loop_preflight",
        agent="hermes-m5",
        broker="agni",
        mode="prevalidate",
    )
    row = preflight["rows"][0]
    assert preflight_exit == 0
    assert row["final_state"] == wake_preflight.READY_WAKE_LOOP_PREVALIDATED
    assert row["wake_lease_present"] is True
    assert row["circuit_breaker_present"] is True


def test_standing_wake_loop_refuses_owner_mismatch(tmp_path: Path, monkeypatch) -> None:
    repo_root, a2a_bus_root, _locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={"hermes-m5": {"status": "operational", "type": "hermes"}},
    )
    monkeypatch.setenv(standing_loop.OWNER_ENV, "codex_composer")

    payload, exit_code = standing_loop.run_once(
        config=_config(
            agent_uid="hermes-m5",
            a2a_bus_root=a2a_bus_root,
            receipt_dir=repo_root / "reports/a2a/standing_wake_loop",
        ),
        repo_root=repo_root,
    )

    assert exit_code == 1
    assert payload["status"] == standing_loop.STATUS_BLOCKED_OWNER_MISMATCH
    assert payload["wrote_heartbeat"] is False
    assert not (a2a_bus_root / "worker_heartbeats/hermes-m5.json").exists()


def test_standing_wake_loop_refuses_session_scoped_agent(tmp_path: Path, monkeypatch) -> None:
    repo_root, a2a_bus_root, _locked_sha = _prepare(
        tmp_path,
        monkeypatch,
        agents={
            "codex_composer": {
                "status": "wake_loop_active",
                "type": "codex-cli",
                "authority": "external_worker_evidence_only",
            }
        },
    )
    monkeypatch.setenv(standing_loop.OWNER_ENV, "codex_composer")

    payload, exit_code = standing_loop.run_once(
        config=_config(
            agent_uid="codex_composer",
            a2a_bus_root=a2a_bus_root,
            receipt_dir=repo_root / "reports/a2a/standing_wake_loop",
        ),
        repo_root=repo_root,
    )

    assert exit_code == 1
    assert payload["status"] == standing_loop.STATUS_DEGRADED_SESSION_SCOPED
    assert standing_loop.STATUS_DEGRADED_SESSION_SCOPED in payload["blockers"]
    assert payload["wrote_heartbeat"] is False
