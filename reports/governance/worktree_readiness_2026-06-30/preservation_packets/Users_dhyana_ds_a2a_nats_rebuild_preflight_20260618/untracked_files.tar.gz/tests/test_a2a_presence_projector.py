from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from scripts.governance import a2a_onboard
from scripts.governance import a2a_presence_preflight as presence_preflight
from scripts.governance import a2a_presence_projector as projector


def _write_json(path: Path, payload: dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _write_agents(root: Path, *, timestamp: str) -> None:
    _write_json(
        root / "agents.json",
        {
            "agents": {
                "codex_composer": {
                    "aliases": ["codex_composer", "codex-5.5"],
                    "authority_status": "standing",
                    "last_seen": timestamp,
                    "status": "ready",
                    "tempo_tier": "warm",
                }
            }
        },
    )


def _write_bridge_heartbeat(root: Path, *, timestamp: str) -> None:
    _write_json(
        root / "bridge_heartbeats/codex_composer.json",
        {
            "schema_version": "dharma.a2a.inbox_bridge_heartbeat.v1",
            "agent_uid": "codex_composer",
            "consumer": "codex_composer_inbox",
            "status": "IDLE",
            "stream": "A2A_INBOX",
            "subject": "dharma.agent.codex_composer.inbox",
            "timestamp": timestamp,
        },
    )


def _write_semantic_source_artifact(repo_root: Path) -> str:
    path = repo_root / "reports/a2a/domain_reply_artifacts/test.json"
    _write_json(
        path,
        {
            "schema_version": "dharma.a2a.domain_reply_artifact.v1",
            "summary": "test semantic source artifact",
        },
    )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _valid_semantic_receipt(
    agent_uid: str,
    locked_sha: str,
    *,
    source_artifact_sha256: str,
) -> dict[str, object]:
    return {
        "schema_version": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
        "timestamp": "2026-06-19T00:00:00Z",
        "status": a2a_onboard.SEMANTIC_SIGNED,
        "proof_tier": a2a_onboard.SEMANTIC_SIGNED,
        "agent_uid": agent_uid,
        "from_agent": agent_uid,
        "to_agent": "operator",
        "packet_id": "packet-semantic-test",
        "reply_subject": "_INBOX.a2a.test",
        "peer_model_processed_claim": True,
        "semantic_reply_claim": True,
        "model_identity": "test-provider/test-model",
        "task_hash": "sha256:test-task",
        "locked_spec_sha256": locked_sha,
        "verdict": "approve",
        "confidence": 0.91,
        "failure_digest": "confusion: none; tried: validated receipt; failed: none; worked: current semantic signoff",
        "evidence_refs": ["reports/a2a/domain_reply_artifacts/test.json"],
        "blockers": [],
        "domain_receipt_schema": a2a_onboard.DOMAIN_RECEIPT_SCHEMA,
        "domain_receipt_sha256": "ab" * 32,
        "source_artifact_path": "reports/a2a/domain_reply_artifacts/test.json",
        "source_artifact_sha256": source_artifact_sha256,
    }


def test_presence_projector_dry_run_does_not_write_projection(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    now = _iso(datetime.now(UTC))
    _write_agents(bus_root, timestamp=now)
    _write_bridge_heartbeat(bus_root, timestamp=now)

    payload, exit_code = projector.run_projection(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_projection",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
        write_projections=False,
    )

    row = payload["rows"][0]
    assert exit_code == 0
    assert payload["passed"] is True
    assert payload["dry_run"] is True
    assert row["presence_evidence_tier"] == "BRIDGE_HEARTBEAT"
    assert row["peer_model_processed_claim"] is False
    assert row["target_owned_claim"] is False
    assert row["projection"]["peer_model_processed_claim"] is False
    assert not (bus_root / "presence/codex_composer.json").exists()
    assert (repo_root / payload["receipt_path"]).exists()


def test_presence_projector_write_mode_satisfies_presence_preflight(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    now = _iso(datetime.now(UTC))
    _write_agents(bus_root, timestamp=now)
    _write_bridge_heartbeat(bus_root, timestamp=now)

    payload, exit_code = projector.run_projection(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_projection",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
        write_projections=True,
    )

    assert exit_code == 0
    assert payload["rows"][0]["write_performed"] is True
    projection_path = bus_root / "presence/codex_composer.json"
    assert projection_path.exists()
    projection = json.loads(projection_path.read_text(encoding="utf-8"))
    assert projection["schema_version"] == projector.PRESENCE_PROJECTION_SCHEMA
    assert projection["peer_model_processed_claim"] is False

    preflight_payload, preflight_exit = presence_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_preflight",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
    )
    assert preflight_exit == 0
    assert preflight_payload["passed"] is True
    assert preflight_payload["rows"][0]["peer_model_processed_claim"] is False


def test_presence_projector_sets_model_claim_only_for_valid_semantic_receipt(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    now = _iso(datetime.now(UTC))
    _write_agents(bus_root, timestamp=now)
    _write_bridge_heartbeat(bus_root, timestamp=now)
    locked_spec = repo_root / a2a_onboard.LOCKED_SPEC_PATH
    locked_spec.parent.mkdir(parents=True, exist_ok=True)
    locked_spec.write_text("locked spec for test\n", encoding="utf-8")
    locked_sha = hashlib.sha256(locked_spec.read_bytes()).hexdigest()
    monkeypatch.setattr(a2a_onboard, "LOCKED_SPEC_SHA256", locked_sha)
    _write_json(
        repo_root / "reports/a2a/semantic_receipts/20260619T000000Z-codex_composer-good-semantic.json",
        _valid_semantic_receipt(
            "codex_composer",
            locked_sha,
            source_artifact_sha256=_write_semantic_source_artifact(repo_root),
        ),
    )

    payload, exit_code = projector.run_projection(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_projection",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
        write_projections=False,
    )

    row = payload["rows"][0]
    assert exit_code == 0
    assert row["peer_model_processed_claim"] is True
    assert row["projection"]["model_state"] == a2a_onboard.SEMANTIC_SIGNED
    assert row["semantic_receipt_path"].endswith("codex_composer-good-semantic.json")


def test_presence_projector_fails_closed_on_stale_source(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    bus_root = tmp_path / "bus"
    stale = _iso(datetime.now(UTC) - timedelta(hours=3))
    _write_agents(bus_root, timestamp=stale)
    _write_bridge_heartbeat(bus_root, timestamp=stale)

    payload, exit_code = projector.run_projection(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_projection",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
        write_projections=True,
    )

    assert exit_code == 1
    assert payload["passed"] is False
    assert any("stale beyond" in blocker for blocker in payload["blockers"])
    assert json.loads((bus_root / "presence/codex_composer.json").read_text(encoding="utf-8"))[
        "peer_model_processed_claim"
    ] is False

    preflight_payload, preflight_exit = presence_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=bus_root,
        receipt_dir=repo_root / "reports/a2a/presence_preflight",
        agent="codex_composer",
        broker="agni",
        domain="agni",
        ttl_seconds=7200,
    )
    assert preflight_exit == 1
    assert preflight_payload["passed"] is False
    assert any("presence is stale" in blocker for blocker in preflight_payload["blockers"])
