#!/usr/bin/env python3
"""Read-only live NATS topology drift probe for the A2A rebuild."""

from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.jetstream_topology import (  # noqa: E402
    A2A_DLQ,
    A2A_INBOX,
    A2A_RECEIPTS,
    A2A_TASKS,
    ConsumerSpec,
    LiveConsumerObservation,
    LiveStreamObservation,
    TopologyMigrationPlan,
    TopologyMigrationStep,
    canonical_topology_plan,
    consumer_config_for_nats,
    plan_live_topology_migration,
    verify_live_topology_observation,
)
from scripts.runtime.pr_merge_control import stamp, utc_now  # noqa: E402


DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "live_topology"
APPLY_ADDITIVE_ENV = "A2A_LIVE_TOPOLOGY_APPLY"
APPLY_ADDITIVE_VALUE = "approved-additive"
RECONCILE_CONSUMERS_ENV = "A2A_LIVE_TOPOLOGY_RECONCILE"
RECONCILE_CONSUMERS_VALUE = "approved-consumer-reconcile"
REPLACE_CONSUMERS_ENV = "A2A_LIVE_TOPOLOGY_REPLACE_CONSUMERS"
REPLACE_CONSUMERS_VALUE = "approved-replace-empty-consumers"
CUTOVER_TOPOLOGY_ENV = "A2A_LIVE_TOPOLOGY_CUTOVER"
CUTOVER_TOPOLOGY_VALUE = "approved-legacy-cutover"


def _run_nats(args: list[str], *, timeout_s: int) -> subprocess.CompletedProcess[str]:
    timeout_arg = f"{timeout_s}s"
    env = {**os.environ, "NATS_TIMEOUT": timeout_arg}
    return subprocess.run(
        ["nats", "--timeout", timeout_arg, *args],
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        timeout=timeout_s + 2,
        check=False,
        env=env,
    )


def _json_or_raise(result: subprocess.CompletedProcess[str], *, label: str) -> Any:
    if result.returncode != 0:
        raise RuntimeError(f"{label} failed: {result.stderr.strip() or result.stdout.strip()}")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{label} did not return JSON: {exc}") from exc


def _stream_observations(context: str, *, timeout_s: int) -> tuple[LiveStreamObservation, ...]:
    names_payload = _json_or_raise(
        _run_nats(["--context", context, "stream", "ls", "--json"], timeout_s=timeout_s),
        label="stream ls",
    )
    if not isinstance(names_payload, list):
        raise RuntimeError("stream ls returned non-list JSON")
    observations: list[LiveStreamObservation] = []
    for name in names_payload:
        info = _json_or_raise(
            _run_nats(
                ["--context", context, "stream", "info", str(name), "--json"],
                timeout_s=timeout_s,
            ),
            label=f"stream info {name}",
        )
        config = info.get("config") if isinstance(info, dict) else {}
        if not isinstance(config, dict):
            config = {}
        subjects = config.get("subjects")
        subject_values = subjects if isinstance(subjects, list) else []
        active_subjects = _stream_active_subjects(context, str(name), timeout_s=timeout_s)
        observations.append(
            LiveStreamObservation(
                name=str(config.get("name") or name),
                subjects=tuple(str(subject) for subject in subject_values),
                active_subjects=active_subjects,
                duplicate_window_s=(
                    int(config["duplicate_window"]) // 1_000_000_000
                    if isinstance(config.get("duplicate_window"), int)
                    else None
                ),
                retention=str(config.get("retention") or ""),
                storage=str(config.get("storage") or ""),
            )
        )
    return tuple(observations)


def _stream_active_subjects(context: str, stream: str, *, timeout_s: int) -> tuple[str, ...]:
    result = _run_nats(
        ["--context", context, "stream", "subjects", stream, "--json"],
        timeout_s=timeout_s,
    )
    if result.returncode != 0:
        return ()
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        return ()
    if not isinstance(payload, dict):
        return ()
    return tuple(sorted(str(subject) for subject in payload))


def _kv_buckets(context: str, *, timeout_s: int) -> tuple[str, ...]:
    result = _run_nats(["--context", context, "kv", "ls", "--names"], timeout_s=timeout_s)
    if result.returncode != 0:
        raise RuntimeError(f"kv ls failed: {result.stderr.strip() or result.stdout.strip()}")
    return tuple(line.strip() for line in result.stdout.splitlines() if line.strip())


def _consumer_observations(
    context: str,
    streams: tuple[LiveStreamObservation, ...],
    *,
    timeout_s: int,
    canonical_consumers_only: bool = False,
) -> tuple[LiveConsumerObservation, ...]:
    observations: list[LiveConsumerObservation] = []
    canonical_streams = {A2A_INBOX, A2A_TASKS, A2A_RECEIPTS, A2A_DLQ}
    for stream in streams:
        if canonical_consumers_only and stream.name not in canonical_streams:
            continue
        result = _run_nats(
            ["--context", context, "consumer", "ls", stream.name, "--json"],
            timeout_s=timeout_s,
        )
        if result.returncode != 0:
            continue
        try:
            names = json.loads(result.stdout)
        except json.JSONDecodeError:
            continue
        if not isinstance(names, list):
            continue
        for name in names:
            info_result = _run_nats(
                ["--context", context, "consumer", "info", stream.name, str(name), "--json"],
                timeout_s=timeout_s,
            )
            if info_result.returncode != 0:
                observations.append(LiveConsumerObservation(stream=stream.name, durable=str(name)))
                continue
            try:
                info = json.loads(info_result.stdout)
            except json.JSONDecodeError:
                observations.append(LiveConsumerObservation(stream=stream.name, durable=str(name)))
                continue
            config = info.get("config") if isinstance(info, dict) else {}
            if not isinstance(config, dict):
                config = {}
            backoff = config.get("backoff")
            observations.append(
                LiveConsumerObservation(
                    stream=stream.name,
                    durable=str(config.get("durable_name") or name),
                    filter_subject=str(config.get("filter_subject") or ""),
                    ack_policy=str(config.get("ack_policy") or ""),
                    deliver_policy=str(config.get("deliver_policy") or ""),
                    ack_wait_ns=(
                        int(config["ack_wait"])
                        if isinstance(config.get("ack_wait"), int)
                        else None
                    ),
                    max_deliver=(
                        int(config["max_deliver"])
                        if isinstance(config.get("max_deliver"), int)
                        else None
                    ),
                    backoff_ns=(
                        tuple(int(item) for item in backoff if isinstance(item, int))
                        if isinstance(backoff, list)
                        else None
                    ),
                    max_ack_pending=(
                        int(config["max_ack_pending"])
                        if isinstance(config.get("max_ack_pending"), int)
                        else None
                    ),
                    num_ack_pending=(
                        int(info["num_ack_pending"])
                        if isinstance(info.get("num_ack_pending"), int)
                        else None
                    ),
                    num_pending=(
                        int(info["num_pending"])
                        if isinstance(info.get("num_pending"), int)
                        else None
                    ),
                    num_redelivered=(
                        int(info["num_redelivered"])
                        if isinstance(info.get("num_redelivered"), int)
                        else None
                    ),
                    num_waiting=(
                        int(info["num_waiting"])
                        if isinstance(info.get("num_waiting"), int)
                        else None
                    ),
                )
            )
    return tuple(observations)


def _write_receipt(receipt_dir: Path, payload: dict[str, Any]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{stamp()}-a2a-live-topology-probe.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _run_plan_step(command: str, *, timeout_s: int) -> dict[str, Any]:
    timeout_arg = f"{timeout_s}s"
    env = {**os.environ, "NATS_TIMEOUT": timeout_arg}
    result = subprocess.run(
        command,
        cwd=REPO_ROOT,
        shell=True,
        text=True,
        capture_output=True,
        timeout=timeout_s + 2,
        check=False,
        env=env,
    )
    return {
        "command": command,
        "returncode": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
        "passed": result.returncode == 0,
    }


def _dry_run_command(command: str) -> str:
    if " stream edit " in command and "--dry-run" not in command:
        return f"{command} --dry-run"
    if " stream add " in command and "--validate" not in command:
        return command.replace(" --defaults", " --validate --defaults")
    if " consumer add " in command and "--validate" not in command:
        return command.replace(" --defaults", " --validate --defaults")
    return command


def _is_stream_edit_dry_run_diff(result: dict[str, Any]) -> bool:
    return (
        result.get("returncode") == 1
        and " stream edit " in str(result.get("command") or "")
        and "--dry-run" in str(result.get("command") or "")
        and str(result.get("stdout") or "").lstrip().startswith("Differences")
        and not str(result.get("stderr") or "").strip()
    )


def _normalise_cutover_result(result: dict[str, Any], *, dry_run: bool) -> dict[str, Any]:
    if dry_run and _is_stream_edit_dry_run_diff(result):
        result["passed"] = True
        result["effective_returncode"] = 0
        result["dry_run_diff_detected"] = True
    return result


def _consumer_by_durable() -> dict[str, ConsumerSpec]:
    return {consumer.durable: consumer for consumer in canonical_topology_plan().consumers}


def _cutover_followup_consumer_command(
    *,
    context: str,
    receipt_dir: Path,
    step: TopologyMigrationStep,
) -> tuple[str, str]:
    durable = step.step_id.removeprefix("add_consumer_")
    consumer = _consumer_by_durable().get(durable)
    if consumer is None:
        return step.command, ""
    config_dir = receipt_dir / "consumer_configs"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / f"{stamp()}-{consumer.stream}-{consumer.durable}.json"
    config_path.write_text(
        json.dumps(consumer_config_for_nats(consumer), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    command = (
        f"nats --context {shlex.quote(context)} consumer add "
        f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} "
        f"--config {shlex.quote(str(config_path))} --defaults"
    )
    return command, str(config_path)


def _cutover_followup_step_ids() -> set[str]:
    return {
        f"add_{A2A_TASKS}",
        f"add_{A2A_RECEIPTS}",
        "add_consumer_a2a_task_claimant",
        "add_consumer_a2a_task_closer",
        "add_consumer_a2a_receipt_indexer",
    }


def _cutover_followup_step_preview(
    *,
    context: str,
    step: TopologyMigrationStep,
) -> dict[str, Any]:
    preview = step.to_dict()
    preview["compensation"] = _post_cutover_step_compensation(context=context, step=step)
    if not step.step_id.startswith("add_consumer_"):
        return preview
    durable = step.step_id.removeprefix("add_consumer_")
    consumer = _consumer_by_durable().get(durable)
    if consumer is None:
        return preview
    preview["planner_command"] = step.command
    preview["command"] = (
        f"nats --context {shlex.quote(context)} consumer add "
        f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} "
        "--config <generated-consumer-config-json> --defaults"
    )
    preview["execution_command_template"] = preview["command"]
    preview["execution_uses_exact_config"] = True
    preview["desired_consumer_config"] = consumer_config_for_nats(consumer)
    return preview


def _post_cutover_step_compensation(
    *,
    context: str,
    step: TopologyMigrationStep,
) -> dict[str, Any]:
    common = {
        "available": False,
        "step_id": step.step_id,
        "execution": "explicit_operator_action",
        "precondition": (
            "run only if the matching post-cutover step created this resource "
            "and follow-up rollback is required"
        ),
        "command": "",
        "blocker": "",
    }
    if step.step_id.startswith("add_consumer_"):
        durable = step.step_id.removeprefix("add_consumer_")
        consumer = _consumer_by_durable().get(durable)
        if consumer is None:
            common["blocker"] = "canonical consumer spec not found"
            return common
        common.update(
            {
                "available": True,
                "kind": "consumer",
                "resource": f"{consumer.stream}/{consumer.durable}",
                "command": (
                    f"nats --context {shlex.quote(context)} consumer rm "
                    f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} --force"
                ),
            }
        )
        return common
    if step.step_id.startswith("add_") and " stream add " in step.command:
        stream_name = step.step_id.removeprefix("add_")
        common.update(
            {
                "available": True,
                "kind": "stream",
                "resource": stream_name,
                "command": (
                    f"nats --context {shlex.quote(context)} stream rm "
                    f"{shlex.quote(stream_name)} --force"
                ),
            }
        )
        return common
    common["blocker"] = "no post-cutover compensation command for step type"
    return common


def _post_cutover_compensation_plan(
    *,
    context: str,
    post_cutover_steps: list[TopologyMigrationStep],
) -> list[dict[str, Any]]:
    compensations = [
        _post_cutover_step_compensation(context=context, step=step)
        for step in reversed(post_cutover_steps)
    ]
    ordered: list[dict[str, Any]] = []
    for index, compensation in enumerate(compensations, start=1):
        compensation["compensation_order"] = index
        compensation["order_basis"] = "reverse_post_cutover_order"
        ordered.append(compensation)
    return ordered


def _legacy_stream_rollback_command(
    *,
    context: str,
    stream: LiveStreamObservation,
) -> str:
    subject_flags = " ".join(
        f"--subjects {shlex.quote(subject)}" for subject in stream.subjects
    )
    if not subject_flags:
        return ""
    return (
        f"nats --context {shlex.quote(context)} stream edit "
        f"{shlex.quote(stream.name)} {subject_flags} --force"
    )


def _cutover_rollback_plan(
    *,
    context: str,
    streams: tuple[LiveStreamObservation, ...],
    migration_plan: TopologyMigrationPlan,
) -> dict[str, dict[str, Any]]:
    observed_by_name = {stream.name: stream for stream in streams}
    rollback_plan: dict[str, dict[str, Any]] = {}
    for step in _legacy_cutover_steps(migration_plan):
        stream_name = step.step_id.removeprefix("cutover_")
        observed = observed_by_name.get(stream_name)
        if observed is None:
            rollback_plan[step.step_id] = {
                "available": False,
                "stream": stream_name,
                "original_subjects": [],
                "command": "",
                "blocker": "pre-cutover stream observation not available",
            }
            continue
        command = _legacy_stream_rollback_command(context=context, stream=observed)
        rollback_plan[step.step_id] = {
            "available": bool(command),
            "stream": observed.name,
            "original_subjects": list(observed.subjects),
            "command": command,
            "blocker": "" if command else "pre-cutover stream had no subjects to restore",
        }
    return rollback_plan


def _subjects_from_step_command(step: TopologyMigrationStep) -> tuple[str, ...]:
    try:
        parts = shlex.split(step.command)
    except ValueError:
        return ()
    subjects: list[str] = []
    index = 0
    while index < len(parts):
        if parts[index] == "--subjects" and index + 1 < len(parts):
            subjects.append(parts[index + 1])
            index += 2
            continue
        index += 1
    return tuple(subjects)


def _streams_after_legacy_cutover(
    streams: tuple[LiveStreamObservation, ...],
    migration_plan: TopologyMigrationPlan,
) -> tuple[LiveStreamObservation, ...]:
    replacements = {
        step.step_id.removeprefix("cutover_"): _subjects_from_step_command(step)
        for step in _legacy_cutover_steps(migration_plan)
    }
    synthetic: list[LiveStreamObservation] = []
    for stream in streams:
        subjects = replacements.get(stream.name)
        if subjects is None:
            synthetic.append(stream)
            continue
        synthetic.append(
            LiveStreamObservation(
                name=stream.name,
                subjects=subjects,
                active_subjects=stream.active_subjects,
                duplicate_window_s=stream.duplicate_window_s,
                retention=stream.retention,
                storage=stream.storage,
            )
        )
    return tuple(synthetic)


def _cutover_transaction_plan(
    *,
    context: str,
    streams: tuple[LiveStreamObservation, ...],
    kv_buckets: tuple[str, ...],
    consumers: tuple[LiveConsumerObservation, ...],
    migration_plan: TopologyMigrationPlan,
    rollback_plan: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    synthetic_streams = _streams_after_legacy_cutover(streams, migration_plan)
    post_plan = plan_live_topology_migration(
        synthetic_streams,
        kv_buckets,
        consumers=consumers,
        context=context,
    )
    post_cutover_steps = _post_cutover_steps(post_plan)
    return {
        "mutation_gate": f"{CUTOVER_TOPOLOGY_ENV}={CUTOVER_TOPOLOGY_VALUE}",
        "legacy_cutover_steps": [
            step.to_dict() for step in _legacy_cutover_steps(migration_plan)
        ],
        "post_cutover_steps_after_legacy_cutover": [
            _cutover_followup_step_preview(context=context, step=step)
            for step in post_cutover_steps
        ],
        "post_cutover_compensation_plan": _post_cutover_compensation_plan(
            context=context,
            post_cutover_steps=post_cutover_steps,
        ),
        "post_cutover_blockers_after_legacy_cutover": list(post_plan.blockers),
        "rollback_plan": rollback_plan,
        "rollback_execution": "explicit_operator_action",
        "dry_run_semantics": (
            "dry-run executes only NATS validation/dry-run commands against current live "
            "state; post-cutover steps are planned from an in-memory legacy-cutover "
            "simulation because current live subjects still overlap until approval. "
            "Post-cutover compensation commands are rendered in reverse post-cutover "
            "order and are explicit operator actions only"
        ),
    }


def _run_cutover_step(
    *,
    context: str,
    receipt_dir: Path,
    step: TopologyMigrationStep,
    timeout_s: int,
    dry_run: bool,
) -> dict[str, Any]:
    command = step.command
    config_path = ""
    if step.step_id.startswith("add_consumer_"):
        command, config_path = _cutover_followup_consumer_command(
            context=context,
            receipt_dir=receipt_dir,
            step=step,
        )
    if dry_run:
        command = _dry_run_command(command)
    result = _run_plan_step(command, timeout_s=timeout_s)
    result = _normalise_cutover_result(result, dry_run=dry_run)
    result["step_id"] = step.step_id
    result["action"] = step.action
    result["phase"] = step.phase
    result["dry_run"] = dry_run
    if step.step_id in _cutover_followup_step_ids():
        result["compensation"] = _post_cutover_step_compensation(context=context, step=step)
    if config_path:
        result["config_path"] = config_path
    return result


def _legacy_cutover_steps(plan: TopologyMigrationPlan) -> list[TopologyMigrationStep]:
    return [
        step
        for step in plan.steps
        if step.phase == "cutover"
        and step.step_id.startswith("cutover_")
        and not step.blocked
    ]


def _post_cutover_steps(plan: TopologyMigrationPlan) -> list[TopologyMigrationStep]:
    allowed = _cutover_followup_step_ids()
    return [step for step in plan.steps if step.step_id in allowed and not step.blocked]


def _run_cutover_topology(
    *,
    context: str,
    receipt_dir: Path,
    migration_plan: TopologyMigrationPlan,
    cutover_rollback_plan: dict[str, dict[str, Any]] | None = None,
    timeout_s: int,
    dry_run: bool,
) -> list[dict[str, Any]]:
    if not dry_run and os.environ.get(CUTOVER_TOPOLOGY_ENV) != CUTOVER_TOPOLOGY_VALUE:
        return [
            {
                "passed": False,
                "returncode": 17,
                "stderr": (
                    f"set {CUTOVER_TOPOLOGY_ENV}={CUTOVER_TOPOLOGY_VALUE} "
                    "to edit legacy streams and install cutover-blocked canonical topology"
                ),
                "dry_run": False,
            }
        ]
    steps = _legacy_cutover_steps(migration_plan)
    if not steps:
        steps = _post_cutover_steps(migration_plan)
    if not steps:
        return [
            {
                "passed": False,
                "returncode": 20,
                "stderr": "no unblocked legacy or post-cutover step is present in the migration plan",
                "dry_run": dry_run,
            }
        ]
    results: list[dict[str, Any]] = []
    rollback_plan = cutover_rollback_plan or {}
    for step in steps:
        result = _run_cutover_step(
            context=context,
            receipt_dir=receipt_dir,
            step=step,
            timeout_s=timeout_s,
            dry_run=dry_run,
        )
        if step.step_id in rollback_plan:
            result["rollback"] = rollback_plan[step.step_id]
        results.append(result)
        if not result["passed"]:
            break
    return results


def _drifted_consumer_keys(verification: object) -> set[str]:
    drifts = getattr(verification, "drifted_consumers", ())
    return {str(drift).split(" ", 1)[0] for drift in drifts}


def _reconcile_consumer_configs(
    *,
    context: str,
    receipt_dir: Path,
    consumers: tuple[LiveConsumerObservation, ...],
    verification: object,
    timeout_s: int,
    dry_run: bool,
) -> list[dict[str, Any]]:
    plan = canonical_topology_plan()
    observed = {(consumer.stream, consumer.durable) for consumer in consumers}
    drifted_keys = _drifted_consumer_keys(verification)
    allowed_streams = {A2A_INBOX, A2A_DLQ}
    config_dir = receipt_dir / "consumer_configs"
    results: list[dict[str, Any]] = []
    if not dry_run and os.environ.get(RECONCILE_CONSUMERS_ENV) != RECONCILE_CONSUMERS_VALUE:
        return [
            {
                "passed": False,
                "returncode": 17,
                "stderr": (
                    f"set {RECONCILE_CONSUMERS_ENV}={RECONCILE_CONSUMERS_VALUE} "
                    "to edit live canonical consumer configs"
                ),
            }
        ]

    for consumer in plan.consumers:
        consumer_key = f"{consumer.stream}/{consumer.durable}"
        if consumer.stream not in allowed_streams:
            continue
        if (consumer.stream, consumer.durable) not in observed:
            continue
        if consumer_key not in drifted_keys:
            continue
        config_dir.mkdir(parents=True, exist_ok=True)
        config_path = config_dir / f"{stamp()}-{consumer.stream}-{consumer.durable}.json"
        config_path.write_text(
            json.dumps(consumer_config_for_nats(consumer), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        command = (
            f"nats --context {shlex.quote(context)} consumer edit "
            f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} "
            f"--config {shlex.quote(str(config_path))} --force"
        )
        if dry_run:
            command += " --dry-run"
        result = _run_plan_step(command, timeout_s=timeout_s)
        result["consumer"] = consumer_key
        result["config_path"] = str(config_path)
        result["dry_run"] = dry_run
        results.append(result)
        if not result["passed"]:
            break
    return results


def _consumer_empty_for_replace(observed: LiveConsumerObservation) -> tuple[bool, str]:
    counters = {
        "num_ack_pending": observed.num_ack_pending,
        "num_pending": observed.num_pending,
        "num_redelivered": observed.num_redelivered,
        "num_waiting": observed.num_waiting,
    }
    unknown = [name for name, value in counters.items() if value is None]
    nonzero = [f"{name}={value}" for name, value in counters.items() if value not in (None, 0)]
    if unknown:
        return False, "unknown live counters: " + ", ".join(unknown)
    if nonzero:
        return False, "consumer is not empty: " + ", ".join(nonzero)
    return True, ""


def _replace_empty_consumer_configs(
    *,
    context: str,
    receipt_dir: Path,
    consumers: tuple[LiveConsumerObservation, ...],
    verification: object,
    timeout_s: int,
    dry_run: bool,
) -> list[dict[str, Any]]:
    plan = canonical_topology_plan()
    observed = {(consumer.stream, consumer.durable): consumer for consumer in consumers}
    drifted_keys = _drifted_consumer_keys(verification)
    allowed_streams = {A2A_INBOX, A2A_DLQ}
    config_dir = receipt_dir / "consumer_configs"
    results: list[dict[str, Any]] = []
    if not dry_run and os.environ.get(REPLACE_CONSUMERS_ENV) != REPLACE_CONSUMERS_VALUE:
        return [
            {
                "passed": False,
                "returncode": 17,
                "stderr": (
                    f"set {REPLACE_CONSUMERS_ENV}={REPLACE_CONSUMERS_VALUE} "
                    "to delete and recreate empty live canonical consumers"
                ),
            }
        ]

    for consumer in plan.consumers:
        consumer_key = f"{consumer.stream}/{consumer.durable}"
        observed_consumer = observed.get((consumer.stream, consumer.durable))
        if consumer.stream not in allowed_streams:
            continue
        if observed_consumer is None:
            continue
        if consumer_key not in drifted_keys:
            continue
        empty, blocker = _consumer_empty_for_replace(observed_consumer)
        if not empty:
            results.append(
                {
                    "consumer": consumer_key,
                    "dry_run": dry_run,
                    "passed": False,
                    "returncode": 18,
                    "stderr": blocker,
                }
            )
            break
        config_dir.mkdir(parents=True, exist_ok=True)
        config_path = config_dir / f"{stamp()}-{consumer.stream}-{consumer.durable}.json"
        config_path.write_text(
            json.dumps(consumer_config_for_nats(consumer), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        validate_command = (
            f"nats --context {shlex.quote(context)} consumer add "
            f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} "
            f"--config {shlex.quote(str(config_path))} --validate"
        )
        validate_result = _run_plan_step(validate_command, timeout_s=timeout_s)
        result: dict[str, Any] = {
            "consumer": consumer_key,
            "config_path": str(config_path),
            "dry_run": dry_run,
            "precondition": "empty",
            "validate": validate_result,
            "passed": validate_result["passed"],
        }
        if not validate_result["passed"] or dry_run:
            results.append(result)
            if not validate_result["passed"]:
                break
            continue

        remove_command = (
            f"nats --context {shlex.quote(context)} consumer rm "
            f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} --force"
        )
        add_command = (
            f"nats --context {shlex.quote(context)} consumer add "
            f"{shlex.quote(consumer.stream)} {shlex.quote(consumer.durable)} "
            f"--config {shlex.quote(str(config_path))} --defaults"
        )
        remove_result = _run_plan_step(remove_command, timeout_s=timeout_s)
        add_result = (
            _run_plan_step(add_command, timeout_s=timeout_s)
            if remove_result["passed"]
            else {
                "command": add_command,
                "returncode": 19,
                "stdout": "",
                "stderr": "skipped because consumer removal failed",
                "passed": False,
            }
        )
        result["remove"] = remove_result
        result["add"] = add_result
        result["passed"] = remove_result["passed"] and add_result["passed"]
        results.append(result)
        if not result["passed"]:
            break
    return results


def probe_live_topology(
    *,
    context: str,
    receipt_dir: Path = DEFAULT_RECEIPT_DIR,
    timeout_s: int = 20,
    apply_additive: bool = False,
    reconcile_consumers: bool = False,
    dry_run_reconcile: bool = False,
    replace_empty_consumers: bool = False,
    dry_run_replace: bool = False,
    cutover_topology: bool = False,
    dry_run_cutover: bool = False,
    canonical_consumers_only: bool = False,
) -> tuple[dict[str, Any], int]:
    streams = _stream_observations(context, timeout_s=timeout_s)
    kv_buckets = _kv_buckets(context, timeout_s=timeout_s)
    consumers = _consumer_observations(
        context,
        streams,
        timeout_s=timeout_s,
        canonical_consumers_only=canonical_consumers_only,
    )
    verification = verify_live_topology_observation(streams, kv_buckets, consumers=consumers)
    migration_plan = plan_live_topology_migration(
        streams,
        kv_buckets,
        consumers=consumers,
        context=context,
    )
    apply_results: list[dict[str, Any]] = []
    consumer_reconcile_results: list[dict[str, Any]] = []
    consumer_replace_results: list[dict[str, Any]] = []
    cutover_results: list[dict[str, Any]] = []
    cutover_rollback_plan = _cutover_rollback_plan(
        context=context,
        streams=streams,
        migration_plan=migration_plan,
    )
    cutover_transaction_plan = _cutover_transaction_plan(
        context=context,
        streams=streams,
        kv_buckets=kv_buckets,
        consumers=consumers,
        migration_plan=migration_plan,
        rollback_plan=cutover_rollback_plan,
    )
    mutation_performed = False
    if apply_additive:
        if os.environ.get(APPLY_ADDITIVE_ENV) != APPLY_ADDITIVE_VALUE:
            apply_results.append(
                {
                    "passed": False,
                    "returncode": 17,
                    "stderr": (
                        f"set {APPLY_ADDITIVE_ENV}={APPLY_ADDITIVE_VALUE} "
                        "to apply additive live topology steps"
                    ),
                }
            )
        else:
            additive_steps = [
                step
                for step in migration_plan.steps
                if step.phase == "additive" and not step.blocked
            ]
            for step in additive_steps:
                result = _run_plan_step(step.command, timeout_s=timeout_s)
                result["step_id"] = step.step_id
                result["action"] = step.action
                apply_results.append(result)
                mutation_performed = mutation_performed or result["passed"]
                if not result["passed"]:
                    break
            streams = _stream_observations(context, timeout_s=timeout_s)
            kv_buckets = _kv_buckets(context, timeout_s=timeout_s)
            consumers = _consumer_observations(
                context,
                streams,
                timeout_s=timeout_s,
                canonical_consumers_only=canonical_consumers_only,
            )
            verification = verify_live_topology_observation(
                streams,
                kv_buckets,
                consumers=consumers,
            )
            migration_plan = plan_live_topology_migration(
                streams,
                kv_buckets,
                consumers=consumers,
                context=context,
            )
            cutover_rollback_plan = _cutover_rollback_plan(
                context=context,
                streams=streams,
                migration_plan=migration_plan,
            )
            cutover_transaction_plan = _cutover_transaction_plan(
                context=context,
                streams=streams,
                kv_buckets=kv_buckets,
                consumers=consumers,
                migration_plan=migration_plan,
                rollback_plan=cutover_rollback_plan,
            )
    if cutover_topology:
        cutover_results = _run_cutover_topology(
            context=context,
            receipt_dir=receipt_dir,
            migration_plan=migration_plan,
            cutover_rollback_plan=cutover_rollback_plan,
            timeout_s=timeout_s,
            dry_run=dry_run_cutover,
        )
        mutation_performed = mutation_performed or any(
            result.get("passed") and not result.get("dry_run")
            for result in cutover_results
        )
        if mutation_performed and all(result.get("passed") for result in cutover_results):
            streams = _stream_observations(context, timeout_s=timeout_s)
            kv_buckets = _kv_buckets(context, timeout_s=timeout_s)
            consumers = _consumer_observations(
                context,
                streams,
                timeout_s=timeout_s,
                canonical_consumers_only=canonical_consumers_only,
            )
            verification = verify_live_topology_observation(
                streams,
                kv_buckets,
                consumers=consumers,
            )
            migration_plan = plan_live_topology_migration(
                streams,
                kv_buckets,
                consumers=consumers,
                context=context,
            )
            for step in _post_cutover_steps(migration_plan):
                result = _run_cutover_step(
                    context=context,
                    receipt_dir=receipt_dir,
                    step=step,
                    timeout_s=timeout_s,
                    dry_run=False,
                )
                cutover_results.append(result)
                mutation_performed = mutation_performed or result.get("passed", False)
                if not result["passed"]:
                    break
            streams = _stream_observations(context, timeout_s=timeout_s)
            kv_buckets = _kv_buckets(context, timeout_s=timeout_s)
            consumers = _consumer_observations(
                context,
                streams,
                timeout_s=timeout_s,
                canonical_consumers_only=canonical_consumers_only,
            )
            verification = verify_live_topology_observation(
                streams,
                kv_buckets,
                consumers=consumers,
            )
            migration_plan = plan_live_topology_migration(
                streams,
                kv_buckets,
                consumers=consumers,
                context=context,
            )
    if reconcile_consumers:
        consumer_reconcile_results = _reconcile_consumer_configs(
            context=context,
            receipt_dir=receipt_dir,
            consumers=consumers,
            verification=verification,
            timeout_s=timeout_s,
            dry_run=dry_run_reconcile,
        )
        mutation_performed = mutation_performed or any(
            result.get("passed") and not result.get("dry_run")
            for result in consumer_reconcile_results
        )
        if mutation_performed:
            streams = _stream_observations(context, timeout_s=timeout_s)
            kv_buckets = _kv_buckets(context, timeout_s=timeout_s)
            consumers = _consumer_observations(
                context,
                streams,
                timeout_s=timeout_s,
                canonical_consumers_only=canonical_consumers_only,
            )
            verification = verify_live_topology_observation(
                streams,
                kv_buckets,
                consumers=consumers,
            )
            migration_plan = plan_live_topology_migration(
                streams,
                kv_buckets,
                consumers=consumers,
                context=context,
            )
    if replace_empty_consumers:
        consumer_replace_results = _replace_empty_consumer_configs(
            context=context,
            receipt_dir=receipt_dir,
            consumers=consumers,
            verification=verification,
            timeout_s=timeout_s,
            dry_run=dry_run_replace,
        )
        replaced = any(
            result.get("passed") and not result.get("dry_run")
            for result in consumer_replace_results
        )
        mutation_performed = mutation_performed or replaced
        if replaced:
            streams = _stream_observations(context, timeout_s=timeout_s)
            kv_buckets = _kv_buckets(context, timeout_s=timeout_s)
            consumers = _consumer_observations(
                context,
                streams,
                timeout_s=timeout_s,
                canonical_consumers_only=canonical_consumers_only,
            )
            verification = verify_live_topology_observation(
                streams,
                kv_buckets,
                consumers=consumers,
            )
            migration_plan = plan_live_topology_migration(
                streams,
                kv_buckets,
                consumers=consumers,
                context=context,
            )
            if not cutover_results:
                cutover_rollback_plan = _cutover_rollback_plan(
                    context=context,
                    streams=streams,
                    migration_plan=migration_plan,
                )
                cutover_transaction_plan = _cutover_transaction_plan(
                    context=context,
                    streams=streams,
                    kv_buckets=kv_buckets,
                    consumers=consumers,
                    migration_plan=migration_plan,
                    rollback_plan=cutover_rollback_plan,
                )
    payload: dict[str, Any] = {
        "schema_version": "dharma.a2a.live_topology_probe.v1",
        "timestamp": utc_now(),
        "context": context,
        "canonical_consumers_only": canonical_consumers_only,
        "passed": verification.passed,
        "failures": list(verification.failures),
        "verification": verification.to_dict(),
        "migration_plan": migration_plan.to_dict(),
        "observed_streams": [stream.to_dict() for stream in streams],
        "observed_consumers": [consumer.to_dict() for consumer in consumers],
        "observed_kv_buckets": list(kv_buckets),
        "apply_additive_requested": apply_additive,
        "apply_results": apply_results,
        "consumer_reconcile_requested": reconcile_consumers,
        "consumer_reconcile_dry_run": dry_run_reconcile,
        "consumer_reconcile_results": consumer_reconcile_results,
        "consumer_replace_requested": replace_empty_consumers,
        "consumer_replace_dry_run": dry_run_replace,
        "consumer_replace_results": consumer_replace_results,
        "cutover_topology_requested": cutover_topology,
        "cutover_topology_dry_run": dry_run_cutover,
        "cutover_rollback_plan": cutover_rollback_plan,
        "cutover_transaction_plan": cutover_transaction_plan,
        "cutover_results": cutover_results,
        "mutation_performed": mutation_performed,
        "operator_note": (
            "read-only NATS topology probe unless --apply-additive is passed with "
            f"{APPLY_ADDITIVE_ENV}={APPLY_ADDITIVE_VALUE}; additive mode never edits "
            "legacy streams or cutover-blocked subjects. Consumer reconciliation requires "
            f"{RECONCILE_CONSUMERS_ENV}={RECONCILE_CONSUMERS_VALUE} and edits only "
            "existing canonical consumers on canonical streams. Empty-consumer replacement "
            f"requires {REPLACE_CONSUMERS_ENV}={REPLACE_CONSUMERS_VALUE}, validates "
            "the desired config, and fails closed unless live counters are zero. Legacy "
            f"stream cutover requires {CUTOVER_TOPOLOGY_ENV}={CUTOVER_TOPOLOGY_VALUE}; "
            "dry-run cutover never mutates and uses NATS CLI validation/dry-run flags. "
            "Cutover receipts include pre-cutover rollback commands derived from the "
            "observed stream subjects, plus a non-mutating transaction plan for the "
            "post-cutover steps that become unblocked after legacy subjects are narrowed."
        ),
    }
    receipt_path = _write_receipt(receipt_dir, payload)
    payload["receipt_path"] = str(receipt_path)
    return payload, 0 if verification.passed else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--context", default="agni-wss")
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--timeout-s", type=int, default=20)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--apply-additive", action="store_true")
    parser.add_argument("--reconcile-consumers", action="store_true")
    parser.add_argument("--dry-run-reconcile", action="store_true")
    parser.add_argument("--replace-empty-consumers", action="store_true")
    parser.add_argument("--dry-run-replace", action="store_true")
    parser.add_argument("--cutover-topology", action="store_true")
    parser.add_argument("--dry-run-cutover", action="store_true")
    parser.add_argument("--canonical-consumers-only", action="store_true")
    args = parser.parse_args(argv)

    try:
        payload, exit_code = probe_live_topology(
            context=args.context,
            receipt_dir=Path(args.receipt_dir),
            timeout_s=args.timeout_s,
            apply_additive=args.apply_additive,
            reconcile_consumers=args.reconcile_consumers,
            dry_run_reconcile=args.dry_run_reconcile,
            replace_empty_consumers=args.replace_empty_consumers,
            dry_run_replace=args.dry_run_replace,
            cutover_topology=args.cutover_topology,
            dry_run_cutover=args.dry_run_cutover,
            canonical_consumers_only=args.canonical_consumers_only,
        )
    except Exception as exc:
        payload = {
            "schema_version": "dharma.a2a.live_topology_probe.v1",
            "timestamp": utc_now(),
            "context": args.context,
            "passed": False,
            "failures": [f"{type(exc).__name__}: {exc}"],
            "mutation_performed": False,
        }
        receipt_path = _write_receipt(Path(args.receipt_dir), payload)
        payload["receipt_path"] = str(receipt_path)
        exit_code = 2

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_LIVE_TOPOLOGY_OK" if payload["passed"] else "A2A_LIVE_TOPOLOGY_DRIFT")
        for failure in payload["failures"]:
            print(f"- {failure}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
