#!/usr/bin/env python3
"""Render or execute live A2A/NATS ACL probes without printing secrets."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import SEED_AGENT_UIDS, resolve_agent_uids  # noqa: E402
from dharma_swarm.a2a.jetstream_topology import (  # noqa: E402
    AclProbeSpec,
    acl_probe_specs,
    safe_durable_token,
    verify_acl_probe_specs,
)


LIVE_ACL_PROBE_SCHEMA = "dharma.a2a.live_acl_probe.v1"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "live_acl"
LIVE_ACL_PROBE_ENV = "A2A_LIVE_ACL_PROBE"
LIVE_ACL_PROBE_VALUE = "approved-live-acl-probe"
COUNTED_AGENT_UIDS = SEED_AGENT_UIDS


@dataclass(frozen=True)
class ProbeCommand:
    probe: str
    agent_uid: str
    principal: str
    context: str
    expectation: str
    command: tuple[str, ...]
    mutates: bool
    rationale: str

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["command"] = list(self.command)
        return payload


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _context_for_principal(template: str, spec: AclProbeSpec) -> str:
    return template.format(agent_uid=spec.agent_uid, principal=spec.principal)


def _probe_commands_for_spec(spec: AclProbeSpec, *, context_template: str) -> tuple[ProbeCommand, ...]:
    context = _context_for_principal(context_template, spec)
    own_consumer = f"a2a_{safe_durable_token(spec.agent_uid)}_inbox"
    commands = [
        ProbeCommand(
            probe="publish_own_presence",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_zero",
            command=(
                "nats",
                "--context",
                context,
                "pub",
                f"dharma.presence.{spec.agent_uid}",
                "{}",
            ),
            mutates=True,
            rationale="positive ACL probe: principal can publish its own presence subject",
        ),
        ProbeCommand(
            probe="publish_own_receipt",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_zero",
            command=(
                "nats",
                "--context",
                context,
                "pub",
                f"dharma.a2a.receipt.{spec.agent_uid}",
                "{}",
            ),
            mutates=True,
            rationale="positive ACL probe: principal can publish its own receipt subject",
        ),
        ProbeCommand(
            probe="pull_own_inbox_consumer",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_zero",
            command=(
                "nats",
                "--context",
                context,
                "consumer",
                "info",
                "A2A_INBOX",
                own_consumer,
                "--json",
            ),
            mutates=False,
            rationale="positive ACL probe: principal can access its own durable binding",
        ),
        ProbeCommand(
            probe="ack_own_delivery",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_zero",
            command=(
                "nats",
                "--context",
                context,
                "consumer",
                "next",
                "A2A_INBOX",
                own_consumer,
                "--count",
                "1",
                "--ack",
                "--timeout",
                "1s",
            ),
            mutates=True,
            rationale="positive ACL probe: principal can ACK its own delivery when a probe message exists",
        ),
        ProbeCommand(
            probe="deny_pull_other_agent_inbox",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_nonzero",
            command=(
                "nats",
                "--context",
                context,
                "consumer",
                "info",
                "A2A_INBOX",
                "a2a_forbidden_other_agent_inbox",
                "--json",
            ),
            mutates=False,
            rationale="negative ACL probe: principal cannot inspect another agent durable",
        ),
        ProbeCommand(
            probe="deny_subscribe_broad_fleet_subjects",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_nonzero",
            command=(
                "nats",
                "--context",
                context,
                "sub",
                "dharma.a2a.>",
                "--count",
                "1",
                "--timeout",
                "1s",
            ),
            mutates=False,
            rationale="negative ACL probe: principal cannot subscribe to broad fleet subjects",
        ),
        ProbeCommand(
            probe="deny_mutate_streams_or_consumers",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_nonzero",
            command=(
                "nats",
                "--context",
                context,
                "stream",
                "add",
                f"_ACL_DENY_PROBE_{spec.principal}",
                "--subjects",
                f"_acl.deny.{spec.agent_uid}",
                "--dry-run",
                "--defaults",
            ),
            mutates=False,
            rationale="negative ACL probe: principal cannot call stream mutation APIs",
        ),
        ProbeCommand(
            probe="deny_insecure_tls_on_agni",
            agent_uid=spec.agent_uid,
            principal=spec.principal,
            context=context,
            expectation="returncode_nonzero",
            command=(
                "nats",
                "--context",
                context,
                "--tlsca",
                "",
                "server",
                "check",
                "connection",
            ),
            mutates=False,
            rationale="negative ACL probe: Agni production path must not accept insecure TLS mode",
        ),
    ]
    return tuple(commands)


def _write_receipt(receipt_dir: Path, payload: dict[str, Any]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{_stamp()}-a2a-live-acl-probe.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _run_command(command: tuple[str, ...], *, timeout_s: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(command),
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        timeout=timeout_s,
        check=False,
    )


def _probe_result(probe: ProbeCommand, *, timeout_s: int) -> dict[str, Any]:
    try:
        result = _run_command(probe.command, timeout_s=timeout_s)
        returncode = result.returncode
        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
    except subprocess.TimeoutExpired as exc:
        returncode = 124
        stdout = str(exc.stdout or "").strip()
        stderr = str(exc.stderr or "").strip() or f"timed out after {timeout_s}s"
    expected_zero = probe.expectation == "returncode_zero"
    passed = returncode == 0 if expected_zero else returncode != 0
    payload = probe.to_dict()
    payload.update(
        {
            "returncode": returncode,
            "stdout": stdout[-1000:],
            "stderr": stderr[-1000:],
            "passed": passed,
        }
    )
    return payload


def run_probe(
    *,
    receipt_dir: Path,
    agent: str,
    a2a_bus_root: Path | None = None,
    context_template: str,
    execute: bool,
    timeout_s: int,
) -> tuple[dict[str, Any], int]:
    counted_agents = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    specs = acl_probe_specs(counted_agents)
    verification = verify_acl_probe_specs(specs, counted_agent_uids=counted_agents)
    planned = [
        command
        for spec in specs
        for command in _probe_commands_for_spec(spec, context_template=context_template)
    ]
    failures = list(verification.failures)
    results: list[dict[str, Any]] = []
    execution_approved = os.environ.get(LIVE_ACL_PROBE_ENV) == LIVE_ACL_PROBE_VALUE
    if not execute:
        failures.append("live ACL probe execution not requested; dry-run rendered planned probes only")
    elif not execution_approved:
        failures.append(f"set {LIVE_ACL_PROBE_ENV}={LIVE_ACL_PROBE_VALUE} to execute live ACL probes")
    else:
        for probe in planned:
            result = _probe_result(probe, timeout_s=timeout_s)
            results.append(result)
            if not result["passed"]:
                failures.append(
                    f"{probe.agent_uid}:{probe.probe} expected {probe.expectation} "
                    f"but got returncode {result['returncode']}"
                )

    payload: dict[str, Any] = {
        "schema_version": LIVE_ACL_PROBE_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not failures,
        "failures": failures,
        "agent": agent,
        "counted_agents": list(counted_agents),
        "execution_requested": execute,
        "execution_approved": execution_approved,
        "approval_gate": f"{LIVE_ACL_PROBE_ENV}={LIVE_ACL_PROBE_VALUE}",
        "context_template": context_template,
        "acl_probe_contract": verification.to_dict(),
        "planned_probes": [probe.to_dict() for probe in planned],
        "probe_results": results,
        "live_acl_probe_verification": {
            "passed": not failures,
            "failures": failures,
            "checked_principals": list(verification.checked_principals),
            "positive_probes": sorted(
                {probe.probe for probe in planned if probe.expectation == "returncode_zero"}
            ),
            "negative_probes": sorted(
                {probe.probe for probe in planned if probe.expectation == "returncode_nonzero"}
            ),
        },
        "operator_note": (
            "Dry-run mode is non-mutating and cannot prove live ACL enforcement. "
            "Execution mode may publish probe presence/receipt messages and ACK an "
            "own delivery if a probe message exists; it requires explicit approval."
        ),
    }
    receipt_path = _write_receipt(receipt_dir, payload)
    payload["receipt_path"] = str(receipt_path)
    receipt_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--context-template", default="{principal}")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--timeout-s", type=int, default=10)
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        payload, exit_code = run_probe(
            receipt_dir=Path(args.receipt_dir).expanduser(),
            agent=args.agent,
            a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
            context_template=args.context_template,
            execute=bool(args.execute),
            timeout_s=args.timeout_s,
        )
    except Exception as exc:
        payload = {
            "schema_version": LIVE_ACL_PROBE_SCHEMA,
            "timestamp": _utc_now(),
            "passed": False,
            "failures": [f"{type(exc).__name__}: {exc}"],
        }
        receipt_path = _write_receipt(Path(args.receipt_dir).expanduser(), payload)
        payload["receipt_path"] = str(receipt_path)
        exit_code = 2
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_LIVE_ACL_PROBE_OK" if payload["passed"] else "A2A_LIVE_ACL_PROBE_NOT_READY")
        for failure in payload.get("failures", []):
            print(f"- {failure}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
