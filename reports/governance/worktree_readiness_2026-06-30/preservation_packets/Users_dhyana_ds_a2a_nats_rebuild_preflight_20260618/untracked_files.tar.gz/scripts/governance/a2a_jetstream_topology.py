#!/usr/bin/env python3
"""Verify and render the canonical A2A JetStream topology."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from dharma_swarm.a2a.jetstream_topology import (  # noqa: E402
    acl_probe_specs,
    canonical_topology_plan,
    render_nats_cli_commands,
    render_nats_consumer_configs,
    verify_acl_probe_specs,
    verify_topology_plan,
)
from scripts.runtime.pr_merge_control import stamp, utc_now  # noqa: E402


DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "topology"


def _write_receipt(receipt_dir: Path, payload: dict[str, object]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{stamp()}-a2a-jetstream-topology.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _parse_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent", default="all", help="all, seed, capability:<name>, role:<name>, or comma-separated agent UIDs")
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--commands", action="store_true", help="print live rollout command recipe")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    counted_agents = _parse_agents(
        args.agent,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
    )
    plan = canonical_topology_plan(counted_agents)
    verification = verify_topology_plan(plan, counted_agent_uids=counted_agents)
    acl_specs = acl_probe_specs(counted_agents)
    acl_verification = verify_acl_probe_specs(acl_specs, counted_agent_uids=counted_agents)
    commands = render_nats_cli_commands(plan)
    payload: dict[str, object] = {
        "schema_version": "dharma.a2a.jetstream_topology_verifier.v1",
        "timestamp": utc_now(),
        "passed": verification.passed and acl_verification.passed,
        "failures": list(verification.failures) + list(acl_verification.failures),
        "counted_agents": list(counted_agents),
        "plan": plan.to_dict(),
        "acl_probe_specs": [spec.to_dict() for spec in acl_specs],
        "acl_probe_verification": acl_verification.to_dict(),
        "commands": list(commands),
        "desired_consumer_configs": render_nats_consumer_configs(plan),
        "live_rollout_note": (
            "Commands are an operator recipe. Live application still requires "
            "Agni credentials and explicit operator approval."
        ),
    }
    receipt_path = _write_receipt(Path(args.receipt_dir), payload)
    payload["receipt_path"] = str(receipt_path)

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_JETSTREAM_TOPOLOGY_OK" if payload["passed"] else "A2A_JETSTREAM_TOPOLOGY_FAIL")
        for failure in payload["failures"]:
            print(f"- {failure}")
        print(f"receipt: {receipt_path}")
        if args.commands:
            for command in commands:
                print(command)
    return 0 if payload["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
