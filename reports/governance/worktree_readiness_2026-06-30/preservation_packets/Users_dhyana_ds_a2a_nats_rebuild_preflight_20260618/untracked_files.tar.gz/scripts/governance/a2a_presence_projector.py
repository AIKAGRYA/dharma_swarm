#!/usr/bin/env python3
"""Project transport evidence into explicit A2A presence rows."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_onboard, a2a_presence_preflight  # noqa: E402


PRESENCE_PROJECTOR_SCHEMA = "dharma.a2a.presence_projector.v1"
PRESENCE_PROJECTION_SCHEMA = "dharma.a2a.presence_projection.v1"
READY_PRESENCE_PROJECTED = "READY_PRESENCE_PROJECTED"
BLOCKED_PRESENCE_PROJECTION = "BLOCKED_PRESENCE_PROJECTION"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "presence_projection"
DEFAULT_A2A_BUS_ROOT = Path.home() / ".dharma" / "a2a_bus"


@dataclass(frozen=True)
class SourceCandidate:
    tier: str
    path: Path
    payload: dict[str, Any]
    timestamp: datetime | None
    timestamp_text: str


@dataclass(frozen=True)
class ProjectionRow:
    agent_uid: str
    final_state: str
    blockers: tuple[str, ...]
    projection_path: str
    write_performed: bool
    presence_evidence_tier: str
    source_paths: tuple[str, ...]
    source_sha256: str
    source_timestamp: str
    expires_at: str
    peer_model_processed_claim: bool
    target_owned_claim: bool
    semantic_receipt_path: str
    domain_receipt_path: str
    projection: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now_dt() -> datetime:
    return datetime.now(UTC)


def _utc_now() -> str:
    return _utc_now_dt().isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _iso(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _sha256_file(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return ""


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _parse_timestamp(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _timestamp_text(payload: dict[str, Any]) -> str:
    for key in ("last_heartbeat_at", "timestamp", "last_heartbeat", "last_seen", "last_updated", "updated_at"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if isinstance(agents, dict):
        return {str(uid): entry for uid, entry in agents.items() if isinstance(entry, dict)}
    return {str(uid): entry for uid, entry in payload.items() if isinstance(entry, dict)}


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _presence_json_entry(payload: dict[str, Any], agent_uid: str) -> dict[str, Any]:
    agents = payload.get("agents")
    if isinstance(agents, dict) and isinstance(agents.get(agent_uid), dict):
        return dict(agents[agent_uid])
    if isinstance(payload.get(agent_uid), dict):
        return dict(payload[agent_uid])
    if payload.get("agent_uid") == agent_uid:
        return dict(payload)
    return {}


def _source_candidates(a2a_bus_root: Path, agent_uid: str, agents: dict[str, dict[str, Any]]) -> list[SourceCandidate]:
    source_specs = (
        ("EXISTING_PRESENCE_PROJECTION", a2a_bus_root / "presence" / f"{agent_uid}.json"),
        ("PRESENCE_INDEX", a2a_bus_root / "presence.json"),
        ("BRIDGE_HEARTBEAT", a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json"),
        ("WORKER_HEARTBEAT", a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json"),
        ("STATE_RECORD", a2a_bus_root / "state" / f"{agent_uid}.json"),
        ("HEARTBEATS_INDEX", a2a_bus_root / "heartbeats.json"),
        ("REGISTRY_ENTRY", a2a_bus_root / "agents.json"),
    )
    candidates: list[SourceCandidate] = []
    for tier, path in source_specs:
        payload = _load_json(path)
        if tier in {"PRESENCE_INDEX", "HEARTBEATS_INDEX", "REGISTRY_ENTRY"}:
            payload = _presence_json_entry(payload, agent_uid)
        if not payload and tier == "REGISTRY_ENTRY":
            payload = dict(agents.get(agent_uid, {}))
        if not payload:
            continue
        timestamp_text = _timestamp_text(payload)
        candidates.append(
            SourceCandidate(
                tier=tier,
                path=path,
                payload=payload,
                timestamp=_parse_timestamp(timestamp_text),
                timestamp_text=timestamp_text,
            )
        )
    return candidates


def _best_source(candidates: list[SourceCandidate]) -> SourceCandidate | None:
    timestamped = [candidate for candidate in candidates if candidate.timestamp is not None]
    if timestamped:
        return max(timestamped, key=lambda candidate: candidate.timestamp or datetime.min.replace(tzinfo=UTC))
    return candidates[0] if candidates else None


def _receipt_timestamp(path_text: str, repo_root: Path) -> str:
    if not path_text:
        return ""
    path = Path(path_text)
    if not path.is_absolute():
        path = repo_root / path
    payload = _load_json(path)
    timestamp = str(payload.get("timestamp") or payload.get("created_at") or "")
    if timestamp:
        return timestamp
    try:
        return _iso(datetime.fromtimestamp(path.stat().st_mtime, UTC))
    except OSError:
        return ""


def _latest_handler_ack_timestamp(agent_uid: str, a2a_bus_root: Path) -> str:
    candidates = [
        path
        for path in (a2a_bus_root / "inboxes").glob("**/*.json")
        if path.is_file() and (agent_uid in path.name or agent_uid in str(path.parent))
    ]
    if not candidates:
        return ""
    latest = max(candidates, key=lambda path: path.stat().st_mtime)
    return _receipt_timestamp(str(latest), Path("/"))


def _transport_state(source: SourceCandidate | None, handler_ack_at: str) -> str:
    if handler_ack_at:
        return "HANDLER_ACKED"
    if source is None:
        return "NO_PRESENCE_EVIDENCE"
    status = str(source.payload.get("transport_state") or source.payload.get("status") or "").strip()
    if status and source.tier == "EXISTING_PRESENCE_PROJECTION":
        return status
    return source.tier


def _projection_for_agent(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    broker: str,
    domain: str,
    ttl_seconds: int,
    write_projections: bool,
) -> ProjectionRow:
    blockers: list[str] = []
    agent_entry = agents.get(agent_uid, {})
    if not agent_entry:
        blockers.append("missing canonical registry entry")
    candidates = _source_candidates(a2a_bus_root, agent_uid, agents)
    source = _best_source(candidates)
    heartbeat_at = source.timestamp if source else None
    heartbeat_text = _iso(heartbeat_at) if heartbeat_at else ""
    expires_at = _iso(heartbeat_at + timedelta(seconds=ttl_seconds)) if heartbeat_at else ""
    now = _utc_now_dt()
    if source is None:
        blockers.append("missing source evidence")
    elif heartbeat_at is None:
        blockers.append("source evidence timestamp is missing or invalid")
    else:
        if (now - heartbeat_at).total_seconds() > ttl_seconds:
            blockers.append(f"source evidence is stale beyond {ttl_seconds}s")
        if heartbeat_at + timedelta(seconds=ttl_seconds) <= now:
            blockers.append("source evidence projects expired presence")

    semantic_path = a2a_onboard._last_valid_semantic_receipt_path(agent_uid, repo_root)
    domain_path = a2a_onboard._last_valid_domain_effect_receipt_path(agent_uid, repo_root)
    peer_model_processed_claim = bool(semantic_path)
    handler_ack_at = _latest_handler_ack_timestamp(agent_uid, a2a_bus_root)
    model_state = a2a_onboard.SEMANTIC_SIGNED if peer_model_processed_claim else "REQUIRED_NOT_BUILT"
    source_payload = source.payload if source else {}
    projection = {
        "schema_version": PRESENCE_PROJECTION_SCHEMA,
        "agent_uid": agent_uid,
        "broker": broker,
        "domain": domain,
        "inbox_subject": f"dharma.agent.{agent_uid}.inbox",
        "durable_consumer": f"a2a_{a2a_presence_preflight._safe_token(agent_uid)}_inbox",
        "transport_state": _transport_state(source, handler_ack_at),
        "model_state": model_state,
        "tempo_tier": str(source_payload.get("tempo_tier") or agent_entry.get("tempo_tier") or ""),
        "authority_status": str(
            source_payload.get("authority_status")
            or agent_entry.get("authority_status")
            or agent_entry.get("authority")
            or ""
        ),
        "last_heartbeat_at": heartbeat_text,
        "last_handler_ack_at": handler_ack_at,
        "last_domain_receipt_at": _receipt_timestamp(domain_path, repo_root),
        "last_semantic_receipt_at": _receipt_timestamp(semantic_path, repo_root),
        "peer_model_processed_claim": peer_model_processed_claim,
        "last_error": str(source_payload.get("last_error") or ""),
        "expires_at": expires_at,
        "projection_timestamp": _utc_now(),
        "presence_evidence_tier": source.tier if source else "NO_EVIDENCE",
        "source_paths": [_relative_or_absolute(candidate.path, repo_root) for candidate in candidates],
        "source_timestamps": [candidate.timestamp_text for candidate in candidates if candidate.timestamp_text],
        "source_sha256": _sha256_file(source.path) if source else "",
        "semantic_receipt_path": semantic_path,
        "domain_receipt_path": domain_path,
        "target_owned_claim": False,
        "operator_note": (
            "Presence projection only. Transport heartbeat evidence does not prove "
            "the target model processed a task; peer_model_processed_claim is true "
            "only when a valid semantic receipt already exists."
        ),
    }
    missing_fields = [
        field for field in a2a_presence_preflight.REQUIRED_PRESENCE_FIELDS if field not in projection
    ]
    if missing_fields:
        blockers.append("projection missing required fields: " + ", ".join(missing_fields))

    projection_path = a2a_bus_root / "presence" / f"{agent_uid}.json"
    write_performed = False
    if write_projections and source is not None:
        _write_json(projection_path, projection)
        write_performed = True

    unique_blockers = tuple(dict.fromkeys(blockers))
    return ProjectionRow(
        agent_uid=agent_uid,
        final_state=READY_PRESENCE_PROJECTED if not unique_blockers else BLOCKED_PRESENCE_PROJECTION,
        blockers=unique_blockers,
        projection_path=_relative_or_absolute(projection_path, repo_root),
        write_performed=write_performed,
        presence_evidence_tier=str(projection["presence_evidence_tier"]),
        source_paths=tuple(projection["source_paths"]),
        source_sha256=str(projection["source_sha256"]),
        source_timestamp=heartbeat_text,
        expires_at=expires_at,
        peer_model_processed_claim=peer_model_processed_claim,
        target_owned_claim=False,
        semantic_receipt_path=semantic_path,
        domain_receipt_path=domain_path,
        projection=projection,
    )


def run_projection(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_dir: Path,
    agent: str,
    broker: str,
    domain: str,
    ttl_seconds: int,
    write_projections: bool,
) -> tuple[dict[str, Any], int]:
    agents = _nested_agents(_load_json(a2a_bus_root / "agents.json"))
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    rows = [
        _projection_for_agent(
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            agents=agents,
            agent_uid=agent_uid,
            broker=broker,
            domain=domain,
            ttl_seconds=ttl_seconds,
            write_projections=write_projections,
        )
        for agent_uid in selected
    ]
    blockers = [f"{row.agent_uid}: {blocker}" for row in rows for blocker in row.blockers]
    payload: dict[str, Any] = {
        "schema_version": PRESENCE_PROJECTOR_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "broker": broker,
        "domain": domain,
        "ttl_seconds": ttl_seconds,
        "dry_run": not write_projections,
        "mutation_performed": write_projections,
        "write_destination": str(a2a_bus_root / "presence"),
        "required_presence_fields": list(a2a_presence_preflight.REQUIRED_PRESENCE_FIELDS),
        "rows": [row.to_dict() for row in rows],
        "blockers": list(dict.fromkeys(blockers)),
        "operator_note": (
            "Default mode writes only this receipt. Use --write-projections to "
            "write presence/<agent_uid>.json projection rows. The projector never "
            "turns heartbeat evidence into semantic/model proof."
        ),
    }
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}-a2a-presence-projector.json"
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    _write_json(receipt_path, payload)
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(DEFAULT_A2A_BUS_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--domain", default="agni")
    parser.add_argument("--ttl-seconds", type=int, default=a2a_presence_preflight.DEFAULT_TTL_SECONDS)
    parser.add_argument("--write-projections", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    payload, exit_code = run_projection(
        repo_root=repo_root,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
        receipt_dir=receipt_dir,
        agent=args.agent,
        broker=args.broker,
        domain=args.domain,
        ttl_seconds=args.ttl_seconds,
        write_projections=args.write_projections,
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_PRESENCE_PROJECTOR_OK" if payload["passed"] else "A2A_PRESENCE_PROJECTOR_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            print(f"  source: {row['presence_evidence_tier']}")
            print(f"  projection: {row['projection_path']}")
            for blocker in row["blockers"]:
                print(f"  * {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
