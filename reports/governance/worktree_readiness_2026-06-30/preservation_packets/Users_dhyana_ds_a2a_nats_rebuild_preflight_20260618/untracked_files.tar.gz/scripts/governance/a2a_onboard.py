#!/usr/bin/env python3
"""Prevalidate the A2A/NATS onboarding contract and write typed receipts."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import uuid
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from dharma_swarm.a2a.agent_roster import (
    SEED_AGENT_UIDS,
    resolve_agent_selection,
)
from dharma_swarm.a2a.jetstream_topology import (
    principal_for_agent,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
LOCKED_SPEC_PATH = "docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md"
LOCKED_SPEC_SHA256 = "e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899"
DOMAIN_RECEIPT_SCHEMA = "dharma.a2a.domain_receipt.v1"
SEMANTIC_RECEIPT_SCHEMA = "dharma.a2a.semantic_receipt.v1"
ONBOARD_RECEIPT_SCHEMA = "dharma.a2a.onboard_receipt.v1"
DOMAIN_RECEIPTED = "DOMAIN_RECEIPTED"
SEMANTIC_SIGNED = "SEMANTIC_SIGNED"
LIVE_APPROVAL_ENV = "A2A_LIVE_OPERATOR_APPROVAL"
LIVE_APPROVAL_VALUE = "approved-a2a-live"

COUNTED_AGENT_UIDS = tuple(SEED_AGENT_UIDS)

EXIT_CODES = {
    "READY_PREVALIDATED": 0,
    "READY_LIVE": 0,
    "BLOCKED_IDENTITY": 10,
    "BLOCKED_CONFIG": 11,
    "BLOCKED_SECRET_REFERENCE": 12,
    "BLOCKED_TRANSPORT_CONFIG": 13,
    "BLOCKED_DURABLE": 14,
    "BLOCKED_RECEIPT_SCHEMA": 15,
    "BLOCKED_WAKE_LOOP": 16,
    "BLOCKED_LIVE_CALL_FORBIDDEN": 17,
    "BLOCKED_PUBLISH": 20,
    "BLOCKED_HANDLER_ACK": 21,
    "BLOCKED_DOMAIN_RECEIPT": 22,
    "BLOCKED_SEMANTIC_RECEIPT": 23,
    "DEGRADED_SESSION_SCOPED": 30,
    "STREAM_MISMATCH": 31,
    "DURABLE_NAME_COLLISION": 32,
    "INTERNAL_ERROR": 99,
}

BROKER_PROFILES = {
    "agni": {
        "domain": "agni",
        "endpoint": "nats://agni:4222",
        "tls_status": "REFERENCE_REQUIRED",
        "secret_env": (
            "AGNI_NATS_URL",
            "AGNI_NATS_CREDS",
            "AGNI_NATS_NKEY",
            "AGNI_NATS_CONTEXT",
            "NATS_URL",
            "NATS_CONTEXT",
        ),
        "leaf_status": "GLOBAL_SOT_REFERENCE",
    },
    "mac": {
        "domain": "mac",
        "endpoint": "nats://127.0.0.1:4222",
        "tls_status": "LOCAL_DEV_REFERENCE",
        "secret_env": ("NATS_URL", "NATS_CREDS", "NATS_NKEY", "NATS_CONTEXT"),
        "leaf_status": "EDGE_REFERENCE",
    },
}

STATE_PRIORITY = (
    "BLOCKED_IDENTITY",
    "BLOCKED_CONFIG",
    "STREAM_MISMATCH",
    "DURABLE_NAME_COLLISION",
    "BLOCKED_RECEIPT_SCHEMA",
    "BLOCKED_SECRET_REFERENCE",
    "BLOCKED_LIVE_CALL_FORBIDDEN",
    "BLOCKED_WAKE_LOOP",
    "DEGRADED_SESSION_SCOPED",
    "BLOCKED_DOMAIN_RECEIPT",
    "BLOCKED_SEMANTIC_RECEIPT",
    "READY_PREVALIDATED",
)


@dataclass(frozen=True)
class AgentOnboardRow:
    agent_uid: str
    broker: str
    domain: str
    inbox_subject: str
    durable_consumer: str
    principal: str
    tls_status: str
    leaf_status: str
    stream_status: str
    transport_state: str
    handler_ack_state: str
    domain_receipt_state: str
    semantic_receipt_state: str
    presence_age_hours: float | None
    last_handler_ack: str
    last_domain_receipt: str
    last_semantic_receipt: str
    wake_loop_state: str
    failure_states: tuple[str, ...]
    final_state: str
    exit_code: int
    remediation: list[str]
    operator_commands: dict[str, str]
    evidence_paths: list[str]


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _safe_token(value: object, *, fallback: str = "unknown") -> str:
    chars = [char if char.isalnum() or char in ("_", "-") else "_" for char in str(value or "")]
    return ("".join(chars).strip("_-") or fallback)[:96]


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    path.write_text(data, encoding="utf-8")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _parse_timestamp(value: object) -> datetime | None:
    if not value:
        return None
    text = str(value)
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _age_hours(value: object) -> float | None:
    parsed = _parse_timestamp(value)
    if parsed is None:
        return None
    return max(0.0, (datetime.now(UTC) - parsed).total_seconds() / 3600.0)


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if not isinstance(agents, dict):
        return {}
    return {str(uid): entry for uid, entry in agents.items() if isinstance(entry, dict)}


def _first_timestamp(*payloads: dict[str, Any]) -> str:
    keys = ("timestamp", "last_heartbeat", "last_seen", "last_updated", "updated_at", "created_at")
    for payload in payloads:
        for key in keys:
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value
    return ""


def _last_receipt_path(agent_uid: str, root: Path, patterns: tuple[str, ...]) -> str:
    candidates: list[Path] = []
    for pattern in patterns:
        candidates.extend(path for path in root.glob(pattern) if path.is_file())
    filtered = [
        path
        for path in candidates
        if agent_uid in path.name or agent_uid in str(path.parent)
    ]
    if not filtered:
        return ""
    latest = max(filtered, key=lambda path: path.stat().st_mtime)
    try:
        return str(latest.relative_to(root))
    except ValueError:
        return str(latest)


def _is_valid_domain_effect_receipt(payload: dict[str, Any]) -> bool:
    status = str(payload.get("status") or "")
    schema = str(payload.get("schema_version") or payload.get("schema") or "")
    if schema == DOMAIN_RECEIPT_SCHEMA and payload.get("domain_receipt") is True:
        return True
    if status in {DOMAIN_RECEIPTED, SEMANTIC_SIGNED, "DOMAIN_REPLY_PUBLISHED"}:
        return payload.get("domain_receipt_claim") is True or payload.get("domain_receipt") is True
    return False


def _last_valid_domain_effect_receipt_path(agent_uid: str, repo_root: Path) -> str:
    candidates: list[Path] = []
    for pattern in (
        "reports/a2a/domain_reply_receipts/**/*.json",
        "reports/a2a/reply_receipts/**/*.json",
    ):
        candidates.extend(path for path in repo_root.glob(pattern) if path.is_file())
    filtered = [
        path
        for path in candidates
        if agent_uid in path.name or agent_uid in str(path.parent)
    ]
    for path in sorted(filtered, key=lambda item: item.stat().st_mtime, reverse=True):
        payload = _load_json(path)
        if _is_valid_domain_effect_receipt(payload):
            return _relative_or_absolute(path, repo_root)
    return ""


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _semantic_hash_value(value: object) -> str:
    text = str(value or "").strip()
    return text.removeprefix("sha256:").strip()


def _semantic_source_artifact_failures(payload: dict[str, Any], *, repo_root: Path) -> list[str]:
    expected_hash = _semantic_hash_value(payload.get("source_artifact_sha256"))
    source_path_raw = str(payload.get("source_artifact_path") or "").strip()
    if not expected_hash:
        return []
    if not source_path_raw:
        return ["semantic receipt source_artifact_sha256 has no source_artifact_path"]
    source_path = Path(source_path_raw).expanduser()
    if not source_path.is_absolute():
        source_path = repo_root / source_path
    if not source_path.exists():
        return ["semantic receipt source_artifact_path does not exist"]
    actual_hash = _semantic_hash_value(_sha256_file(source_path))
    if actual_hash != expected_hash:
        return ["semantic receipt source_artifact_sha256 does not match source_artifact_path"]
    return []


def _semantic_receipt_validation_failures(
    payload: dict[str, Any],
    *,
    agent_uid: str,
    locked_spec_sha256: str,
    repo_root: Path | None = None,
) -> list[str]:
    failures: list[str] = []
    if payload.get("schema_version") != SEMANTIC_RECEIPT_SCHEMA:
        failures.append("wrong semantic receipt schema")
    if payload.get("status") != SEMANTIC_SIGNED:
        failures.append("semantic receipt status is not SEMANTIC_SIGNED")
    if payload.get("agent_uid") != agent_uid:
        failures.append("semantic receipt agent_uid does not match onboard row")
    if payload.get("locked_spec_sha256") != locked_spec_sha256:
        failures.append("semantic receipt locked_spec_sha256 does not match current locked spec")
    if not str(payload.get("task_hash") or "").strip():
        failures.append("semantic receipt missing task_hash")
    if not str(payload.get("model_identity") or "").strip():
        failures.append("semantic receipt missing model_identity")
    if payload.get("peer_model_processed_claim") is not True:
        failures.append("semantic receipt missing peer_model_processed_claim=true")
    if payload.get("semantic_reply_claim") is not True:
        failures.append("semantic receipt missing semantic_reply_claim=true")
    confidence = payload.get("confidence")
    if not isinstance(confidence, int | float) or isinstance(confidence, bool) or not 0.0 <= float(confidence) <= 1.0:
        failures.append("semantic receipt confidence must be between 0 and 1")
    evidence_refs = payload.get("evidence_refs")
    if not isinstance(evidence_refs, list) or not evidence_refs:
        failures.append("semantic receipt evidence_refs must be non-empty")
    if not str(payload.get("failure_digest") or "").strip():
        failures.append("semantic receipt missing failure_digest")
    if not str(payload.get("source_artifact_sha256") or payload.get("domain_receipt_sha256") or "").strip():
        failures.append("semantic receipt missing recomputable source/domain hash")
    if repo_root is not None:
        failures.extend(_semantic_source_artifact_failures(payload, repo_root=repo_root))
    return failures


def _last_valid_semantic_receipt_path(agent_uid: str, repo_root: Path) -> str:
    candidates: list[Path] = []
    for pattern in (
        "reports/a2a/semantic_receipts/**/*.json",
        "reports/a2a/reply_receipts/**/*semantic*.json",
    ):
        candidates.extend(path for path in repo_root.glob(pattern) if path.is_file())
    filtered = [
        path
        for path in candidates
        if agent_uid in path.name or agent_uid in str(path.parent)
    ]
    for path in sorted(filtered, key=lambda item: item.stat().st_mtime, reverse=True):
        payload = _load_json(path)
        if not _semantic_receipt_validation_failures(
            payload,
            agent_uid=agent_uid,
            locked_spec_sha256=LOCKED_SPEC_SHA256,
            repo_root=repo_root,
        ):
            return _relative_or_absolute(path, repo_root)
    return ""


def _selected_agents(
    agent: str,
    *,
    a2a_bus_root: Path | None = None,
    cohort: str | None = None,
) -> list[str]:
    return list(
        resolve_agent_selection(
            agent,
            cohort=cohort,
            a2a_bus_root=a2a_bus_root,
        ).agent_uids
    )


def _spec_state_from_failures(failures: list[str]) -> str:
    if not failures:
        return "READY_PREVALIDATED"
    for state in STATE_PRIORITY:
        if state in failures:
            return state
    return "BLOCKED_CONFIG"


def _remediation_for(state: str, agent_uid: str, broker: str) -> list[str]:
    if state == "BLOCKED_IDENTITY":
        return [f"Register canonical agent {agent_uid} in ~/.dharma/a2a_bus/agents.json."]
    if state == "BLOCKED_SECRET_REFERENCE":
        return [
            f"Add {broker} NATS credential references, e.g. AGNI_NATS_URL/CREDS or NATS_CONTEXT=agni-wss."
        ]
    if state == "BLOCKED_WAKE_LOOP":
        return [f"Start or register a receipt-producing wake loop for {agent_uid}; bridge ACKs alone do not qualify."]
    if state == "DEGRADED_SESSION_SCOPED":
        return [f"Promote {agent_uid} from session/evidence-only to a standing loop before READY_LIVE claims."]
    if state == "BLOCKED_SEMANTIC_RECEIPT":
        return [f"Produce a model-processed semantic receipt for {agent_uid}; DOMAIN_RECEIPTED is not SEMANTIC_SIGNED."]
    if state == "BLOCKED_DOMAIN_RECEIPT":
        return [f"Produce a target-owned domain effect receipt for {agent_uid}; onboard verifier receipts do not qualify."]
    if state == "BLOCKED_LIVE_CALL_FORBIDDEN":
        return [f"Set {LIVE_APPROVAL_ENV}={LIVE_APPROVAL_VALUE} only after explicit operator approval for live A2A calls."]
    if state == "STREAM_MISMATCH":
        return ["Install or verify A2A_INBOX/A2A_TASKS/A2A_RECEIPTS/A2A_DLQ; DHARMA_* names are aliases only."]
    if state == "BLOCKED_CONFIG":
        return ["Fix the locked spec copy or broker profile before onboarding."]
    return []


def _remediation_for_states(states: list[str], agent_uid: str, broker: str) -> list[str]:
    remediations: list[str] = []
    for state in states:
        for item in _remediation_for(state, agent_uid, broker):
            if item not in remediations:
                remediations.append(item)
    return remediations


def _operator_commands_for(agent_uid: str, *, broker: str, mode: str) -> dict[str, str]:
    durable = f"a2a_{_safe_token(agent_uid)}_inbox"
    context = "${NATS_CONTEXT:-agni-wss}"
    packet = f"reports/a2a/semantic_tasks/{_safe_token(agent_uid)}-packet.md"
    outbox_artifact = f"~/.dharma/a2a_bus/outboxes/{agent_uid}/<packet_id>.json"
    semantic_receipt = f"reports/a2a/semantic_receipts/<timestamp>-{_safe_token(agent_uid)}-semantic.json"
    return {
        "onboard_json": (
            f"make a2a-onboard AGENT={agent_uid} BROKER={broker} MODE={mode} "
            "ARGS='--json'"
        ),
        "verify_consumer": (
            f"nats --context {context} consumer info A2A_INBOX {durable} --json"
        ),
        "publish_presence": (
            f"nats --context {context} pub dharma.presence.{agent_uid} "
            f"'{{\"agent_uid\":\"{agent_uid}\",\"status\":\"online\"}}'"
        ),
        "render_semantic_task_packet": (
            f"make a2a-semantic-task-packet AGENT={agent_uid} BROKER={broker} "
            f"MODE={mode} ARGS='--json'"
        ),
        "identity_reconcile": (
            f"make a2a-identity-reconcile AGENT={agent_uid} "
            "ARGS='--json'"
        ),
        "project_presence": (
            f"make a2a-presence-projector AGENT={agent_uid} BROKER={broker} "
            "ARGS='--json'"
        ),
        "write_presence_projection": (
            f"make a2a-presence-projector AGENT={agent_uid} BROKER={broker} "
            "ARGS='--write-projections --json'"
        ),
        "presence_preflight": (
            f"make a2a-presence-preflight AGENT={agent_uid} BROKER={broker} "
            "ARGS='--json'"
        ),
        "send_hot_contact": (
            "PYTHONPATH=. python3 scripts/runtime/a2a_send.py "
            f"--route agent-inbox --to {agent_uid} --agent-uid {agent_uid} "
            f"--from operator --file {packet} --wait 30 --json"
        ),
        "wake_loop_preflight": (
            f"make a2a-wake-loop-preflight AGENT={agent_uid} BROKER={broker} "
            f"MODE={mode} ARGS='--json'"
        ),
        "standing_agent_preflight": (
            f"make a2a-standing-agent-preflight AGENT={agent_uid} BROKER={broker} "
            "ARGS='--json'"
        ),
        "start_standing_wake_loop": (
            f"A2A_STANDING_WAKE_LOOP_AGENT={agent_uid} make a2a-standing-wake-loop "
            f"AGENT={agent_uid} ARGS='--json'"
        ),
        "capture_reply": (
            "PYTHONPATH=. python3 scripts/runtime/a2a_reply_capture.py "
            f"--send-receipt <send_receipt_path> --context {context} "
            "--stream A2A_INBOX --json"
        ),
        "preflight_domain_reply_artifact": (
            f"make a2a-domain-reply-artifact-preflight AGENT={agent_uid} "
            "ARGS='--json'"
        ),
        "render_domain_reply_request": (
            f"make a2a-domain-reply-request AGENT={agent_uid} "
            "ARGS='--json'"
        ),
        "write_domain_reply_artifact": (
            f"A2A_DOMAIN_REPLY_ARTIFACT_AGENT={agent_uid} "
            f"make a2a-domain-reply-artifact AGENT={agent_uid} "
            "ARGS='--delivery-record <delivery_record_path> "
            "--send-receipt <send_receipt_path> "
            "--summary <target-authored-summary> "
            "--peer-model-processed --semantic-reply "
            "--model-identity <provider/model> --confidence <0..1> "
            "--failure-digest <confused/tried/failed/worked> "
            "--evidence-ref <evidence_path> --json'"
        ),
        "publish_domain_receipt": (
            "PYTHONPATH=. python3 scripts/runtime/a2a_domain_reply_worker.py "
            "--send-receipt <send_receipt_path> "
            f"--reply-artifact {outbox_artifact} --agent-uid {agent_uid} --json"
        ),
        "write_semantic_receipt": (
            f"write {SEMANTIC_RECEIPT_SCHEMA} to {semantic_receipt} with "
            f"agent_uid={agent_uid}, locked_spec_sha256={LOCKED_SPEC_SHA256}, "
            "peer_model_processed_claim=true, semantic_reply_claim=true, "
            "task_hash=<sha256>, failure_digest=<what_confused_me/what_failed/what_worked>, "
            "source_artifact_sha256=<sha256>"
        ),
        "prove_live_acl": (
            f"make a2a-live-acl-probe AGENT={agent_uid} "
            "ARGS='--execute --json' after explicit "
            "A2A_LIVE_ACL_PROBE=approved-live-acl-probe approval"
        ),
    }


def _agent_row(
    agent_uid: str,
    *,
    broker: str,
    mode: str,
    repo_root: Path,
    a2a_bus_root: Path,
    agents: dict[str, dict[str, Any]],
    heartbeats: dict[str, dict[str, Any]],
) -> AgentOnboardRow:
    profile = BROKER_PROFILES[broker]
    state_payload = _load_json(a2a_bus_root / "state" / f"{agent_uid}.json")
    bridge_payload = _load_json(a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json")
    worker_payload = _load_json(a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json")
    agent_entry = agents.get(agent_uid, {})
    heartbeat_entry = heartbeats.get(agent_uid, {})

    failures: list[str] = []
    evidence_paths: list[str] = []
    if agent_uid not in agents:
        failures.append("BLOCKED_IDENTITY")
    else:
        evidence_paths.append(str(a2a_bus_root / "agents.json"))

    locked_spec = repo_root / LOCKED_SPEC_PATH
    if not locked_spec.exists() or _sha256_file(locked_spec) != LOCKED_SPEC_SHA256:
        failures.append("BLOCKED_CONFIG")
    else:
        evidence_paths.append(LOCKED_SPEC_PATH)

    if mode == "live" and os.environ.get(LIVE_APPROVAL_ENV) != LIVE_APPROVAL_VALUE:
        failures.append("BLOCKED_LIVE_CALL_FORBIDDEN")

    stream_status = "A2A_STREAMS_DECLARED"
    if broker == "agni" and not any(os.environ.get(name) for name in profile["secret_env"]):
        failures.append("BLOCKED_SECRET_REFERENCE")

    wake_loop_state = str(
        bridge_payload.get("status")
        or worker_payload.get("status")
        or state_payload.get("status")
        or agent_entry.get("status")
        or heartbeat_entry.get("status")
        or "missing"
    )
    session_scoped = str(agent_entry.get("authority") or state_payload.get("authority") or "").endswith(
        "evidence_only"
    ) or str(agent_entry.get("type") or "").endswith("-cli")
    if not bridge_payload and not worker_payload and not bool(agent_entry.get("wake_loop_active")):
        failures.append("BLOCKED_WAKE_LOOP")
    elif session_scoped:
        failures.append("DEGRADED_SESSION_SCOPED")

    if agent_uid == "qwen_code":
        failures.append("DEGRADED_SESSION_SCOPED")

    presence_at = _first_timestamp(bridge_payload, worker_payload, state_payload, heartbeat_entry, agent_entry)
    last_handler_ack = _last_receipt_path(agent_uid, a2a_bus_root, ("inboxes/**/*.json",))
    last_domain_receipt = _last_valid_domain_effect_receipt_path(agent_uid, repo_root)
    last_semantic_receipt = _last_valid_semantic_receipt_path(agent_uid, repo_root)
    if not last_domain_receipt:
        failures.append("BLOCKED_DOMAIN_RECEIPT")
    if not last_semantic_receipt:
        failures.append("BLOCKED_SEMANTIC_RECEIPT")
    failure_states = list(dict.fromkeys(failures))
    final_state = _spec_state_from_failures(failures)
    handler_ack_state = "HANDLER_ACKED" if last_handler_ack else "NO_HANDLER_ACK"
    domain_receipt_state = DOMAIN_RECEIPTED if last_domain_receipt else "REQUIRED_NOT_BUILT"
    semantic_receipt_state = SEMANTIC_SIGNED if last_semantic_receipt else "REQUIRED_NOT_BUILT"
    return AgentOnboardRow(
        agent_uid=agent_uid,
        broker=broker,
        domain=str(profile["domain"]),
        inbox_subject=f"dharma.agent.{agent_uid}.inbox",
        durable_consumer=f"a2a_{_safe_token(agent_uid)}_inbox",
        principal=principal_for_agent(agent_uid),
        tls_status=str(profile["tls_status"]),
        leaf_status=str(profile["leaf_status"]),
        stream_status=stream_status,
        transport_state="TRANSPORT_CONFIG_VALID",
        handler_ack_state=handler_ack_state,
        domain_receipt_state=domain_receipt_state,
        semantic_receipt_state=semantic_receipt_state,
        presence_age_hours=round(_age_hours(presence_at), 3) if presence_at else None,
        last_handler_ack=last_handler_ack,
        last_domain_receipt=last_domain_receipt,
        last_semantic_receipt=last_semantic_receipt,
        wake_loop_state=wake_loop_state,
        failure_states=tuple(failure_states),
        final_state=final_state,
        exit_code=EXIT_CODES[final_state],
        remediation=_remediation_for_states(failure_states, agent_uid, broker),
        operator_commands=_operator_commands_for(agent_uid, broker=broker, mode=mode),
        evidence_paths=evidence_paths,
    )


def _aggregate_exit_code(rows: list[AgentOnboardRow]) -> int:
    if all(row.exit_code == 0 for row in rows):
        return 0
    priority = {state: index for index, state in enumerate(STATE_PRIORITY)}
    worst = min(rows, key=lambda row: priority.get(row.final_state, len(priority)))
    return worst.exit_code


def _domain_receipt(
    row: AgentOnboardRow,
    *,
    run_id: str,
    mode: str,
    timestamp: str,
    onboard_receipt_path: str,
) -> dict[str, Any]:
    return {
        "schema_version": DOMAIN_RECEIPT_SCHEMA,
        "timestamp": timestamp,
        "status": DOMAIN_RECEIPTED,
        "proof_tier": DOMAIN_RECEIPTED,
        "contact_evidence_tier": DOMAIN_RECEIPTED,
        "reply_evidence_tier": DOMAIN_RECEIPTED,
        "domain_receipt_claim": True,
        "semantic_reply_claim": False,
        "semantic_receipt_schema": SEMANTIC_RECEIPT_SCHEMA,
        "semantic_evidence_tier": row.semantic_receipt_state,
        "agent": row.agent_uid,
        "agent_uid": row.agent_uid,
        "onboard_run_id": run_id,
        "run_id": run_id,
        "broker": row.broker,
        "mode": mode,
        "locked_spec_path": LOCKED_SPEC_PATH,
        "locked_spec_sha256": LOCKED_SPEC_SHA256,
        "domain": row.domain,
        "inbox_subject": row.inbox_subject,
        "durable_consumer": row.durable_consumer,
        "principal": row.principal,
        "final_state": row.final_state,
        "exit_code": row.exit_code,
        "transport_state": row.transport_state,
        "handler_ack_state": row.handler_ack_state,
        "domain_receipt_state": row.domain_receipt_state,
        "semantic_receipt_state": row.semantic_receipt_state,
        "failure_states": list(row.failure_states),
        "onboard_receipt_path": onboard_receipt_path,
        "evidence_scope": "local_a2a_onboard_contract_prevalidation",
        "operator_contact_note": (
            "typed local A2A onboard-domain receipt; this proves the onboarding "
            "contract evaluated the agent, not that the agent semantically replied"
        ),
    }


def run_onboard(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_root: Path,
    agent: str,
    broker: str,
    mode: str,
    cohort: str | None = None,
) -> tuple[dict[str, Any], int]:
    if broker not in BROKER_PROFILES:
        raise ValueError(f"unsupported broker: {broker}")
    if mode not in {"prevalidate", "live"}:
        raise ValueError(f"unsupported mode: {mode}")

    timestamp = _utc_now()
    run_id = f"a2a_onboard_{timestamp.replace(':', '').replace('-', '')}_{uuid.uuid4().hex[:8]}"
    agents = _nested_agents(_load_json(a2a_bus_root / "agents.json"))
    heartbeats = _nested_agents(_load_json(a2a_bus_root / "heartbeats.json"))
    selection = resolve_agent_selection(agent, cohort=cohort, a2a_bus_root=a2a_bus_root)
    selected = list(selection.agent_uids)
    rows = [
        _agent_row(
            uid,
            broker=broker,
            mode=mode,
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            agents=agents,
            heartbeats=heartbeats,
        )
        for uid in selected
    ]
    exit_code = _aggregate_exit_code(rows)
    receipt_dir = receipt_root / "onboard_receipts"
    domain_dir = receipt_root / "domain_receipts"
    onboard_path = receipt_dir / f"{timestamp.replace(':', '').replace('-', '')}-{_safe_token(run_id)}.json"
    relative_onboard_path = str(onboard_path.relative_to(repo_root)) if onboard_path.is_relative_to(repo_root) else str(onboard_path)
    domain_paths: list[str] = []
    for row in rows:
        receipt = _domain_receipt(
            row,
            run_id=run_id,
            mode=mode,
            timestamp=timestamp,
            onboard_receipt_path=relative_onboard_path,
        )
        path = domain_dir / f"{timestamp.replace(':', '').replace('-', '')}-{_safe_token(run_id)}-{_safe_token(row.agent_uid)}.json"
        _write_json(path, receipt)
        domain_paths.append(str(path.relative_to(repo_root)) if path.is_relative_to(repo_root) else str(path))

    payload = {
        "schema_version": ONBOARD_RECEIPT_SCHEMA,
        "timestamp": timestamp,
        "onboard_run_id": run_id,
        "run_id": run_id,
        "agent": agent,
        "cohort_selection": selection.to_dict(),
        "counted_agents": list(selected),
        "required_counted_agents": list(selected),
        "broker": broker,
        "mode": mode,
        "locked_spec_path": LOCKED_SPEC_PATH,
        "locked_spec_sha256": LOCKED_SPEC_SHA256,
        "exit_code": exit_code,
        "ready": exit_code == 0,
        "rows": [asdict(row) for row in rows],
        "domain_receipt_paths": domain_paths,
        "receipt_schemas": [
            ONBOARD_RECEIPT_SCHEMA,
            DOMAIN_RECEIPT_SCHEMA,
            SEMANTIC_RECEIPT_SCHEMA,
        ],
        "presence_projection": [
            {
                "agent_uid": row.agent_uid,
                "broker": row.broker,
                "domain": row.domain,
                "inbox_subject": row.inbox_subject,
                "durable_consumer": row.durable_consumer,
                "transport_state": row.transport_state,
                "handler_ack_state": row.handler_ack_state,
                "domain_receipt_state": row.domain_receipt_state,
                "semantic_receipt_state": row.semantic_receipt_state,
                "failure_states": list(row.failure_states),
                "wake_loop_state": row.wake_loop_state,
                "presence_age_hours": row.presence_age_hours,
                "peer_model_processed_claim": row.semantic_receipt_state == SEMANTIC_SIGNED,
                "operator_commands": row.operator_commands,
            }
            for row in rows
        ],
    }
    _write_json(onboard_path, payload)
    return payload, exit_code


def _print_table(payload: dict[str, Any]) -> None:
    headers = (
        "agent_uid",
        "broker",
        "domain",
        "inbox_subject",
        "durable_consumer",
        "tls_status",
        "presence_age_h",
        "wake_loop_state",
        "handler_ack",
        "last_domain_receipt",
        "last_semantic_receipt",
        "final_state",
        "exit",
    )
    print(" | ".join(headers))
    print(" | ".join("---" for _ in headers))
    for row in payload["rows"]:
        print(
            " | ".join(
                [
                    str(row["agent_uid"]),
                    str(row["broker"]),
                    str(row["domain"]),
                    str(row["inbox_subject"]),
                    str(row["durable_consumer"]),
                    str(row["tls_status"]),
                    "" if row["presence_age_hours"] is None else str(row["presence_age_hours"]),
                    str(row["wake_loop_state"]),
                    str(row["handler_ack_state"]),
                    str(row["last_domain_receipt"] or "REQUIRED_NOT_BUILT"),
                    str(row["last_semantic_receipt"] or "REQUIRED_NOT_BUILT"),
                    str(row["final_state"]),
                    str(row["exit_code"]),
                ]
            )
        )
    blockers = [row for row in payload["rows"] if row["exit_code"] != 0]
    if blockers:
        print("\nremediation:")
        for row in blockers:
            for command in row["remediation"]:
                print(f"- {row['agent_uid']}: {command}")
    print("\noperator commands:")
    for row in payload["rows"]:
        commands = row.get("operator_commands") if isinstance(row, dict) else {}
        if not isinstance(commands, dict):
            continue
        print(f"- {row['agent_uid']}:")
        for name in (
            "onboard_json",
            "verify_consumer",
            "render_semantic_task_packet",
            "identity_reconcile",
            "project_presence",
            "write_presence_projection",
            "presence_preflight",
            "wake_loop_preflight",
            "standing_agent_preflight",
            "send_hot_contact",
            "capture_reply",
            "render_domain_reply_request",
            "write_domain_reply_artifact",
            "preflight_domain_reply_artifact",
            "publish_domain_receipt",
            "write_semantic_receipt",
            "prove_live_acl",
        ):
            command = commands.get(name)
            if command:
                print(f"  {name}: {command}")
    print(f"\nonboard_run_id={payload['onboard_run_id']}")
    print(f"receipt_paths={', '.join(payload['domain_receipt_paths'])}")


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma/a2a_bus"))
    parser.add_argument("--receipt-root", default="reports/a2a")
    parser.add_argument("--agent", default="all")
    parser.add_argument("--cohort")
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--mode", default="prevalidate")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_root = Path(args.receipt_root)
    if not receipt_root.is_absolute():
        receipt_root = repo_root / receipt_root
    try:
        payload, exit_code = run_onboard(
            repo_root=repo_root,
            a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
            receipt_root=receipt_root,
            agent=args.agent,
            broker=args.broker,
            mode=args.mode,
            cohort=args.cohort,
        )
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_CODES["INTERNAL_ERROR"]
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        _print_table(payload)
        print(json.dumps({"onboard_run_id": payload["onboard_run_id"], "exit_code": exit_code}, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
