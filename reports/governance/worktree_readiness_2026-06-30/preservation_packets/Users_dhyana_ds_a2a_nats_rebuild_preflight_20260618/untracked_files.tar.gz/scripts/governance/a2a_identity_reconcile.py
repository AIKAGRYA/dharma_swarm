#!/usr/bin/env python3
"""Render a gated reconciliation plan for A2A registry identity collisions."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_onboard  # noqa: E402


IDENTITY_RECONCILE_SCHEMA = "dharma.a2a.identity_reconcile.v1"
READY_IDENTITY_CANONICAL = "READY_IDENTITY_CANONICAL"
BLOCKED_IDENTITY_COLLISION = "BLOCKED_IDENTITY_COLLISION"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "identity_reconcile"
DEFAULT_A2A_BUS_ROOT = Path.home() / ".dharma" / "a2a_bus"
WRITE_APPROVAL_ENV = "A2A_IDENTITY_RECONCILE"
WRITE_APPROVAL_VALUE = "approved-identity-reconcile"


@dataclass(frozen=True)
class ProposedChange:
    op: str
    agent_uid: str
    alias: str
    canonical_owner: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class IdentityRow:
    agent_uid: str
    final_state: str
    aliases: tuple[str, ...]
    collisions: tuple[str, ...]
    proposed_changes: tuple[ProposedChange, ...]
    would_pass_after_plan: bool

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["proposed_changes"] = [change.to_dict() for change in self.proposed_changes]
        return payload


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _sha256_file(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return ""


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if isinstance(agents, dict):
        return {str(uid): entry for uid, entry in agents.items() if isinstance(entry, dict)}
    return {str(uid): entry for uid, entry in payload.items() if isinstance(entry, dict)}


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _aliases(entry: dict[str, Any]) -> tuple[str, ...]:
    aliases = entry.get("aliases")
    if not isinstance(aliases, list):
        return ()
    return tuple(str(alias).strip() for alias in aliases if str(alias).strip())


def _alias_owners(agents: dict[str, dict[str, Any]]) -> dict[str, set[str]]:
    owners_by_alias: dict[str, set[str]] = {}
    for uid, entry in agents.items():
        values = {uid}
        values.update(_aliases(entry))
        for value in values:
            owners_by_alias.setdefault(value, set()).add(uid)
    return owners_by_alias


def _collision_messages(
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    *,
    counted_agent_uids: tuple[str, ...],
) -> tuple[str, ...]:
    owners_by_alias = _alias_owners(agents)
    messages: list[str] = []
    for alias, owners in sorted(owners_by_alias.items()):
        if agent_uid in owners and len(owners) > 1:
            messages.append(f"alias {alias} maps to multiple agents: {', '.join(sorted(owners))}")
        if alias in counted_agent_uids and alias != agent_uid and agent_uid in owners:
            messages.append(f"alias {alias} collides with counted agent uid")
    return tuple(dict.fromkeys(messages))


def _proposed_changes(
    *,
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    counted_agent_uids: tuple[str, ...],
) -> tuple[ProposedChange, ...]:
    entry = agents.get(agent_uid, {})
    changes: list[ProposedChange] = []
    owners_by_alias = _alias_owners(agents)
    for alias in _aliases(entry):
        owners = owners_by_alias.get(alias, set())
        if len(owners) <= 1 and alias not in counted_agent_uids:
            continue
        if alias in agents and alias != agent_uid:
            changes.append(
                ProposedChange(
                    op="remove_alias",
                    agent_uid=agent_uid,
                    alias=alias,
                    canonical_owner=alias,
                    reason=(
                        f"alias {alias} is also a top-level registry uid; keep "
                        f"{alias} as canonical owner and remove it from {agent_uid}.aliases"
                    ),
                )
            )
            continue
        if alias in counted_agent_uids and alias != agent_uid:
            changes.append(
                ProposedChange(
                    op="remove_alias",
                    agent_uid=agent_uid,
                    alias=alias,
                    canonical_owner=alias,
                    reason=f"alias {alias} is a counted agent uid owned by {alias}",
                )
            )
    return tuple(dict.fromkeys(changes))


def _apply_changes_to_agents(
    agents: dict[str, dict[str, Any]],
    changes: tuple[ProposedChange, ...],
) -> dict[str, dict[str, Any]]:
    simulated = json.loads(json.dumps(agents))
    for change in changes:
        if change.op != "remove_alias":
            continue
        entry = simulated.get(change.agent_uid)
        if not isinstance(entry, dict):
            continue
        aliases = entry.get("aliases")
        if not isinstance(aliases, list):
            continue
        entry["aliases"] = [alias for alias in aliases if str(alias).strip() != change.alias]
    return simulated


def _row(
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    *,
    counted_agent_uids: tuple[str, ...],
) -> IdentityRow:
    entry = agents.get(agent_uid, {})
    collisions = _collision_messages(
        agents,
        agent_uid,
        counted_agent_uids=counted_agent_uids,
    )
    changes = _proposed_changes(
        agents=agents,
        agent_uid=agent_uid,
        counted_agent_uids=counted_agent_uids,
    )
    simulated = _apply_changes_to_agents(agents, changes)
    remaining_collisions = _collision_messages(
        simulated,
        agent_uid,
        counted_agent_uids=counted_agent_uids,
    )
    blockers = collisions
    return IdentityRow(
        agent_uid=agent_uid,
        final_state=READY_IDENTITY_CANONICAL if not blockers else BLOCKED_IDENTITY_COLLISION,
        aliases=_aliases(entry),
        collisions=blockers,
        proposed_changes=changes,
        would_pass_after_plan=not remaining_collisions,
    )


def _apply_registry_write(
    *,
    agents_path: Path,
    payload: dict[str, Any],
    changes: tuple[ProposedChange, ...],
) -> str:
    if os.environ.get(WRITE_APPROVAL_ENV) != WRITE_APPROVAL_VALUE:
        return "write skipped: missing approval env"
    agents = _nested_agents(payload)
    updated_agents = _apply_changes_to_agents(agents, changes)
    if payload.get("agents") and isinstance(payload["agents"], dict):
        payload["agents"] = updated_agents
    else:
        payload = updated_agents
    _write_json(agents_path, payload)
    return "registry write performed"


def run_reconcile(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_dir: Path,
    agent: str,
    write_registry: bool,
) -> tuple[dict[str, Any], int]:
    agents_path = a2a_bus_root / "agents.json"
    registry_payload = _load_json(agents_path)
    agents = _nested_agents(registry_payload)
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    before_sha256 = _sha256_file(agents_path)
    rows_before = [
        _row(agents, agent_uid, counted_agent_uids=selected)
        for agent_uid in selected
    ]
    all_changes = tuple(change for row in rows_before for change in row.proposed_changes)
    write_status = "dry-run only"
    if write_registry:
        write_status = _apply_registry_write(
            agents_path=agents_path,
            payload=registry_payload,
            changes=all_changes,
        )
    after_sha256 = _sha256_file(agents_path)
    if before_sha256 != after_sha256:
        agents_after = _nested_agents(_load_json(agents_path))
        rows = [
            _row(agents_after, agent_uid, counted_agent_uids=selected)
            for agent_uid in selected
        ]
    else:
        rows = rows_before
    blockers = [
        f"{row.agent_uid}: {collision}"
        for row in rows
        for collision in row.collisions
    ]
    payload: dict[str, Any] = {
        "schema_version": IDENTITY_RECONCILE_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "counted_agents": list(selected),
        "registry_path": str(agents_path),
        "registry_sha256_before": before_sha256,
        "registry_sha256_after": after_sha256,
        "dry_run": not write_registry,
        "mutation_requested": write_registry,
        "mutation_performed": before_sha256 != after_sha256,
        "write_approval_env": WRITE_APPROVAL_ENV,
        "write_approval_value": WRITE_APPROVAL_VALUE,
        "write_status": write_status,
        "rows_before": [row.to_dict() for row in rows_before],
        "rows": [row.to_dict() for row in rows],
        "proposed_changes": [change.to_dict() for change in all_changes],
        "blockers": list(dict.fromkeys(blockers)),
        "operator_note": (
            "This tool is dry-run by default. It plans only alias removals from "
            "the selected counted agent when an alias is already a top-level "
            "registry uid or another counted uid. It does not delete registry "
            "entries or fabricate presence/model evidence."
        ),
    }
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}-a2a-identity-reconcile.json"
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    _write_json(receipt_path, payload)
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(DEFAULT_A2A_BUS_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--write-registry", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    payload, exit_code = run_reconcile(
        repo_root=repo_root,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
        receipt_dir=receipt_dir,
        agent=args.agent,
        write_registry=args.write_registry,
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_IDENTITY_RECONCILE_OK" if payload["passed"] else "A2A_IDENTITY_RECONCILE_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            for collision in row["collisions"]:
                print(f"  * {collision}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
