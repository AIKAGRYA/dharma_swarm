#!/usr/bin/env python3
"""Adversarial verifier for the A2A/NATS runtime onboarding contract."""

from __future__ import annotations

import argparse
import glob
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from dharma_swarm.a2a.agent_roster import SEED_AGENT_UIDS, resolve_agent_uids


REPO_ROOT = Path(__file__).resolve().parents[2]
DOMAIN_RECEIPTED = "DOMAIN_RECEIPTED"
HANDLER_ACKED = "HANDLER_ACKED"
DOMAIN_SCHEMAS = {
    "dharma.a2a.domain_receipt.v1",
    "dharma.a2a.reply_receipt.v1",
    "dharma.a2a.semantic_reply.v1",
}
DEFAULT_EVIDENCE_GLOBS = (
    "reports/a2a/onboard/**/*.json",
    "reports/a2a/reply_receipts/**/*.json",
    "reports/a2a/domain_receipts/**/*.json",
)
LOCKED_SPEC_PATH = "docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md"
LOCKED_SPEC_SHA256 = "e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899"
COUNTED_AGENT_UIDS = tuple(SEED_AGENT_UIDS)
ACCEPTED_ONBOARD_RETURN_CODES = {
    0,
    # GNU make reports recipe failures as 2 even when the recipe's child process
    # used the spec's richer blocker code. Require onboard_run_id + receipts to
    # distinguish honest blocker output from a missing target.
    2,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    20,
    21,
    22,
    23,
    30,
    31,
    32,
}


@dataclass(frozen=True)
class VerifierResult:
    passed: bool
    failures: list[str]
    evidence_paths: list[str]
    evidence_agents: list[str]
    make_returncode: int
    make_stdout_tail: str
    make_stderr_tail: str
    onboard_run_id: str


def _tail(text: str, *, limit: int = 3000) -> str:
    return text[-limit:]


def _receipt_schema(receipt: dict[str, Any]) -> str:
    payload = receipt.get("reply_payload")
    if isinstance(payload, dict):
        schema = payload.get("schema_version") or payload.get("schema")
        if schema:
            return str(schema)
    return str(
        receipt.get("reply_schema")
        or receipt.get("domain_receipt_schema")
        or receipt.get("schema_version")
        or receipt.get("schema")
        or ""
    )


def _tier_values(receipt: dict[str, Any]) -> set[str]:
    keys = (
        "status",
        "ack_tier",
        "contact_evidence_tier",
        "reply_evidence_tier",
        "proof_tier",
    )
    return {str(receipt.get(key) or "") for key in keys if receipt.get(key)}


def _parse_timestamp(value: object) -> datetime | None:
    if not value:
        return None
    text = str(value)
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _extract_onboard_run_id(stdout: str) -> str:
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            run_id = payload.get("onboard_run_id") or payload.get("run_id")
            if run_id:
                return str(run_id)
    return ""


def _expected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> list[str]:
    return list(resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root))


def _receipt_agent(receipt: dict[str, Any]) -> str:
    return str(receipt.get("agent") or receipt.get("agent_uid") or receipt.get("target_uid") or "")


def _has_domain_receipt(
    receipt: dict[str, Any],
    *,
    expected_agents: set[str],
    broker: str,
    mode: str,
    onboard_run_id: str,
    max_age_s: int,
) -> bool:
    tiers = _tier_values(receipt)
    schema = _receipt_schema(receipt)
    if DOMAIN_RECEIPTED not in tiers:
        return False
    if receipt.get("domain_receipt_claim") is not True:
        return False
    if schema not in DOMAIN_SCHEMAS:
        return False
    if str(receipt.get("locked_spec_path") or "") != LOCKED_SPEC_PATH:
        return False
    if str(receipt.get("locked_spec_sha256") or "") != LOCKED_SPEC_SHA256:
        return False
    if str(receipt.get("broker") or "") != broker:
        return False
    if str(receipt.get("mode") or "") != mode:
        return False
    if onboard_run_id and str(receipt.get("onboard_run_id") or receipt.get("run_id") or "") != onboard_run_id:
        return False
    receipt_agent = _receipt_agent(receipt)
    if receipt_agent not in expected_agents:
        return False
    timestamp = _parse_timestamp(receipt.get("timestamp") or receipt.get("created_at"))
    if timestamp is None:
        return False
    age_s = (datetime.now(UTC) - timestamp).total_seconds()
    if age_s < 0 or age_s > max_age_s:
        return False
    return True


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _scan_evidence(
    repo_root: Path,
    patterns: list[str],
    *,
    expected_agents: set[str],
    broker: str,
    mode: str,
    onboard_run_id: str,
    max_age_s: int,
) -> tuple[list[str], dict[str, str], bool]:
    paths: list[Path] = []
    for pattern in patterns:
        paths.extend(Path(match) for match in glob.glob(str(repo_root / pattern), recursive=True))
    unique_paths = sorted({path.resolve() for path in paths if path.is_file()})
    handler_only_seen = False
    domain_paths: list[str] = []
    domain_agents: dict[str, str] = {}
    for path in unique_paths:
        receipt = _load_json(path)
        tiers = _tier_values(receipt)
        if HANDLER_ACKED in tiers and DOMAIN_RECEIPTED not in tiers:
            handler_only_seen = True
        if _has_domain_receipt(
            receipt,
            expected_agents=expected_agents,
            broker=broker,
            mode=mode,
            onboard_run_id=onboard_run_id,
            max_age_s=max_age_s,
        ):
            rel_path = str(path.relative_to(repo_root))
            domain_paths.append(rel_path)
            receipt_agent = _receipt_agent(receipt)
            if receipt_agent:
                domain_agents[receipt_agent] = rel_path
    return domain_paths, domain_agents, handler_only_seen


def run_verifier(
    *,
    repo_root: Path,
    agent: str,
    broker: str,
    mode: str,
    timeout_s: int,
    max_evidence_age_s: int,
    evidence_globs: list[str],
    skip_make: bool,
    a2a_bus_root: Path | None = None,
) -> VerifierResult:
    failures: list[str] = []
    stdout_tail = ""
    stderr_tail = ""
    returncode = 0
    onboard_run_id = ""

    if skip_make:
        returncode = 0
    else:
        command = ["make", "a2a-onboard", f"AGENT={agent}", f"BROKER={broker}", f"MODE={mode}"]
        env = {**os.environ, "A2A_ONBOARD_CONTRACT_VERIFIER": "1"}
        try:
            run = subprocess.run(
                command,
                cwd=repo_root,
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_s,
                check=False,
            )
            returncode = run.returncode
            stdout_tail = _tail(run.stdout)
            stderr_tail = _tail(run.stderr)
            onboard_run_id = _extract_onboard_run_id(run.stdout)
        except subprocess.TimeoutExpired as exc:
            returncode = 124
            stdout_tail = _tail(exc.stdout or "")
            stderr_tail = _tail(exc.stderr or "")
            failures.append(f"make a2a-onboard timed out after {timeout_s}s")
        if returncode not in ACCEPTED_ONBOARD_RETURN_CODES:
            failures.append(f"make a2a-onboard failed or is absent: exit {returncode}")
        if not onboard_run_id:
            failures.append("make a2a-onboard did not emit onboard_run_id/run_id JSON")

    expected_agents = _expected_agents(agent, a2a_bus_root=a2a_bus_root)
    evidence_paths, evidence_agents, handler_only_seen = _scan_evidence(
        repo_root,
        evidence_globs,
        expected_agents=set(expected_agents),
        broker=broker,
        mode=mode,
        onboard_run_id=onboard_run_id,
        max_age_s=max_evidence_age_s,
    )
    if not evidence_paths:
        if handler_only_seen:
            failures.append("only HANDLER_ACKED evidence was found; DOMAIN_RECEIPTED is required")
        else:
            failures.append("no DOMAIN_RECEIPTED evidence receipt found")
    missing_agents = sorted(uid for uid in expected_agents if uid not in evidence_agents)
    if missing_agents:
        failures.append(
            "missing DOMAIN_RECEIPTED evidence for agents: " + ", ".join(missing_agents)
        )

    return VerifierResult(
        passed=not failures,
        failures=failures,
        evidence_paths=evidence_paths,
        evidence_agents=sorted(evidence_agents),
        make_returncode=returncode,
        make_stdout_tail=stdout_tail,
        make_stderr_tail=stderr_tail,
        onboard_run_id=onboard_run_id,
    )


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--mode", default="prevalidate")
    parser.add_argument("--timeout-s", type=int, default=180)
    parser.add_argument("--max-evidence-age-s", type=int, default=600)
    parser.add_argument("--skip-make", action="store_true")
    parser.add_argument(
        "--evidence-glob",
        action="append",
        default=[],
        help="Repo-relative glob to inspect for DOMAIN_RECEIPTED JSON receipts.",
    )
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    evidence_globs = args.evidence_glob or list(DEFAULT_EVIDENCE_GLOBS)
    result = run_verifier(
        repo_root=repo_root,
        agent=args.agent,
        broker=args.broker,
        mode=args.mode,
        timeout_s=args.timeout_s,
        max_evidence_age_s=args.max_evidence_age_s,
        evidence_globs=evidence_globs,
        skip_make=bool(args.skip_make),
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
    )
    payload = {
        "schema_version": "dharma.a2a.onboard_contract_verifier.v1",
        "passed": result.passed,
        "failures": result.failures,
        "domain_receipt_evidence_paths": result.evidence_paths,
        "domain_receipt_evidence_agents": result.evidence_agents,
        "make_returncode": result.make_returncode,
        "make_stdout_tail": result.make_stdout_tail,
        "make_stderr_tail": result.make_stderr_tail,
        "onboard_run_id": result.onboard_run_id,
        "required_tier": DOMAIN_RECEIPTED,
        "rejected_as_sufficient": HANDLER_ACKED,
        "required_locked_spec_path": LOCKED_SPEC_PATH,
        "required_locked_spec_sha256": LOCKED_SPEC_SHA256,
        "max_evidence_age_s": args.max_evidence_age_s,
    }
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        status = "A2A_ONBOARD_CONTRACT_OK" if result.passed else "A2A_ONBOARD_CONTRACT_FAIL"
        print(status)
        for failure in result.failures:
            print(f"- {failure}")
        if result.evidence_paths:
            print("DOMAIN_RECEIPTED evidence:")
            for path in result.evidence_paths:
                print(f"- {path}")
        if result.make_stderr_tail:
            print("make stderr tail:")
            print(result.make_stderr_tail)
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
