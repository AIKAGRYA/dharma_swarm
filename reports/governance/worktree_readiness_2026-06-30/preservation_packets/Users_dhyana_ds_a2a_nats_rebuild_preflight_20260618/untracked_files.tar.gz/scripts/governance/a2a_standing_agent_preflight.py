#!/usr/bin/env python3
"""Render read-only standing-agent promotion preflight rows."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_onboard  # noqa: E402


STANDING_AGENT_PREFLIGHT_SCHEMA = "dharma.a2a.standing_agent_preflight.v1"
READY_STANDING_AGENT = "READY_STANDING_AGENT"
BLOCKED_STANDING_AGENT = "BLOCKED_STANDING_AGENT"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "standing_agent_preflight"
DEFAULT_A2A_BUS_ROOT = Path.home() / ".dharma" / "a2a_bus"


@dataclass(frozen=True)
class StandingAgentRow:
    agent_uid: str
    final_state: str
    blockers: tuple[str, ...]
    registry_entry_present: bool
    authority: str
    authority_status: str
    agent_type: str
    dispatch_enabled: bool | None
    session_scoped: bool
    wake_loop_active: bool
    bridge_heartbeat_present: bool
    worker_heartbeat_present: bool
    domain_receipt_path: str
    semantic_receipt_path: str
    required_promotions: tuple[str, ...]
    operator_commands: dict[str, str]
    evidence_paths: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if isinstance(agents, dict):
        return {str(uid): entry for uid, entry in agents.items() if isinstance(entry, dict)}
    return {str(uid): entry for uid, entry in payload.items() if isinstance(entry, dict)}


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "active", "online", "ready", "wake_loop_active"}
    return bool(value)


def _session_scoped(agent_uid: str, agent_entry: dict[str, Any], state_payload: dict[str, Any]) -> bool:
    authority = str(agent_entry.get("authority") or state_payload.get("authority") or "")
    agent_type = str(agent_entry.get("type") or state_payload.get("type") or "")
    if authority.endswith("evidence_only") or agent_type.endswith("-cli"):
        return True
    return agent_uid == "qwen_code"


def _operator_commands(agent_uid: str, broker: str) -> dict[str, str]:
    return {
        "standing_agent_preflight": f"make a2a-standing-agent-preflight AGENT={agent_uid} ARGS='--json'",
        "standing_wake_loop_dry_run": (
            f"A2A_STANDING_WAKE_LOOP_AGENT={agent_uid} "
            f"make a2a-standing-wake-loop AGENT={agent_uid} ARGS='--dry-run --json'"
        ),
        "wake_loop_preflight": (
            f"make a2a-wake-loop-preflight AGENT={agent_uid} BROKER={broker} "
            "ARGS='--json'"
        ),
        "presence_preflight": f"make a2a-presence-preflight AGENT={agent_uid} BROKER={broker} ARGS='--json'",
        "domain_reply_artifact_preflight": (
            f"make a2a-domain-reply-artifact-preflight AGENT={agent_uid} ARGS='--json'"
        ),
    }


def _row(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    broker: str,
) -> StandingAgentRow:
    agent_entry = agents.get(agent_uid, {})
    state_payload = _load_json(a2a_bus_root / "state" / f"{agent_uid}.json")
    bridge_payload = _load_json(a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json")
    worker_payload = _load_json(a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json")
    evidence_paths: list[str] = []
    blockers: list[str] = []
    required_promotions: list[str] = []

    registry_entry_present = bool(agent_entry)
    if registry_entry_present:
        evidence_paths.append(str(a2a_bus_root / "agents.json"))
    else:
        blockers.append("missing canonical registry entry")
        required_promotions.append("register canonical counted agent identity")
    if state_payload:
        evidence_paths.append(str(a2a_bus_root / "state" / f"{agent_uid}.json"))
    if bridge_payload:
        evidence_paths.append(str(a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json"))
    if worker_payload:
        evidence_paths.append(str(a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json"))

    authority = str(agent_entry.get("authority") or state_payload.get("authority") or "")
    authority_status = str(agent_entry.get("authority_status") or state_payload.get("authority_status") or "")
    agent_type = str(agent_entry.get("type") or state_payload.get("type") or "")
    dispatch = agent_entry.get("dispatch_enabled", state_payload.get("dispatch_enabled"))
    dispatch_enabled = dispatch if isinstance(dispatch, bool) else None
    session_scoped = _session_scoped(agent_uid, agent_entry, state_payload)
    if session_scoped:
        blockers.append("agent is session/evidence scoped")
        required_promotions.append("target-owned standing loop evidence must replace evidence-only/session-scoped authority")
    if dispatch_enabled is False:
        blockers.append("dispatch is disabled")
        required_promotions.append("enable dispatch only after standing wake loop and semantic receipt evidence exist")

    wake_loop_active = _truthy(agent_entry.get("wake_loop_active") or state_payload.get("wake_loop_active"))
    bridge_heartbeat_present = bool(bridge_payload)
    worker_heartbeat_present = bool(worker_payload)
    if not wake_loop_active and not worker_heartbeat_present:
        blockers.append("missing standing wake-loop heartbeat")
        required_promotions.append("run target-owned standing wake loop with owner env gate")

    domain_receipt_path = a2a_onboard._last_valid_domain_effect_receipt_path(agent_uid, repo_root)
    semantic_receipt_path = a2a_onboard._last_valid_semantic_receipt_path(agent_uid, repo_root)
    if domain_receipt_path:
        evidence_paths.append(domain_receipt_path)
    else:
        blockers.append("missing target-owned DOMAIN_RECEIPTED evidence")
        required_promotions.append("produce and publish target-owned domain reply artifact")
    if semantic_receipt_path:
        evidence_paths.append(semantic_receipt_path)
    else:
        blockers.append("missing current SEMANTIC_SIGNED evidence")
        required_promotions.append("produce current semantic receipt with peer_model_processed_claim=true")

    unique_blockers = tuple(dict.fromkeys(blockers))
    return StandingAgentRow(
        agent_uid=agent_uid,
        final_state=READY_STANDING_AGENT if not unique_blockers else BLOCKED_STANDING_AGENT,
        blockers=unique_blockers,
        registry_entry_present=registry_entry_present,
        authority=authority,
        authority_status=authority_status,
        agent_type=agent_type,
        dispatch_enabled=dispatch_enabled,
        session_scoped=session_scoped,
        wake_loop_active=wake_loop_active,
        bridge_heartbeat_present=bridge_heartbeat_present,
        worker_heartbeat_present=worker_heartbeat_present,
        domain_receipt_path=domain_receipt_path,
        semantic_receipt_path=semantic_receipt_path,
        required_promotions=tuple(dict.fromkeys(required_promotions)),
        operator_commands=_operator_commands(agent_uid, broker),
        evidence_paths=tuple(dict.fromkeys(evidence_paths)),
    )


def run_preflight(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_dir: Path,
    agent: str,
    broker: str,
) -> tuple[dict[str, Any], int]:
    agents = _nested_agents(_load_json(a2a_bus_root / "agents.json"))
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    rows = [
        _row(
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            agents=agents,
            agent_uid=agent_uid,
            broker=broker,
        )
        for agent_uid in selected
    ]
    blockers = [f"{row.agent_uid}: {blocker}" for row in rows for blocker in row.blockers]
    payload: dict[str, Any] = {
        "schema_version": STANDING_AGENT_PREFLIGHT_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "broker": broker,
        "counted_agents": list(selected),
        "required_counted_agents": list(selected),
        "rows": [row.to_dict() for row in rows],
        "blockers": list(dict.fromkeys(blockers)),
        "operator_note": (
            "This preflight is read-only. It plans standing-agent promotion "
            "requirements but does not edit registry state, start wake loops, "
            "write heartbeats, or fabricate target-owned domain/semantic evidence."
        ),
    }
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}-a2a-standing-agent-preflight.json"
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    _write_json(receipt_path, payload)
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(DEFAULT_A2A_BUS_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    payload, exit_code = run_preflight(
        repo_root=repo_root,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
        receipt_dir=receipt_dir,
        agent=args.agent,
        broker=args.broker,
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_STANDING_AGENT_PREFLIGHT_OK" if payload["passed"] else "A2A_STANDING_AGENT_PREFLIGHT_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            for blocker in row["blockers"]:
                print(f"  * {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
