#!/usr/bin/env python3
"""Render a non-mutating A2A standing wake-loop preflight receipt."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_onboard  # noqa: E402


WAKE_LOOP_PREFLIGHT_SCHEMA = "dharma.a2a.wake_loop_preflight.v1"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "wake_loop_preflight"
READY_WAKE_LOOP_PREVALIDATED = "READY_WAKE_LOOP_PREVALIDATED"

REQUIRED_CONTRACT_SURFACES = (
    "WakeLoopConfig",
    "WakeLoopPrevalidator",
    "StandingWakeLoop",
    "WakeLoopRegistry",
    "WakeLease",
    "DomainReceiptProducer",
    "SemanticReceiptProducer",
    "WakeCircuitBreaker",
)

STATE_PRIORITY = (
    "BLOCKED_IDENTITY",
    "BLOCKED_WAKE_LOOP",
    "DEGRADED_SESSION_SCOPED",
    "BLOCKED_DOMAIN_RECEIPT",
    "BLOCKED_SEMANTIC_RECEIPT",
)


@dataclass(frozen=True)
class WakeLoopRow:
    agent_uid: str
    final_state: str
    blockers: tuple[str, ...]
    registry_entry_present: bool
    transport_loop_present: bool
    semantic_loop_present: bool
    wake_lease_present: bool
    circuit_breaker_present: bool
    session_scoped: bool
    bridge_heartbeat_present: bool
    worker_heartbeat_present: bool
    state_file_present: bool
    domain_receipt_path: str
    semantic_receipt_path: str
    latest_standing_wake_loop_receipt_path: str
    latest_standing_wake_loop_status: str
    latest_standing_wake_loop_blockers: tuple[str, ...]
    latest_standing_wake_loop_wrote_heartbeat: bool | None
    latest_standing_wake_loop_session_scoped: bool | None
    contract_surfaces: dict[str, dict[str, Any]]
    operator_commands: dict[str, str]
    evidence_paths: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _write_receipt(receipt_dir: Path, payload: dict[str, Any]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{_stamp()}-a2a-wake-loop-preflight.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _latest_json(root: Path, pattern: str) -> Path | None:
    candidates = [path for path in root.glob(pattern) if path.is_file()]
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def _latest_standing_wake_loop_receipt(
    *,
    repo_root: Path,
    agent_uid: str,
) -> tuple[Path | None, dict[str, Any]]:
    path = _latest_json(
        repo_root / "reports" / "a2a" / "standing_wake_loop",
        f"*-{agent_uid}-standing-wake-loop.json",
    )
    if path is None:
        return None, {}
    return path, a2a_onboard._load_json(path)


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "active", "online", "ready", "wake_loop_active"}
    return bool(value)


def _session_scoped(agent_uid: str, agent_entry: dict[str, Any], state_payload: dict[str, Any]) -> bool:
    authority = str(agent_entry.get("authority") or state_payload.get("authority") or "")
    agent_type = str(agent_entry.get("type") or state_payload.get("type") or "")
    if authority.endswith("evidence_only") or agent_type.endswith("-cli"):
        return True
    return agent_uid == "qwen_code"


def _has_wake_lease(*payloads: dict[str, Any]) -> bool:
    for payload in payloads:
        lease = payload.get("lease")
        if isinstance(lease, dict) and lease:
            return True
        lease_refs = payload.get("lease_refs")
        if isinstance(lease_refs, list) and lease_refs:
            return True
        if str(payload.get("lease_owner") or payload.get("wake_lease") or "").strip():
            return True
        if payload.get("max_lease_seconds"):
            return True
    return False


def _has_circuit_breaker(*payloads: dict[str, Any]) -> bool:
    for payload in payloads:
        breaker = payload.get("circuit_breaker") or payload.get("wake_circuit_breaker")
        if isinstance(breaker, dict) and breaker:
            return True
        if str(payload.get("circuit_breaker_state") or "").strip():
            return True
    return False


def _has_semantic_loop(*payloads: dict[str, Any]) -> bool:
    for payload in payloads:
        if payload.get("peer_model_processed_claim") is True:
            return True
        if _truthy(payload.get("standing_semantic_loop") or payload.get("semantic_loop_active")):
            return True
    return False


def _path_if_exists(path: Path, repo_root: Path, evidence: list[str]) -> dict[str, Any]:
    present = path.exists()
    if present:
        evidence.append(a2a_onboard._relative_or_absolute(path, repo_root))
    return {"present": present, "path": a2a_onboard._relative_or_absolute(path, repo_root)}


def _contract_surfaces(
    *,
    repo_root: Path,
    registry_entry_present: bool,
    semantic_loop_present: bool,
    wake_lease_present: bool,
    circuit_breaker_present: bool,
    evidence_paths: list[str],
) -> dict[str, dict[str, Any]]:
    domain_worker = repo_root / "scripts" / "runtime" / "a2a_domain_reply_worker.py"
    semantic_worker = domain_worker
    return {
        "WakeLoopConfig": {
            "present": registry_entry_present,
            "evidence": "agents.json/state payload",
        },
        "WakeLoopPrevalidator": {
            "present": True,
            "evidence": "scripts/governance/a2a_wake_loop_preflight.py",
        },
        "StandingWakeLoop": {
            "present": semantic_loop_present,
            "evidence": "standing_semantic_loop or peer_model_processed_claim",
        },
        "WakeLoopRegistry": {
            "present": registry_entry_present,
            "evidence": "a2a_bus agents.json",
        },
        "WakeLease": {
            "present": wake_lease_present,
            "evidence": "lease, lease_refs, lease_owner, wake_lease, or max_lease_seconds",
        },
        "DomainReceiptProducer": {
            **_path_if_exists(domain_worker, repo_root, evidence_paths),
            "evidence": "target-owned domain reply worker",
        },
        "SemanticReceiptProducer": {
            **_path_if_exists(semantic_worker, repo_root, evidence_paths),
            "evidence": "semantic receipt schema emitted by domain reply worker",
        },
        "WakeCircuitBreaker": {
            "present": circuit_breaker_present,
            "evidence": "circuit_breaker or circuit_breaker_state",
        },
    }


def _final_state(blockers: list[str]) -> str:
    if not blockers:
        return READY_WAKE_LOOP_PREVALIDATED
    for state in STATE_PRIORITY:
        if state in blockers:
            return state
    return "BLOCKED_WAKE_LOOP"


def _row(
    agent_uid: str,
    *,
    broker: str,
    mode: str,
    repo_root: Path,
    a2a_bus_root: Path,
    agents: dict[str, dict[str, Any]],
) -> WakeLoopRow:
    agent_entry = agents.get(agent_uid, {})
    state_payload = a2a_onboard._load_json(a2a_bus_root / "state" / f"{agent_uid}.json")
    bridge_payload = a2a_onboard._load_json(a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json")
    worker_payload = a2a_onboard._load_json(a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json")
    wake_attempt_path, wake_attempt = _latest_standing_wake_loop_receipt(
        repo_root=repo_root,
        agent_uid=agent_uid,
    )
    evidence_paths: list[str] = []
    blockers: list[str] = []
    wake_attempt_status = str(wake_attempt.get("status") or "")
    wake_attempt_blockers_raw = wake_attempt.get("blockers")
    wake_attempt_blockers = tuple(
        str(blocker)
        for blocker in wake_attempt_blockers_raw
        if isinstance(blocker, str)
    ) if isinstance(wake_attempt_blockers_raw, list) else ()
    wake_attempt_wrote_raw = wake_attempt.get("wrote_heartbeat")
    wake_attempt_wrote = (
        wake_attempt_wrote_raw if isinstance(wake_attempt_wrote_raw, bool) else None
    )
    wake_attempt_session_raw = wake_attempt.get("session_scoped")
    wake_attempt_session = (
        wake_attempt_session_raw if isinstance(wake_attempt_session_raw, bool) else None
    )
    if wake_attempt_path is not None:
        evidence_paths.append(a2a_onboard._relative_or_absolute(wake_attempt_path, repo_root))

    registry_entry_present = bool(agent_entry)
    bridge_heartbeat_present = bool(bridge_payload)
    worker_heartbeat_present = bool(worker_payload)
    state_file_present = bool(state_payload)
    wake_loop_active_claim = _truthy(agent_entry.get("wake_loop_active") or agent_entry.get("status"))
    transport_loop_present = wake_loop_active_claim or bridge_heartbeat_present or worker_heartbeat_present
    session_scoped = _session_scoped(agent_uid, agent_entry, state_payload)
    semantic_loop_present = _has_semantic_loop(agent_entry, state_payload, bridge_payload, worker_payload)
    wake_lease_present = _has_wake_lease(agent_entry, state_payload, bridge_payload, worker_payload)
    circuit_breaker_present = _has_circuit_breaker(agent_entry, state_payload, bridge_payload, worker_payload)
    domain_receipt_path = a2a_onboard._last_valid_domain_effect_receipt_path(agent_uid, repo_root)
    semantic_receipt_path = a2a_onboard._last_valid_semantic_receipt_path(agent_uid, repo_root)

    if registry_entry_present:
        evidence_paths.append(str(a2a_bus_root / "agents.json"))
    else:
        blockers.append("BLOCKED_IDENTITY")
    if state_file_present:
        evidence_paths.append(str(a2a_bus_root / "state" / f"{agent_uid}.json"))
    if bridge_heartbeat_present:
        evidence_paths.append(str(a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json"))
    if worker_heartbeat_present:
        evidence_paths.append(str(a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json"))
    if domain_receipt_path:
        evidence_paths.append(domain_receipt_path)
    else:
        blockers.append("BLOCKED_DOMAIN_RECEIPT")
    if semantic_receipt_path:
        evidence_paths.append(semantic_receipt_path)
    else:
        blockers.append("BLOCKED_SEMANTIC_RECEIPT")

    if not transport_loop_present:
        blockers.append("BLOCKED_WAKE_LOOP")
        if wake_attempt_status:
            blockers.append(f"latest standing wake-loop status is {wake_attempt_status}")
        for wake_attempt_blocker in wake_attempt_blockers:
            blockers.append(f"latest standing wake-loop blocker: {wake_attempt_blocker}")
    if session_scoped:
        blockers.append("DEGRADED_SESSION_SCOPED")
        if wake_attempt_status:
            blockers.append(f"latest standing wake-loop status is {wake_attempt_status}")
        for wake_attempt_blocker in wake_attempt_blockers:
            blockers.append(f"latest standing wake-loop blocker: {wake_attempt_blocker}")
    elif not semantic_loop_present:
        blockers.append("BLOCKED_WAKE_LOOP")
    elif not wake_lease_present:
        blockers.append("BLOCKED_WAKE_LOOP")
    elif not circuit_breaker_present:
        blockers.append("BLOCKED_WAKE_LOOP")

    surfaces = _contract_surfaces(
        repo_root=repo_root,
        registry_entry_present=registry_entry_present,
        semantic_loop_present=semantic_loop_present and not session_scoped,
        wake_lease_present=wake_lease_present,
        circuit_breaker_present=circuit_breaker_present,
        evidence_paths=evidence_paths,
    )
    for surface, data in surfaces.items():
        if data.get("present") is not True:
            blockers.append(f"missing {surface}")

    unique_blockers = tuple(dict.fromkeys(blockers))
    return WakeLoopRow(
        agent_uid=agent_uid,
        final_state=_final_state(list(unique_blockers)),
        blockers=unique_blockers,
        registry_entry_present=registry_entry_present,
        transport_loop_present=transport_loop_present,
        semantic_loop_present=semantic_loop_present and not session_scoped,
        wake_lease_present=wake_lease_present,
        circuit_breaker_present=circuit_breaker_present,
        session_scoped=session_scoped,
        bridge_heartbeat_present=bridge_heartbeat_present,
        worker_heartbeat_present=worker_heartbeat_present,
        state_file_present=state_file_present,
        domain_receipt_path=domain_receipt_path,
        semantic_receipt_path=semantic_receipt_path,
        latest_standing_wake_loop_receipt_path=a2a_onboard._relative_or_absolute(
            wake_attempt_path,
            repo_root,
        ) if wake_attempt_path is not None else "",
        latest_standing_wake_loop_status=wake_attempt_status,
        latest_standing_wake_loop_blockers=wake_attempt_blockers,
        latest_standing_wake_loop_wrote_heartbeat=wake_attempt_wrote,
        latest_standing_wake_loop_session_scoped=wake_attempt_session,
        contract_surfaces=surfaces,
        operator_commands=a2a_onboard._operator_commands_for(agent_uid, broker=broker, mode=mode),
        evidence_paths=tuple(dict.fromkeys(evidence_paths)),
    )


def run_preflight(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_dir: Path,
    agent: str,
    broker: str,
    mode: str,
) -> tuple[dict[str, Any], int]:
    agents = a2a_onboard._nested_agents(a2a_onboard._load_json(a2a_bus_root / "agents.json"))
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    rows = [
        _row(
            uid,
            broker=broker,
            mode=mode,
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            agents=agents,
        )
        for uid in selected
    ]
    blockers = [f"{row.agent_uid}: {blocker}" for row in rows for blocker in row.blockers]
    payload: dict[str, Any] = {
        "schema_version": WAKE_LOOP_PREFLIGHT_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "broker": broker,
        "mode": mode,
        "counted_agents": list(selected),
        "required_contract_surfaces": list(REQUIRED_CONTRACT_SURFACES),
        "rows": [row.to_dict() for row in rows],
        "blockers": blockers,
        "operator_note": (
            "This preflight is non-mutating supporting evidence. It does not "
            "promote a session-scoped CLI, bridge heartbeat, or transport ACK "
            "into semantic readiness."
        ),
    }
    receipt_path = _write_receipt(receipt_dir, payload)
    payload["receipt_path"] = a2a_onboard._relative_or_absolute(receipt_path, repo_root)
    receipt_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma/a2a_bus"))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--mode", default="prevalidate")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    payload, exit_code = run_preflight(
        repo_root=repo_root,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
        receipt_dir=receipt_dir,
        agent=args.agent,
        broker=args.broker,
        mode=args.mode,
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_WAKE_LOOP_PREFLIGHT_OK" if payload["passed"] else "A2A_WAKE_LOOP_PREFLIGHT_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            for blocker in row["blockers"]:
                print(f"  * {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
