#!/usr/bin/env python3
"""Aggregate the A2A/NATS full-spec readiness proof into one receipt."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import AgentSelection, resolve_agent_selection  # noqa: E402
from dharma_swarm.a2a.jetstream_topology import (  # noqa: E402
    acl_probe_specs,
    canonical_topology_plan,
    render_nats_cli_commands,
    render_nats_consumer_configs,
    verify_acl_probe_specs,
    verify_topology_plan,
)
from scripts.governance import (  # noqa: E402
    a2a_domain_reply_artifact_preflight,
    a2a_domain_reply_request,
    a2a_identity_reconcile,
    a2a_live_acl_probe,
    a2a_live_topology_probe,
    a2a_onboard,
    a2a_presence_preflight,
    a2a_semantic_task_packet,
    a2a_standing_agent_preflight,
    a2a_wake_loop_preflight,
)


READINESS_SCHEMA = "dharma.a2a.full_spec_readiness.v1"
LIVE_ACL_PROBE_SCHEMA = "dharma.a2a.live_acl_probe.v1"
SEND_RECEIPT_SCHEMA = "dharma.a2a.send_receipt.v1"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "full_spec_readiness"
REQUIRED_TOPOLOGY_STREAMS = ("A2A_INBOX", "A2A_TASKS", "A2A_RECEIPTS", "A2A_DLQ")
REQUIRED_CUTOVER_FOLLOWUP_STEPS = (
    "add_A2A_TASKS",
    "add_A2A_RECEIPTS",
    "add_consumer_a2a_task_claimant",
    "add_consumer_a2a_task_closer",
    "add_consumer_a2a_receipt_indexer",
)
REQUIRED_CUTOVER_CONSUMER_STEPS = (
    "add_consumer_a2a_task_claimant",
    "add_consumer_a2a_task_closer",
    "add_consumer_a2a_receipt_indexer",
)
SEMANTIC_SEND_ROUTE = "agent-inbox"
VALID_SEMANTIC_SEND_ACK_TIERS = ("PUBLISH_ACCEPTED", "HANDLER_ACKED")
FAILED_SEMANTIC_SEND_STATUSES = (
    "NATS_SECRETS_MISSING",
    "NATS_CLIENT_MISSING",
    "PUBLISH_FAILED",
    "PUBLISH_DEDUPED",
)
EXIT_NOT_READY = 1
EXIT_INTERNAL_ERROR = 2


@dataclass(frozen=True)
class ReadinessComponent:
    name: str
    passed: bool
    blockers: tuple[str, ...]
    evidence_paths: tuple[str, ...] = ()
    details: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        if payload.get("details") is None:
            payload["details"] = {}
        return payload


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _latest_json(root: Path, pattern: str) -> Path | None:
    candidates = [path for path in root.glob(pattern) if path.is_file()]
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def _write_receipt(receipt_dir: Path, payload: dict[str, Any]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{_stamp()}-a2a-full-spec-readiness.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _run_onboard_receipt(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_root: Path,
    agent: str,
    broker: str,
    mode: str,
    cohort: str | None = None,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_onboard.run_onboard(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_root=receipt_root,
        agent=agent,
        broker=broker,
        mode=mode,
        cohort=cohort,
    )
    onboard_path = _latest_json(receipt_root / "onboard_receipts", "*-*.json")
    return payload, _relative_or_absolute(onboard_path, repo_root) if onboard_path else ""


def _latest_onboard_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(repo_root / "reports" / "a2a" / "onboard_receipts", "*.json")
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _run_live_topology_receipt(
    *,
    context: str,
    receipt_dir: Path,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_live_topology_probe.probe_live_topology(
        context=context,
        receipt_dir=receipt_dir,
        canonical_consumers_only=True,
    )
    return payload, str(payload.get("receipt_path") or "")


def _latest_live_topology_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(repo_root / "reports" / "a2a" / "live_topology", "*-a2a-live-topology-probe.json")
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _run_live_acl_probe_receipt(
    *,
    receipt_dir: Path,
    agent: str,
    a2a_bus_root: Path,
    context_template: str,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_live_acl_probe.run_probe(
        receipt_dir=receipt_dir,
        agent=agent,
        a2a_bus_root=a2a_bus_root,
        context_template=context_template,
        execute=False,
        timeout_s=10,
    )
    return payload, str(payload.get("receipt_path") or "")


def _latest_live_acl_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(repo_root / "reports" / "a2a" / "live_acl", "*-a2a-live-acl-probe.json")
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _run_semantic_task_packet_receipt(
    *,
    repo_root: Path,
    receipt_root: Path,
    agent: str,
    broker: str,
    mode: str,
    a2a_bus_root: Path,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_semantic_task_packet.render_packets(
        repo_root=repo_root,
        packet_dir=receipt_root / "semantic_tasks",
        receipt_dir=receipt_root / "semantic_task_packets",
        agent=agent,
        broker=broker,
        mode=mode,
        a2a_bus_root=a2a_bus_root,
    )
    packet_path = _latest_json(receipt_root / "semantic_task_packets", "*-a2a-semantic-task-packet.json")
    return payload, _relative_or_absolute(packet_path, repo_root) if packet_path else ""


def _latest_semantic_task_packet_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(repo_root / "reports" / "a2a" / "semantic_task_packets", "*-a2a-semantic-task-packet.json")
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _run_presence_preflight_receipt(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_root: Path,
    agent: str,
    broker: str,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_presence_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=receipt_root / "presence_preflight",
        agent=agent,
        broker=broker,
        domain=broker,
        ttl_seconds=a2a_presence_preflight.DEFAULT_TTL_SECONDS,
    )
    receipt_path = payload.get("receipt_path")
    return payload, str(receipt_path or "")


def _latest_presence_preflight_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(
        repo_root / "reports" / "a2a" / "presence_preflight",
        "*-a2a-presence-preflight.json",
    )
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _latest_identity_reconcile_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(
        repo_root / "reports" / "a2a" / "identity_reconcile",
        "*-a2a-identity-reconcile.json",
    )
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _latest_standing_agent_preflight_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(
        repo_root / "reports" / "a2a" / "standing_agent_preflight",
        "*-a2a-standing-agent-preflight.json",
    )
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _run_domain_reply_artifact_preflight_receipt(
    *,
    repo_root: Path,
    receipt_root: Path,
    semantic_task_packet_receipt_path: Path | None,
    semantic_send_receipt_dir: Path,
    outbox_root: Path,
    agent: str,
    a2a_bus_root: Path,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_domain_reply_artifact_preflight.run_preflight(
        repo_root=repo_root,
        receipt_dir=receipt_root / "domain_reply_artifact_preflight",
        semantic_task_packet_receipt_path=semantic_task_packet_receipt_path,
        send_receipt_root=semantic_send_receipt_dir,
        outbox_root=outbox_root,
        agent=agent,
        a2a_bus_root=a2a_bus_root,
    )
    receipt_path = payload.get("receipt_path")
    return payload, str(receipt_path or "")


def _latest_domain_reply_artifact_preflight_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(
        repo_root / "reports" / "a2a" / "domain_reply_artifact_preflight",
        "*-a2a-domain-reply-artifact-preflight.json",
    )
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _latest_domain_reply_request_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(
        repo_root / "reports" / "a2a" / "domain_reply_requests",
        "*-a2a-domain-reply-request.json",
    )
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _run_wake_loop_preflight_receipt(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_root: Path,
    agent: str,
    broker: str,
    mode: str,
) -> tuple[dict[str, Any], str]:
    payload, _exit_code = a2a_wake_loop_preflight.run_preflight(
        repo_root=repo_root,
        a2a_bus_root=a2a_bus_root,
        receipt_dir=receipt_root / "wake_loop_preflight",
        agent=agent,
        broker=broker,
        mode=mode,
    )
    wake_path = _latest_json(receipt_root / "wake_loop_preflight", "*-a2a-wake-loop-preflight.json")
    return payload, _relative_or_absolute(wake_path, repo_root) if wake_path else ""


def _latest_wake_loop_preflight_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(repo_root / "reports" / "a2a" / "wake_loop_preflight", "*-a2a-wake-loop-preflight.json")
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _selected_agents(
    agent: str,
    *,
    a2a_bus_root: Path | None = None,
    cohort: str | None = None,
    min_agents: int | None = None,
) -> AgentSelection:
    return resolve_agent_selection(
        agent,
        cohort=cohort,
        a2a_bus_root=a2a_bus_root,
        min_agents=min_agents,
    )


def _cohort_denominator_blockers(
    payload: dict[str, Any],
    *,
    selection: AgentSelection,
    label: str,
) -> list[str]:
    counted_agents = tuple(str(agent) for agent in payload.get("counted_agents", []) if isinstance(agent, str))
    expected_agents = selection.agent_uids
    if set(counted_agents) == set(expected_agents):
        return []
    return [
        f"{label} counted agent denominator mismatch: expected "
        + ", ".join(expected_agents)
        + "; observed "
        + ", ".join(counted_agents)
    ]


def _agent_quorum_result(
    *,
    component_name: str,
    selection: AgentSelection,
    failures_by_agent: dict[str, list[str]],
    evidence_paths: Iterable[str] = (),
) -> ReadinessComponent:
    passed_agents = [
        agent_uid
        for agent_uid in selection.agent_uids
        if not failures_by_agent.get(agent_uid)
    ]
    all_agent_blockers = [
        failure
        for agent_uid in selection.agent_uids
        for failure in failures_by_agent.get(agent_uid, [])
    ]
    quorum_blockers: list[str] = []
    if len(passed_agents) < selection.required_agent_count:
        quorum_blockers.append(
            f"{component_name} quorum failed: "
            f"{len(passed_agents)}/{selection.required_agent_count} agents passed "
            f"for selector {selection.selector}"
        )
        quorum_blockers.extend(all_agent_blockers)
    elif selection.strict:
        quorum_blockers.extend(all_agent_blockers)
    return ReadinessComponent(
        component_name,
        not quorum_blockers,
        tuple(dict.fromkeys(quorum_blockers)),
        tuple(dict.fromkeys(path for path in evidence_paths if path)),
        {
            "selector": selection.selector,
            "selection_kind": selection.selection_kind,
            "required_agent_count": selection.required_agent_count,
            "selected_agent_count": len(selection.agent_uids),
            "passed_agents": passed_agents,
            "failed_agents": [
                agent_uid
                for agent_uid in selection.agent_uids
                if failures_by_agent.get(agent_uid)
            ],
        },
    )


def _run_topology_receipt(
    *,
    repo_root: Path,
    counted_agents: tuple[str, ...],
) -> tuple[dict[str, Any], str]:
    plan = canonical_topology_plan(counted_agents)
    verification = verify_topology_plan(plan, counted_agent_uids=counted_agents)
    acl_specs = acl_probe_specs(counted_agents)
    acl_verification = verify_acl_probe_specs(acl_specs, counted_agent_uids=counted_agents)
    payload: dict[str, Any] = {
        "schema_version": "dharma.a2a.jetstream_topology_verifier.v1",
        "timestamp": _utc_now(),
        "passed": verification.passed and acl_verification.passed,
        "failures": list(verification.failures) + list(acl_verification.failures),
        "counted_agents": list(counted_agents),
        "plan": plan.to_dict(),
        "acl_probe_specs": [spec.to_dict() for spec in acl_specs],
        "acl_probe_verification": acl_verification.to_dict(),
        "commands": list(render_nats_cli_commands(plan)),
        "desired_consumer_configs": render_nats_consumer_configs(plan),
        "live_rollout_note": (
            "Commands are an operator recipe. Live application still requires "
            "Agni credentials and explicit operator approval."
        ),
    }
    topology_dir = repo_root / "reports" / "a2a" / "topology"
    topology_dir.mkdir(parents=True, exist_ok=True)
    path = topology_dir / f"{_stamp()}-a2a-jetstream-topology.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    payload["receipt_path"] = _relative_or_absolute(path, repo_root)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload, str(payload["receipt_path"])


def _latest_topology_receipt(repo_root: Path) -> tuple[dict[str, Any], str]:
    path = _latest_json(repo_root / "reports" / "a2a" / "topology", "*-a2a-jetstream-topology.json")
    if path is None:
        return {}, ""
    return _load_json(path), _relative_or_absolute(path, repo_root)


def _topology_component(
    payload: dict[str, Any],
    evidence_path: str,
    *,
    topology_path: str = "",
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths = [path for path in (evidence_path, topology_path) if path]
    if not payload:
        blockers.append("missing live topology receipt")
        return ReadinessComponent("live_topology", False, tuple(blockers), tuple(evidence_paths))
    if payload.get("schema_version") != "dharma.a2a.live_topology_probe.v1":
        blockers.append("live topology receipt has wrong schema")
    if payload.get("passed") is not True:
        failures = payload.get("failures")
        if isinstance(failures, list) and failures:
            blockers.extend(str(failure) for failure in failures)
        else:
            blockers.append("live topology verification did not pass")
    verification = payload.get("verification") if isinstance(payload.get("verification"), dict) else {}
    missing_streams = verification.get("missing_streams")
    if isinstance(missing_streams, list) and missing_streams:
        blockers.append("missing canonical streams: " + ", ".join(str(item) for item in missing_streams))
    overlaps = verification.get("overlapping_subjects")
    if isinstance(overlaps, list) and overlaps:
        blockers.append("canonical subject overlaps remain: " + "; ".join(str(item) for item in overlaps))
    observed = set(str(item) for item in verification.get("observed_streams", []) if isinstance(item, str))
    if observed:
        missing_required = sorted(set(REQUIRED_TOPOLOGY_STREAMS) - observed)
        if missing_required:
            blockers.append("required topology streams absent from observation: " + ", ".join(missing_required))
    return ReadinessComponent(
        "live_topology",
        not blockers,
        tuple(dict.fromkeys(blockers)),
        tuple(dict.fromkeys(evidence_paths)),
    )


def _acl_probe_contract_component(
    payload: dict[str, Any],
    evidence_path: str,
    *,
    selection: AgentSelection,
    mode: str,
    live_acl_payload: dict[str, Any] | None = None,
    live_acl_path: str = "",
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths = [evidence_path] if evidence_path else []
    if not payload:
        blockers.append("missing topology/ACL probe contract receipt")
        return ReadinessComponent("acl_probe_contract", False, tuple(blockers))
    if payload.get("schema_version") != "dharma.a2a.jetstream_topology_verifier.v1":
        blockers.append("topology/ACL receipt has wrong schema")
    expected_agents = selection.agent_uids
    blockers.extend(_cohort_denominator_blockers(payload, selection=selection, label="ACL"))
    acl_verification = payload.get("acl_probe_verification")
    if not isinstance(acl_verification, dict):
        blockers.append("topology receipt missing acl_probe_verification")
    elif acl_verification.get("passed") is not True:
        failures = acl_verification.get("failures")
        if isinstance(failures, list) and failures:
            blockers.extend(f"ACL probe contract failure: {failure}" for failure in failures)
        else:
            blockers.append("ACL probe contract did not pass")
    specs = payload.get("acl_probe_specs")
    if not isinstance(specs, list) or not specs:
        blockers.append("topology receipt missing acl_probe_specs")
    else:
        by_agent = {
            str(spec.get("agent_uid")): spec
            for spec in specs
            if isinstance(spec, dict) and spec.get("agent_uid")
        }
        for agent_uid in expected_agents:
            spec = by_agent.get(agent_uid)
            if spec is None:
                blockers.append(f"{agent_uid}: missing ACL probe spec")
                continue
            principal = str(spec.get("principal") or "")
            if not principal.startswith("a2a_"):
                blockers.append(f"{agent_uid}: ACL principal is not canonical a2a_ form")
            for required in ("publish_own_presence", "pull_own_inbox_consumer", "ack_own_delivery", "publish_own_receipt"):
                if required not in tuple(spec.get("positive_probes") or ()):
                    blockers.append(f"{agent_uid}: missing positive ACL probe {required}")
            for required in (
                "deny_pull_other_agent_inbox",
                "deny_subscribe_broad_fleet_subjects",
                "deny_mutate_streams_or_consumers",
                "deny_insecure_tls_on_agni",
            ):
                if required not in tuple(spec.get("negative_probes") or ()):
                    blockers.append(f"{agent_uid}: missing negative ACL probe {required}")
            deny_subjects = tuple(spec.get("deny_subjects") or ())
            if "$JS.API.STREAM.>" not in deny_subjects or "$JS.API.CONSUMER.>" not in deny_subjects:
                blockers.append(f"{agent_uid}: ACL does not deny JetStream mutation APIs")
            if "dharma.a2a.>" not in deny_subjects:
                blockers.append(f"{agent_uid}: ACL does not deny broad fleet subscription")
    if mode == "live":
        if live_acl_path:
            evidence_paths.append(live_acl_path)
        if not live_acl_payload:
            blockers.append("missing live ACL probe receipt")
        elif live_acl_payload.get("schema_version") != LIVE_ACL_PROBE_SCHEMA:
            blockers.append("live ACL probe receipt has wrong schema")
        else:
            live_counted_agents = tuple(
                str(agent)
                for agent in live_acl_payload.get("counted_agents", [])
                if isinstance(agent, str)
            )
            if set(live_counted_agents) != set(expected_agents):
                blockers.append(
                    "live ACL counted agent denominator mismatch: expected "
                    + ", ".join(expected_agents)
                    + "; observed "
                    + ", ".join(live_counted_agents)
                )
            live_acl = live_acl_payload.get("live_acl_probe_verification")
            if live_acl_payload.get("passed") is not True or not isinstance(live_acl, dict) or live_acl.get("passed") is not True:
                failures = live_acl_payload.get("failures")
                if isinstance(failures, list) and failures:
                    blockers.extend(f"live ACL probe failure: {failure}" for failure in failures)
                else:
                    blockers.append("live ACL positive/negative probes are not proven")
    return ReadinessComponent(
        "acl_probe_contract",
        not blockers,
        tuple(dict.fromkeys(blockers)),
        tuple(dict.fromkeys(evidence_paths)),
    )


def _row_state(row: dict[str, Any], key: str) -> str:
    value = row.get(key)
    return str(value or "")


def _onboard_component(
    payload: dict[str, Any],
    evidence_path: str,
    *,
    selection: AgentSelection,
    mode: str,
) -> ReadinessComponent:
    blockers: list[str] = []
    if not payload:
        blockers.append("missing onboard receipt")
        return ReadinessComponent("counted_agent_readiness", False, tuple(blockers))
    if payload.get("schema_version") != a2a_onboard.ONBOARD_RECEIPT_SCHEMA:
        blockers.append("onboard receipt has wrong schema")
    expected_agents = selection.agent_uids
    blockers.extend(_cohort_denominator_blockers(payload, selection=selection, label="onboard"))
    rows = payload.get("rows")
    if not isinstance(rows, list):
        rows = []
        blockers.append("onboard receipt missing rows")
    row_by_agent = {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }
    failures_by_agent: dict[str, list[str]] = {agent_uid: [] for agent_uid in expected_agents}
    for agent_uid in expected_agents:
        row = row_by_agent.get(agent_uid)
        if row is None:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing onboard row")
            continue
        failure_states = row.get("failure_states")
        if isinstance(failure_states, list | tuple) and failure_states:
            failures_by_agent[agent_uid].append(f"{agent_uid}: failure states present: {', '.join(str(item) for item in failure_states)}")
        if _row_state(row, "domain_receipt_state") != a2a_onboard.DOMAIN_RECEIPTED:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing target-owned DOMAIN_RECEIPTED evidence")
        if _row_state(row, "semantic_receipt_state") != a2a_onboard.SEMANTIC_SIGNED:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing current SEMANTIC_SIGNED evidence")
        if _row_state(row, "handler_ack_state") != "HANDLER_ACKED" and mode == "live":
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing HANDLER_ACKED evidence for live mode")
        if row.get("last_domain_receipt") == "":
            failures_by_agent[agent_uid].append(f"{agent_uid}: no target-owned domain receipt path")
        if row.get("last_semantic_receipt") == "":
            failures_by_agent[agent_uid].append(f"{agent_uid}: no semantic receipt path")
        if "BLOCKED_WAKE_LOOP" in row.get("failure_states", ()):
            failures_by_agent[agent_uid].append(f"{agent_uid}: wake loop is blocked")
        if "DEGRADED_SESSION_SCOPED" in row.get("failure_states", ()):
            failures_by_agent[agent_uid].append(f"{agent_uid}: session-scoped evidence cannot satisfy standing-agent readiness")
    required_final = "READY_LIVE" if mode == "live" else "READY_PREVALIDATED"
    for agent_uid, row in row_by_agent.items():
        if agent_uid not in expected_agents:
            continue
        if _row_state(row, "final_state") != required_final:
            failures_by_agent.setdefault(agent_uid, []).append(
                f"{agent_uid}: final_state is {_row_state(row, 'final_state')}, not {required_final}"
            )
    quorum = _agent_quorum_result(
        component_name="counted_agent_readiness",
        selection=selection,
        failures_by_agent=failures_by_agent,
        evidence_paths=(evidence_path,) if evidence_path else (),
    )
    return ReadinessComponent(
        quorum.name,
        not blockers and quorum.passed,
        tuple(dict.fromkeys(blockers + list(quorum.blockers))),
        quorum.evidence_paths,
        quorum.details,
    )


def _semantic_task_packet_component(
    payload: dict[str, Any],
    evidence_path: str,
    *,
    selection: AgentSelection,
    repo_root: Path,
) -> ReadinessComponent:
    blockers: list[str] = []
    if not payload:
        blockers.append("missing semantic task packet receipt")
        return ReadinessComponent("semantic_task_packets", False, tuple(blockers))
    if payload.get("schema_version") != a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA:
        blockers.append("semantic task packet receipt has wrong schema")
    if payload.get("locked_spec_sha256") != a2a_onboard.LOCKED_SPEC_SHA256:
        blockers.append("semantic task packet locked_spec_sha256 does not match current locked spec")
    expected_agents = selection.agent_uids
    blockers.extend(_cohort_denominator_blockers(payload, selection=selection, label="semantic task packet"))
    rows = payload.get("rows")
    if not isinstance(rows, list):
        rows = []
        blockers.append("semantic task packet receipt missing rows")
    row_by_agent = {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }
    failures_by_agent: dict[str, list[str]] = {agent_uid: [] for agent_uid in expected_agents}
    for agent_uid in expected_agents:
        row = row_by_agent.get(agent_uid)
        if row is None:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing semantic task packet row")
            continue
        if row.get("locked_spec_sha256") != a2a_onboard.LOCKED_SPEC_SHA256:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet locked spec hash mismatch")
        if row.get("required_reply_artifact_schema") != a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet missing required reply artifact schema")
        if row.get("required_semantic_receipt_schema") != a2a_onboard.SEMANTIC_RECEIPT_SCHEMA:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet missing required semantic receipt schema")
        if row.get("required_failure_digest_prompt") != a2a_semantic_task_packet.REQUIRED_FAILURE_DIGEST_PROMPT:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet missing failure digest prompt")
        packet_path_raw = str(row.get("packet_path") or "")
        if not packet_path_raw:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet row missing packet_path")
            continue
        packet_path = Path(packet_path_raw).expanduser()
        if not packet_path.is_absolute():
            packet_path = repo_root / packet_path
        if not packet_path.exists():
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet file does not exist")
            continue
        packet_sha = hashlib.sha256(packet_path.read_bytes()).hexdigest()
        if row.get("packet_sha256") != packet_sha:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet hash mismatch")
        if row.get("task_hash") != f"sha256:{packet_sha}":
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet task_hash mismatch")
        packet_text = packet_path.read_text(encoding="utf-8")
        for required in (
            a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA,
            a2a_semantic_task_packet.REQUIRED_REPLY_ARTIFACT_SCHEMA,
            a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
            "failure_digest",
            a2a_onboard.LOCKED_SPEC_SHA256,
        ):
            if required not in packet_text:
                failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet text missing {required}")
    quorum = _agent_quorum_result(
        component_name="semantic_task_packets",
        selection=selection,
        failures_by_agent=failures_by_agent,
        evidence_paths=(evidence_path,) if evidence_path else (),
    )
    return ReadinessComponent(
        quorum.name,
        not blockers and quorum.passed,
        tuple(dict.fromkeys(blockers + list(quorum.blockers))),
        quorum.evidence_paths,
        quorum.details,
    )


def _semantic_task_rows(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = payload.get("rows")
    if not isinstance(rows, list):
        return {}
    return {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }


def _send_receipt_entries(
    *,
    repo_root: Path,
    receipt_dir: Path,
) -> list[tuple[dict[str, Any], str]]:
    if not receipt_dir.exists():
        return []
    entries: list[tuple[dict[str, Any], str]] = []
    for path in sorted(receipt_dir.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
        payload = _load_json(path)
        if payload.get("schema_version") == SEND_RECEIPT_SCHEMA:
            entries.append((payload, _relative_or_absolute(path, repo_root)))
    return entries


def _semantic_send_receipt_failures(
    *,
    receipt: dict[str, Any],
    row: dict[str, Any],
    agent_uid: str,
) -> list[str]:
    failures: list[str] = []
    packet_id = str(row.get("packet_id") or "")
    if receipt.get("packet_id") != packet_id:
        failures.append(f"{agent_uid}: semantic send receipt packet_id mismatch")
    if receipt.get("target_uid") != agent_uid:
        failures.append(f"{agent_uid}: semantic send receipt target_uid mismatch")
    if receipt.get("route") != SEMANTIC_SEND_ROUTE:
        failures.append(f"{agent_uid}: semantic send receipt route is not {SEMANTIC_SEND_ROUTE}")
    expected_subject = f"dharma.agent.{agent_uid}.inbox"
    if receipt.get("subject") != expected_subject:
        failures.append(f"{agent_uid}: semantic send receipt subject is not {expected_subject}")
    expected_reply_subject = f"{expected_subject}.reply.{packet_id}"
    if receipt.get("reply_subject") != expected_reply_subject:
        failures.append(f"{agent_uid}: semantic send receipt reply_subject mismatch")
    status = str(receipt.get("status") or "")
    if status in FAILED_SEMANTIC_SEND_STATUSES or not status:
        failures.append(f"{agent_uid}: semantic send receipt status is not publish proof")
    ack_tier = str(receipt.get("ack_tier") or "")
    if ack_tier not in VALID_SEMANTIC_SEND_ACK_TIERS:
        failures.append(f"{agent_uid}: semantic send receipt ack_tier is not publish proof")

    semantic_ref = receipt.get("semantic_task_packet")
    if not isinstance(semantic_ref, dict):
        failures.append(f"{agent_uid}: semantic send receipt missing semantic_task_packet reference")
        semantic_ref = {}
    checks = (
        (receipt, "semantic_task_packet_sha256", row.get("packet_sha256"), "semantic_task_packet_sha256"),
        (receipt, "task_hash", row.get("task_hash"), "task_hash"),
        (receipt, "locked_spec_sha256", row.get("locked_spec_sha256"), "locked_spec_sha256"),
        (semantic_ref, "packet_id", packet_id, "semantic_task_packet.packet_id"),
        (semantic_ref, "agent_uid", agent_uid, "semantic_task_packet.agent_uid"),
        (semantic_ref, "packet_sha256", row.get("packet_sha256"), "semantic_task_packet.packet_sha256"),
        (semantic_ref, "task_hash", row.get("task_hash"), "semantic_task_packet.task_hash"),
        (semantic_ref, "locked_spec_sha256", row.get("locked_spec_sha256"), "semantic_task_packet.locked_spec_sha256"),
    )
    for source, key, expected, label in checks:
        if source.get(key) != expected:
            failures.append(f"{agent_uid}: semantic send receipt {label} mismatch")
    return failures


def _semantic_send_receipts_component(
    semantic_task_payload: dict[str, Any],
    *,
    selection: AgentSelection,
    repo_root: Path,
    receipt_dir: Path,
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths: list[str] = []
    rows = _semantic_task_rows(semantic_task_payload)
    if not rows:
        blockers.append("missing semantic task packet rows for send receipt validation")
        return ReadinessComponent("semantic_send_receipts", False, tuple(blockers))

    entries = _send_receipt_entries(repo_root=repo_root, receipt_dir=receipt_dir)
    failures_by_agent: dict[str, list[str]] = {agent_uid: [] for agent_uid in selection.agent_uids}
    for agent_uid in selection.agent_uids:
        row = rows.get(agent_uid)
        if row is None:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing semantic task packet row for send receipt validation")
            continue
        packet_id = str(row.get("packet_id") or "")
        if not packet_id:
            failures_by_agent[agent_uid].append(f"{agent_uid}: semantic task packet row missing packet_id for send receipt validation")
            continue
        candidates = [
            (receipt, path)
            for receipt, path in entries
            if str(receipt.get("packet_id") or "") == packet_id
        ]
        if not candidates:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing semantic task send receipt")
            continue
        candidate_failures = [
            (_semantic_send_receipt_failures(receipt=receipt, row=row, agent_uid=agent_uid), path)
            for receipt, path in candidates
        ]
        valid = next(((failures, path) for failures, path in candidate_failures if not failures), None)
        if valid is not None:
            evidence_paths.append(valid[1])
            continue
        first_failures, first_path = candidate_failures[0]
        evidence_paths.append(first_path)
        failures_by_agent[agent_uid].extend(first_failures)
    quorum = _agent_quorum_result(
        component_name="semantic_send_receipts",
        selection=selection,
        failures_by_agent=failures_by_agent,
        evidence_paths=evidence_paths,
    )
    return ReadinessComponent(
        quorum.name,
        not blockers and quorum.passed,
        tuple(dict.fromkeys(blockers + list(quorum.blockers))),
        quorum.evidence_paths,
        quorum.details,
    )


def _identity_presence_component(
    payload: dict[str, Any],
    evidence_path: str,
    identity_payload: dict[str, Any],
    identity_evidence_path: str,
    *,
    selection: AgentSelection,
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths = [evidence_path] if evidence_path else []
    if (
        identity_evidence_path
        and identity_payload.get("schema_version") == a2a_identity_reconcile.IDENTITY_RECONCILE_SCHEMA
    ):
        evidence_paths.append(identity_evidence_path)
    if not payload:
        blockers.append("missing presence preflight receipt")
        return ReadinessComponent("identity_presence", False, tuple(blockers), tuple(evidence_paths))
    if payload.get("schema_version") != a2a_presence_preflight.PRESENCE_PREFLIGHT_SCHEMA:
        blockers.append("presence preflight receipt has wrong schema")
    if payload.get("passed") is not True and selection.strict:
        failures = payload.get("blockers")
        if isinstance(failures, list) and failures:
            blockers.extend(str(failure) for failure in failures)
        else:
            blockers.append("presence preflight did not pass")
    expected_agents = selection.agent_uids
    blockers.extend(_cohort_denominator_blockers(payload, selection=selection, label="presence"))
    required_fields = set(a2a_presence_preflight.REQUIRED_PRESENCE_FIELDS)
    observed_fields = set(str(field) for field in payload.get("required_presence_fields", []) if isinstance(field, str))
    missing_fields = sorted(required_fields - observed_fields)
    if missing_fields:
        blockers.append("presence preflight missing required field declarations: " + ", ".join(missing_fields))
    rows = payload.get("rows")
    if not isinstance(rows, list):
        rows = []
        blockers.append("presence preflight receipt missing rows")
    row_by_agent = {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }
    failures_by_agent: dict[str, list[str]] = {agent_uid: [] for agent_uid in expected_agents}
    for agent_uid in expected_agents:
        row = row_by_agent.get(agent_uid)
        if row is None:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing presence preflight row")
            continue
        if row.get("registry_entry_present") is not True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing canonical registry entry")
        if row.get("presence_projection_present") is not True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing presence projection")
        if row.get("stale_presence") is True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: stale presence")
        if row.get("expired_presence") is True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: expired presence")
        if row.get("alias_collisions"):
            failures_by_agent[agent_uid].append(f"{agent_uid}: alias collision")
        if row.get("final_state") != a2a_presence_preflight.READY_PRESENCE_PREVALIDATED:
            failures_by_agent[agent_uid].append(f"{agent_uid}: presence final_state is not READY_PRESENCE_PREVALIDATED")
    quorum = _agent_quorum_result(
        component_name="identity_presence",
        selection=selection,
        failures_by_agent=failures_by_agent,
        evidence_paths=evidence_paths,
    )
    return ReadinessComponent(
        quorum.name,
        not blockers and quorum.passed,
        tuple(dict.fromkeys(blockers + list(quorum.blockers))),
        quorum.evidence_paths,
        quorum.details,
    )


def _domain_reply_artifact_component(
    payload: dict[str, Any],
    evidence_path: str,
    request_payload: dict[str, Any] | None = None,
    request_evidence_path: str = "",
    *,
    selection: AgentSelection,
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths = [evidence_path] if evidence_path else []
    if (
        request_evidence_path
        and request_payload
        and request_payload.get("schema_version") == a2a_domain_reply_request.DOMAIN_REPLY_REQUEST_SCHEMA
    ):
        evidence_paths.append(request_evidence_path)
    if not payload:
        blockers.append("missing domain-reply artifact preflight receipt")
        return ReadinessComponent("domain_reply_artifacts", False, tuple(blockers), tuple(evidence_paths))
    if payload.get("schema_version") != a2a_domain_reply_artifact_preflight.DOMAIN_REPLY_ARTIFACT_PREFLIGHT_SCHEMA:
        blockers.append("domain-reply artifact preflight receipt has wrong schema")
    if payload.get("passed") is not True and selection.strict:
        failures = payload.get("blockers")
        if isinstance(failures, list) and failures:
            blockers.extend(str(failure) for failure in failures)
        else:
            blockers.append("domain-reply artifact preflight did not pass")
    expected_agents = selection.agent_uids
    blockers.extend(_cohort_denominator_blockers(payload, selection=selection, label="domain-reply artifact"))
    rows = payload.get("rows")
    if not isinstance(rows, list):
        rows = []
        blockers.append("domain-reply artifact preflight receipt missing rows")
    row_by_agent = {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }
    failures_by_agent: dict[str, list[str]] = {agent_uid: [] for agent_uid in expected_agents}
    for agent_uid in expected_agents:
        row = row_by_agent.get(agent_uid)
        if row is None:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing domain-reply artifact preflight row")
            continue
        row_evidence = row.get("evidence_paths")
        if isinstance(row_evidence, list | tuple):
            evidence_paths.extend(
                str(path)
                for path in row_evidence
                if isinstance(path, str) and path
            )
        if _row_state(row, "final_state") != a2a_domain_reply_artifact_preflight.READY_DOMAIN_REPLY_ARTIFACT:
            failures_by_agent[agent_uid].append(f"{agent_uid}: domain reply artifact is blocked")
        if row.get("send_receipt_present") is not True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing semantic task send receipt for domain reply artifact")
        if row.get("artifact_present") is not True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing target-owned domain reply artifact")
        if row.get("peer_model_processed_claim") is not True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: domain reply artifact lacks peer_model_processed_claim")
        if row.get("semantic_reply_claim") is not True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: domain reply artifact lacks semantic_reply_claim")
    quorum = _agent_quorum_result(
        component_name="domain_reply_artifacts",
        selection=selection,
        failures_by_agent=failures_by_agent,
        evidence_paths=evidence_paths,
    )
    return ReadinessComponent(
        quorum.name,
        not blockers and quorum.passed,
        tuple(dict.fromkeys(blockers + list(quorum.blockers))),
        quorum.evidence_paths,
        quorum.details,
    )


def _wake_loop_component(
    payload: dict[str, Any],
    evidence_path: str,
    standing_payload: dict[str, Any],
    standing_evidence_path: str,
    *,
    selection: AgentSelection,
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths = [evidence_path] if evidence_path else []
    if (
        standing_evidence_path
        and standing_payload.get("schema_version") == a2a_standing_agent_preflight.STANDING_AGENT_PREFLIGHT_SCHEMA
    ):
        evidence_paths.append(standing_evidence_path)
    if not payload:
        blockers.append("missing wake-loop preflight receipt")
        return ReadinessComponent("wake_loop_preflight", False, tuple(blockers), tuple(evidence_paths))
    if payload.get("schema_version") != a2a_wake_loop_preflight.WAKE_LOOP_PREFLIGHT_SCHEMA:
        blockers.append("wake-loop preflight receipt has wrong schema")
    if payload.get("passed") is not True and selection.strict:
        failures = payload.get("blockers")
        if isinstance(failures, list) and failures:
            blockers.extend(str(failure) for failure in failures)
        else:
            blockers.append("wake-loop preflight did not pass")
    expected_agents = selection.agent_uids
    blockers.extend(_cohort_denominator_blockers(payload, selection=selection, label="wake-loop"))
    required_surfaces = set(a2a_wake_loop_preflight.REQUIRED_CONTRACT_SURFACES)
    observed_surfaces = set(str(surface) for surface in payload.get("required_contract_surfaces", ()) if isinstance(surface, str))
    missing_declared_surfaces = sorted(required_surfaces - observed_surfaces)
    if missing_declared_surfaces:
        blockers.append("wake-loop receipt missing declared surfaces: " + ", ".join(missing_declared_surfaces))
    rows = payload.get("rows")
    if not isinstance(rows, list):
        rows = []
        blockers.append("wake-loop preflight receipt missing rows")
    row_by_agent = {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }
    failures_by_agent: dict[str, list[str]] = {agent_uid: [] for agent_uid in expected_agents}
    for agent_uid in expected_agents:
        row = row_by_agent.get(agent_uid)
        if row is None:
            failures_by_agent[agent_uid].append(f"{agent_uid}: missing wake-loop preflight row")
            continue
        row_evidence = row.get("evidence_paths")
        if isinstance(row_evidence, list | tuple):
            evidence_paths.extend(
                str(path)
                for path in row_evidence
                if isinstance(path, str) and path
            )
        final_state = _row_state(row, "final_state")
        if final_state != a2a_wake_loop_preflight.READY_WAKE_LOOP_PREVALIDATED:
            failures_by_agent[agent_uid].append(
                f"{agent_uid}: wake-loop final_state is {final_state}, "
                f"not {a2a_wake_loop_preflight.READY_WAKE_LOOP_PREVALIDATED}"
            )
        if row.get("session_scoped") is True:
            failures_by_agent[agent_uid].append(f"{agent_uid}: wake-loop evidence is session scoped")
        surfaces = row.get("contract_surfaces")
        if not isinstance(surfaces, dict):
            failures_by_agent[agent_uid].append(f"{agent_uid}: wake-loop row missing contract_surfaces")
            continue
        for surface in a2a_wake_loop_preflight.REQUIRED_CONTRACT_SURFACES:
            surface_payload = surfaces.get(surface)
            if not isinstance(surface_payload, dict) or surface_payload.get("present") is not True:
                failures_by_agent[agent_uid].append(f"{agent_uid}: missing {surface}")
    quorum = _agent_quorum_result(
        component_name="wake_loop_preflight",
        selection=selection,
        failures_by_agent=failures_by_agent,
        evidence_paths=evidence_paths,
    )
    return ReadinessComponent(
        quorum.name,
        not blockers and quorum.passed,
        tuple(dict.fromkeys(blockers + list(quorum.blockers))),
        quorum.evidence_paths,
        quorum.details,
    )


def _cutover_gate_component(
    payload: dict[str, Any],
    evidence_path: str,
    *,
    topology_path: str = "",
) -> ReadinessComponent:
    blockers: list[str] = []
    evidence_paths = [path for path in (evidence_path, topology_path) if path]
    transaction = payload.get("cutover_transaction_plan") if isinstance(payload.get("cutover_transaction_plan"), dict) else {}
    verification = payload.get("verification") if isinstance(payload.get("verification"), dict) else {}
    legacy_present = bool(verification.get("overlapping_subjects"))
    if payload.get("passed") is not True:
        gate = transaction.get("mutation_gate") or "A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover"
        blockers.append(f"live cutover/install not complete; required gate remains {gate}")
        if not transaction:
            blockers.append("cutover transaction plan missing")
    if payload.get("passed") is not True and transaction:
        legacy_steps = transaction.get("legacy_cutover_steps")
        if legacy_present and not legacy_steps:
            blockers.append("cutover transaction plan missing legacy cutover steps")
        rollback_plan = transaction.get("rollback_plan")
        if not isinstance(rollback_plan, dict) or not rollback_plan:
            rollback_plan = payload.get("cutover_rollback_plan")
        if legacy_present and not isinstance(rollback_plan, dict) and rollback_plan is not None:
            blockers.append("cutover transaction plan has invalid rollback plan")
        if legacy_present and not rollback_plan:
            blockers.append("cutover transaction plan missing rollback plan")
        if isinstance(legacy_steps, list) and isinstance(rollback_plan, dict):
            for step in legacy_steps:
                if not isinstance(step, dict):
                    continue
                step_id = str(step.get("step_id") or "")
                rollback = rollback_plan.get(step_id)
                if not isinstance(rollback, dict) or rollback.get("available") is not True:
                    blockers.append(f"{step_id}: missing available rollback command")
        post_cutover_blockers = transaction.get("post_cutover_blockers_after_legacy_cutover")
        if isinstance(post_cutover_blockers, list) and post_cutover_blockers:
            blockers.extend(
                f"post-cutover simulation blocker: {blocker}"
                for blocker in post_cutover_blockers
            )
        followup_steps = transaction.get("post_cutover_steps_after_legacy_cutover")
        if not followup_steps:
            blockers.append("cutover transaction plan missing post-cutover steps")
        elif isinstance(followup_steps, list):
            followup_by_id = {
                str(step.get("step_id")): step
                for step in followup_steps
                if isinstance(step, dict) and step.get("step_id")
            }
            for step_id in REQUIRED_CUTOVER_FOLLOWUP_STEPS:
                if step_id not in followup_by_id:
                    blockers.append(f"cutover transaction plan missing follow-up step {step_id}")
            for step_id in REQUIRED_CUTOVER_CONSUMER_STEPS:
                step = followup_by_id.get(step_id)
                if step is None:
                    continue
                if not isinstance(step.get("desired_consumer_config"), dict):
                    blockers.append(f"{step_id}: missing exact desired_consumer_config")
                if not step.get("execution_command_template"):
                    blockers.append(f"{step_id}: missing execution_command_template")
                if step.get("execution_uses_exact_config") is not True:
                    blockers.append(f"{step_id}: execution does not use exact config")
            for step_id, step in followup_by_id.items():
                compensation = step.get("compensation")
                if not isinstance(compensation, dict) or compensation.get("available") is not True:
                    blockers.append(f"{step_id}: missing available compensation command")
        compensation_plan = transaction.get("post_cutover_compensation_plan")
        if not compensation_plan:
            blockers.append("cutover transaction plan missing compensation plan")
        elif isinstance(compensation_plan, list) and isinstance(followup_steps, list):
            compensation_step_ids = {
                str(item.get("step_id"))
                for item in compensation_plan
                if isinstance(item, dict) and item.get("step_id")
            }
            followup_step_ids = {
                str(item.get("step_id"))
                for item in followup_steps
                if isinstance(item, dict) and item.get("step_id")
            }
            missing_compensation = sorted(followup_step_ids - compensation_step_ids)
            if missing_compensation:
                blockers.append(
                    "cutover transaction plan missing compensation for: "
                    + ", ".join(missing_compensation)
                )
    return ReadinessComponent(
        "cutover_completion",
        not blockers,
        tuple(dict.fromkeys(blockers)),
        tuple(dict.fromkeys(evidence_paths)),
    )


def _readiness_score(components: tuple[ReadinessComponent, ...]) -> int:
    weights = {
        "live_topology": 30,
        "cutover_completion": 20,
        "acl_probe_contract": 15,
        "semantic_task_packets": 5,
        "semantic_send_receipts": 5,
        "identity_presence": 5,
        "domain_reply_artifacts": 5,
        "wake_loop_preflight": 10,
        "counted_agent_readiness": 5,
    }
    return sum(weights.get(component.name, 0) for component in components if component.passed)


def run_readiness(
    *,
    repo_root: Path,
    receipt_dir: Path,
    agent: str,
    cohort: str | None = None,
    min_agents: int | None = None,
    broker: str,
    mode: str,
    a2a_bus_root: Path,
    context: str,
    run_onboard: bool,
    run_live_probe: bool,
    run_live_acl_probe: bool = False,
    run_semantic_task_packet: bool = False,
    run_presence_preflight: bool = False,
    run_domain_reply_artifact_preflight: bool = False,
    run_wake_loop_preflight: bool = False,
    run_topology: bool = False,
    onboard_receipt_path: Path | None = None,
    live_topology_receipt_path: Path | None = None,
    live_acl_receipt_path: Path | None = None,
    semantic_task_packet_receipt_path: Path | None = None,
    semantic_send_receipt_dir: Path | None = None,
    presence_receipt_path: Path | None = None,
    domain_reply_artifact_receipt_path: Path | None = None,
    domain_reply_request_receipt_path: Path | None = None,
    wake_loop_receipt_path: Path | None = None,
    topology_receipt_path: Path | None = None,
    live_acl_context_template: str = "{principal}",
) -> tuple[dict[str, Any], int]:
    receipt_root = repo_root / "reports" / "a2a"
    selection = _selected_agents(
        agent,
        cohort=cohort,
        a2a_bus_root=a2a_bus_root,
        min_agents=min_agents,
    )
    counted_agents = selection.agent_uids
    if run_topology:
        topology_payload, topology_path = _run_topology_receipt(
            repo_root=repo_root,
            counted_agents=counted_agents,
        )
    elif topology_receipt_path is not None:
        topology_payload = _load_json(topology_receipt_path)
        topology_path = _relative_or_absolute(topology_receipt_path, repo_root)
    else:
        topology_payload, topology_path = _latest_topology_receipt(repo_root)

    if run_onboard:
        onboard_payload, onboard_path = _run_onboard_receipt(
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            receipt_root=receipt_root,
            agent=agent,
            broker=broker,
            mode=mode,
            cohort=cohort,
        )
    elif onboard_receipt_path is not None:
        onboard_payload = _load_json(onboard_receipt_path)
        onboard_path = _relative_or_absolute(onboard_receipt_path, repo_root)
    else:
        onboard_payload, onboard_path = _latest_onboard_receipt(repo_root)

    if run_live_probe:
        live_payload, live_path = _run_live_topology_receipt(
            context=context,
            receipt_dir=repo_root / "reports" / "a2a" / "live_topology",
        )
        live_path = _relative_or_absolute(Path(live_path), repo_root) if live_path else ""
    elif live_topology_receipt_path is not None:
        live_payload = _load_json(live_topology_receipt_path)
        live_path = _relative_or_absolute(live_topology_receipt_path, repo_root)
    else:
        live_payload, live_path = _latest_live_topology_receipt(repo_root)

    if run_live_acl_probe:
        live_acl_payload, live_acl_path = _run_live_acl_probe_receipt(
            receipt_dir=repo_root / "reports" / "a2a" / "live_acl",
            agent=agent,
            a2a_bus_root=a2a_bus_root,
            context_template=live_acl_context_template,
        )
        live_acl_path = _relative_or_absolute(Path(live_acl_path), repo_root) if live_acl_path else ""
    elif live_acl_receipt_path is not None:
        live_acl_payload = _load_json(live_acl_receipt_path)
        live_acl_path = _relative_or_absolute(live_acl_receipt_path, repo_root)
    else:
        live_acl_payload, live_acl_path = _latest_live_acl_receipt(repo_root)

    if run_semantic_task_packet:
        semantic_task_packet_payload, semantic_task_packet_path = _run_semantic_task_packet_receipt(
            repo_root=repo_root,
            receipt_root=receipt_root,
            agent=agent,
            broker=broker,
            mode=mode,
            a2a_bus_root=a2a_bus_root,
        )
    elif semantic_task_packet_receipt_path is not None:
        semantic_task_packet_payload = _load_json(semantic_task_packet_receipt_path)
        semantic_task_packet_path = _relative_or_absolute(semantic_task_packet_receipt_path, repo_root)
    else:
        semantic_task_packet_payload, semantic_task_packet_path = _latest_semantic_task_packet_receipt(repo_root)
    semantic_send_receipts_dir = semantic_send_receipt_dir or receipt_root / "send_receipts"

    if run_presence_preflight:
        presence_payload, presence_path = _run_presence_preflight_receipt(
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            receipt_root=receipt_root,
            agent=agent,
            broker=broker,
        )
    elif presence_receipt_path is not None:
        presence_payload = _load_json(presence_receipt_path)
        presence_path = _relative_or_absolute(presence_receipt_path, repo_root)
    else:
        presence_payload, presence_path = _latest_presence_preflight_receipt(repo_root)
    identity_payload, identity_path = _latest_identity_reconcile_receipt(repo_root)

    if semantic_task_packet_receipt_path is not None:
        semantic_task_packet_receipt_for_preflight = semantic_task_packet_receipt_path
    elif semantic_task_packet_path:
        semantic_task_packet_receipt_for_preflight = repo_root / semantic_task_packet_path
    else:
        semantic_task_packet_receipt_for_preflight = None

    if run_domain_reply_artifact_preflight:
        domain_reply_artifact_payload, domain_reply_artifact_path = _run_domain_reply_artifact_preflight_receipt(
            repo_root=repo_root,
            receipt_root=receipt_root,
            semantic_task_packet_receipt_path=semantic_task_packet_receipt_for_preflight,
            semantic_send_receipt_dir=semantic_send_receipts_dir,
            outbox_root=a2a_bus_root / "outboxes",
            agent=agent,
            a2a_bus_root=a2a_bus_root,
        )
    elif domain_reply_artifact_receipt_path is not None:
        domain_reply_artifact_payload = _load_json(domain_reply_artifact_receipt_path)
        domain_reply_artifact_path = _relative_or_absolute(domain_reply_artifact_receipt_path, repo_root)
    else:
        domain_reply_artifact_payload, domain_reply_artifact_path = _latest_domain_reply_artifact_preflight_receipt(repo_root)
    if domain_reply_request_receipt_path is not None:
        domain_reply_request_payload = _load_json(domain_reply_request_receipt_path)
        domain_reply_request_path = _relative_or_absolute(domain_reply_request_receipt_path, repo_root)
    else:
        domain_reply_request_payload, domain_reply_request_path = _latest_domain_reply_request_receipt(repo_root)

    if run_wake_loop_preflight:
        wake_loop_payload, wake_loop_path = _run_wake_loop_preflight_receipt(
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            receipt_root=receipt_root,
            agent=agent,
            broker=broker,
            mode=mode,
        )
    elif wake_loop_receipt_path is not None:
        wake_loop_payload = _load_json(wake_loop_receipt_path)
        wake_loop_path = _relative_or_absolute(wake_loop_receipt_path, repo_root)
    else:
        wake_loop_payload, wake_loop_path = _latest_wake_loop_preflight_receipt(repo_root)
    standing_payload, standing_path = _latest_standing_agent_preflight_receipt(repo_root)

    components = (
        _topology_component(live_payload, live_path, topology_path=topology_path),
        _cutover_gate_component(live_payload, live_path, topology_path=topology_path),
        _acl_probe_contract_component(
            topology_payload,
            topology_path,
            selection=selection,
            mode=mode,
            live_acl_payload=live_acl_payload,
            live_acl_path=live_acl_path,
        ),
        _semantic_task_packet_component(
            semantic_task_packet_payload,
            semantic_task_packet_path,
            selection=selection,
            repo_root=repo_root,
        ),
        _semantic_send_receipts_component(
            semantic_task_packet_payload,
            selection=selection,
            repo_root=repo_root,
            receipt_dir=semantic_send_receipts_dir,
        ),
        _identity_presence_component(
            presence_payload,
            presence_path,
            identity_payload,
            identity_path,
            selection=selection,
        ),
        _domain_reply_artifact_component(
            domain_reply_artifact_payload,
            domain_reply_artifact_path,
            domain_reply_request_payload,
            domain_reply_request_path,
            selection=selection,
        ),
        _wake_loop_component(
            wake_loop_payload,
            wake_loop_path,
            standing_payload,
            standing_path,
            selection=selection,
        ),
        _onboard_component(onboard_payload, onboard_path, selection=selection, mode=mode),
    )
    blockers = [
        blocker
        for component in components
        for blocker in component.blockers
    ]
    full_spec_ready = not blockers
    payload: dict[str, Any] = {
        "schema_version": READINESS_SCHEMA,
        "timestamp": _utc_now(),
        "full_spec_ready": full_spec_ready,
        "readiness_score": _readiness_score(components),
        "target_score": 100,
        "mode": mode,
        "broker": broker,
        "agent": agent,
        "cohort": cohort or agent,
        "cohort_selection": selection.to_dict(),
        "required_counted_agents": list(counted_agents),
        "required_agent_count": selection.required_agent_count,
        "components": [component.to_dict() for component in components],
        "blockers": list(dict.fromkeys(blockers)),
        "evidence_paths": sorted(
            {
                path
                for component in components
                for path in component.evidence_paths
                if path
            }
        ),
        "readiness_rule": (
            "100/100 requires passed live topology, completed cutover/canonical streams, "
            "a passing per-agent ACL probe contract, "
            "hash-bound semantic task packets for the selected cohort/quorum, "
            "receipt-bound semantic task-packet sends for the selected cohort/quorum, "
            "fresh stale-fail-closed identity/presence projection for the selected cohort/quorum, "
            "validated target-owned semantic domain reply artifacts for the selected cohort/quorum, "
            "a passing wake-loop preflight for the selected cohort/quorum, "
            "and required selected agents at the required mode state with DOMAIN_RECEIPTED, "
            "SEMANTIC_SIGNED, and no wake-loop/session-scope blockers"
        ),
    }
    receipt_path = _write_receipt(receipt_dir, payload)
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    receipt_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload, 0 if full_spec_ready else EXIT_NOT_READY


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--cohort")
    parser.add_argument("--min-agents", type=int)
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--mode", default="prevalidate", choices=("prevalidate", "live"))
    parser.add_argument("--context", default="agni-wss")
    parser.add_argument("--run-onboard", action="store_true")
    parser.add_argument("--run-live-probe", action="store_true")
    parser.add_argument("--run-live-acl-probe", action="store_true")
    parser.add_argument("--run-semantic-task-packet", action="store_true")
    parser.add_argument("--run-presence-preflight", action="store_true")
    parser.add_argument("--run-domain-reply-artifact-preflight", action="store_true")
    parser.add_argument("--run-wake-loop-preflight", action="store_true")
    parser.add_argument("--run-topology", action="store_true")
    parser.add_argument("--onboard-receipt")
    parser.add_argument("--live-topology-receipt")
    parser.add_argument("--live-acl-receipt")
    parser.add_argument("--semantic-task-packet-receipt")
    parser.add_argument("--semantic-send-receipt-dir")
    parser.add_argument("--presence-receipt")
    parser.add_argument("--domain-reply-artifact-receipt")
    parser.add_argument("--domain-reply-request-receipt")
    parser.add_argument("--wake-loop-receipt")
    parser.add_argument("--topology-receipt")
    parser.add_argument("--live-acl-context-template", default="{principal}")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    try:
        payload, exit_code = run_readiness(
            repo_root=repo_root,
            receipt_dir=receipt_dir,
            agent=args.agent,
            cohort=args.cohort,
            min_agents=args.min_agents,
            broker=args.broker,
            mode=args.mode,
            a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
            context=args.context,
            run_onboard=bool(args.run_onboard),
            run_live_probe=bool(args.run_live_probe),
            run_live_acl_probe=bool(args.run_live_acl_probe),
            run_semantic_task_packet=bool(args.run_semantic_task_packet),
            run_presence_preflight=bool(args.run_presence_preflight),
            run_domain_reply_artifact_preflight=bool(args.run_domain_reply_artifact_preflight),
            run_wake_loop_preflight=bool(args.run_wake_loop_preflight),
            run_topology=bool(args.run_topology),
            onboard_receipt_path=Path(args.onboard_receipt).expanduser().resolve()
            if args.onboard_receipt
            else None,
            live_topology_receipt_path=Path(args.live_topology_receipt).expanduser().resolve()
            if args.live_topology_receipt
            else None,
            live_acl_receipt_path=Path(args.live_acl_receipt).expanduser().resolve()
            if args.live_acl_receipt
            else None,
            semantic_task_packet_receipt_path=Path(args.semantic_task_packet_receipt).expanduser().resolve()
            if args.semantic_task_packet_receipt
            else None,
            semantic_send_receipt_dir=Path(args.semantic_send_receipt_dir).expanduser().resolve()
            if args.semantic_send_receipt_dir
            else None,
            presence_receipt_path=Path(args.presence_receipt).expanduser().resolve()
            if args.presence_receipt
            else None,
            domain_reply_artifact_receipt_path=Path(args.domain_reply_artifact_receipt).expanduser().resolve()
            if args.domain_reply_artifact_receipt
            else None,
            domain_reply_request_receipt_path=Path(args.domain_reply_request_receipt).expanduser().resolve()
            if args.domain_reply_request_receipt
            else None,
            wake_loop_receipt_path=Path(args.wake_loop_receipt).expanduser().resolve()
            if args.wake_loop_receipt
            else None,
            topology_receipt_path=Path(args.topology_receipt).expanduser().resolve()
            if args.topology_receipt
            else None,
            live_acl_context_template=str(args.live_acl_context_template),
        )
    except Exception as exc:
        payload = {
            "schema_version": READINESS_SCHEMA,
            "timestamp": _utc_now(),
            "full_spec_ready": False,
            "readiness_score": 0,
            "target_score": 100,
            "blockers": [f"{type(exc).__name__}: {exc}"],
        }
        receipt_path = _write_receipt(receipt_dir, payload)
        payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
        exit_code = EXIT_INTERNAL_ERROR
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_FULL_SPEC_READY" if payload["full_spec_ready"] else "A2A_FULL_SPEC_NOT_READY")
        print(f"readiness_score={payload['readiness_score']}/{payload['target_score']}")
        for blocker in payload.get("blockers", []):
            print(f"- {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
