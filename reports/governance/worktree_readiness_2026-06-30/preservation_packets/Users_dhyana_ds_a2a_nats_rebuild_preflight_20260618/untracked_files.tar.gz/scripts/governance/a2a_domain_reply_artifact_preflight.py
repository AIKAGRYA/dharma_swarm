#!/usr/bin/env python3
"""Validate target-owned A2A domain reply artifacts before publishing."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_onboard, a2a_semantic_task_packet  # noqa: E402
from scripts.runtime import a2a_domain_reply_worker  # noqa: E402


DOMAIN_REPLY_ARTIFACT_PREFLIGHT_SCHEMA = "dharma.a2a.domain_reply_artifact_preflight.v1"
READY_DOMAIN_REPLY_ARTIFACT = "READY_DOMAIN_REPLY_ARTIFACT"
BLOCKED_DOMAIN_REPLY_ARTIFACT = "BLOCKED_DOMAIN_REPLY_ARTIFACT"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "domain_reply_artifact_preflight"
DEFAULT_SEND_RECEIPT_ROOT = REPO_ROOT / "reports" / "a2a" / "send_receipts"
DEFAULT_OUTBOX_ROOT = Path.home() / ".dharma" / "a2a_bus" / "outboxes"
SEND_RECEIPT_SCHEMA = "dharma.a2a.send_receipt.v1"


@dataclass(frozen=True)
class DomainReplyArtifactRow:
    agent_uid: str
    final_state: str
    blockers: tuple[str, ...]
    packet_id: str
    task_hash: str
    locked_spec_sha256: str
    send_receipt_path: str
    send_receipt_present: bool
    expected_artifact_path: str
    artifact_present: bool
    artifact_sha256: str
    semantic_reply_claim: bool
    peer_model_processed_claim: bool
    latest_model_capture_receipt_path: str
    latest_model_capture_status: str
    latest_model_capture_blockers: tuple[str, ...]
    latest_model_capture_stdout_tail: str
    latest_model_capture_stderr_tail: str
    latest_model_capture_wrote_artifact: bool | None
    evidence_paths: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_receipt(receipt_dir: Path, payload: dict[str, Any]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{_stamp()}-a2a-domain-reply-artifact-preflight.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _latest_json(root: Path, pattern: str) -> Path | None:
    candidates = [path for path in root.glob(pattern) if path.is_file()]
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def _latest_model_capture_receipt(
    *,
    repo_root: Path,
    agent_uid: str,
    packet_id: str,
) -> tuple[Path | None, dict[str, Any]]:
    if not packet_id:
        return None, {}
    path = _latest_json(
        repo_root / "reports" / "a2a" / "model_reply_captures",
        f"*-{agent_uid}-{packet_id}.json",
    )
    if path is None:
        return None, {}
    return path, _load_json(path)


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _latest_semantic_task_packet_receipt(repo_root: Path) -> Path | None:
    return _latest_json(
        repo_root / "reports" / "a2a" / "semantic_task_packets",
        "*-a2a-semantic-task-packet.json",
    )


def _semantic_rows(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = payload.get("rows")
    if not isinstance(rows, list):
        return {}
    return {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }


def _send_receipts(send_receipt_root: Path) -> list[tuple[Path, dict[str, Any]]]:
    if not send_receipt_root.exists():
        return []
    rows: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted(send_receipt_root.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
        payload = _load_json(path)
        if payload.get("schema_version") == SEND_RECEIPT_SCHEMA:
            rows.append((path, payload))
    return rows


def _matching_send_receipt(
    *,
    send_receipts: list[tuple[Path, dict[str, Any]]],
    agent_uid: str,
    packet_id: str,
) -> tuple[Path | None, dict[str, Any]]:
    for path, payload in send_receipts:
        if payload.get("packet_id") == packet_id and payload.get("target_uid") == agent_uid:
            return path, payload
    return None, {}


def _placeholder(value: Any) -> bool:
    text = str(value or "").strip()
    return text.startswith("<") and text.endswith(">")


def _semantic_claim_failures(artifact: dict[str, Any]) -> list[str]:
    failures: list[str] = []
    if artifact.get("peer_model_processed_claim") is not True:
        failures.append("peer_model_processed_claim is not true")
    if artifact.get("semantic_reply_claim") is not True:
        failures.append("semantic_reply_claim is not true")
    for key in ("model_identity", "task_hash", "locked_spec_sha256", "failure_digest"):
        if not str(artifact.get(key) or "").strip():
            failures.append(f"artifact missing {key}")
        elif _placeholder(artifact.get(key)):
            failures.append(f"artifact {key} is still a placeholder")
    evidence_refs = artifact.get("evidence_refs")
    if not isinstance(evidence_refs, list) or not evidence_refs:
        failures.append("artifact evidence_refs must be non-empty")
    elif any(_placeholder(ref) for ref in evidence_refs):
        failures.append("artifact evidence_refs contain placeholders")
    confidence = artifact.get("confidence")
    if not isinstance(confidence, int | float) or isinstance(confidence, bool):
        failures.append("artifact confidence must be numeric")
    elif not 0.0 <= float(confidence) <= 1.0:
        failures.append("artifact confidence must be between 0 and 1")
    digest = str(artifact.get("failure_digest") or "").lower()
    for required in ("confused", "tried", "failed", "worked"):
        if required not in digest:
            failures.append(f"artifact failure_digest missing {required}")
    return failures


def _row(
    *,
    agent_uid: str,
    row: dict[str, Any],
    send_receipts: list[tuple[Path, dict[str, Any]]],
    repo_root: Path,
    outbox_root: Path,
) -> DomainReplyArtifactRow:
    blockers: list[str] = []
    evidence_paths: list[str] = []
    packet_id = str(row.get("packet_id") or "")
    task_hash = str(row.get("task_hash") or "")
    locked_spec_sha256 = str(row.get("locked_spec_sha256") or "")
    expected_artifact_path = outbox_root / agent_uid / f"{packet_id}.json"
    capture_path, capture_payload = _latest_model_capture_receipt(
        repo_root=repo_root,
        agent_uid=agent_uid,
        packet_id=packet_id,
    )
    capture_status = str(capture_payload.get("status") or "")
    capture_blockers_raw = capture_payload.get("blockers")
    capture_blockers = tuple(
        str(blocker)
        for blocker in capture_blockers_raw
        if isinstance(blocker, str)
    ) if isinstance(capture_blockers_raw, list) else ()
    capture_stdout_tail = str(capture_payload.get("stdout_tail") or "")
    capture_stderr_tail = str(capture_payload.get("stderr_tail") or "")
    capture_wrote_raw = capture_payload.get("wrote_artifact")
    capture_wrote = capture_wrote_raw if isinstance(capture_wrote_raw, bool) else None
    if capture_path is not None:
        evidence_paths.append(_relative_or_absolute(capture_path, repo_root))

    send_path, send_receipt = _matching_send_receipt(
        send_receipts=send_receipts,
        agent_uid=agent_uid,
        packet_id=packet_id,
    )
    if send_path is None:
        blockers.append("missing semantic task send receipt")
        send_receipt_path = ""
    else:
        send_receipt_path = _relative_or_absolute(send_path, repo_root)
        evidence_paths.append(send_receipt_path)
        if send_receipt.get("task_hash") != task_hash:
            blockers.append("send receipt task_hash mismatch")
        if send_receipt.get("locked_spec_sha256") != locked_spec_sha256:
            blockers.append("send receipt locked_spec_sha256 mismatch")
        if not str(send_receipt.get("reply_subject") or ""):
            blockers.append("send receipt missing reply_subject")

    artifact_present = expected_artifact_path.is_file()
    artifact_sha = ""
    semantic_claim = False
    peer_claim = False
    if not artifact_present:
        blockers.append("missing target-owned domain reply artifact")
        if capture_status:
            blockers.append(f"latest target model capture status is {capture_status}")
        for capture_blocker in capture_blockers:
            blockers.append(f"latest target model capture blocker: {capture_blocker}")
    elif send_path is None:
        artifact_sha = _sha256_file(expected_artifact_path)
        evidence_paths.append(_relative_or_absolute(expected_artifact_path, repo_root))
    else:
        artifact_sha = _sha256_file(expected_artifact_path)
        artifact_ref = _relative_or_absolute(expected_artifact_path, repo_root)
        evidence_paths.append(artifact_ref)
        artifact = _load_json(expected_artifact_path)
        semantic_claim = artifact.get("semantic_reply_claim") is True
        peer_claim = artifact.get("peer_model_processed_claim") is True
        try:
            target = a2a_domain_reply_worker.load_domain_reply_target(
                send_receipt_path=send_path,
                reply_artifact_path=expected_artifact_path,
                agent_uid=agent_uid,
                outbox_root=outbox_root,
                enforce_owner_path=True,
            )
            artifact = target.reply_artifact
            semantic_claim = artifact.get("semantic_reply_claim") is True
            peer_claim = artifact.get("peer_model_processed_claim") is True
        except Exception as exc:
            blockers.append(f"artifact validation failed: {type(exc).__name__}: {exc}")
        blockers.extend(_semantic_claim_failures(artifact))
        if artifact.get("task_hash") != task_hash:
            blockers.append("artifact task_hash does not match semantic task packet")
        if artifact.get("locked_spec_sha256") != a2a_onboard.LOCKED_SPEC_SHA256:
            blockers.append("artifact locked_spec_sha256 does not match locked spec")

    unique_blockers = tuple(dict.fromkeys(blockers))
    return DomainReplyArtifactRow(
        agent_uid=agent_uid,
        final_state=READY_DOMAIN_REPLY_ARTIFACT if not unique_blockers else BLOCKED_DOMAIN_REPLY_ARTIFACT,
        blockers=unique_blockers,
        packet_id=packet_id,
        task_hash=task_hash,
        locked_spec_sha256=locked_spec_sha256,
        send_receipt_path=send_receipt_path,
        send_receipt_present=send_path is not None,
        expected_artifact_path=_relative_or_absolute(expected_artifact_path, repo_root),
        artifact_present=artifact_present,
        artifact_sha256=artifact_sha,
        semantic_reply_claim=semantic_claim,
        peer_model_processed_claim=peer_claim,
        latest_model_capture_receipt_path=_relative_or_absolute(capture_path, repo_root)
        if capture_path is not None
        else "",
        latest_model_capture_status=capture_status,
        latest_model_capture_blockers=capture_blockers,
        latest_model_capture_stdout_tail=capture_stdout_tail,
        latest_model_capture_stderr_tail=capture_stderr_tail,
        latest_model_capture_wrote_artifact=capture_wrote,
        evidence_paths=tuple(dict.fromkeys(evidence_paths)),
    )


def run_preflight(
    *,
    repo_root: Path,
    receipt_dir: Path,
    semantic_task_packet_receipt_path: Path | None,
    send_receipt_root: Path,
    outbox_root: Path,
    agent: str,
    a2a_bus_root: Path | None = None,
) -> tuple[dict[str, Any], int]:
    semantic_path = semantic_task_packet_receipt_path or _latest_semantic_task_packet_receipt(repo_root)
    blockers: list[str] = []
    if semantic_path is None:
        semantic_payload: dict[str, Any] = {}
        semantic_receipt_ref = ""
        blockers.append("missing semantic task packet receipt")
    else:
        semantic_payload = _load_json(semantic_path)
        semantic_receipt_ref = _relative_or_absolute(semantic_path, repo_root)
    if semantic_payload.get("schema_version") != a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA:
        blockers.append("semantic task packet receipt has wrong schema")
    rows_by_agent = _semantic_rows(semantic_payload)
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    send_rows = _send_receipts(send_receipt_root)
    rows: list[DomainReplyArtifactRow] = []
    for agent_uid in selected:
        semantic_row = rows_by_agent.get(agent_uid)
        if semantic_row is None:
            blockers.append(f"{agent_uid}: missing semantic task packet row")
            rows.append(
                DomainReplyArtifactRow(
                    agent_uid=agent_uid,
                    final_state=BLOCKED_DOMAIN_REPLY_ARTIFACT,
                    blockers=("missing semantic task packet row",),
                    packet_id="",
                    task_hash="",
                    locked_spec_sha256="",
                    send_receipt_path="",
                    send_receipt_present=False,
                    expected_artifact_path="",
                    artifact_present=False,
                    artifact_sha256="",
                    semantic_reply_claim=False,
                    peer_model_processed_claim=False,
                    latest_model_capture_receipt_path="",
                    latest_model_capture_status="",
                    latest_model_capture_blockers=(),
                    latest_model_capture_stdout_tail="",
                    latest_model_capture_stderr_tail="",
                    latest_model_capture_wrote_artifact=None,
                    evidence_paths=(),
                )
            )
            continue
        rows.append(
            _row(
                agent_uid=agent_uid,
                row=semantic_row,
                send_receipts=send_rows,
                repo_root=repo_root,
                outbox_root=outbox_root,
            )
        )
    blockers.extend(f"{row.agent_uid}: {blocker}" for row in rows for blocker in row.blockers)
    payload: dict[str, Any] = {
        "schema_version": DOMAIN_REPLY_ARTIFACT_PREFLIGHT_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "counted_agents": list(selected),
        "semantic_task_packet_receipt_path": semantic_receipt_ref,
        "send_receipt_root": _relative_or_absolute(send_receipt_root, repo_root),
        "outbox_root": str(outbox_root),
        "required_artifact_schema": a2a_domain_reply_worker.DOMAIN_REPLY_ARTIFACT_SCHEMA,
        "required_locked_spec_sha256": a2a_onboard.LOCKED_SPEC_SHA256,
        "rows": [row.to_dict() for row in rows],
        "blockers": list(dict.fromkeys(blockers)),
        "operator_note": (
            "This preflight is read-only. It validates target-owned outbox artifacts "
            "against semantic task packets and send receipts before domain receipts "
            "are published."
        ),
    }
    receipt_path = _write_receipt(receipt_dir, payload)
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    receipt_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--semantic-task-packet-receipt", default="")
    parser.add_argument("--send-receipt-root", default=str(DEFAULT_SEND_RECEIPT_ROOT))
    parser.add_argument("--outbox-root", default=str(DEFAULT_OUTBOX_ROOT))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    semantic_receipt = Path(args.semantic_task_packet_receipt).expanduser().resolve() if args.semantic_task_packet_receipt else None
    payload, exit_code = run_preflight(
        repo_root=repo_root,
        receipt_dir=receipt_dir,
        semantic_task_packet_receipt_path=semantic_receipt,
        send_receipt_root=Path(args.send_receipt_root).expanduser().resolve(),
        outbox_root=Path(args.outbox_root).expanduser().resolve(),
        agent=args.agent,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_DOMAIN_REPLY_ARTIFACT_PREFLIGHT_OK" if payload["passed"] else "A2A_DOMAIN_REPLY_ARTIFACT_PREFLIGHT_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            for blocker in row["blockers"]:
                print(f"  * {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
