#!/usr/bin/env python3
"""Render target-owned domain reply artifact requests without writing outboxes."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_domain_reply_artifact_preflight  # noqa: E402
from scripts.governance import a2a_onboard, a2a_semantic_task_packet  # noqa: E402
from scripts.runtime import a2a_domain_reply_worker  # noqa: E402


DOMAIN_REPLY_REQUEST_SCHEMA = "dharma.a2a.domain_reply_request.v1"
DEFAULT_REQUEST_DIR = REPO_ROOT / "reports" / "a2a" / "domain_reply_requests"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "domain_reply_requests"
DEFAULT_SEND_RECEIPT_ROOT = REPO_ROOT / "reports" / "a2a" / "send_receipts"
DEFAULT_OUTBOX_ROOT = Path.home() / ".dharma" / "a2a_bus" / "outboxes"
READY_DOMAIN_REPLY_REQUEST = "READY_DOMAIN_REPLY_REQUEST"
BLOCKED_DOMAIN_REPLY_REQUEST = "BLOCKED_DOMAIN_REPLY_REQUEST"


@dataclass(frozen=True)
class DomainReplyRequestRow:
    agent_uid: str
    final_state: str
    blockers: tuple[str, ...]
    packet_id: str
    task_hash: str
    locked_spec_sha256: str
    send_receipt_path: str
    reply_subject: str
    expected_artifact_path: str
    request_path: str
    request_sha256: str
    target_owned_write_required: bool
    evidence_paths: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _safe_token(value: object, *, fallback: str = "unknown") -> str:
    chars = [char if char.isalnum() or char in ("_", "-") else "_" for char in str(value or "")]
    return ("".join(chars).strip("_-") or fallback)[:96]


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _latest_json(root: Path, pattern: str) -> Path | None:
    candidates = [path for path in root.glob(pattern) if path.is_file()]
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def _latest_semantic_task_packet_receipt(repo_root: Path) -> Path | None:
    return _latest_json(
        repo_root / "reports" / "a2a" / "semantic_task_packets",
        "*-a2a-semantic-task-packet.json",
    )


def _semantic_rows(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = payload.get("rows")
    if not isinstance(rows, list):
        return {}
    return {
        str(row.get("agent_uid")): row
        for row in rows
        if isinstance(row, dict) and row.get("agent_uid")
    }


def _send_receipts(send_receipt_root: Path) -> list[tuple[Path, dict[str, Any]]]:
    if not send_receipt_root.exists():
        return []
    receipts: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted(send_receipt_root.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
        payload = _load_json(path)
        if payload.get("schema_version") == a2a_domain_reply_artifact_preflight.SEND_RECEIPT_SCHEMA:
            receipts.append((path, payload))
    return receipts


def _matching_send_receipt(
    *,
    send_receipts: list[tuple[Path, dict[str, Any]]],
    agent_uid: str,
    packet_id: str,
) -> tuple[Path | None, dict[str, Any]]:
    for path, payload in send_receipts:
        if payload.get("target_uid") == agent_uid and payload.get("packet_id") == packet_id:
            return path, payload
    return None, {}


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _request_body(
    *,
    agent_uid: str,
    packet_id: str,
    task_hash: str,
    locked_spec_sha256: str,
    send_receipt_path: str,
    reply_subject: str,
    expected_artifact_path: str,
) -> str:
    artifact = {
        "schema_version": a2a_domain_reply_worker.DOMAIN_REPLY_ARTIFACT_SCHEMA,
        "authored_by": agent_uid,
        "packet_id": packet_id,
        "reply_subject": reply_subject,
        "send_receipt_path": send_receipt_path,
        "verdict": "approve|revise|reject|blocked",
        "summary": "<target-authored semantic review>",
        "evidence_refs": [a2a_onboard.LOCKED_SPEC_PATH],
        "peer_model_processed_claim": True,
        "semantic_reply_claim": True,
        "model_identity": "<target provider/model or executable seat>",
        "task_hash": task_hash,
        "locked_spec_sha256": locked_spec_sha256,
        "confidence": 0.0,
        "failure_digest": a2a_semantic_task_packet.REQUIRED_FAILURE_DIGEST_PROMPT,
        "blockers": [],
    }
    return "\n".join(
        [
            "---",
            f"schema_version: {DOMAIN_REPLY_REQUEST_SCHEMA}",
            f"agent_uid: {agent_uid}",
            f"packet_id: {packet_id}",
            f"task_hash: {task_hash}",
            f"locked_spec_sha256: {locked_spec_sha256}",
            "---",
            "",
            "# A2A Target-Owned Domain Reply Artifact Request",
            "",
            f"Target agent: `{agent_uid}`",
            f"Expected target-owned artifact path: `{expected_artifact_path}`",
            f"Send receipt: `{send_receipt_path}`",
            f"Reply subject: `{reply_subject}`",
            "",
            "This request is not the reply artifact. A target-owned process or model must",
            "write the artifact at the expected outbox path before the domain reply worker",
            "or semantic receipt verifier can promote the evidence.",
            "",
            "Required artifact JSON:",
            "",
            "```json",
            json.dumps(artifact, indent=2, sort_keys=True),
            "```",
            "",
        ]
    )


def _row(
    *,
    repo_root: Path,
    request_dir: Path,
    outbox_root: Path,
    agent_uid: str,
    semantic_row: dict[str, Any] | None,
    send_receipts: list[tuple[Path, dict[str, Any]]],
) -> DomainReplyRequestRow:
    blockers: list[str] = []
    evidence_paths: list[str] = []
    packet_id = str((semantic_row or {}).get("packet_id") or "")
    task_hash = str((semantic_row or {}).get("task_hash") or "")
    locked_spec_sha256 = str((semantic_row or {}).get("locked_spec_sha256") or "")
    if not semantic_row:
        blockers.append("missing semantic task packet row")
    expected_artifact_path = outbox_root / agent_uid / f"{packet_id}.json"
    send_path, send_receipt = _matching_send_receipt(
        send_receipts=send_receipts,
        agent_uid=agent_uid,
        packet_id=packet_id,
    )
    send_ref = ""
    reply_subject = ""
    if send_path is None:
        blockers.append("missing semantic task send receipt")
    else:
        send_ref = _relative_or_absolute(send_path, repo_root)
        evidence_paths.append(send_ref)
        reply_subject = str(send_receipt.get("reply_subject") or "")
        if not reply_subject:
            blockers.append("send receipt missing reply_subject")
        if send_receipt.get("task_hash") != task_hash:
            blockers.append("send receipt task_hash mismatch")
        if send_receipt.get("locked_spec_sha256") != locked_spec_sha256:
            blockers.append("send receipt locked_spec_sha256 mismatch")
    request_path = request_dir / f"{_safe_token(agent_uid)}-{_safe_token(packet_id)}-domain-reply-request.md"
    request_sha256 = ""
    if not blockers:
        body = _request_body(
            agent_uid=agent_uid,
            packet_id=packet_id,
            task_hash=task_hash,
            locked_spec_sha256=locked_spec_sha256,
            send_receipt_path=send_ref,
            reply_subject=reply_subject,
            expected_artifact_path=str(expected_artifact_path),
        )
        _write_text(request_path, body)
        request_sha256 = _sha256_file(request_path)
        evidence_paths.append(_relative_or_absolute(request_path, repo_root))

    unique_blockers = tuple(dict.fromkeys(blockers))
    return DomainReplyRequestRow(
        agent_uid=agent_uid,
        final_state=READY_DOMAIN_REPLY_REQUEST if not unique_blockers else BLOCKED_DOMAIN_REPLY_REQUEST,
        blockers=unique_blockers,
        packet_id=packet_id,
        task_hash=task_hash,
        locked_spec_sha256=locked_spec_sha256,
        send_receipt_path=send_ref,
        reply_subject=reply_subject,
        expected_artifact_path=str(expected_artifact_path),
        request_path=_relative_or_absolute(request_path, repo_root),
        request_sha256=request_sha256,
        target_owned_write_required=True,
        evidence_paths=tuple(dict.fromkeys(evidence_paths)),
    )


def run_requests(
    *,
    repo_root: Path,
    request_dir: Path,
    receipt_dir: Path,
    semantic_task_packet_receipt_path: Path | None,
    send_receipt_root: Path,
    outbox_root: Path,
    agent: str,
    a2a_bus_root: Path | None = None,
) -> tuple[dict[str, Any], int]:
    semantic_path = semantic_task_packet_receipt_path or _latest_semantic_task_packet_receipt(repo_root)
    blockers: list[str] = []
    if semantic_path is None:
        semantic_payload: dict[str, Any] = {}
        semantic_ref = ""
        blockers.append("missing semantic task packet receipt")
    else:
        semantic_payload = _load_json(semantic_path)
        semantic_ref = _relative_or_absolute(semantic_path, repo_root)
    if semantic_payload.get("schema_version") != a2a_semantic_task_packet.SEMANTIC_TASK_PACKET_SCHEMA:
        blockers.append("semantic task packet receipt has wrong schema")
    rows_by_agent = _semantic_rows(semantic_payload)
    send_rows = _send_receipts(send_receipt_root)
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    rows = [
        _row(
            repo_root=repo_root,
            request_dir=request_dir,
            outbox_root=outbox_root,
            agent_uid=agent_uid,
            semantic_row=rows_by_agent.get(agent_uid),
            send_receipts=send_rows,
        )
        for agent_uid in selected
    ]
    blockers.extend(f"{row.agent_uid}: {blocker}" for row in rows for blocker in row.blockers)
    payload: dict[str, Any] = {
        "schema_version": DOMAIN_REPLY_REQUEST_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "counted_agents": list(selected),
        "semantic_task_packet_receipt_path": semantic_ref,
        "send_receipt_root": _relative_or_absolute(send_receipt_root, repo_root),
        "request_dir": _relative_or_absolute(request_dir, repo_root),
        "outbox_root": str(outbox_root),
        "target_outbox_mutation_performed": False,
        "required_artifact_schema": a2a_domain_reply_worker.DOMAIN_REPLY_ARTIFACT_SCHEMA,
        "rows": [row.to_dict() for row in rows],
        "blockers": list(dict.fromkeys(blockers)),
        "operator_note": (
            "This tool writes request files under reports/a2a/domain_reply_requests only. "
            "It does not write target outboxes or create target-owned artifacts."
        ),
    }
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}-a2a-domain-reply-request.json"
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    _write_json(receipt_path, payload)
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--request-dir", default=str(DEFAULT_REQUEST_DIR))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--semantic-task-packet-receipt", default="")
    parser.add_argument("--send-receipt-root", default=str(DEFAULT_SEND_RECEIPT_ROOT))
    parser.add_argument("--outbox-root", default=str(DEFAULT_OUTBOX_ROOT))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    request_dir = Path(args.request_dir).expanduser()
    if not request_dir.is_absolute():
        request_dir = repo_root / request_dir
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    semantic_receipt = Path(args.semantic_task_packet_receipt).expanduser().resolve() if args.semantic_task_packet_receipt else None
    payload, exit_code = run_requests(
        repo_root=repo_root,
        request_dir=request_dir,
        receipt_dir=receipt_dir,
        semantic_task_packet_receipt_path=semantic_receipt,
        send_receipt_root=Path(args.send_receipt_root).expanduser().resolve(),
        outbox_root=Path(args.outbox_root).expanduser().resolve(),
        agent=args.agent,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_DOMAIN_REPLY_REQUEST_OK" if payload["passed"] else "A2A_DOMAIN_REPLY_REQUEST_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            for blocker in row["blockers"]:
                print(f"  * {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
