#!/usr/bin/env python3
"""Render locked-spec semantic role-call packets for A2A counted agents."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from scripts.governance import a2a_onboard  # noqa: E402


SEMANTIC_TASK_PACKET_SCHEMA = "dharma.a2a.semantic_task_packet.v1"
DEFAULT_PACKET_DIR = REPO_ROOT / "reports" / "a2a" / "semantic_tasks"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "semantic_task_packets"

REQUIRED_REPLY_ARTIFACT_SCHEMA = "dharma.a2a.domain_reply_artifact.v1"
REQUIRED_FAILURE_DIGEST_PROMPT = (
    "what confused me; what I tried; what failed; what finally worked"
)


@dataclass(frozen=True)
class SemanticTaskPacket:
    agent_uid: str
    packet_id: str
    packet_path: str
    packet_sha256: str
    task_hash: str
    locked_spec_sha256: str
    required_reply_artifact_schema: str
    required_semantic_receipt_schema: str
    required_failure_digest_prompt: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _safe_token(value: object, *, fallback: str = "unknown") -> str:
    chars = [char if char.isalnum() or char in ("_", "-") else "_" for char in str(value or "")]
    return ("".join(chars).strip("_-") or fallback)[:96]


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _packet_id(agent_uid: str, *, locked_spec_sha256: str) -> str:
    return f"a2a-semantic-signoff-{_safe_token(agent_uid)}-{locked_spec_sha256[:12]}"


def _render_packet(
    *,
    agent_uid: str,
    broker: str,
    mode: str,
    packet_id: str,
    locked_spec_path: str,
    locked_spec_sha256: str,
) -> str:
    outbox_artifact = f"~/.dharma/a2a_bus/outboxes/{agent_uid}/{packet_id}.json"
    return "\n".join(
        [
            "---",
            f"schema_version: {SEMANTIC_TASK_PACKET_SCHEMA}",
            f"packet_id: {packet_id}",
            f"agent_uid: {agent_uid}",
            f"broker: {broker}",
            f"mode: {mode}",
            f"locked_spec_path: {locked_spec_path}",
            f"locked_spec_sha256: {locked_spec_sha256}",
            f"required_reply_artifact_schema: {REQUIRED_REPLY_ARTIFACT_SCHEMA}",
            f"required_semantic_receipt_schema: {a2a_onboard.SEMANTIC_RECEIPT_SCHEMA}",
            "---",
            "",
            "# A2A Semantic Role-Call Packet",
            "",
            f"Target agent: `{agent_uid}`",
            f"Packet id: `{packet_id}`",
            f"Locked spec: `{locked_spec_path}`",
            f"Locked spec SHA-256: `{locked_spec_sha256}`",
            "",
            "## Required Action",
            "",
            "Read the locked spec identified above and produce a target-owned reply artifact.",
            "The reply artifact must live at:",
            "",
            f"`{outbox_artifact}`",
            "",
            "Do not answer with transport ACKs, heartbeat text, or a generic status update.",
            "The reply artifact must be authored by the target agent/model and must be suitable",
            "for `scripts/runtime/a2a_domain_reply_worker.py`.",
            "",
            "## Required Reply Artifact Fields",
            "",
            "```json",
            json.dumps(
                {
                    "schema_version": REQUIRED_REPLY_ARTIFACT_SCHEMA,
                    "authored_by": agent_uid,
                    "packet_id": packet_id,
                    "reply_subject": "<copy from send receipt>",
                    "send_receipt_path": "<path from send command>",
                    "verdict": "approve|revise|reject|blocked",
                    "summary": "<concise semantic review>",
                    "evidence_refs": [locked_spec_path],
                    "peer_model_processed_claim": True,
                    "semantic_reply_claim": True,
                    "model_identity": "<provider/model or executable seat>",
                    "task_hash": "<use task_hash from semantic task packet receipt>",
                    "locked_spec_sha256": locked_spec_sha256,
                    "confidence": 0.0,
                    "failure_digest": REQUIRED_FAILURE_DIGEST_PROMPT,
                    "blockers": [],
                },
                indent=2,
                sort_keys=True,
            ),
            "```",
            "",
            "## Failure Digest Requirement",
            "",
            "Your `failure_digest` must explicitly summarize:",
            "",
            "- what confused me",
            "- what I tried",
            "- what failed",
            "- what finally worked",
            "",
            "A semantic receipt without `failure_digest` is treated exactly like no",
            "semantic receipt.",
            "",
            "## Operator Follow-Up",
            "",
            "After the target-owned artifact exists, publish it with:",
            "",
            "```bash",
            "PYTHONPATH=. python3 scripts/runtime/a2a_domain_reply_worker.py "
            "--send-receipt <send_receipt_path> "
            f"--reply-artifact {outbox_artifact} "
            f"--agent-uid {agent_uid} --json",
            "```",
            "",
        ]
    )


def render_packets(
    *,
    repo_root: Path,
    packet_dir: Path,
    receipt_dir: Path,
    agent: str,
    broker: str,
    mode: str,
    a2a_bus_root: Path | None = None,
) -> tuple[dict[str, Any], int]:
    locked_spec_path = a2a_onboard.LOCKED_SPEC_PATH
    locked_spec = repo_root / locked_spec_path
    locked_spec_sha256 = _sha256_file(locked_spec)
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    packet_dir.mkdir(parents=True, exist_ok=True)
    rows: list[SemanticTaskPacket] = []
    for agent_uid in selected:
        packet_id = _packet_id(agent_uid, locked_spec_sha256=locked_spec_sha256)
        packet_path = packet_dir / f"{_safe_token(agent_uid)}-packet.md"
        text = _render_packet(
            agent_uid=agent_uid,
            broker=broker,
            mode=mode,
            packet_id=packet_id,
            locked_spec_path=str(locked_spec_path),
            locked_spec_sha256=locked_spec_sha256,
        )
        packet_path.write_text(text, encoding="utf-8")
        packet_sha256 = _sha256_bytes(text.encode("utf-8"))
        rows.append(
            SemanticTaskPacket(
                agent_uid=agent_uid,
                packet_id=packet_id,
                packet_path=_relative_or_absolute(packet_path, repo_root),
                packet_sha256=packet_sha256,
                task_hash=f"sha256:{packet_sha256}",
                locked_spec_sha256=locked_spec_sha256,
                required_reply_artifact_schema=REQUIRED_REPLY_ARTIFACT_SCHEMA,
                required_semantic_receipt_schema=a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
                required_failure_digest_prompt=REQUIRED_FAILURE_DIGEST_PROMPT,
            )
        )
    receipt = {
        "schema_version": SEMANTIC_TASK_PACKET_SCHEMA,
        "timestamp": _utc_now(),
        "agent": agent,
        "broker": broker,
        "mode": mode,
        "locked_spec_path": str(locked_spec_path),
        "locked_spec_sha256": locked_spec_sha256,
        "counted_agents": list(selected),
        "rows": [row.to_dict() for row in rows],
        "required_reply_artifact_schema": REQUIRED_REPLY_ARTIFACT_SCHEMA,
        "required_semantic_receipt_schema": a2a_onboard.SEMANTIC_RECEIPT_SCHEMA,
        "required_failure_digest_prompt": REQUIRED_FAILURE_DIGEST_PROMPT,
    }
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}-a2a-semantic-task-packet.json"
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    receipt["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return receipt, 0


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--packet-dir", default=str(DEFAULT_PACKET_DIR))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--a2a-bus-root", default=str(Path.home() / ".dharma" / "a2a_bus"))
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--mode", default="prevalidate")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    packet_dir = Path(args.packet_dir).expanduser()
    if not packet_dir.is_absolute():
        packet_dir = repo_root / packet_dir
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    payload, exit_code = render_packets(
        repo_root=repo_root,
        packet_dir=packet_dir,
        receipt_dir=receipt_dir,
        agent=str(args.agent),
        broker=str(args.broker),
        mode=str(args.mode),
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_SEMANTIC_TASK_PACKET_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['packet_path']} task_hash={row['task_hash']}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
