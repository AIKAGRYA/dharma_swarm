#!/usr/bin/env python3
"""Validate A2A identity projection and stale-fail-closed presence evidence."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_roster import resolve_agent_uids  # noqa: E402
from dharma_swarm.a2a.jetstream_topology import principal_for_agent  # noqa: E402
from scripts.governance import a2a_onboard  # noqa: E402


PRESENCE_PREFLIGHT_SCHEMA = "dharma.a2a.presence_preflight.v1"
PRESENCE_PROJECTOR_SCHEMA = "dharma.a2a.presence_projector.v1"
PRESENCE_PROJECTION_SCHEMA = "dharma.a2a.presence_projection.v1"
READY_PRESENCE_PREVALIDATED = "READY_PRESENCE_PREVALIDATED"
BLOCKED_PRESENCE = "BLOCKED_PRESENCE"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "presence_preflight"
DEFAULT_PROJECTOR_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "presence_projection"
DEFAULT_A2A_BUS_ROOT = Path.home() / ".dharma" / "a2a_bus"
DEFAULT_TTL_SECONDS = 2 * 60 * 60

REQUIRED_PRESENCE_FIELDS = (
    "agent_uid",
    "broker",
    "domain",
    "inbox_subject",
    "durable_consumer",
    "transport_state",
    "model_state",
    "tempo_tier",
    "authority_status",
    "last_heartbeat_at",
    "last_handler_ack_at",
    "last_domain_receipt_at",
    "last_semantic_receipt_at",
    "peer_model_processed_claim",
    "last_error",
    "expires_at",
)


@dataclass(frozen=True)
class PresenceRow:
    agent_uid: str
    final_state: str
    blockers: tuple[str, ...]
    registry_entry_present: bool
    principal: str
    aliases: tuple[str, ...]
    alias_collisions: tuple[str, ...]
    presence_projection_present: bool
    presence_source_path: str
    missing_presence_fields: tuple[str, ...]
    stale_presence: bool
    expired_presence: bool
    presence_age_seconds: float | None
    expires_at: str
    inbox_subject: str
    durable_consumer: str
    transport_state: str
    model_state: str
    peer_model_processed_claim: bool | None
    evidence_paths: tuple[str, ...]
    operator_commands: dict[str, str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now_dt() -> datetime:
    return datetime.now(UTC)


def _utc_now() -> str:
    return _utc_now_dt().isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return _utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _safe_token(value: object, *, fallback: str = "unknown") -> str:
    chars = [char if char.isalnum() or char in ("_", "-") else "_" for char in str(value or "")]
    return ("".join(chars).strip("_-") or fallback)[:96]


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_receipt(receipt_dir: Path, payload: dict[str, Any]) -> Path:
    receipt_dir.mkdir(parents=True, exist_ok=True)
    path = receipt_dir / f"{_stamp()}-a2a-presence-preflight.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _selected_agents(agent: str, *, a2a_bus_root: Path | None = None) -> tuple[str, ...]:
    return resolve_agent_uids(agent, a2a_bus_root=a2a_bus_root)


def _parse_timestamp(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if isinstance(agents, dict):
        return {str(uid): entry for uid, entry in agents.items() if isinstance(entry, dict)}
    return {str(uid): entry for uid, entry in payload.items() if isinstance(entry, dict)}


def _presence_json_entry(payload: dict[str, Any], agent_uid: str) -> dict[str, Any]:
    if not payload:
        return {}
    agents = payload.get("agents")
    if isinstance(agents, dict) and isinstance(agents.get(agent_uid), dict):
        return dict(agents[agent_uid])
    if isinstance(payload.get(agent_uid), dict):
        return dict(payload[agent_uid])
    if payload.get("agent_uid") == agent_uid:
        return dict(payload)
    return {}


def _latest_projector_projection(repo_root: Path, agent_uid: str) -> tuple[dict[str, Any], Path | None]:
    receipt_dir = repo_root / "reports" / "a2a" / "presence_projection"
    candidates = [
        path
        for path in receipt_dir.glob("*-a2a-presence-projector.json")
        if path.is_file()
    ]
    for path in sorted(candidates, key=lambda item: item.stat().st_mtime, reverse=True):
        payload = _load_json(path)
        if payload.get("schema_version") != PRESENCE_PROJECTOR_SCHEMA:
            continue
        rows = payload.get("rows")
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict) or row.get("agent_uid") != agent_uid:
                continue
            projection = row.get("projection")
            if not isinstance(projection, dict):
                continue
            if projection.get("schema_version") != PRESENCE_PROJECTION_SCHEMA:
                continue
            return dict(projection), path
    return {}, None


def _presence_payload(repo_root: Path, a2a_bus_root: Path, agent_uid: str) -> tuple[dict[str, Any], Path | None]:
    candidates = (
        a2a_bus_root / "presence" / f"{agent_uid}.json",
        a2a_bus_root / "presence.json",
    )
    for path in candidates:
        payload = _presence_json_entry(_load_json(path), agent_uid)
        if payload:
            return payload, path
    projector_payload, projector_path = _latest_projector_projection(repo_root, agent_uid)
    if projector_payload:
        return projector_payload, projector_path
    for path in (
        a2a_bus_root / "worker_heartbeats" / f"{agent_uid}.json",
        a2a_bus_root / "bridge_heartbeats" / f"{agent_uid}.json",
        a2a_bus_root / "state" / f"{agent_uid}.json",
    ):
        payload = _presence_json_entry(_load_json(path), agent_uid)
        if payload:
            return payload, path
    return {}, None


def _alias_collisions(
    *,
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    counted_agent_uids: tuple[str, ...],
) -> tuple[str, ...]:
    aliases_by_value: dict[str, set[str]] = {}
    for uid, entry in agents.items():
        aliases = entry.get("aliases")
        values = {uid}
        if isinstance(aliases, list):
            values.update(str(alias) for alias in aliases if str(alias).strip())
        for alias in values:
            aliases_by_value.setdefault(alias, set()).add(uid)

    collisions: list[str] = []
    own_aliases = aliases_by_value.keys()
    for alias in sorted(own_aliases):
        owners = aliases_by_value.get(alias, set())
        if agent_uid in owners and len(owners) > 1:
            collisions.append(f"alias {alias} maps to multiple agents: {', '.join(sorted(owners))}")
        if alias in counted_agent_uids and alias != agent_uid and agent_uid in owners:
            collisions.append(f"alias {alias} collides with counted agent uid")
    return tuple(dict.fromkeys(collisions))


def _last_receipt_timestamp(path_text: str, repo_root: Path) -> str:
    if not path_text:
        return ""
    path = Path(path_text)
    if not path.is_absolute():
        path = repo_root / path
    payload = _load_json(path)
    timestamp = str(payload.get("timestamp") or payload.get("created_at") or "")
    if timestamp:
        return timestamp
    if path.exists():
        return datetime.fromtimestamp(path.stat().st_mtime, UTC).isoformat().replace("+00:00", "Z")
    return ""


def _expected_presence_overlay(
    *,
    repo_root: Path,
    agent_uid: str,
    broker: str,
    domain: str,
    agent_entry: dict[str, Any],
    presence: dict[str, Any],
) -> dict[str, Any]:
    semantic_path = a2a_onboard._last_valid_semantic_receipt_path(agent_uid, repo_root)
    domain_path = a2a_onboard._last_valid_domain_effect_receipt_path(agent_uid, repo_root)
    return {
        "agent_uid": presence.get("agent_uid") or agent_uid,
        "broker": presence.get("broker") or broker,
        "domain": presence.get("domain") or domain,
        "inbox_subject": presence.get("inbox_subject") or f"dharma.agent.{agent_uid}.inbox",
        "durable_consumer": presence.get("durable_consumer") or f"a2a_{_safe_token(agent_uid)}_inbox",
        "transport_state": presence.get("transport_state") or presence.get("status") or "",
        "model_state": presence.get("model_state") or agent_entry.get("status") or "",
        "tempo_tier": presence.get("tempo_tier") or agent_entry.get("tempo_tier") or "",
        "authority_status": presence.get("authority_status") or agent_entry.get("authority_status") or agent_entry.get("authority") or "",
        "last_heartbeat_at": presence.get("last_heartbeat_at") or presence.get("timestamp") or presence.get("last_seen") or "",
        "last_handler_ack_at": presence.get("last_handler_ack_at") or "",
        "last_domain_receipt_at": presence.get("last_domain_receipt_at") or _last_receipt_timestamp(domain_path, repo_root),
        "last_semantic_receipt_at": presence.get("last_semantic_receipt_at") or _last_receipt_timestamp(semantic_path, repo_root),
        "peer_model_processed_claim": presence.get("peer_model_processed_claim"),
        "last_error": presence.get("last_error") or "",
        "expires_at": presence.get("expires_at") or "",
    }


def _operator_commands(agent_uid: str, broker: str) -> dict[str, str]:
    context = "${NATS_CONTEXT:-agni-wss}"
    return {
        "identity_reconcile": f"make a2a-identity-reconcile AGENT={agent_uid} ARGS='--json'",
        "presence_preflight": f"make a2a-presence-preflight AGENT={agent_uid} ARGS='--json'",
        "inspect_presence_kv": f"nats --context {context} kv get PRESENCE agent.{agent_uid}",
        "write_presence_kv": (
            f"nats --context {context} kv put PRESENCE agent.{agent_uid} "
            "<fresh-presence-json-with-required-fields>"
        ),
        "onboard_json": f"make a2a-onboard AGENT={agent_uid} BROKER={broker} ARGS='--json'",
    }


def _row(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    agents: dict[str, dict[str, Any]],
    agent_uid: str,
    broker: str,
    domain: str,
    ttl_seconds: int,
    counted_agent_uids: tuple[str, ...],
) -> PresenceRow:
    blockers: list[str] = []
    evidence_paths: list[str] = []
    agent_entry = agents.get(agent_uid, {})
    registry_entry_present = bool(agent_entry)
    if registry_entry_present:
        evidence_paths.append(str(a2a_bus_root / "agents.json"))
    else:
        blockers.append("missing canonical registry entry")

    aliases = tuple(str(alias) for alias in agent_entry.get("aliases", []) if str(alias).strip())
    collisions = _alias_collisions(
        agents=agents,
        agent_uid=agent_uid,
        counted_agent_uids=counted_agent_uids,
    )
    blockers.extend(collisions)

    presence, source_path = _presence_payload(repo_root, a2a_bus_root, agent_uid)
    if source_path is not None:
        evidence_paths.append(_relative_or_absolute(source_path, repo_root))
    else:
        blockers.append("missing presence projection")
    overlay = _expected_presence_overlay(
        repo_root=repo_root,
        agent_uid=agent_uid,
        broker=broker,
        domain=domain,
        agent_entry=agent_entry,
        presence=presence,
    )

    missing_fields = tuple(field for field in REQUIRED_PRESENCE_FIELDS if field not in presence)
    if missing_fields:
        blockers.append("presence projection missing required fields: " + ", ".join(missing_fields))
    if overlay["agent_uid"] != agent_uid:
        blockers.append("presence agent_uid does not match canonical uid")
    if overlay["broker"] != broker:
        blockers.append(f"presence broker is not {broker}")
    if overlay["domain"] != domain:
        blockers.append(f"presence domain is not {domain}")
    expected_inbox = f"dharma.agent.{agent_uid}.inbox"
    if overlay["inbox_subject"] != expected_inbox:
        blockers.append(f"presence inbox_subject is not {expected_inbox}")
    expected_durable = f"a2a_{_safe_token(agent_uid)}_inbox"
    if overlay["durable_consumer"] != expected_durable:
        blockers.append(f"presence durable_consumer is not {expected_durable}")
    if not isinstance(overlay["peer_model_processed_claim"], bool):
        blockers.append("presence peer_model_processed_claim must be boolean")

    heartbeat_at = _parse_timestamp(overlay["last_heartbeat_at"])
    expires_at = _parse_timestamp(overlay["expires_at"])
    now = _utc_now_dt()
    age_seconds: float | None = None
    stale_presence = True
    expired_presence = True
    if heartbeat_at is not None:
        age_seconds = max(0.0, (now - heartbeat_at).total_seconds())
        stale_presence = age_seconds > ttl_seconds
    else:
        blockers.append("presence last_heartbeat_at is missing or invalid")
    if expires_at is not None:
        expired_presence = expires_at <= now
    else:
        blockers.append("presence expires_at is missing or invalid")
    if stale_presence:
        blockers.append(f"presence is stale beyond {ttl_seconds}s")
    if expired_presence:
        blockers.append("presence is expired")

    unique_blockers = tuple(dict.fromkeys(blockers))
    return PresenceRow(
        agent_uid=agent_uid,
        final_state=READY_PRESENCE_PREVALIDATED if not unique_blockers else BLOCKED_PRESENCE,
        blockers=unique_blockers,
        registry_entry_present=registry_entry_present,
        principal=principal_for_agent(agent_uid),
        aliases=aliases,
        alias_collisions=collisions,
        presence_projection_present=bool(presence),
        presence_source_path=_relative_or_absolute(source_path, repo_root) if source_path else "",
        missing_presence_fields=missing_fields,
        stale_presence=stale_presence,
        expired_presence=expired_presence,
        presence_age_seconds=round(age_seconds, 3) if age_seconds is not None else None,
        expires_at=str(overlay["expires_at"] or ""),
        inbox_subject=str(overlay["inbox_subject"] or ""),
        durable_consumer=str(overlay["durable_consumer"] or ""),
        transport_state=str(overlay["transport_state"] or ""),
        model_state=str(overlay["model_state"] or ""),
        peer_model_processed_claim=overlay["peer_model_processed_claim"]
        if isinstance(overlay["peer_model_processed_claim"], bool)
        else None,
        evidence_paths=tuple(dict.fromkeys(evidence_paths)),
        operator_commands=_operator_commands(agent_uid, broker),
    )


def run_preflight(
    *,
    repo_root: Path,
    a2a_bus_root: Path,
    receipt_dir: Path,
    agent: str,
    broker: str,
    domain: str,
    ttl_seconds: int,
) -> tuple[dict[str, Any], int]:
    agents = _nested_agents(_load_json(a2a_bus_root / "agents.json"))
    selected = _selected_agents(agent, a2a_bus_root=a2a_bus_root)
    rows = [
        _row(
            repo_root=repo_root,
            a2a_bus_root=a2a_bus_root,
            agents=agents,
            agent_uid=agent_uid,
            broker=broker,
            domain=domain,
            ttl_seconds=ttl_seconds,
            counted_agent_uids=selected,
        )
        for agent_uid in selected
    ]
    blockers = [f"{row.agent_uid}: {blocker}" for row in rows for blocker in row.blockers]
    payload: dict[str, Any] = {
        "schema_version": PRESENCE_PREFLIGHT_SCHEMA,
        "timestamp": _utc_now(),
        "passed": not blockers,
        "agent": agent,
        "broker": broker,
        "domain": domain,
        "ttl_seconds": ttl_seconds,
        "required_counted_agents": list(selected),
        "counted_agents": list(selected),
        "required_presence_fields": list(REQUIRED_PRESENCE_FIELDS),
        "kv_bucket": "PRESENCE",
        "kv_key_template": "agent.<agent_uid>",
        "rows": [row.to_dict() for row in rows],
        "blockers": list(dict.fromkeys(blockers)),
        "operator_note": (
            "This preflight is read-only. It validates canonical identity and "
            "fresh presence projection evidence, including alias collision "
            "checks; it can read a2a_presence_projector receipts but does not "
            "write NATS KV."
        ),
    }
    receipt_path = _write_receipt(receipt_dir, payload)
    payload["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    receipt_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload, 0 if payload["passed"] else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--a2a-bus-root", default=str(DEFAULT_A2A_BUS_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--agent", default="all")
    parser.add_argument("--broker", default="agni")
    parser.add_argument("--domain", default="agni")
    parser.add_argument("--ttl-seconds", type=int, default=DEFAULT_TTL_SECONDS)
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    payload, exit_code = run_preflight(
        repo_root=repo_root,
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
        receipt_dir=receipt_dir,
        agent=args.agent,
        broker=args.broker,
        domain=args.domain,
        ttl_seconds=args.ttl_seconds,
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("A2A_PRESENCE_PREFLIGHT_OK" if payload["passed"] else "A2A_PRESENCE_PREFLIGHT_NOT_READY")
        for row in payload["rows"]:
            print(f"- {row['agent_uid']}: {row['final_state']}")
            for blocker in row["blockers"]:
                print(f"  * {blocker}")
        print(f"receipt: {payload['receipt_path']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
