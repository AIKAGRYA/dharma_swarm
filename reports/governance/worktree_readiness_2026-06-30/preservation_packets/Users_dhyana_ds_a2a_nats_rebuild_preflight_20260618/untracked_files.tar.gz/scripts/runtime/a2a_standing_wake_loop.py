#!/usr/bin/env python3
"""Write target-owned standing wake-loop heartbeats for A2A agents.

This is the runtime producer for the wake-loop evidence consumed by
`a2a_wake_loop_preflight.py`. It is deliberately gated: a process may only
write a heartbeat for the agent named by `A2A_STANDING_WAKE_LOOP_AGENT`, and it
refuses to promote session-scoped or evidence-only registry entries.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import asdict, dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.a2a.agent_card import resolve_agent_uid  # noqa: E402


DEFAULT_A2A_BUS = Path.home() / ".dharma" / "a2a_bus"
DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "standing_wake_loop"
OWNER_ENV = "A2A_STANDING_WAKE_LOOP_AGENT"

HEARTBEAT_SCHEMA = "dharma.a2a.standing_wake_loop_heartbeat.v1"
RECEIPT_SCHEMA = "dharma.a2a.standing_wake_loop_receipt.v1"

STATUS_HEARTBEAT_WRITTEN = "WAKE_LOOP_HEARTBEAT_WRITTEN"
STATUS_DRY_RUN_VALIDATED = "DRY_RUN_VALIDATED"
STATUS_BLOCKED_IDENTITY = "BLOCKED_IDENTITY"
STATUS_BLOCKED_OWNER_MISMATCH = "BLOCKED_OWNER_MISMATCH"
STATUS_DEGRADED_SESSION_SCOPED = "DEGRADED_SESSION_SCOPED"
STATUS_BLOCKED_CIRCUIT_OPEN = "BLOCKED_CIRCUIT_OPEN"


@dataclass(frozen=True)
class StandingWakeLoopConfig:
    agent_uid: str
    a2a_bus_root: Path
    receipt_dir: Path
    lease_seconds: int
    failure_count: int
    failure_threshold: int
    dry_run: bool
    owner_env: str = OWNER_ENV


@dataclass(frozen=True)
class StandingWakeLoopResult:
    status: str
    wrote_heartbeat: bool
    receipt_path: str
    heartbeat_path: str
    blockers: tuple[str, ...]
    heartbeat: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def stamp() -> str:
    return utc_now().replace("-", "").replace(":", "").replace(".", "_")


def _safe_token(value: object, *, fallback: str = "unknown") -> str:
    chars = [char if char.isalnum() or char in ("_", "-") else "_" for char in str(value or "")]
    return ("".join(chars).strip("_-") or fallback)[:96]


def _read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{stamp()}.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if isinstance(agents, dict):
        return {str(key): value for key, value in agents.items() if isinstance(value, dict)}
    return {}


def _session_scoped(agent_uid: str, agent_entry: dict[str, Any], state_payload: dict[str, Any]) -> bool:
    authority = str(agent_entry.get("authority") or state_payload.get("authority") or "")
    agent_type = str(agent_entry.get("type") or state_payload.get("type") or "")
    if authority.endswith("evidence_only") or agent_type.endswith("-cli"):
        return True
    return agent_uid == "qwen_code"


def _heartbeat_file(a2a_bus_root: Path, agent_uid: str) -> Path:
    return a2a_bus_root / "worker_heartbeats" / f"{resolve_agent_uid(agent_uid)}.json"


def _relative_or_absolute(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def _lease(agent_uid: str, *, started_at: str, lease_seconds: int) -> dict[str, Any]:
    expires = datetime.fromisoformat(started_at.replace("Z", "+00:00")) + timedelta(seconds=lease_seconds)
    return {
        "lease_id": f"wake-{_safe_token(agent_uid)}-{stamp()}",
        "agent_uid": agent_uid,
        "lease_owner": agent_uid,
        "started_at": started_at,
        "expires_at": expires.isoformat().replace("+00:00", "Z"),
        "max_lease_seconds": lease_seconds,
        "renewal_mode": "standing_wake_loop",
    }


def build_heartbeat(
    *,
    agent_uid: str,
    owner: str,
    lease_seconds: int,
    failure_count: int,
    failure_threshold: int,
) -> dict[str, Any]:
    now = utc_now()
    lease = _lease(agent_uid, started_at=now, lease_seconds=lease_seconds)
    circuit_state = "open" if failure_count >= failure_threshold else "closed"
    return {
        "schema_version": HEARTBEAT_SCHEMA,
        "timestamp": now,
        "agent_uid": agent_uid,
        "status": "wake_loop_active" if circuit_state == "closed" else "wake_loop_blocked",
        "wake_loop_active": circuit_state == "closed",
        "standing_semantic_loop": circuit_state == "closed",
        "lease": lease,
        "lease_refs": [lease],
        "lease_owner": agent_uid,
        "wake_lease": lease["lease_id"],
        "max_lease_seconds": lease_seconds,
        "circuit_breaker": {
            "state": circuit_state,
            "failure_count": failure_count,
            "failure_threshold": failure_threshold,
        },
        "circuit_breaker_state": circuit_state,
        "target_owned_claim": owner == agent_uid,
        "producer_identity": owner,
        "owner_env": OWNER_ENV,
    }


def run_once(
    *,
    config: StandingWakeLoopConfig,
    repo_root: Path = REPO_ROOT,
) -> tuple[dict[str, Any], int]:
    agent_uid = resolve_agent_uid(config.agent_uid)
    agents = _nested_agents(_read_json(config.a2a_bus_root / "agents.json"))
    agent_entry = agents.get(agent_uid, {})
    state_payload = _read_json(config.a2a_bus_root / "state" / f"{agent_uid}.json")
    owner = str(os.environ.get(config.owner_env) or "")
    blockers: list[str] = []

    if not agent_entry:
        blockers.append(STATUS_BLOCKED_IDENTITY)
    if owner != agent_uid:
        blockers.append(STATUS_BLOCKED_OWNER_MISMATCH)
    if _session_scoped(agent_uid, agent_entry, state_payload):
        blockers.append(STATUS_DEGRADED_SESSION_SCOPED)
    if config.failure_count >= config.failure_threshold:
        blockers.append(STATUS_BLOCKED_CIRCUIT_OPEN)

    heartbeat = build_heartbeat(
        agent_uid=agent_uid,
        owner=owner,
        lease_seconds=config.lease_seconds,
        failure_count=config.failure_count,
        failure_threshold=config.failure_threshold,
    )
    heartbeat_path = _heartbeat_file(config.a2a_bus_root, agent_uid)
    wrote_heartbeat = False
    if not blockers and not config.dry_run:
        _write_json_atomic(heartbeat_path, heartbeat)
        wrote_heartbeat = True

    if blockers:
        status = blockers[0]
    elif config.dry_run:
        status = STATUS_DRY_RUN_VALIDATED
    else:
        status = STATUS_HEARTBEAT_WRITTEN

    receipt = {
        "schema_version": RECEIPT_SCHEMA,
        "timestamp": utc_now(),
        "status": status,
        "agent_uid": agent_uid,
        "owner_env": config.owner_env,
        "owner_env_value": owner,
        "owner_gate_satisfied": owner == agent_uid,
        "session_scoped": _session_scoped(agent_uid, agent_entry, state_payload),
        "dry_run": config.dry_run,
        "wrote_heartbeat": wrote_heartbeat,
        "heartbeat_path": _relative_or_absolute(heartbeat_path, repo_root),
        "heartbeat": heartbeat,
        "blockers": list(dict.fromkeys(blockers)),
    }
    config.receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = config.receipt_dir / f"{stamp()}-{_safe_token(agent_uid)}-standing-wake-loop.json"
    _write_json_atomic(receipt_path, receipt)
    receipt["receipt_path"] = _relative_or_absolute(receipt_path, repo_root)
    _write_json_atomic(receipt_path, receipt)
    result = StandingWakeLoopResult(
        status=status,
        wrote_heartbeat=wrote_heartbeat,
        receipt_path=str(receipt["receipt_path"]),
        heartbeat_path=str(receipt["heartbeat_path"]),
        blockers=tuple(receipt["blockers"]),
        heartbeat=heartbeat,
    )
    return {**receipt, "result": result.to_dict()}, 0 if not blockers else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent-uid", "--agent", dest="agent_uid", required=True)
    parser.add_argument("--a2a-bus-root", default=str(DEFAULT_A2A_BUS))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--lease-seconds", type=int, default=300)
    parser.add_argument("--failure-count", type=int, default=0)
    parser.add_argument("--failure-threshold", type=int, default=3)
    parser.add_argument("--interval-seconds", type=float, default=30.0)
    parser.add_argument("--iterations", type=int, default=1)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    repo_root = REPO_ROOT
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = repo_root / receipt_dir
    config = StandingWakeLoopConfig(
        agent_uid=str(args.agent_uid),
        a2a_bus_root=Path(args.a2a_bus_root).expanduser().resolve(),
        receipt_dir=receipt_dir,
        lease_seconds=int(args.lease_seconds),
        failure_count=max(0, int(args.failure_count)),
        failure_threshold=max(1, int(args.failure_threshold)),
        dry_run=bool(args.dry_run),
    )
    last_payload: dict[str, Any] = {}
    exit_code = 0
    iterations = int(args.iterations)
    count = 0
    while iterations == 0 or count < iterations:
        payload, exit_code = run_once(config=config, repo_root=repo_root)
        last_payload = payload
        count += 1
        if exit_code != 0 or iterations == 1:
            break
        time.sleep(max(0.1, float(args.interval_seconds)))

    if args.json:
        print(json.dumps(last_payload, indent=2, sort_keys=True))
    else:
        print(last_payload.get("status", "UNKNOWN"))
        for blocker in last_payload.get("blockers", []):
            print(f"- {blocker}")
        print(f"receipt: {last_payload.get('receipt_path', '')}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
