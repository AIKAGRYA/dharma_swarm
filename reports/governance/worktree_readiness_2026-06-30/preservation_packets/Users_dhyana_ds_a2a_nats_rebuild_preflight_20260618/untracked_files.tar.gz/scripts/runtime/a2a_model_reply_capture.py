#!/usr/bin/env python3
"""Capture a target model's stdout as a validated A2A domain reply artifact.

This is the provenance-preserving path for agents that can be invoked as a
local command but do not directly write their own outbox files. The command is
the semantic author; this wrapper only validates, frames, and writes the JSON
artifact under the target-owned outbox.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.a2a_domain_reply_worker import (  # noqa: E402
    DEFAULT_OUTBOX_ROOT,
    DOMAIN_REPLY_ARTIFACT_SCHEMA,
    default_outbox_dir,
    load_domain_reply_target,
)
from scripts.runtime.a2a_send import resolve_agent_uid  # noqa: E402
from scripts.runtime.pr_merge_control import stamp, utc_now  # noqa: E402


CAPTURE_RECEIPT_SCHEMA = "dharma.a2a.model_reply_capture_receipt.v1"

STATUS_MODEL_REPLY_ARTIFACT_WRITTEN = "MODEL_REPLY_ARTIFACT_WRITTEN"
STATUS_DRY_RUN_VALIDATED = "DRY_RUN_VALIDATED"
STATUS_MODEL_COMMAND_FAILED = "MODEL_COMMAND_FAILED"
STATUS_MODEL_STDOUT_INVALID = "MODEL_STDOUT_INVALID"
STATUS_ARTIFACT_VALIDATION_FAILED = "ARTIFACT_VALIDATION_FAILED"

DEFAULT_RECEIPT_DIR = REPO_ROOT / "reports" / "a2a" / "model_reply_captures"


@dataclass(frozen=True)
class CaptureResult:
    status: str
    agent_uid: str
    packet_id: str
    artifact_path: str
    receipt_path: str
    wrote_artifact: bool
    blockers: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"JSON object required: {path}")
    return data


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{stamp()}.tmp")
    tmp.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    tmp.replace(path)


def _safe_token(value: object, *, fallback: str = "unknown") -> str:
    chars = [
        char if char.isalnum() or char in ("_", "-") else "_"
        for char in str(value or "")
    ]
    return ("".join(chars).strip("_-") or fallback)[:96]


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _sha256_json(value: dict[str, Any]) -> str:
    data = json.dumps(value, ensure_ascii=True, sort_keys=True).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _bounded_tail(value: str, *, limit: int = 2000) -> str:
    return value[-limit:] if value else ""


def _extract_json_object(text: str) -> dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()
    decoder = json.JSONDecoder()
    start = stripped.find("{")
    if start < 0:
        raise ValueError("model stdout did not contain a JSON object")
    payload, end = decoder.raw_decode(stripped[start:])
    trailing = stripped[start + end :].strip()
    if trailing:
        raise ValueError("model stdout contained trailing non-JSON text")
    if not isinstance(payload, dict):
        raise ValueError("model stdout JSON must be an object")
    return payload


def _delivery_envelope(delivery_record: dict[str, Any]) -> dict[str, Any]:
    if delivery_record.get("schema_version") != "dharma.a2a.inbox_delivery.v1":
        raise ValueError("delivery record must use schema dharma.a2a.inbox_delivery.v1")
    envelope = delivery_record.get("envelope")
    if not isinstance(envelope, dict):
        raise ValueError("delivery record is missing envelope object")
    return envelope


def _send_receipt_semantic_field(send_receipt: dict[str, Any], key: str) -> str:
    direct = str(send_receipt.get(key) or "").strip()
    if direct:
        return direct
    semantic_ref = send_receipt.get("semantic_task_packet")
    if isinstance(semantic_ref, dict):
        return str(semantic_ref.get(key) or "").strip()
    return ""


def _placeholder(value: Any) -> bool:
    text = str(value or "").strip()
    return text.startswith("<") and text.endswith(">")


def _artifact_failures(
    *,
    artifact: dict[str, Any],
    agent_uid: str,
    packet_id: str,
    reply_subject: str,
    send_receipt_path: Path,
    send_receipt: dict[str, Any],
) -> list[str]:
    failures: list[str] = []
    if artifact.get("schema_version") != DOMAIN_REPLY_ARTIFACT_SCHEMA:
        failures.append(
            f"artifact schema_version must be {DOMAIN_REPLY_ARTIFACT_SCHEMA}"
        )
    actor = str(
        artifact.get("authored_by")
        or artifact.get("from_agent")
        or artifact.get("agent_uid")
        or ""
    ).strip()
    if resolve_agent_uid(actor) != agent_uid:
        failures.append("artifact actor does not match target agent")
    if artifact.get("packet_id") != packet_id:
        failures.append("artifact packet_id does not match delivery packet")
    if artifact.get("reply_subject") != reply_subject:
        failures.append("artifact reply_subject does not match delivery reply_subject")
    artifact_send = str(artifact.get("send_receipt_path") or "").strip()
    if not artifact_send:
        failures.append("artifact missing send_receipt_path")
    elif Path(artifact_send).expanduser().resolve() != send_receipt_path:
        failures.append("artifact send_receipt_path does not match")
    if artifact.get("peer_model_processed_claim") is not True:
        failures.append("artifact peer_model_processed_claim is not true")
    if artifact.get("semantic_reply_claim") is not True:
        failures.append("artifact semantic_reply_claim is not true")
    for key in (
        "model_identity",
        "task_hash",
        "locked_spec_sha256",
        "failure_digest",
        "summary",
        "verdict",
    ):
        if not str(artifact.get(key) or "").strip():
            failures.append(f"artifact missing {key}")
        elif _placeholder(artifact.get(key)):
            failures.append(f"artifact {key} is still a placeholder")
    evidence_refs = artifact.get("evidence_refs")
    if not isinstance(evidence_refs, list) or not evidence_refs:
        failures.append("artifact evidence_refs must be non-empty")
    elif any(_placeholder(ref) for ref in evidence_refs):
        failures.append("artifact evidence_refs contain placeholders")
    confidence = artifact.get("confidence")
    if not isinstance(confidence, int | float) or isinstance(confidence, bool):
        failures.append("artifact confidence must be numeric")
    elif not 0.0 <= float(confidence) <= 1.0:
        failures.append("artifact confidence must be between 0 and 1")
    digest = str(artifact.get("failure_digest") or "").lower()
    for required in ("confused", "tried", "failed", "worked"):
        if required not in digest:
            failures.append(f"artifact failure_digest missing {required}")
    send_task_hash = _send_receipt_semantic_field(send_receipt, "task_hash")
    if send_task_hash and artifact.get("task_hash") != send_task_hash:
        failures.append("artifact task_hash does not match send receipt")
    send_locked_spec = _send_receipt_semantic_field(send_receipt, "locked_spec_sha256")
    if send_locked_spec and artifact.get("locked_spec_sha256") != send_locked_spec:
        failures.append("artifact locked_spec_sha256 does not match send receipt")
    return failures


def _augment_artifact(
    *,
    artifact: dict[str, Any],
    delivery_record_path: Path,
    send_receipt_path: Path,
    stdout: str,
    command: list[str],
) -> dict[str, Any]:
    framed = dict(artifact)
    framed.setdefault("author_kind", "target_model_stdout_capture")
    framed["model_stdout_sha256"] = _sha256_text(stdout)
    framed["model_capture_command_sha256"] = _sha256_text(
        json.dumps(command, ensure_ascii=True)
    )
    framed["source_delivery_record_path"] = str(delivery_record_path)
    framed["source_send_receipt_path"] = str(send_receipt_path)
    framed["captured_at"] = utc_now()
    return framed


def run_capture(
    *,
    agent_uid: str,
    delivery_record_path: Path,
    send_receipt_path: Path,
    outbox_root: Path,
    receipt_dir: Path,
    command: list[str],
    timeout_seconds: float,
    dry_run: bool = False,
) -> tuple[dict[str, Any], int]:
    agent = resolve_agent_uid(agent_uid)
    delivery_record = _read_json(delivery_record_path)
    send_receipt = _read_json(send_receipt_path)
    envelope = _delivery_envelope(delivery_record)
    delivery_agent = resolve_agent_uid(
        str(delivery_record.get("agent_uid") or envelope.get("target_uid") or "")
    )
    packet_id = str(envelope.get("packet_id") or "")
    reply_subject = str(envelope.get("reply_subject") or "")
    if delivery_agent != agent:
        raise ValueError("delivery record target does not match requested agent")
    if not packet_id or not reply_subject:
        raise ValueError("delivery record is missing packet_id or reply_subject")
    if not command:
        raise ValueError("--command is required")

    started = time.monotonic()
    proc = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout_seconds,
        check=False,
    )
    elapsed = round(time.monotonic() - started, 3)
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""
    artifact_path = (
        default_outbox_dir(agent, outbox_root=outbox_root) / f"{packet_id}.json"
    )
    blockers: list[str] = []
    status = STATUS_MODEL_REPLY_ARTIFACT_WRITTEN
    artifact: dict[str, Any] = {}

    if proc.returncode != 0:
        status = STATUS_MODEL_COMMAND_FAILED
        blockers.append(f"model command exited {proc.returncode}")
    else:
        try:
            artifact = _extract_json_object(stdout)
        except ValueError as exc:
            status = STATUS_MODEL_STDOUT_INVALID
            blockers.append(str(exc))
        else:
            blockers.extend(
                _artifact_failures(
                    artifact=artifact,
                    agent_uid=agent,
                    packet_id=packet_id,
                    reply_subject=reply_subject,
                    send_receipt_path=send_receipt_path,
                    send_receipt=send_receipt,
                )
            )
            if blockers:
                status = STATUS_ARTIFACT_VALIDATION_FAILED
            else:
                artifact = _augment_artifact(
                    artifact=artifact,
                    delivery_record_path=delivery_record_path,
                    send_receipt_path=send_receipt_path,
                    stdout=stdout,
                    command=command,
                )

    wrote_artifact = False
    if not blockers and not dry_run:
        _write_json(artifact_path, artifact)
        load_domain_reply_target(
            send_receipt_path=send_receipt_path,
            reply_artifact_path=artifact_path,
            agent_uid=agent,
            outbox_root=outbox_root,
            enforce_owner_path=True,
        )
        wrote_artifact = True
    elif not blockers and dry_run:
        status = STATUS_DRY_RUN_VALIDATED

    receipt = {
        "schema_version": CAPTURE_RECEIPT_SCHEMA,
        "timestamp": utc_now(),
        "status": status,
        "agent_uid": agent,
        "packet_id": packet_id,
        "artifact_path": str(artifact_path),
        "wrote_artifact": wrote_artifact,
        "dry_run": dry_run,
        "blockers": list(dict.fromkeys(blockers)),
        "command": command,
        "command_returncode": proc.returncode,
        "command_elapsed_seconds": elapsed,
        "stdout_sha256": _sha256_text(stdout),
        "stdout_tail": _bounded_tail(stdout)
        if status != STATUS_MODEL_REPLY_ARTIFACT_WRITTEN
        else "",
        "stderr_tail": stderr[-2000:],
        "delivery_record_path": str(delivery_record_path),
        "send_receipt_path": str(send_receipt_path),
        "artifact_sha256": _sha256_json(artifact) if artifact else "",
        "semantic_reply_claim": bool(artifact.get("semantic_reply_claim", False)),
        "peer_model_processed_claim": bool(
            artifact.get("peer_model_processed_claim", False)
        ),
        "operator_contact_note": (
            "target model stdout was captured and validated before writing the "
            "target-owned reply artifact; no semantic fields are invented by "
            "the wrapper"
        ),
    }
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / (
        f"{stamp()}-{_safe_token(agent)}-{_safe_token(packet_id)}.json"
    )
    receipt["receipt_path"] = str(receipt_path)
    receipt["result"] = CaptureResult(
        status=status,
        agent_uid=agent,
        packet_id=packet_id,
        artifact_path=str(artifact_path),
        receipt_path=str(receipt_path),
        wrote_artifact=wrote_artifact,
        blockers=tuple(receipt["blockers"]),
    ).to_dict()
    _write_json(receipt_path, receipt)
    return receipt, 0 if not blockers else 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        command_index = argv.index("--command")
    except ValueError:
        pass
    else:
        separator_index = command_index + 1
        if len(argv) > separator_index and argv[separator_index] == "--":
            del argv[separator_index]
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--agent-uid", "--agent", dest="agent_uid", required=True)
    parser.add_argument("--delivery-record", required=True)
    parser.add_argument("--send-receipt", required=True)
    parser.add_argument("--outbox-root", default=str(DEFAULT_OUTBOX_ROOT))
    parser.add_argument("--receipt-dir", default=str(DEFAULT_RECEIPT_DIR))
    parser.add_argument("--timeout-seconds", type=float, default=120.0)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--command", nargs=argparse.REMAINDER, required=True)
    args = parser.parse_args(argv)
    if args.command and args.command[0] == "--":
        args.command = args.command[1:]
    return args


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    receipt_dir = Path(args.receipt_dir).expanduser()
    if not receipt_dir.is_absolute():
        receipt_dir = REPO_ROOT / receipt_dir
    try:
        payload, exit_code = run_capture(
            agent_uid=str(args.agent_uid),
            delivery_record_path=Path(args.delivery_record).expanduser().resolve(),
            send_receipt_path=Path(args.send_receipt).expanduser().resolve(),
            outbox_root=Path(args.outbox_root).expanduser().resolve(),
            receipt_dir=receipt_dir,
            command=list(args.command),
            timeout_seconds=float(args.timeout_seconds),
            dry_run=bool(args.dry_run),
        )
    except subprocess.TimeoutExpired as exc:
        payload = {
            "schema_version": CAPTURE_RECEIPT_SCHEMA,
            "timestamp": utc_now(),
            "status": STATUS_MODEL_COMMAND_FAILED,
            "agent_uid": str(args.agent_uid),
            "packet_id": "",
            "artifact_path": "",
            "wrote_artifact": False,
            "blockers": [f"model command timed out after {exc.timeout:g}s"],
            "command": list(args.command),
        }
        receipt_dir.mkdir(parents=True, exist_ok=True)
        path = receipt_dir / f"{stamp()}-{_safe_token(args.agent_uid)}-timeout.json"
        payload["receipt_path"] = str(path)
        _write_json(path, payload)
        exit_code = 1
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(payload.get("status", "UNKNOWN"))
        for blocker in payload.get("blockers", []):
            print(f"- {blocker}")
        print(f"receipt: {payload.get('receipt_path', '')}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
