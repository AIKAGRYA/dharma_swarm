"""A2A agent roster and cohort selection helpers.

This module keeps the fixed seed cohort available for regression gates while
letting governance checks resolve dynamic, capability-based cohorts from the
operator roster at ``~/.dharma/a2a_bus/agents.json``.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable


SEED_AGENT_UIDS = (
    "codex_composer",
    "devin-roaming-2987d222",
    "hermes-m5",
    "qwen_code",
    "opus_composer",
)

DEFAULT_A2A_BUS_ROOT = Path.home() / ".dharma" / "a2a_bus"

BLOCKED_QUOTA_STATES = {
    "blocked",
    "credit_exhausted",
    "depleted",
    "exhausted",
    "quota_exhausted",
    "rate_limited",
    "unavailable",
}
BLOCKED_STATUS_TOKENS = (
    "blocked",
    "credit",
    "exhausted",
    "offline",
    "quota",
    "rate_limited",
    "unavailable",
)

DEFAULT_SEED_METADATA: dict[str, dict[str, Any]] = {
    "codex_composer": {
        "provider": "codex",
        "model_identity": "openai/codex",
        "type": "codex-cli",
        "role": "repo_engineer",
        "capabilities": (
            "lead_orchestration",
            "repo_engineering",
            "code_review",
            "research_synthesis",
        ),
    },
    "devin-roaming-2987d222": {
        "provider": "cognition",
        "model_identity": "cognition/devin",
        "type": "devin",
        "role": "devops_specialist",
        "capabilities": (
            "build_system",
            "ci_cd",
            "deployment",
            "test_infrastructure",
        ),
    },
    "hermes-m5": {
        "provider": "hermes",
        "model_identity": "hermes/m5",
        "type": "hermes",
        "role": "memory_worker",
        "capabilities": ("memory", "evolution", "fleet"),
    },
    "qwen_code": {
        "provider": "alibaba",
        "model_identity": "alibaba/qwen-code-runtime",
        "type": "qwen-code",
        "role": "code_worker",
        "capabilities": (
            "code_review",
            "debugging",
            "test_authoring",
            "reasoning",
            "codebase_exploration",
        ),
    },
    "opus_composer": {
        "provider": "anthropic",
        "model_identity": "anthropic/claude-opus",
        "type": "claude-code",
        "role": "reasoning_reviewer",
        "capabilities": (
            "deep_single_pass_reasoning",
            "architectural_decisions",
            "adversarial_review",
            "cross_domain_synthesis",
        ),
    },
}


def _normal(value: object) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def _as_tuple(value: object) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,) if value.strip() else ()
    if isinstance(value, Iterable):
        return tuple(str(item).strip() for item in value if str(item).strip())
    return ()


def _nested_agents(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    agents = payload.get("agents")
    if isinstance(agents, dict):
        return {str(uid): entry for uid, entry in agents.items() if isinstance(entry, dict)}
    return {str(uid): entry for uid, entry in payload.items() if isinstance(entry, dict)}


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


@dataclass(frozen=True)
class AgentRosterEntry:
    agent_uid: str
    agent_type: str = ""
    provider: str = ""
    model_identity: str = ""
    role: str = ""
    capabilities: tuple[str, ...] = ()
    aliases: tuple[str, ...] = ()
    authority: str = ""
    status: str = ""
    dispatch_enabled: bool | None = None
    wake_loop_active: bool | None = None
    stale: bool = False
    quota_state: str = ""
    raw: dict[str, Any] | None = None

    @classmethod
    def from_raw(cls, agent_uid: str, raw: dict[str, Any]) -> "AgentRosterEntry":
        role_values = [
            raw.get("role"),
            raw.get("team_role"),
            raw.get("authority_rank"),
            raw.get("type"),
            raw.get("provider"),
            raw.get("harness"),
        ]
        role = next((str(value) for value in role_values if value), "")
        dispatch_raw = raw.get("dispatch_enabled")
        dispatch_enabled = dispatch_raw if isinstance(dispatch_raw, bool) else None
        wake_raw = raw.get("wake_loop_active")
        wake_loop_active = wake_raw if isinstance(wake_raw, bool) else None
        return cls(
            agent_uid=agent_uid,
            agent_type=str(raw.get("type") or raw.get("agent_type") or ""),
            provider=str(raw.get("provider") or raw.get("model_provider") or ""),
            model_identity=str(raw.get("model_identity") or raw.get("engine") or ""),
            role=role,
            capabilities=_as_tuple(raw.get("capabilities")),
            aliases=_as_tuple(raw.get("aliases")),
            authority=str(raw.get("authority") or ""),
            status=str(raw.get("status") or ""),
            dispatch_enabled=dispatch_enabled,
            wake_loop_active=wake_loop_active,
            stale=bool(raw.get("stale")),
            quota_state=str(
                raw.get("quota_state")
                or raw.get("provider_state")
                or raw.get("availability_state")
                or ""
            ),
            raw=dict(raw),
        )

    @property
    def normalized_capabilities(self) -> set[str]:
        return {_normal(item) for item in self.capabilities}

    @property
    def normalized_roles(self) -> set[str]:
        values = {
            self.role,
            self.agent_type,
            self.provider,
            self.authority,
            self.model_identity.split("/", 1)[0] if "/" in self.model_identity else "",
        }
        return {_normal(value) for value in values if value}

    @property
    def quota_blocked(self) -> bool:
        quota = _normal(self.quota_state)
        if quota in BLOCKED_QUOTA_STATES:
            return True
        status = _normal(self.status)
        return any(token in status for token in BLOCKED_STATUS_TOKENS)

    @property
    def eligible_for_dynamic_cohort(self) -> bool:
        if self.dispatch_enabled is False:
            return False
        if self.stale or self.quota_blocked:
            return False
        if not self.capabilities and not self.role and not self.agent_type:
            return False
        return True

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["raw"] = dict(self.raw or {})
        payload["eligible_for_dynamic_cohort"] = self.eligible_for_dynamic_cohort
        payload["quota_blocked"] = self.quota_blocked
        return payload


@dataclass(frozen=True)
class AgentSelection:
    selector: str
    selection_kind: str
    agent_uids: tuple[str, ...]
    required_agent_count: int
    strict: bool
    roster_path: str
    candidate_agent_uids: tuple[str, ...]
    excluded_agent_uids: tuple[str, ...]
    warnings: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "selector": self.selector,
            "selection_kind": self.selection_kind,
            "agent_uids": list(self.agent_uids),
            "required_agent_count": self.required_agent_count,
            "strict": self.strict,
            "roster_path": self.roster_path,
            "candidate_agent_uids": list(self.candidate_agent_uids),
            "excluded_agent_uids": list(self.excluded_agent_uids),
            "warnings": list(self.warnings),
        }


def load_agent_roster(
    *,
    a2a_bus_root: Path | None = None,
    registry_path: Path | None = None,
) -> tuple[dict[str, AgentRosterEntry], str]:
    roster_path = registry_path or (a2a_bus_root or DEFAULT_A2A_BUS_ROOT) / "agents.json"
    payload = _load_json(Path(roster_path).expanduser())
    raw_agents = _nested_agents(payload)
    if raw_agents:
        merged = {
            uid: {**DEFAULT_SEED_METADATA.get(uid, {}), **raw}
            for uid, raw in raw_agents.items()
        }
    else:
        merged = {uid: dict(meta) for uid, meta in DEFAULT_SEED_METADATA.items()}
    entries = {
        uid: AgentRosterEntry.from_raw(uid, raw)
        for uid, raw in merged.items()
    }
    return entries, str(Path(roster_path).expanduser())


def _dedupe(values: Iterable[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(item for item in values if item))


def _explicit_agent_list(selector: str) -> tuple[str, ...]:
    return tuple(item.strip() for item in selector.split(",") if item.strip())


def _select_dynamic(entries: dict[str, AgentRosterEntry]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    selected = sorted(
        uid for uid, entry in entries.items() if entry.eligible_for_dynamic_cohort
    )
    excluded = sorted(uid for uid in entries if uid not in selected)
    return tuple(selected), tuple(excluded)


def _select_capability(
    entries: dict[str, AgentRosterEntry],
    capability: str,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    wanted = _normal(capability)
    selected = sorted(
        uid
        for uid, entry in entries.items()
        if entry.eligible_for_dynamic_cohort and wanted in entry.normalized_capabilities
    )
    excluded = sorted(uid for uid in entries if uid not in selected)
    return tuple(selected), tuple(excluded)


def _select_role(
    entries: dict[str, AgentRosterEntry],
    role: str,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    wanted = _normal(role)
    selected = sorted(
        uid
        for uid, entry in entries.items()
        if entry.eligible_for_dynamic_cohort and wanted in entry.normalized_roles
    )
    excluded = sorted(uid for uid in entries if uid not in selected)
    return tuple(selected), tuple(excluded)


def resolve_agent_selection(
    selector: str = "all",
    *,
    cohort: str | None = None,
    a2a_bus_root: Path | None = None,
    registry_path: Path | None = None,
    min_agents: int | None = None,
) -> AgentSelection:
    entries, roster_path = load_agent_roster(
        a2a_bus_root=a2a_bus_root,
        registry_path=registry_path,
    )
    raw_selector = (cohort or selector or "all").strip()
    normalized = _normal(raw_selector)
    warnings: list[str] = []

    if normalized in {"seed", "seed_cohort", "counted_seed"}:
        selected = tuple(SEED_AGENT_UIDS)
        excluded = tuple(sorted(uid for uid in entries if uid not in selected))
        selection_kind = "seed"
        default_required = len(selected)
    elif normalized in {"all", "all_ready", "eligible", "dynamic", "fleet"}:
        selected, excluded = _select_dynamic(entries)
        selection_kind = "dynamic_all_ready"
        default_required = len(selected)
    elif normalized in {"roster", "all_registered", "registered"}:
        selected = tuple(sorted(entries))
        excluded = ()
        selection_kind = "all_registered"
        default_required = len(selected)
    elif normalized.startswith("capability:"):
        selected, excluded = _select_capability(entries, raw_selector.split(":", 1)[1])
        selection_kind = "capability"
        default_required = 1
    elif normalized.startswith("role:"):
        selected, excluded = _select_role(entries, raw_selector.split(":", 1)[1])
        selection_kind = "role"
        default_required = 1
    else:
        selected = _explicit_agent_list(raw_selector)
        excluded = tuple(sorted(uid for uid in entries if uid not in selected))
        selection_kind = "explicit"
        default_required = len(selected)

    if not selected and selection_kind == "dynamic_all_ready":
        selected = tuple(uid for uid in SEED_AGENT_UIDS if uid in entries)
        excluded = tuple(sorted(uid for uid in entries if uid not in selected))
        selection_kind = "dynamic_all_ready_seed_fallback"
        default_required = len(selected)
        warnings.append("dynamic roster was empty; fell back to seed cohort")

    required = min_agents if min_agents is not None else default_required
    if required < 0:
        raise ValueError("min_agents must be non-negative")
    strict = bool(selected) and required >= len(selected)
    if selected and required > len(selected):
        warnings.append(
            f"required_agent_count {required} exceeds selected cohort size {len(selected)}"
        )

    return AgentSelection(
        selector=raw_selector,
        selection_kind=selection_kind,
        agent_uids=_dedupe(selected),
        required_agent_count=required,
        strict=strict,
        roster_path=roster_path,
        candidate_agent_uids=_dedupe(selected),
        excluded_agent_uids=_dedupe(excluded),
        warnings=tuple(warnings),
    )


def resolve_agent_uids(
    selector: str = "all",
    *,
    cohort: str | None = None,
    a2a_bus_root: Path | None = None,
    registry_path: Path | None = None,
    min_agents: int | None = None,
) -> tuple[str, ...]:
    return resolve_agent_selection(
        selector,
        cohort=cohort,
        a2a_bus_root=a2a_bus_root,
        registry_path=registry_path,
        min_agents=min_agents,
    ).agent_uids
