"""Canonical A2A JetStream topology for the v12d rebuild.

The module is deliberately import-safe and offline-verifiable. It renders the
streams/consumers that a live installer should apply, and it verifies the
contract without needing broker credentials.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Any, Iterable

from dharma_swarm.a2a.agent_roster import SEED_AGENT_UIDS


A2A_INBOX = "A2A_INBOX"
A2A_TASKS = "A2A_TASKS"
A2A_RECEIPTS = "A2A_RECEIPTS"
A2A_DLQ = "A2A_DLQ"

PRESENCE_BUCKET = "PRESENCE"

COUNTED_AGENT_UIDS = SEED_AGENT_UIDS

MIGRATION_ALIASES = {
    "DHARMA_A2A": A2A_TASKS,
    "DHARMA_FLEET": A2A_RECEIPTS,
    "DS_A2A": A2A_TASKS,
    "DS_A2A_INBOX": A2A_INBOX,
    "DS_A2A_RECEIPTS": A2A_RECEIPTS,
}


@dataclass(frozen=True)
class StreamSpec:
    name: str
    subjects: tuple[str, ...]
    retention: str
    storage: str
    max_age_s: int
    duplicate_window_s: int
    discard: str = "old"
    max_bytes: int = 512 * 1024 * 1024
    max_msgs_per_subject: int = 100_000
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ConsumerSpec:
    durable: str
    stream: str
    filter_subject: str
    ack_policy: str
    ack_wait_s: int
    max_deliver: int
    backoff_s: tuple[int, ...]
    max_ack_pending: int
    deliver_policy: str
    kind: str
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TopologyPlan:
    streams: tuple[StreamSpec, ...]
    consumers: tuple[ConsumerSpec, ...]
    migration_aliases: dict[str, str]
    presence_bucket: str = PRESENCE_BUCKET

    def to_dict(self) -> dict[str, Any]:
        return {
            "streams": [stream.to_dict() for stream in self.streams],
            "consumers": [consumer.to_dict() for consumer in self.consumers],
            "migration_aliases": dict(self.migration_aliases),
            "presence_bucket": self.presence_bucket,
        }


@dataclass(frozen=True)
class TopologyVerification:
    passed: bool
    failures: tuple[str, ...]
    checked_streams: tuple[str, ...]
    checked_consumers: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AclProbeSpec:
    agent_uid: str
    principal: str
    allow_publish: tuple[str, ...]
    allow_subscribe: tuple[str, ...]
    allow_jetstream_pull: tuple[str, ...]
    deny_subjects: tuple[str, ...]
    deny_operations: tuple[str, ...]
    positive_probes: tuple[str, ...]
    negative_probes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AclProbeVerification:
    passed: bool
    failures: tuple[str, ...]
    checked_principals: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LiveStreamObservation:
    name: str
    subjects: tuple[str, ...]
    active_subjects: tuple[str, ...] = ()
    duplicate_window_s: int | None = None
    retention: str = ""
    storage: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LiveConsumerObservation:
    stream: str
    durable: str
    filter_subject: str = ""
    ack_policy: str = ""
    deliver_policy: str = ""
    ack_wait_ns: int | None = None
    max_deliver: int | None = None
    backoff_ns: tuple[int, ...] | None = None
    max_ack_pending: int | None = None
    num_ack_pending: int | None = None
    num_pending: int | None = None
    num_redelivered: int | None = None
    num_waiting: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LiveTopologyVerification:
    passed: bool
    failures: tuple[str, ...]
    observed_streams: tuple[str, ...]
    observed_consumers: tuple[str, ...]
    observed_kv_buckets: tuple[str, ...]
    missing_streams: tuple[str, ...]
    missing_consumers: tuple[str, ...]
    drifted_consumers: tuple[str, ...]
    legacy_streams: tuple[str, ...]
    overlapping_subjects: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TopologyMigrationStep:
    step_id: str
    phase: str
    action: str
    command: str
    mutates: bool
    requires_approval: bool
    blocked: bool
    blocker: str = ""
    rationale: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TopologyMigrationPlan:
    strategy: str
    can_apply_additive: bool
    can_apply_cutover: bool
    blockers: tuple[str, ...]
    steps: tuple[TopologyMigrationStep, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "strategy": self.strategy,
            "can_apply_additive": self.can_apply_additive,
            "can_apply_cutover": self.can_apply_cutover,
            "blockers": list(self.blockers),
            "steps": [step.to_dict() for step in self.steps],
        }


def safe_durable_token(value: object, *, fallback: str = "agent") -> str:
    chars = [char if char.isalnum() or char in ("_", "-") else "_" for char in str(value or "")]
    return ("".join(chars).strip("_-") or fallback)[:96]


def principal_for_agent(agent_uid: str) -> str:
    """Broker principal name for a counted A2A agent."""
    return f"a2a_{safe_durable_token(agent_uid)}"


A2A_STREAM_SPECS = (
    StreamSpec(
        name=A2A_INBOX,
        subjects=(
            "dharma.agent.*.inbox",
            "dharma.agent.*.inbox.>",
            "dharma.agent.*.outbox",
            "dharma.agent.*.outbox.>",
        ),
        retention="limits",
        storage="file",
        max_age_s=14 * 24 * 60 * 60,
        duplicate_window_s=10 * 60,
        max_bytes=512 * 1024 * 1024,
        max_msgs_per_subject=50_000,
        description="agent inbox/outbox hot-contact envelopes",
    ),
    StreamSpec(
        name=A2A_TASKS,
        subjects=("dharma.a2a.task.>",),
        retention="workqueue",
        storage="file",
        max_age_s=30 * 24 * 60 * 60,
        duplicate_window_s=10 * 60,
        max_bytes=1024 * 1024 * 1024,
        max_msgs_per_subject=50_000,
        description="A2A task claim/close work queue",
    ),
    StreamSpec(
        name=A2A_RECEIPTS,
        subjects=("dharma.a2a.receipt", "dharma.a2a.receipt.>", "dharma.substrate.health"),
        retention="limits",
        storage="file",
        max_age_s=90 * 24 * 60 * 60,
        duplicate_window_s=10 * 60,
        max_bytes=1024 * 1024 * 1024,
        max_msgs_per_subject=200_000,
        description="typed receipts and substrate health projections",
    ),
    StreamSpec(
        name=A2A_DLQ,
        subjects=("dharma.dlq.>",),
        retention="limits",
        storage="file",
        max_age_s=90 * 24 * 60 * 60,
        duplicate_window_s=10 * 60,
        max_bytes=512 * 1024 * 1024,
        max_msgs_per_subject=100_000,
        description="invalid-envelope quarantine and terminal failures",
    ),
)


def agent_inbox_consumer(agent_uid: str) -> ConsumerSpec:
    uid = safe_durable_token(agent_uid)
    return ConsumerSpec(
        durable=f"a2a_{uid}_inbox",
        stream=A2A_INBOX,
        filter_subject=f"dharma.agent.{agent_uid}.inbox",
        ack_policy="explicit",
        ack_wait_s=5,
        max_deliver=5,
        backoff_s=(5, 30, 120, 600),
        max_ack_pending=20,
        deliver_policy="new",
        kind="agent_inbox",
        description=f"canonical inbox pull consumer for {agent_uid}",
    )


def canonical_consumer_specs(agent_uids: Iterable[str] = COUNTED_AGENT_UIDS) -> tuple[ConsumerSpec, ...]:
    consumers = [agent_inbox_consumer(agent_uid) for agent_uid in agent_uids]
    consumers.extend(
        [
            ConsumerSpec(
                durable="a2a_task_claimant",
                stream=A2A_TASKS,
                filter_subject="dharma.a2a.task.claim",
                ack_policy="explicit",
                ack_wait_s=10,
                max_deliver=3,
                backoff_s=(10, 60),
                max_ack_pending=10,
                deliver_policy="all",
                kind="task_claimant",
                description="bounded task-claim workqueue consumer",
            ),
            ConsumerSpec(
                durable="a2a_task_closer",
                stream=A2A_TASKS,
                filter_subject="dharma.a2a.task.close",
                ack_policy="explicit",
                ack_wait_s=10,
                max_deliver=3,
                backoff_s=(10, 60),
                max_ack_pending=10,
                deliver_policy="all",
                kind="task_closer",
                description="bounded task-close workqueue consumer",
            ),
            ConsumerSpec(
                durable="a2a_receipt_indexer",
                stream=A2A_RECEIPTS,
                filter_subject="dharma.a2a.receipt",
                ack_policy="explicit",
                ack_wait_s=5,
                max_deliver=5,
                backoff_s=(5, 30, 120, 600),
                max_ack_pending=100,
                deliver_policy="all",
                kind="receipt_indexer",
                description="audit/indexer consumer may replay all receipts",
            ),
            ConsumerSpec(
                durable="a2a_dlq_operator_replay",
                stream=A2A_DLQ,
                filter_subject="dharma.dlq.>",
                ack_policy="explicit",
                ack_wait_s=120,
                max_deliver=10,
                backoff_s=(),
                max_ack_pending=20,
                deliver_policy="all",
                kind="dlq_operator_replay",
                description="operator replay surface for quarantined envelopes",
            ),
        ]
    )
    return tuple(consumers)


def canonical_topology_plan(agent_uids: Iterable[str] = COUNTED_AGENT_UIDS) -> TopologyPlan:
    return TopologyPlan(
        streams=A2A_STREAM_SPECS,
        consumers=canonical_consumer_specs(agent_uids),
        migration_aliases=dict(MIGRATION_ALIASES),
    )


def acl_probe_specs(agent_uids: Iterable[str] = COUNTED_AGENT_UIDS) -> tuple[AclProbeSpec, ...]:
    specs: list[AclProbeSpec] = []
    for agent_uid in agent_uids:
        uid = safe_durable_token(agent_uid)
        inbox = f"dharma.agent.{agent_uid}.inbox"
        outbox = f"dharma.agent.{agent_uid}.outbox"
        receipt = f"dharma.a2a.receipt.{agent_uid}"
        presence = f"dharma.presence.{agent_uid}"
        reply_prefix = f"_INBOX.a2a.{agent_uid}.>"
        specs.append(
            AclProbeSpec(
                agent_uid=agent_uid,
                principal=principal_for_agent(agent_uid),
                allow_publish=(
                    presence,
                    receipt,
                    outbox,
                    reply_prefix,
                    "dharma.a2a.task.claim",
                    "dharma.a2a.task.close",
                ),
                allow_subscribe=(inbox, reply_prefix),
                allow_jetstream_pull=(f"A2A_INBOX/a2a_{uid}_inbox",),
                deny_subjects=(
                    "dharma.agent.*.inbox.>",
                    "dharma.a2a.>",
                    "_INBOX.>",
                    "$JS.API.STREAM.>",
                    "$JS.API.CONSUMER.>",
                ),
                deny_operations=(
                    "pull_other_agent_inbox",
                    "subscribe_broad_fleet_subjects",
                    "mutate_streams_or_consumers",
                    "use_insecure_tls_on_agni",
                ),
                positive_probes=(
                    "publish_own_presence",
                    "pull_own_inbox_consumer",
                    "ack_own_delivery",
                    "publish_own_receipt",
                ),
                negative_probes=(
                    "deny_pull_other_agent_inbox",
                    "deny_subscribe_broad_fleet_subjects",
                    "deny_mutate_streams_or_consumers",
                    "deny_insecure_tls_on_agni",
                ),
            )
        )
    return tuple(specs)


def verify_acl_probe_specs(
    specs: Iterable[AclProbeSpec] | None = None,
    *,
    counted_agent_uids: Iterable[str] = COUNTED_AGENT_UIDS,
) -> AclProbeVerification:
    specs = tuple(specs or acl_probe_specs(counted_agent_uids))
    expected_agents = tuple(counted_agent_uids)
    failures: list[str] = []
    by_agent = {spec.agent_uid: spec for spec in specs}
    if set(by_agent) != set(expected_agents):
        failures.append("ACL probe specs must match counted agent denominator exactly")
    principals = [spec.principal for spec in specs]
    if len(set(principals)) != len(principals):
        failures.append("ACL broker principals must be unique")

    for agent_uid in expected_agents:
        spec = by_agent.get(agent_uid)
        if spec is None:
            failures.append(f"missing ACL probe spec for {agent_uid}")
            continue
        expected_principal = principal_for_agent(agent_uid)
        if spec.principal != expected_principal:
            failures.append(f"{agent_uid} principal must be {expected_principal}")
        own_inbox = f"dharma.agent.{agent_uid}.inbox"
        own_receipt = f"dharma.a2a.receipt.{agent_uid}"
        own_presence = f"dharma.presence.{agent_uid}"
        own_consumer = f"A2A_INBOX/a2a_{safe_durable_token(agent_uid)}_inbox"
        for required in (own_presence, own_receipt):
            if required not in spec.allow_publish:
                failures.append(f"{spec.principal} missing publish allow for {required}")
        if own_inbox not in spec.allow_subscribe:
            failures.append(f"{spec.principal} missing subscribe allow for {own_inbox}")
        if own_consumer not in spec.allow_jetstream_pull:
            failures.append(f"{spec.principal} missing own durable pull allow for {own_consumer}")
        if "dharma.agent.*.inbox.>" not in spec.deny_subjects:
            failures.append(f"{spec.principal} must deny cross-agent inbox wildcard")
        if "dharma.a2a.>" not in spec.deny_subjects:
            failures.append(f"{spec.principal} must deny broad fleet subjects")
        if "$JS.API.STREAM.>" not in spec.deny_subjects or "$JS.API.CONSUMER.>" not in spec.deny_subjects:
            failures.append(f"{spec.principal} must deny stream/consumer mutation APIs")
        if "use_insecure_tls_on_agni" not in spec.deny_operations:
            failures.append(f"{spec.principal} must deny insecure TLS on Agni")
        for probe in (
            "publish_own_presence",
            "pull_own_inbox_consumer",
            "ack_own_delivery",
            "publish_own_receipt",
        ):
            if probe not in spec.positive_probes:
                failures.append(f"{spec.principal} missing positive probe {probe}")
        for probe in (
            "deny_pull_other_agent_inbox",
            "deny_subscribe_broad_fleet_subjects",
            "deny_mutate_streams_or_consumers",
            "deny_insecure_tls_on_agni",
        ):
            if probe not in spec.negative_probes:
                failures.append(f"{spec.principal} missing negative probe {probe}")

    return AclProbeVerification(
        passed=not failures,
        failures=tuple(failures),
        checked_principals=tuple(sorted(principals)),
    )


def verify_topology_plan(
    plan: TopologyPlan | None = None,
    *,
    counted_agent_uids: Iterable[str] = COUNTED_AGENT_UIDS,
) -> TopologyVerification:
    plan = plan or canonical_topology_plan(counted_agent_uids)
    failures: list[str] = []
    streams = {stream.name: stream for stream in plan.streams}
    required_streams = {A2A_INBOX, A2A_TASKS, A2A_RECEIPTS, A2A_DLQ}
    missing_streams = sorted(required_streams - set(streams))
    if missing_streams:
        failures.append("missing canonical streams: " + ", ".join(missing_streams))

    for stream in plan.streams:
        if stream.duplicate_window_s != 600:
            failures.append(f"{stream.name} duplicate window must be 600s")
        if stream.discard != "old":
            failures.append(f"{stream.name} must discard old messages under bounds")
        if stream.max_bytes <= 0 or stream.max_msgs_per_subject <= 0:
            failures.append(f"{stream.name} must have bounded max bytes and max msgs per subject")
        if not stream.subjects:
            failures.append(f"{stream.name} must declare subjects")

    consumers = {consumer.durable: consumer for consumer in plan.consumers}
    if len(consumers) != len(plan.consumers):
        failures.append("durable consumer names must be unique")
    for consumer in plan.consumers:
        if consumer.stream not in required_streams:
            failures.append(f"{consumer.durable} points at unknown stream {consumer.stream}")
        if consumer.ack_policy != "explicit":
            failures.append(f"{consumer.durable} must use explicit ack policy")
        if consumer.max_deliver == -1:
            failures.append(f"{consumer.durable} must not use unbounded MaxDeliver")
        if consumer.max_deliver <= 0:
            failures.append(f"{consumer.durable} must set positive MaxDeliver")
        if consumer.backoff_s and len(consumer.backoff_s) >= consumer.max_deliver:
            failures.append(f"{consumer.durable} backoff count must be lower than MaxDeliver")
        if consumer.backoff_s and consumer.ack_wait_s != consumer.backoff_s[0]:
            failures.append(f"{consumer.durable} ack_wait_s must match first backoff interval")
        if consumer.max_ack_pending <= 0:
            failures.append(f"{consumer.durable} must bound MaxAckPending")
        deliver_all_kinds = {
            "dlq_operator_replay",
            "receipt_indexer",
            "task_claimant",
            "task_closer",
        }
        if consumer.kind not in deliver_all_kinds and consumer.deliver_policy != "new":
            failures.append(
                f"{consumer.durable} must use DeliverNew unless explicitly replay/workqueue"
            )
        if consumer.kind in {"task_claimant", "task_closer"} and consumer.deliver_policy != "all":
            failures.append(f"{consumer.durable} must use DeliverAll on workqueue streams")

    for agent_uid in counted_agent_uids:
        durable = f"a2a_{safe_durable_token(agent_uid)}_inbox"
        consumer = consumers.get(durable)
        if consumer is None:
            failures.append(f"missing durable inbox consumer for {agent_uid}")
            continue
        expected_subject = f"dharma.agent.{agent_uid}.inbox"
        if consumer.filter_subject != expected_subject:
            failures.append(f"{durable} must filter {expected_subject}")

    for alias in ("DHARMA_A2A", "DHARMA_FLEET", "DS_A2A"):
        if alias not in plan.migration_aliases:
            failures.append(f"missing migration alias {alias}")
    if plan.migration_aliases.get("DHARMA_A2A") == "DHARMA_A2A":
        failures.append("DHARMA_A2A cannot alias to itself")
    if plan.presence_bucket != PRESENCE_BUCKET:
        failures.append("presence bucket must be PRESENCE")

    return TopologyVerification(
        passed=not failures,
        failures=tuple(failures),
        checked_streams=tuple(sorted(streams)),
        checked_consumers=tuple(sorted(consumers)),
    )


def _duration(seconds: int) -> str:
    if seconds % 86_400 == 0:
        return f"{seconds // 86_400}d"
    if seconds % 3_600 == 0:
        return f"{seconds // 3_600}h"
    if seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def _nanos(seconds: int) -> int:
    return seconds * 1_000_000_000


def consumer_config_for_nats(consumer: ConsumerSpec) -> dict[str, Any]:
    """Render a NATS consumer config with exact duration/backoff values."""

    config: dict[str, Any] = {
        "ack_policy": consumer.ack_policy,
        "ack_wait": _nanos(consumer.ack_wait_s),
        "deliver_policy": consumer.deliver_policy,
        "durable_name": consumer.durable,
        "filter_subject": consumer.filter_subject,
        "max_ack_pending": consumer.max_ack_pending,
        "max_deliver": consumer.max_deliver,
        "name": consumer.durable,
        "replay_policy": "instant",
    }
    if consumer.backoff_s:
        config["backoff"] = [_nanos(value) for value in consumer.backoff_s]
    return config


def render_nats_consumer_configs(plan: TopologyPlan | None = None) -> dict[str, dict[str, Any]]:
    plan = plan or canonical_topology_plan()
    return {
        f"{consumer.stream}/{consumer.durable}": consumer_config_for_nats(consumer)
        for consumer in plan.consumers
    }


def _shell_quote(value: object) -> str:
    text = str(value)
    return "'" + text.replace("'", "'\"'\"'") + "'"


def _cli_retention(value: str) -> str:
    return "work" if value == "workqueue" else value


def _cli_backoff_flags(values: tuple[int, ...]) -> str:
    if not values:
        return ""
    return (
        f" --backoff linear --backoff-steps {len(values)} "
        f"--backoff-min {_duration(values[0])} --backoff-max {_duration(values[-1])}"
    )


def render_nats_cli_commands(plan: TopologyPlan | None = None) -> tuple[str, ...]:
    plan = plan or canonical_topology_plan()
    commands: list[str] = []
    for stream in plan.streams:
        subjects = " ".join(f"--subjects {_shell_quote(subject)}" for subject in stream.subjects)
        commands.append(
            "nats stream add "
            f"{stream.name} {subjects} --storage {stream.storage} "
            f"--retention {_cli_retention(stream.retention)} --discard {stream.discard} "
            f"--dupe-window {_duration(stream.duplicate_window_s)} "
            f"--max-age {_duration(stream.max_age_s)} "
            f"--max-bytes {stream.max_bytes} "
            f"--max-msgs-per-subject {stream.max_msgs_per_subject} --defaults"
        )
    for consumer in plan.consumers:
        backoff = _cli_backoff_flags(consumer.backoff_s)
        commands.append(
            "nats consumer add "
            f"{consumer.stream} {consumer.durable} --pull "
            f"--filter {_shell_quote(consumer.filter_subject)} --ack {consumer.ack_policy} "
            f"--deliver {consumer.deliver_policy} --wait {_duration(consumer.ack_wait_s)} "
            f"--max-deliver {consumer.max_deliver} "
            f"--max-pending {consumer.max_ack_pending}{backoff} --defaults"
        )
    commands.append(f"nats kv add {plan.presence_bucket} --ttl 2m --history 1")
    return tuple(commands)


def _contextual(command: str, *, context: str) -> str:
    return command.replace("nats ", f"nats --context {_shell_quote(context)} ", 1)


def _subject_patterns_overlap(left: str, right: str) -> bool:
    left_tokens = left.split(".")
    right_tokens = right.split(".")

    def walk(left_index: int, right_index: int) -> bool:
        if left_index == len(left_tokens) and right_index == len(right_tokens):
            return True
        if left_index < len(left_tokens) and left_tokens[left_index] == ">":
            return True
        if right_index < len(right_tokens) and right_tokens[right_index] == ">":
            return True
        if left_index == len(left_tokens) or right_index == len(right_tokens):
            return False
        left_part = left_tokens[left_index]
        right_part = right_tokens[right_index]
        if left_part == "*" or right_part == "*" or left_part == right_part:
            return walk(left_index + 1, right_index + 1)
        return False

    return walk(0, 0)


def _stream_overlaps_observation(stream: StreamSpec, observed: LiveStreamObservation) -> bool:
    return any(
        _subject_patterns_overlap(stream_subject, observed_subject)
        for stream_subject in stream.subjects
        for observed_subject in observed.subjects
    )


def _overlaps_any(subject: str, subject_patterns: Iterable[str]) -> bool:
    return any(_subject_patterns_overlap(subject, pattern) for pattern in subject_patterns)


def _append_cutover_subject(
    subjects: list[str],
    subject: str,
    *,
    canonical_subjects: tuple[str, ...],
) -> None:
    subject = str(subject or "").strip()
    if not subject or subject in subjects:
        return
    if _overlaps_any(subject, canonical_subjects):
        return
    subjects.append(subject)


def _legacy_cutover_subjects(
    observed: LiveStreamObservation,
    consumers: Iterable[LiveConsumerObservation],
    *,
    plan: TopologyPlan,
) -> tuple[str, ...]:
    canonical_subjects = tuple(subject for stream in plan.streams for subject in stream.subjects)
    narrowed: list[str] = []
    for subject in observed.active_subjects:
        _append_cutover_subject(narrowed, subject, canonical_subjects=canonical_subjects)
    for consumer in consumers:
        if consumer.stream != observed.name:
            continue
        _append_cutover_subject(
            narrowed,
            consumer.filter_subject,
            canonical_subjects=canonical_subjects,
        )
    if not narrowed:
        for subject in observed.subjects:
            _append_cutover_subject(narrowed, subject, canonical_subjects=canonical_subjects)
    return tuple(narrowed)


def verify_live_topology_observation(
    streams: Iterable[LiveStreamObservation],
    kv_buckets: Iterable[str],
    *,
    consumers: Iterable[LiveConsumerObservation] = (),
    plan: TopologyPlan | None = None,
) -> LiveTopologyVerification:
    plan = plan or canonical_topology_plan()
    observed_streams = {stream.name: stream for stream in streams}
    observed_consumers = {
        (consumer.stream, consumer.durable): consumer
        for consumer in consumers
    }
    observed_kv_buckets = tuple(sorted(str(bucket) for bucket in kv_buckets))
    required_streams = {stream.name for stream in plan.streams}
    missing_streams = tuple(sorted(required_streams - set(observed_streams)))
    legacy_streams = tuple(sorted(name for name in observed_streams if name in MIGRATION_ALIASES))
    canonical_subjects = tuple(subject for stream in plan.streams for subject in stream.subjects)
    overlapping_subjects: list[str] = []

    for stream in observed_streams.values():
        if stream.name in required_streams:
            continue
        for observed_subject in stream.subjects:
            for canonical_subject in canonical_subjects:
                if _subject_patterns_overlap(observed_subject, canonical_subject):
                    overlapping_subjects.append(
                        f"{stream.name}:{observed_subject} overlaps canonical {canonical_subject}"
                    )
                    break

    failures: list[str] = []
    if missing_streams:
        failures.append("missing live canonical streams: " + ", ".join(missing_streams))
    if plan.presence_bucket not in observed_kv_buckets:
        failures.append(f"missing live KV bucket: {plan.presence_bucket}")
    missing_consumers: list[str] = []
    drifted_consumers: list[str] = []
    for consumer in plan.consumers:
        if consumer.stream not in observed_streams:
            continue
        consumer_key = f"{consumer.stream}/{consumer.durable}"
        observed = observed_consumers.get((consumer.stream, consumer.durable))
        if observed is None:
            missing_consumers.append(consumer_key)
            continue
        if observed.filter_subject and observed.filter_subject != consumer.filter_subject:
            drifted_consumers.append(
                f"{consumer_key} filter_subject {observed.filter_subject} != "
                f"{consumer.filter_subject}"
            )
        if observed.ack_policy and observed.ack_policy != consumer.ack_policy:
            drifted_consumers.append(
                f"{consumer_key} ack_policy {observed.ack_policy} != {consumer.ack_policy}"
            )
        if observed.deliver_policy and observed.deliver_policy != consumer.deliver_policy:
            drifted_consumers.append(
                f"{consumer_key} deliver_policy {observed.deliver_policy} != "
                f"{consumer.deliver_policy}"
            )
        if observed.ack_wait_ns is not None and observed.ack_wait_ns != _nanos(consumer.ack_wait_s):
            drifted_consumers.append(
                f"{consumer_key} ack_wait_ns {observed.ack_wait_ns} != "
                f"{_nanos(consumer.ack_wait_s)}"
            )
        if observed.max_deliver is not None and observed.max_deliver != consumer.max_deliver:
            drifted_consumers.append(
                f"{consumer_key} max_deliver {observed.max_deliver} != {consumer.max_deliver}"
            )
        expected_backoff_ns = tuple(_nanos(value) for value in consumer.backoff_s)
        if observed.backoff_ns is not None and observed.backoff_ns != expected_backoff_ns:
            drifted_consumers.append(
                f"{consumer_key} backoff_ns {observed.backoff_ns} != {expected_backoff_ns}"
            )
        if (
            observed.max_ack_pending is not None
            and observed.max_ack_pending != consumer.max_ack_pending
        ):
            drifted_consumers.append(
                f"{consumer_key} max_ack_pending {observed.max_ack_pending} != "
                f"{consumer.max_ack_pending}"
            )
    if missing_consumers:
        failures.append("missing live canonical consumers: " + ", ".join(sorted(missing_consumers)))
    if drifted_consumers:
        failures.append(
            "live canonical consumer config drift: "
            + "; ".join(sorted(dict.fromkeys(drifted_consumers)))
        )
    if overlapping_subjects:
        failures.append("live subject overlap blocks blind canonical install: " + "; ".join(overlapping_subjects))

    return LiveTopologyVerification(
        passed=not failures,
        failures=tuple(failures),
        observed_streams=tuple(sorted(observed_streams)),
        observed_consumers=tuple(
            sorted(f"{stream}/{durable}" for stream, durable in observed_consumers)
        ),
        observed_kv_buckets=observed_kv_buckets,
        missing_streams=missing_streams,
        missing_consumers=tuple(sorted(missing_consumers)),
        drifted_consumers=tuple(sorted(dict.fromkeys(drifted_consumers))),
        legacy_streams=legacy_streams,
        overlapping_subjects=tuple(sorted(overlapping_subjects)),
    )


def plan_live_topology_migration(
    streams: Iterable[LiveStreamObservation],
    kv_buckets: Iterable[str],
    *,
    consumers: Iterable[LiveConsumerObservation] = (),
    context: str = "agni-wss",
    plan: TopologyPlan | None = None,
) -> TopologyMigrationPlan:
    plan = plan or canonical_topology_plan()
    observed_streams = {stream.name: stream for stream in streams}
    observed_consumers = tuple(consumers)
    observed_consumer_keys = {
        (consumer.stream, consumer.durable)
        for consumer in observed_consumers
    }
    observed_kv_buckets = set(str(bucket) for bucket in kv_buckets)
    noncanonical_streams = [
        stream
        for stream in observed_streams.values()
        if stream.name not in {spec.name for spec in plan.streams}
    ]
    canonical_commands = {
        command.split()[3] if command.startswith("nats stream add ") else "": command
        for command in render_nats_cli_commands(plan)
    }
    steps: list[TopologyMigrationStep] = []
    blockers: list[str] = []

    for stream in plan.streams:
        if stream.name in observed_streams:
            continue
        overlaps = [
            observed.name
            for observed in noncanonical_streams
            if _stream_overlaps_observation(stream, observed)
        ]
        command = _contextual(canonical_commands.get(stream.name, ""), context=context)
        if overlaps:
            blocker = (
                f"{stream.name} subjects overlap existing live streams: "
                + ", ".join(sorted(overlaps))
            )
            blockers.append(blocker)
            steps.append(
                TopologyMigrationStep(
                    step_id=f"blocked_add_{stream.name}",
                    phase="cutover",
                    action=f"add canonical stream {stream.name}",
                    command=command,
                    mutates=True,
                    requires_approval=True,
                    blocked=True,
                    blocker=blocker,
                    rationale="cannot create overlapping JetStream subjects before legacy stream cutover",
                )
            )
        else:
            steps.append(
                TopologyMigrationStep(
                    step_id=f"add_{stream.name}",
                    phase="additive",
                    action=f"add canonical stream {stream.name}",
                    command=command,
                    mutates=True,
                    requires_approval=False,
                    blocked=False,
                    rationale="stream subjects do not overlap observed legacy streams",
                )
            )

    if plan.presence_bucket not in observed_kv_buckets:
        steps.append(
            TopologyMigrationStep(
                step_id=f"add_kv_{plan.presence_bucket}",
                phase="additive",
                action=f"add KV bucket {plan.presence_bucket}",
                command=_contextual(
                    f"nats kv add {plan.presence_bucket} --ttl 2m --history 1",
                    context=context,
                ),
                mutates=True,
                requires_approval=False,
                blocked=False,
                rationale="presence bucket is additive and does not alter stream subjects",
            )
        )

    for observed in noncanonical_streams:
        overlapping_targets = [
            stream.name
            for stream in plan.streams
            if _stream_overlaps_observation(stream, observed)
        ]
        if not overlapping_targets:
            continue
        narrowed_subjects = _legacy_cutover_subjects(observed, observed_consumers, plan=plan)
        if not narrowed_subjects:
            blocker = (
                f"{observed.name} has no non-overlapping active subjects or legacy "
                "consumer filter subjects to preserve during cutover"
            )
            blockers.append(blocker)
            steps.insert(
                0,
                TopologyMigrationStep(
                    step_id=f"blocked_cutover_{observed.name}",
                    phase="cutover",
                    action=f"narrow legacy stream {observed.name} away from canonical subjects",
                    command=_contextual(f"nats stream edit {observed.name} --force", context=context),
                    mutates=True,
                    requires_approval=True,
                    blocked=True,
                    blocker=blocker,
                    rationale="cutover must not erase the last legacy subject binding silently",
                ),
            )
            continue
        subject_flags = " ".join(f"--subjects {_shell_quote(subject)}" for subject in narrowed_subjects)
        command = (
            f"nats stream edit {observed.name} {subject_flags} --force"
            if subject_flags
            else f"nats stream edit {observed.name} --force"
        )
        steps.insert(
            0,
            TopologyMigrationStep(
                step_id=f"cutover_{observed.name}",
                phase="cutover",
                action=f"narrow legacy stream {observed.name} away from canonical subjects",
                command=_contextual(command, context=context),
                mutates=True,
                requires_approval=True,
                blocked=False,
                rationale=(
                    "required before adding overlapping canonical streams "
                    + ", ".join(sorted(overlapping_targets))
                ),
            ),
        )

    for consumer in plan.consumers:
        if (consumer.stream, consumer.durable) in observed_consumer_keys:
            continue
        stream_missing_step = next(
            (
                step
                for step in steps
                if step.step_id in {f"add_{consumer.stream}", f"blocked_add_{consumer.stream}"}
            ),
            None,
        )
        blocked = bool(stream_missing_step and stream_missing_step.blocked)
        phase = "cutover" if blocked or consumer.stream in {A2A_TASKS, A2A_RECEIPTS} else "additive"
        blocker = (
            f"consumer {consumer.durable} waits for canonical stream {consumer.stream}"
            if blocked
            else ""
        )
        if blocker:
            blockers.append(blocker)
        backoff = _cli_backoff_flags(consumer.backoff_s)
        command = (
            "nats consumer add "
            f"{consumer.stream} {consumer.durable} --pull "
            f"--filter {_shell_quote(consumer.filter_subject)} --ack {consumer.ack_policy} "
            f"--deliver {consumer.deliver_policy} --wait {_duration(consumer.ack_wait_s)} "
            f"--max-deliver {consumer.max_deliver} --max-pending {consumer.max_ack_pending}"
            f"{backoff} --defaults"
        )
        steps.append(
            TopologyMigrationStep(
                step_id=f"add_consumer_{consumer.durable}",
                phase=phase,
                action=f"add durable consumer {consumer.durable}",
                command=_contextual(command, context=context),
                mutates=True,
                requires_approval=phase == "cutover",
                blocked=blocked,
                blocker=blocker,
                rationale=f"consumer binds canonical stream {consumer.stream}",
            )
        )

    additive_steps = [step for step in steps if step.phase == "additive"]
    cutover_steps = [step for step in steps if step.phase == "cutover"]
    return TopologyMigrationPlan(
        strategy="additive-first-then-approved-cutover",
        can_apply_additive=bool(additive_steps) and all(not step.blocked for step in additive_steps),
        can_apply_cutover=bool(cutover_steps) and not blockers,
        blockers=tuple(dict.fromkeys(blockers)),
        steps=tuple(steps),
    )


async def install_topology(jetstream: Any, plan: TopologyPlan | None = None) -> dict[str, Any]:
    """Apply the topology to an injected JetStream-like admin client.

    The live NATS client type differs by version, so the installer uses a small
    duck-typed surface in tests and local adapters: ``add_stream`` and
    ``add_consumer`` receive plain dictionaries.
    """

    plan = plan or canonical_topology_plan()
    verification = verify_topology_plan(plan)
    if not verification.passed:
        return {
            "schema_version": "dharma.a2a.jetstream_topology_install.v1",
            "installed": False,
            "failures": list(verification.failures),
            "streams": [],
            "consumers": [],
        }
    installed_streams: list[str] = []
    installed_consumers: list[str] = []
    for stream in plan.streams:
        await jetstream.add_stream(stream.to_dict())
        installed_streams.append(stream.name)
    for consumer in plan.consumers:
        await jetstream.add_consumer(consumer.stream, consumer_config_for_nats(consumer))
        installed_consumers.append(consumer.durable)
    return {
        "schema_version": "dharma.a2a.jetstream_topology_install.v1",
        "installed": True,
        "streams": installed_streams,
        "consumers": installed_consumers,
        "presence_bucket": plan.presence_bucket,
    }


def with_replaced_consumer(plan: TopologyPlan, durable: str, **updates: Any) -> TopologyPlan:
    """Test helper for adversarial verifier cases."""

    consumers = tuple(
        replace(consumer, **updates) if consumer.durable == durable else consumer
        for consumer in plan.consumers
    )
    return replace(plan, consumers=consumers)
