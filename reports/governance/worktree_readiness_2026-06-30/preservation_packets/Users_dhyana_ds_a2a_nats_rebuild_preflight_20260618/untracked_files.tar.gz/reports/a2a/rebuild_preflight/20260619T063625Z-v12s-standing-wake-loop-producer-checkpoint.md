# v12s Standing Wake-Loop Producer Checkpoint

Timestamp: 2026-06-19T06:36:25Z

## Scope

- Added `scripts/runtime/a2a_standing_wake_loop.py`, the gated runtime producer
  for `StandingWakeLoop`, `WakeLease`, and `WakeCircuitBreaker` evidence.
- Added `tests/test_a2a_standing_wake_loop.py`.
- Added `make a2a-standing-wake-loop` and included the new tests in
  `make nats-substrate-contract`.
- Added `start_standing_wake_loop` to `a2a_onboard.py` operator command bundles.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py` so the standing
  wake-loop producer is part of the guarded A2A/NATS contract.

## Runtime Guard

The producer writes `dharma.a2a.standing_wake_loop_heartbeat.v1` heartbeats
under `~/.dharma/a2a_bus/worker_heartbeats/<agent>.json` only when:

- `A2A_STANDING_WAKE_LOOP_AGENT` equals the target `agent_uid`;
- the registry identity exists;
- the target is not session scoped or `external_worker_evidence_only`;
- the circuit breaker is closed.

Failure writes a red `dharma.a2a.standing_wake_loop_receipt.v1` receipt rather
than a promoted heartbeat.

## Receipts

- Dry-run standing wake-loop producer:
  `reports/a2a/standing_wake_loop/20260619T063534_797898Z-hermes-m5-standing-wake-loop.json`
  - `status=DRY_RUN_VALIDATED`
  - `wrote_heartbeat=false`
  - `owner_gate_satisfied=true`
  - `session_scoped=false`
- Wake-loop preflight:
  `reports/a2a/wake_loop_preflight/20260619T063542_959936Z-a2a-wake-loop-preflight.json`
- Aggregate readiness:
  `reports/a2a/full_spec_readiness/20260619T063546_472248Z-a2a-full-spec-readiness.json`

## Current Aggregate Readiness

Readiness remains `15/100`, fail-closed:

- `live_topology`: red
- `cutover_completion`: red
- `acl_probe_contract`: green
- `wake_loop_preflight`: red
- `counted_agent_readiness`: red

The score did not increase because the standing wake-loop run was a dry-run and
did not mutate live worker heartbeat state.

## Verification

- Focused tests:
  `uv run pytest -q tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_onboard.py --tb=short`
  - `13 passed`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `125 passed`
- Broad regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `261 passed`, one existing FastAPI/Starlette deprecation warning.
- `python3 -m compileall -q ...`
  - passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `git diff --check`
  - passed
- Context+ static analysis on `scripts/runtime/a2a_standing_wake_loop.py`
  - no issues found
- `uv.lock` was reverted after `uv run` churn.

## Remaining 100/100 Gates

- Explicit approval and execution for canonical live topology cutover.
- Explicit approval and execution for live ACL probes.
- Real target-owned standing wake-loop heartbeats for counted agents, not
  dry-run receipts.
- Per-counted-agent target-owned domain receipts.
- Per-counted-agent current semantic receipts for the locked spec.
- Removal or replacement of session-scoped/evidence-only counted agents before
  they can satisfy standing-agent readiness.
