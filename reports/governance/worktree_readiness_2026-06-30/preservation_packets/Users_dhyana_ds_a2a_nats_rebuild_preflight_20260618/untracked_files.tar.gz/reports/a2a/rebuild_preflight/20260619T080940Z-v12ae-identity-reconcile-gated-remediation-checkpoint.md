# v12ae Identity Reconcile Gated Remediation Checkpoint

## Scope

- Added `scripts/governance/a2a_identity_reconcile.py`.
- Added `make a2a-identity-reconcile`.
- Added receipt schema `dharma.a2a.identity_reconcile.v1`.
- Added approval gate `A2A_IDENTITY_RECONCILE=approved-identity-reconcile` for `--write-registry`.
- Kept dry-run as default and did not mutate `~/.dharma/a2a_bus/agents.json`.
- Reconciler plans only alias removals from the selected counted agent when the alias is already a top-level registry UID or another counted UID.
- Reconciler does not delete registry entries, rename agents, claim target-owned output, or fabricate presence/model evidence.
- Added identity reconciliation operator commands to onboard and presence-preflight rows.
- Added identity reconciliation receipt evidence to the aggregate `identity_presence` readiness component.
- Updated `NATS_SUBSTRATE_MASTER_SPEC.md` and `check_nats_substrate_contract.py`.
- Added `tests/test_a2a_identity_reconcile.py` and full-spec evidence-path coverage.

## Runtime Truth

- Dry-run identity reconcile receipt: `reports/a2a/identity_reconcile/20260619T080703_233940Z-a2a-identity-reconcile.json`.
- The receipt found one registry identity collision:
  - `opus_composer` alias `claude-opus` maps to both top-level `claude-opus` and `opus_composer`.
- Proposed gated remediation:
  - remove alias `claude-opus` from `opus_composer.aliases`;
  - keep top-level `claude-opus` registry entry intact.
- `mutation_performed=false`; registry hash before and after was unchanged.
- Refreshed readiness receipt: `reports/a2a/full_spec_readiness/20260619T080930_702432Z-a2a-full-spec-readiness.json`.
- Prevalidate readiness remains 25/100.

## Verification

- `uv run pytest -q tests/test_a2a_identity_reconcile.py tests/test_a2a_presence_preflight.py tests/test_a2a_onboard.py --tb=short` -> 16 passed.
- `uv run pytest -q tests/test_a2a_identity_reconcile.py tests/test_a2a_full_spec_readiness.py --tb=short` -> 13 passed.
- `python3 -m compileall -q scripts/governance/a2a_identity_reconcile.py scripts/governance/a2a_full_spec_readiness.py scripts/governance/a2a_presence_preflight.py scripts/governance/a2a_onboard.py scripts/governance/check_nats_substrate_contract.py` -> clean.
- `uv run ruff check ... --select=F821,F401,F541` on touched governance/tests -> clean.
- `PYTHONPATH=. python3 scripts/governance/check_nats_substrate_contract.py` -> `NATS_CONTRACT_OK`.
- `make lint-blockers` -> clean.
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short` -> 338 passed, 1 existing Starlette/httpx warning.
- `make nats-substrate-contract` -> 152 passed.
- `uv.lock` churn from `uv run` reverted.

## Remaining Blockers

- `qwen_code` presence evidence remains stale/expired.
- `opus_composer` alias collision remains until the gated registry write is explicitly approved and run.
- Live topology still lacks `A2A_TASKS` and `A2A_RECEIPTS`.
- Legacy `DHARMA_A2A` still overlaps canonical subject space.
- Actual live cutover requires explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Actual live ACL probe execution requires explicit `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`.
- Counted agents still lack target-owned domain reply artifacts and current `SEMANTIC_SIGNED` evidence.
- Wake-loop readiness remains red for standing target-owned semantic loops.
