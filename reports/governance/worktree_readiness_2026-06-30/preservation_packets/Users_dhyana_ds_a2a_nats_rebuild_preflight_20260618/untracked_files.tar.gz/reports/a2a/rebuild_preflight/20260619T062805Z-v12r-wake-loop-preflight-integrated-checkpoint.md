# v12r Wake-Loop Preflight Integrated Checkpoint

Timestamp: 2026-06-19T06:28:05Z

## Scope

- Added the non-mutating wake-loop preflight producer:
  `scripts/governance/a2a_wake_loop_preflight.py`
- Added focused tests:
  `tests/test_a2a_wake_loop_preflight.py`
- Wired `make a2a-wake-loop-preflight` and included the tests in
  `make nats-substrate-contract`.
- Added wake-loop operator commands to `scripts/governance/a2a_onboard.py`.
- Integrated wake-loop preflight into the aggregate 100/100 readiness gate in
  `scripts/governance/a2a_full_spec_readiness.py`.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py` so the contract guards
  the new aggregate wake-loop requirement.

## Receipts

- Wake-loop preflight:
  `reports/a2a/wake_loop_preflight/20260619T062726_850490Z-a2a-wake-loop-preflight.json`
- Aggregate readiness:
  `reports/a2a/full_spec_readiness/20260619T062731_308212Z-a2a-full-spec-readiness.json`
- Prior non-mutating live topology cutover packet:
  `reports/a2a/live_topology/20260619T061413Z-a2a-live-topology-probe.json`

## Current Aggregate Readiness

Readiness remains `15/100`, fail-closed:

- `live_topology`: red; `A2A_RECEIPTS` and `A2A_TASKS` are absent, and
  `DHARMA_A2A` still overlaps canonical subject space.
- `cutover_completion`: red; live mutation still requires
  `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- `acl_probe_contract`: green; offline per-agent ACL probe contract is present.
- `wake_loop_preflight`: red; counted agents lack standing-loop, wake-lease,
  and circuit-breaker evidence. Several agents remain session scoped and/or
  missing target-owned domain and semantic receipts.
- `counted_agent_readiness`: red; counted agents are not all
  `READY_PREVALIDATED`.

## Wake-Loop Findings

- `codex_composer`: `DEGRADED_SESSION_SCOPED`; missing `StandingWakeLoop`,
  `WakeLease`, and `WakeCircuitBreaker`.
- `devin-roaming-2987d222`: `DEGRADED_SESSION_SCOPED`; missing target-owned
  domain receipt, semantic receipt, `StandingWakeLoop`, `WakeLease`, and
  `WakeCircuitBreaker`.
- `hermes-m5`: `BLOCKED_WAKE_LOOP`; missing target-owned domain receipt,
  semantic receipt, `StandingWakeLoop`, `WakeLease`, and `WakeCircuitBreaker`.
- `qwen_code`: `BLOCKED_WAKE_LOOP`; also session scoped and missing target-owned
  domain receipt, semantic receipt, `StandingWakeLoop`, `WakeLease`, and
  `WakeCircuitBreaker`.
- `opus_composer`: `DEGRADED_SESSION_SCOPED`; missing target-owned domain
  receipt, semantic receipt, `StandingWakeLoop`, `WakeLease`, and
  `WakeCircuitBreaker`.

## Verification

- `uv run pytest -q tests/test_a2a_full_spec_readiness.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_onboard.py --tb=short`
  - `17 passed`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `122 passed`
- Broad regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `258 passed`, one existing FastAPI/Starlette deprecation warning.
- `python3 -m compileall -q ...`
  - passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `git diff --check`
  - passed
- Context+ static analysis on `scripts/governance/a2a_full_spec_readiness.py`
  - no issues found

## Remaining 100/100 Gates

Actual 100/100 still requires externally approved live action/evidence:

- canonical live topology cutover approval and execution;
- live ACL probe execution approval and passing receipt;
- standing semantic wake loops with wake leases and circuit breakers;
- per-counted-agent target-owned domain receipts;
- per-counted-agent current semantic receipts for the locked spec;
- all counted agents promoted out of session-scoped/blocker states.
