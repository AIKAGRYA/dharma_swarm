# v12ac Identity Presence Preflight Gate Checkpoint

## Summary

Added a read-only identity/presence preflight and wired it into the A2A/NATS full-spec readiness gate.

The rebuild remains **25/100** in prevalidate mode and **10/100** in live mode. This is expected: the previously green components stay green, and presence now fails closed instead of allowing bridge heartbeats or stale registry timestamps to stand in for fresh KV/projection presence.

## Implementation

- Added `scripts/governance/a2a_presence_preflight.py`.
- Added `make a2a-presence-preflight`.
- Added `identity_presence` to `scripts/governance/a2a_full_spec_readiness.py`.
- Kept the readiness total at 100 by moving `live_topology` from 35 to 30 points.
- Updated `make a2a-onboard` operator commands to include the presence preflight.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- Updated `scripts/governance/check_nats_substrate_contract.py`.
- Added `tests/test_a2a_presence_preflight.py`.
- Updated readiness and onboard tests for the new gate.

## Receipts

- Presence preflight: `reports/a2a/presence_preflight/20260619T074603_298852Z-a2a-presence-preflight.json`
- Prevalidate readiness: `reports/a2a/full_spec_readiness/20260619T074603_303203Z-a2a-full-spec-readiness.json`
- Live readiness: `reports/a2a/full_spec_readiness/20260619T074608_366926Z-a2a-full-spec-readiness.json`

## Verification

- `uv run pytest -q tests/test_a2a_presence_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py --tb=short` => 20 passed
- `make nats-substrate-contract` => 143 passed
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short` => 329 passed, 1 existing FastAPI/Starlette warning
- `.venv/bin/python -m compileall -q ...` on touched Python files => clean
- `uv run ruff check ... --select=F821,F401,F541` => clean
- `make lint-blockers` => clean

## Current Presence Findings

- Counted bridge heartbeat files exist for several agents, but they do not satisfy the required presence projection schema.
- `qwen_code` has no presence projection.
- `opus_composer` has an alias collision on `claude-opus`.
- All counted agents lack required non-expired `expires_at` presence proof.
- All counted agents lack boolean `peer_model_processed_claim` in the presence projection.

## Remaining Blockers

- Live topology still lacks `A2A_TASKS` and `A2A_RECEIPTS`.
- Legacy `DHARMA_A2A` still owns canonical subject space.
- Actual topology cutover requires explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover` approval.
- Live ACL execution requires explicit `A2A_LIVE_ACL_PROBE=approved-live-acl-probe` approval.
- All five counted agents are missing target-owned `dharma.a2a.domain_reply_artifact.v1` artifacts.
- Wake-loop and counted-agent readiness remain red because standing target-owned domain/semantic evidence is absent.
