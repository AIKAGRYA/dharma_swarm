# v12ag Domain Reply Request Checkpoint

Timestamp: 2026-06-19T08:26:54Z

## Scope

Implemented a receipt-backed domain reply request workflow for the full-spec A2A/NATS readiness gate.

This slice adds:

- `scripts/governance/a2a_domain_reply_request.py`
- `make a2a-domain-reply-request`
- operator command surfacing from `make a2a-onboard`
- contract/spec wiring in `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- readiness evidence inclusion for domain reply request receipts
- focused tests in `tests/test_a2a_domain_reply_request.py`

## Boundary

The request workflow writes only under:

- `reports/a2a/domain_reply_requests/`

It does not write target outboxes, does not create target-owned artifacts, and does not satisfy the domain-reply artifact readiness component by itself.

The request receipt sets:

- `schema_version=dharma.a2a.domain_reply_request.v1`
- `target_outbox_mutation_performed=false`
- row-level `target_owned_write_required=true`

## Current Receipts

Domain reply request:

- `reports/a2a/domain_reply_requests/20260619T082552_894176Z-a2a-domain-reply-request.json`

Full-spec readiness refresh:

- `reports/a2a/full_spec_readiness/20260619T082559_173848Z-a2a-full-spec-readiness.json`

## Current Readiness

Score remains `25/100`.

The new request receipt is cited under the `domain_reply_artifacts` component evidence paths, but the component remains red because actual target-owned `dharma.a2a.domain_reply_artifact.v1` artifacts are still missing for all counted agents.

## Verification

Passed:

- `uv run pytest -q tests/test_a2a_domain_reply_request.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py --tb=short`
- `python3 -m compileall -q scripts/governance/a2a_domain_reply_request.py scripts/governance/a2a_full_spec_readiness.py scripts/governance/a2a_onboard.py tests/test_a2a_domain_reply_request.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py scripts/governance/check_nats_substrate_contract.py`
- `uv run ruff check scripts/governance/a2a_domain_reply_request.py scripts/governance/a2a_full_spec_readiness.py scripts/governance/a2a_onboard.py tests/test_a2a_domain_reply_request.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py scripts/governance/check_nats_substrate_contract.py --select=F821,F401,F541`
- `PYTHONPATH=. python3 scripts/governance/check_nats_substrate_contract.py`
- `make lint-blockers`
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short`
- `make nats-substrate-contract`

Expected red:

- `make a2a-full-spec-readiness AGENT=all MODE=prevalidate ARGS='--json'` exits nonzero because readiness remains honestly blocked.

## Remaining Blockers

- live topology cutover remains gated by `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`
- actual live ACL execution remains gated by `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`
- qwen presence is stale/expired
- `opus_composer` alias collision remains unresolved
- target-owned domain reply artifacts are missing for all counted agents
- target-owned `DOMAIN_RECEIPTED` and current `SEMANTIC_SIGNED` evidence are missing for counted agents
- standing wake-loop evidence is still missing or session-scoped
