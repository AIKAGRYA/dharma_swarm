# v12p Onboard Command Bundle Checkpoint

Timestamp: 2026-06-19T06:12:14Z

## Scope

This slice closed a remaining local spec-compliance gap in `make a2a-onboard`.
The locked v12 spec requires the onboarding command to tell a new agent exactly
how to connect, which subject/consumer to use, how to prove presence, and how
to leave domain and semantic signoff evidence.

Updated:

- `scripts/governance/a2a_onboard.py`
- `tests/test_a2a_onboard.py`
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `scripts/governance/check_nats_substrate_contract.py`

## Result

Each onboard row now carries an `operator_commands` bundle with non-secret
commands/instructions for:

- JSON onboard refresh
- durable consumer verification
- presence publish
- hot-contact send through `scripts/runtime/a2a_send.py --route agent-inbox`
- reply capture through `scripts/runtime/a2a_reply_capture.py --send-receipt`
- target-owned domain receipt publish through
  `scripts/runtime/a2a_domain_reply_worker.py --send-receipt`
- semantic receipt creation with locked spec hash and source hash requirements
- gated live ACL proof through `make a2a-live-acl-probe`

The refreshed full-spec readiness receipt remains red by design:

- `reports/a2a/full_spec_readiness/20260619T061149_737571Z-a2a-full-spec-readiness.json`
- Score: `15/100`

The readiness evidence now points at an onboard receipt whose rows include the
command bundle:

- `reports/a2a/onboard_receipts/20260619T061052.469031Z-a2a_onboard_20260619T061052_469031Z_b641d666.json`

## Verification

Passed:

- `python3 -m compileall -q scripts/governance/a2a_onboard.py tests/test_a2a_onboard.py scripts/governance/check_nats_substrate_contract.py`
- `uv run pytest -q tests/test_a2a_onboard.py --tb=short` -> 7 passed
- `python3 scripts/governance/check_nats_substrate_contract.py` -> `NATS_CONTRACT_OK`
- `make a2a-onboard AGENT=codex_composer BROKER=agni MODE=prevalidate` -> expected nonzero `DEGRADED_SESSION_SCOPED`, command bundle printed
- `make nats-substrate-contract PYTEST='uv run pytest'` -> 119 passed
- Context+ static analysis on `a2a_onboard.py` and the contract checker -> clean
- Broad A2A/runtime suite -> 255 passed, 1 Starlette deprecation warning
- `make a2a-full-spec-readiness ARGS='--run-topology --run-onboard --run-live-probe --run-live-acl-probe'` -> expected red receipt with command-bearing onboard evidence
- `git diff --check` -> clean

`uv.lock` churn from `uv run` was reverted.

## Remaining Live Blockers

- `DHARMA_A2A` still owns `dharma.a2a.>` and overlaps canonical task subjects.
- `A2A_TASKS` and `A2A_RECEIPTS` are not live-observed canonical streams.
- Actual cutover still requires explicit
  `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Live ACL execution still requires explicit
  `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`.
- Counted non-Codex seats still need target-owned domain receipts and current
  semantic receipts.
- Session-scoped and wake-loop blockers remain, including `qwen_code`.
