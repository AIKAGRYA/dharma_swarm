# A2A/NATS Rebuild Checkpoint: Proof-Tier Boundary Hardening

Timestamp: 2026-06-19T04:52:37Z

## What Changed

- `a2a_onboard.py` no longer counts its own `reports/a2a/domain_receipts/` verifier rows as agent `DOMAIN_RECEIPTED` evidence.
- Agent domain evidence now comes only from target-owned domain reply publish receipts and captured reply-subject receipts.
- Semantic receipt validation now recomputes `source_artifact_sha256` from `source_artifact_path` when present.
- The NATS substrate contract checker now guards against both regressions.
- `NATS_SUBSTRATE_MASTER_SPEC.md` now states the evaluator/domain receipt boundary and recomputable semantic-source rule.

## Corrected Live State

Latest onboard run: `a2a_onboard_20260619T045207.616846Z_e4a4e025`

- `codex_composer`: `DOMAIN_RECEIPTED`, `SEMANTIC_SIGNED`, still `DEGRADED_SESSION_SCOPED`.
- `devin-roaming-2987d222`: `DEGRADED_SESSION_SCOPED`, `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.
- `hermes-m5`: `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.
- `qwen_code`: `BLOCKED_WAKE_LOOP`, `DEGRADED_SESSION_SCOPED`, `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.
- `opus_composer`: `DEGRADED_SESSION_SCOPED`, `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.

The previous onboard rows that showed `DOMAIN_RECEIPTED` for all seats were false-green by evaluator self-counting. The corrected gate preserves the distinction between evaluator receipts and target-agent domain effects.

## Current Score

- Local/offline implementation: 98/100, stricter than before.
- Live full-spec implementation: 91/100 after removing false domain-evidence credit.

## Remaining Live Blockers

- Legacy `DHARMA_A2A` still owns `dharma.a2a.>`, blocking safe install of `A2A_TASKS` and `A2A_RECEIPTS` without approved cutover/narrowing.
- Four non-Codex seats still need target-owned domain reply receipts.
- Four non-Codex seats still need model-processed `SEMANTIC_SIGNED` receipts for the locked spec.
- Session-scoped seats still need standing wake-loop promotion or an explicit denominator ruling.
- `qwen_code` still lacks handler ACK and a receipt-producing wake loop.
- Live ACL probes and final Mac-to-Agni semantic roundtrip proof remain incomplete.

## Verification

- `uv run pytest -q tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py --tb=short` -> 13 passed.
- `python3 scripts/governance/check_nats_substrate_contract.py` -> `NATS_CONTRACT_OK`.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short` -> 231 passed, 1 FastAPI/Starlette warning.
- `make nats-substrate-contract PYTEST='uv run pytest'` -> `NATS_CONTRACT_OK`, 95 passed.
- `python3 -m compileall -q scripts/runtime scripts/governance dharma_swarm/a2a` -> passed.
- `git diff --check` -> passed.
