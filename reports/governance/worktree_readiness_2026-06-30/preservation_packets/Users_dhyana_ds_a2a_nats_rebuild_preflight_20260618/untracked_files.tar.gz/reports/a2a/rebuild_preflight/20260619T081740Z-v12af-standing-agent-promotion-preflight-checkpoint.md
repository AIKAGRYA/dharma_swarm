# v12af Standing-Agent Promotion Preflight Checkpoint

## Scope

- Added `scripts/governance/a2a_standing_agent_preflight.py`.
- Added `make a2a-standing-agent-preflight`.
- Added receipt schema `dharma.a2a.standing_agent_preflight.v1`.
- Kept the tool read-only: it does not edit registry state, start wake loops, write heartbeats, or fabricate target-owned domain/semantic evidence.
- Added standing-agent promotion commands to onboard rows.
- Added standing-agent preflight evidence to the aggregate `wake_loop_preflight` readiness component.
- Updated `NATS_SUBSTRATE_MASTER_SPEC.md` and `check_nats_substrate_contract.py`.
- Added `tests/test_a2a_standing_agent_preflight.py` and full-spec evidence-path coverage.

## Runtime Truth

- Standing-agent preflight receipt: `reports/a2a/standing_agent_preflight/20260619T081709_777717Z-a2a-standing-agent-preflight.json`.
- Refreshed readiness receipt: `reports/a2a/full_spec_readiness/20260619T081732_767051Z-a2a-full-spec-readiness.json`.
- Prevalidate readiness remains 25/100.
- The aggregate `wake_loop_preflight` component now cites both:
  - `reports/a2a/wake_loop_preflight/20260619T064728_732708Z-a2a-wake-loop-preflight.json`
  - `reports/a2a/standing_agent_preflight/20260619T081709_777717Z-a2a-standing-agent-preflight.json`

## Standing-Agent Findings

- `codex_composer`: session/evidence scoped; missing current `SEMANTIC_SIGNED`.
- `devin-roaming-2987d222`: session/evidence scoped; missing standing wake-loop heartbeat; missing target-owned `DOMAIN_RECEIPTED`; missing current `SEMANTIC_SIGNED`.
- `hermes-m5`: missing standing wake-loop heartbeat; missing target-owned `DOMAIN_RECEIPTED`; missing current `SEMANTIC_SIGNED`.
- `qwen_code`: session/evidence scoped; dispatch disabled; missing standing wake-loop heartbeat; missing target-owned `DOMAIN_RECEIPTED`; missing current `SEMANTIC_SIGNED`.
- `opus_composer`: session/evidence scoped; missing standing wake-loop heartbeat; missing target-owned `DOMAIN_RECEIPTED`; missing current `SEMANTIC_SIGNED`.

## Verification

- `uv run pytest -q tests/test_a2a_standing_agent_preflight.py tests/test_a2a_onboard.py tests/test_a2a_full_spec_readiness.py --tb=short` -> 20 passed.
- `python3 -m compileall -q scripts/governance/a2a_standing_agent_preflight.py scripts/governance/a2a_full_spec_readiness.py scripts/governance/a2a_onboard.py scripts/governance/check_nats_substrate_contract.py` -> clean.
- `uv run ruff check ... --select=F821,F401,F541` on touched governance/tests -> clean.
- `PYTHONPATH=. python3 scripts/governance/check_nats_substrate_contract.py` -> `NATS_CONTRACT_OK`.
- `make lint-blockers` -> clean.
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short` -> 341 passed, 1 existing Starlette/httpx warning.
- `make nats-substrate-contract` -> 155 passed.
- `uv.lock` churn from `uv run` reverted.

## Remaining Blockers

- `qwen_code` presence evidence remains stale/expired.
- `opus_composer` alias collision remains until the gated registry write is explicitly approved and run.
- Live topology still lacks `A2A_TASKS` and `A2A_RECEIPTS`.
- Legacy `DHARMA_A2A` still overlaps canonical subject space.
- Actual live cutover requires explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Actual live ACL probe execution requires explicit `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`.
- Counted agents still lack target-owned domain reply artifacts and current `SEMANTIC_SIGNED` evidence.
- Wake-loop readiness remains red until standing target-owned semantic loop evidence exists.
