# A2A/NATS Full Spec Checkpoint - 2026-06-19T09:53:24Z

## Current Score

- Readiness score: 30/100
- Full spec ready: false
- Latest full-readiness receipt: `reports/a2a/full_spec_readiness/20260619T095301_938071Z-a2a-full-spec-readiness.json`
- Latest cutover dry-run/live-topology receipt: `reports/a2a/live_topology/20260619T095222Z-a2a-live-topology-probe.json`
- Latest offline topology receipt: `reports/a2a/topology/20260619T095301_922748Z-a2a-jetstream-topology.json`

## Work Completed

- Ran the non-mutating live topology cutover dry-run:
  - Command shape: `make a2a-live-topology ARGS='--cutover-topology --dry-run-cutover --json --timeout-s 20'`
  - Result: expected nonzero overall because live topology is still not cut over.
  - Cutover dry-run step `cutover_DHARMA_A2A` passed under dry-run semantics.
  - Dry-run detected the intended diff from broad `dharma.a2a.>` to preserved non-overlapping legacy subjects.
  - Rollback command is present for restoring `DHARMA_A2A` to `dharma.a2a.>`.
  - `mutation_performed=false`.
- Refreshed full readiness against the dry-run evidence:
  - `reports/a2a/full_spec_readiness/20260619T095301_938071Z-a2a-full-spec-readiness.json`
  - Score remains 30/100.
- Attempted to request approval for the real live cutover command:
  - `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover make a2a-live-topology ARGS='--cutover-topology --json --timeout-s 20'`
  - The safety reviewer rejected the attempt because there is no explicit user authorization for that exact shared-service mutation.
  - No live cutover was run and no workaround was attempted.

## Current Live Topology State

- `A2A_INBOX` is live.
- `A2A_DLQ` is live.
- `A2A_TASKS` is still absent.
- `A2A_RECEIPTS` is still absent.
- `DHARMA_A2A` is still live with broad `dharma.a2a.>` and overlaps canonical task/receipt subjects.
- The dry-run proves the planned legacy narrowing is mechanically valid, but the score cannot move until the live mutation is explicitly approved and executed.

## Remaining 100/100 Blockers

- Live cutover requires explicit user authorization for the exact Agni JetStream mutation.
- Devin target model capture remains blocked by the model rate limit; latest known reset was after 12:22 UTC.
- Opus target model capture remains blocked by Claude credit.
- Codex and Qwen wake-loop evidence remains session/evidence-scoped and cannot be promoted honestly from this Codex session.
- Devin and Opus still lack target-owned domain reply artifacts, domain receipts, semantic receipts, and standing wake-loop evidence.

## Verification

- `make nats-substrate-contract`
  - Result: `NATS_CONTRACT_OK`; 172 tests passed
- `make lint-blockers`
  - Result: OK, no undefined names
- `make a2a-full-spec-readiness AGENT=all MODE=prevalidate ARGS='--run-topology --json'`
  - Result: expected nonzero because full spec is not ready; wrote `reports/a2a/full_spec_readiness/20260619T095301_938071Z-a2a-full-spec-readiness.json` with score 30/100

