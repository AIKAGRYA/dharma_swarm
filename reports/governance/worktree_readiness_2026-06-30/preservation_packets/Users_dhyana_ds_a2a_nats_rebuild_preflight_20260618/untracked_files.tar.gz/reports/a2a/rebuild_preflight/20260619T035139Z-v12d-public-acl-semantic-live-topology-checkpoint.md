# V12d Public A2A / ACL / Semantic Gate / Live Topology Checkpoint

timestamp: 2026-06-19T03:51:39Z
branch: runtime-truth/nats-rebuild-preflight-20260618
worktree: /Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618
locked_spec: docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md

## Score

- Local/offline V12 implementation surface: 96/100.
- Full live 100/100 target: 82/100.

The repo-local implementation and verifier spine are now green for public A2A,
canonical topology rendering, ACL probe specs, semantic receipt validation, and
onboard fail-closed behavior. Full live readiness is still blocked by observed
Agni topology drift and missing per-seat semantic/wake evidence.

## Completed In This Pass

- Implemented public A2A gateway routes:
  - `GET /.well-known/agent-card.json` public serializer.
  - `POST /message:send`.
  - `POST /message:stream`.
  - Public task/card field names and `canceled` spelling at the HTTP boundary.
- Added canonical ACL probe specs:
  - principal form `a2a_<agent_uid>`;
  - positive probes for own presence, own durable pull, ACK, own receipt;
  - negative probes for cross-agent inbox pull, broad fleet subscribe, stream
    mutation APIs, and insecure Agni TLS.
- Hardened onboard semantic readiness:
  - file presence no longer proves `SEMANTIC_SIGNED`;
  - A2A semantic receipts must match agent UID, current locked spec hash, task
    hash, model identity, semantic claims, confidence, evidence refs, and a
    recomputable source/domain hash.
- Added read-only live topology drift probe:
  - `make a2a-live-topology`;
  - receipt schema `dharma.a2a.live_topology_probe.v1`;
  - `mutation_performed=false`;
  - detects legacy wildcard subject overlap before any install attempt.
- Wove the above into `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py`.

## Evidence

- Static/governance:
  - `python3 scripts/governance/check_nats_substrate_contract.py` -> OK.
  - `make nats-substrate-contract PYTEST='uv run pytest'` -> 82 passed.
- Focused regression:
  - A2A/NATS/public/semantic suite -> 174 passed, 1 warning.
  - `python3 -m compileall -q dharma_swarm/a2a scripts/governance scripts/runtime` -> passed.
  - `git diff --check` -> passed.
- Topology receipts:
  - `reports/a2a/topology/20260619T034238Z-a2a-jetstream-topology.json`
    has canonical streams, consumers, and ACL probes with `passed=true`.
  - `reports/a2a/live_topology/20260619T035019Z-a2a-live-topology-probe.json`
    has `passed=false`, `mutation_performed=false`, and concrete live drift
    blockers.
- Onboard receipts:
  - `reports/a2a/onboard_receipts/20260619T034626.041020Z-a2a_onboard_20260619T034626_041020Z_9007518e.json`
    prevalidate with `NATS_CONTEXT=agni-wss`.
  - `reports/a2a/onboard_receipts/20260619T034632.803578Z-a2a_onboard_20260619T034632_803578Z_c4cb14d7.json`
    live mode with `A2A_LIVE_OPERATOR_APPROVAL=approved-a2a-live`.

## Remaining 18 Points To 100 Live

- Agni live topology is not canonical:
  - missing `A2A_INBOX`, `A2A_TASKS`, `A2A_RECEIPTS`, `A2A_DLQ`;
  - missing `PRESENCE`;
  - legacy `DHARMA_A2A` still owns `dharma.a2a.>`;
  - that wildcard overlaps canonical `dharma.a2a.task.*`, so blind stream
    install is blocked.
- Live per-agent ACLs are rendered and verifier-checked offline, but not
  installed/probed against scoped per-agent credentials.
- `make a2a-onboard` remains fail-closed:
  - `codex_composer`, `devin-roaming-2987d222`, and `opus_composer` are still
    session/evidence scoped rather than standing semantic loops.
  - `hermes-m5` still lacks a valid current `SEMANTIC_SIGNED` receipt.
  - `qwen_code` still lacks a standing wake loop/handler ACK path.
- Mac-to-Agni leaf-node `/leafz` and both-way semantic request/reply acceptance
  remain unverified.

## Next Safe Move

Do not mutate Agni from the generic `trishula` context. The next implementation
step should be a migration plan/installer that either:

1. uses an operator-approved admin context to split `DHARMA_A2A:dharma.a2a.>`
   safely into canonical `A2A_*` streams, or
2. explicitly documents a staged compatibility plan where `DHARMA_A2A` remains
   the legacy source while new canonical streams are introduced without subject
   overlap.

Only after that should live ACL probes and five-lane semantic roll-call be run.
