# v12o Live ACL Probe Producer Checkpoint

Timestamp: 2026-06-19T06:06:10Z

## Scope

This slice added the missing first-class live ACL probe receipt producer and
wired it into the full-spec readiness gate.

Added or updated:

- `scripts/governance/a2a_live_acl_probe.py`
- `tests/test_a2a_live_acl_probe.py`
- `scripts/governance/a2a_full_spec_readiness.py`
- `tests/test_a2a_full_spec_readiness.py`
- `Makefile`
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `scripts/governance/check_nats_substrate_contract.py`

## Result

Local/offline gate coverage remains approximately 99/100.

Live full-spec readiness remains approximately 91/100. The machine aggregate
receipt is still red by design because live topology/cutover, live ACL
execution, and counted-agent live evidence are not all proven.

The current aggregate receipt scores are lower than implementation coverage
because the readiness score is a live proof score:

- Prevalidate smoke: `15/100`
- Live-mode smoke: `0/100`

## Receipts

Standalone live ACL dry-run receipt:

- `reports/a2a/live_acl/20260619T060310_667856Z-a2a-live-acl-probe.json`

Aggregate prevalidate readiness receipt:

- `reports/a2a/full_spec_readiness/20260619T060408_618120Z-a2a-full-spec-readiness.json`

Aggregate live-mode readiness receipt:

- `reports/a2a/full_spec_readiness/20260619T060534_971588Z-a2a-full-spec-readiness.json`

The live-mode receipt now includes this explicit live ACL blocker:

- `live ACL probe failure: live ACL probe execution not requested; dry-run rendered planned probes only`

## Verification

Passed:

- `python3 -m compileall -q scripts/governance/a2a_live_acl_probe.py scripts/governance/a2a_full_spec_readiness.py scripts/governance/check_nats_substrate_contract.py tests/test_a2a_live_acl_probe.py tests/test_a2a_full_spec_readiness.py`
- `uv run pytest -q tests/test_a2a_live_acl_probe.py tests/test_a2a_full_spec_readiness.py --tb=short` -> 11 passed
- `python3 scripts/governance/check_nats_substrate_contract.py` -> `NATS_CONTRACT_OK`
- Context+ static analysis on the changed governance scripts -> clean
- `make a2a-live-acl-probe` -> expected fail-closed dry-run receipt
- `make a2a-full-spec-readiness ARGS='--run-topology --run-onboard --run-live-probe --run-live-acl-probe'` -> expected red prevalidate receipt
- `make a2a-full-spec-readiness MODE=live ARGS='--run-topology --run-onboard --run-live-probe --run-live-acl-probe'` -> expected red live receipt with explicit ACL blocker
- `make nats-substrate-contract PYTEST='uv run pytest'` -> 119 passed
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short` -> 255 passed, 1 Starlette deprecation warning
- `git diff --check` -> clean

`uv.lock` churn from `uv run` was reverted.

## Remaining Live Blockers

- `DHARMA_A2A` still owns `dharma.a2a.>` and overlaps canonical task subjects.
- `A2A_TASKS` and `A2A_RECEIPTS` are not live-observed canonical streams.
- Actual cutover still requires `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Live ACL execution still requires a separate explicit
  `A2A_LIVE_ACL_PROBE=approved-live-acl-probe` run.
- Non-Codex counted seats still lack target-owned domain receipts and current
  semantic receipts.
- Session-scoped and wake-loop blockers remain, including `qwen_code`.
