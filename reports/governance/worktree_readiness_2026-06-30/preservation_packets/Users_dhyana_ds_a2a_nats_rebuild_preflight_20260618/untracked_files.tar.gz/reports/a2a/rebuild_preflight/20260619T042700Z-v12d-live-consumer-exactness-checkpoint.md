# v12d Live Consumer Exactness Checkpoint

Timestamp: 2026-06-19T04:27:00Z

## Completed

- Live topology probe now records exact NATS consumer config fields:
  `ack_wait_ns`, `backoff_ns`, `num_ack_pending`, `num_pending`,
  `num_redelivered`, and `num_waiting`.
- Offline topology receipt now renders `desired_consumer_configs` with exact
  NATS JSON config values.
- Live verifier now reports structured `drifted_consumers`.
- Added guarded live consumer config modes:
  - `--reconcile-consumers` with `A2A_LIVE_TOPOLOGY_RECONCILE=approved-consumer-reconcile`
  - `--replace-empty-consumers` with `A2A_LIVE_TOPOLOGY_REPLACE_CONSUMERS=approved-replace-empty-consumers`
  - dry-run modes for both mutation paths
- Corrected canonical NATS semantics: when backoff is configured, NATS reports
  AckWait as the first backoff interval, so canonical `ack_wait_s` must match
  the first backoff interval.
- Replaced the five drifted canonical `A2A_INBOX` consumers after dry-run
  validation and zero-counter checks. No legacy streams were edited.

## Live Evidence

- Edit dry-run receipt:
  `reports/a2a/live_topology/20260619T041832Z-a2a-live-topology-probe.json`
  - Result: in-place edit rejected by NATS with
    `consumers with backoff policies do not support editing Ack Wait`.
- Replace dry-run receipt:
  `reports/a2a/live_topology/20260619T042136Z-a2a-live-topology-probe.json`
  - Result: all five drifted canonical inbox consumer configs validated and
    all live counters were zero.
- Guarded replacement receipt:
  `reports/a2a/live_topology/20260619T042403Z-a2a-live-topology-probe.json`
  - Result: five `A2A_INBOX` consumers removed/recreated with exact backoff.
- Final read-only live probe:
  `reports/a2a/live_topology/20260619T042627Z-a2a-live-topology-probe.json`
  - Result: `drifted_consumers: []`
  - Remaining live failures:
    - missing live canonical streams: `A2A_RECEIPTS`, `A2A_TASKS`
    - legacy migration-alias stream still present: `DHARMA_A2A`
    - `DHARMA_A2A:dharma.a2a.>` still overlaps canonical
      `dharma.a2a.task.>`
- Offline exact topology receipt:
  `reports/a2a/topology/20260619T042641Z-a2a-jetstream-topology.json`

## Verification

- `uv run pytest -q tests/test_a2a_jetstream_topology.py --tb=short`
  - 16 passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `python3 -m compileall -q dharma_swarm/a2a scripts/governance scripts/runtime`
  - passed
- Focused A2A/NATS/public/semantic suite:
  - 181 passed, 1 warning
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - 89 passed
- `git diff --check`
  - passed

## Remaining Blockers

- No legacy wildcard cutover was executed. `DHARMA_A2A` still owns
  `dharma.a2a.>`, so `A2A_TASKS` and `A2A_RECEIPTS` remain cutover-blocked.
- Live scoped per-agent ACL credentials/probes are still not installed and run.
- Live semantic onboarding still has missing/session-scoped receipts and wake
  loop ACK gaps.
- Mac-to-Agni leaf and both-way semantic request/reply acceptance remain
  unverified.

