# A2A/NATS Full Spec Live Cutover Checkpoint

Timestamp: 2026-06-20T01:53:01Z

Score: 80/100

Aggregate readiness:

- `reports/a2a/full_spec_readiness/20260620T015243_890144Z-a2a-full-spec-readiness.json`
- `full_spec_ready=false`
- `readiness_score=80`
- `target_score=100`

Live topology/cutover result:

- Canonical live topology now passes.
- `A2A_INBOX`, `A2A_TASKS`, `A2A_RECEIPTS`, `A2A_DLQ`, and `PRESENCE` are observed.
- Canonical consumers are observed:
  - `A2A_INBOX/a2a_codex_composer_inbox`
  - `A2A_INBOX/a2a_devin-roaming-2987d222_inbox`
  - `A2A_INBOX/a2a_hermes-m5_inbox`
  - `A2A_INBOX/a2a_opus_composer_inbox`
  - `A2A_INBOX/a2a_qwen_code_inbox`
  - `A2A_TASKS/a2a_task_claimant`
  - `A2A_TASKS/a2a_task_closer`
  - `A2A_RECEIPTS/a2a_receipt_indexer`
  - `A2A_DLQ/a2a_dlq_operator_replay`
- `DHARMA_A2A` remains live only as a narrowed migration alias and no longer overlaps canonical subject space.

Key receipts:

- Passing live topology receipt: `reports/a2a/live_topology/20260620T015035Z-a2a-live-topology-probe.json`
- Aggregate readiness receipt: `reports/a2a/full_spec_readiness/20260620T015243_890144Z-a2a-full-spec-readiness.json`
- Refreshed domain artifact preflight: `reports/a2a/domain_reply_artifact_preflight/20260620T015236_531802Z-a2a-domain-reply-artifact-preflight.json`
- Refreshed standing agent preflight: `reports/a2a/standing_agent_preflight/20260620T015236_383718Z-a2a-standing-agent-preflight.json`
- Refreshed wake-loop preflight: `reports/a2a/wake_loop_preflight/20260620T015236_388230Z-a2a-wake-loop-preflight.json`
- Latest Devin capture failure: `reports/a2a/model_reply_captures/20260620T015152Z-devin-roaming-2987d222-a2a-semantic-signoff-devin-roaming-2987d222-e4778df2dfe6.json`
- Latest Opus capture failure: `reports/a2a/model_reply_captures/20260620T015222Z-opus_composer-a2a-semantic-signoff-opus_composer-e4778df2dfe6.json`

Implementation corrections made during cutover:

- `dharma_swarm/a2a/jetstream_topology.py` now renders `A2A_TASKS` workqueue consumers with NATS-required `DeliverAll`.
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` now documents the `DeliverAll` workqueue policy.
- `scripts/governance/a2a_live_topology_probe.py` can apply post-cutover canonical consumers after the legacy stream has already been narrowed and supports `--canonical-consumers-only` for bounded post-cutover readiness checks.
- `scripts/governance/a2a_full_spec_readiness.py` uses canonical-only live topology observation for aggregate readiness and no longer treats a narrowed non-overlapping migration alias as a topology failure.

Passing components:

- `live_topology`
- `cutover_completion`
- `acl_probe_contract`
- `semantic_task_packets`
- `semantic_send_receipts`
- `identity_presence`

Failing components:

- `domain_reply_artifacts`
- `wake_loop_preflight`
- `counted_agent_readiness`

Current blockers:

- Devin did not emit a target-owned artifact. The latest capture failed because the Devin weekly usage quota is exhausted.
- Opus did not emit a target-owned artifact. The latest capture failed because Claude credit balance is too low.
- Codex, Devin, Qwen, and Opus remain session/evidence scoped for standing-agent readiness.
- Codex, Devin, Qwen, and Opus do not have acceptable target-owned standing wake-loop proof with `StandingWakeLoop`, `WakeLease`, and `WakeCircuitBreaker`.
- Devin and Opus cannot produce `DOMAIN_RECEIPTED`/`SEMANTIC_SIGNED` until their target-owned domain reply artifacts exist.

Verification:

- `pytest -q tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_full_spec_readiness.py --tb=short` passed: 38 tests.
- `make nats-substrate-contract` passed: `NATS_CONTRACT_OK`, 172 tests.
- `make lint-blockers` passed: no undefined names.
- `ruff check dharma_swarm/a2a/jetstream_topology.py scripts/governance/a2a_live_topology_probe.py scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_full_spec_readiness.py --select=F821,F401,F541` passed.

What remains to reach 100/100:

1. Restore Devin capacity or provide a valid Devin-owned artifact for `devin-roaming-2987d222`.
2. Restore Claude/Opus credit or provide a valid Opus-owned artifact for `opus_composer`.
3. Run target-owned standing wake loops from non-session-scoped identities for Codex, Devin, Qwen, and Opus, with lease and circuit-breaker fields.
4. Re-run domain reply artifact preflight, wake-loop preflight, onboard/readiness, and the aggregate full-spec readiness gate.
