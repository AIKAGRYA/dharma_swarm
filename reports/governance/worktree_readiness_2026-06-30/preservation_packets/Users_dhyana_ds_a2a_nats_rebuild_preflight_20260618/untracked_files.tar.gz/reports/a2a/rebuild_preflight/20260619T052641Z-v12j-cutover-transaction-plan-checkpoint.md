# A2A/NATS Rebuild Preflight Checkpoint v12j

Timestamp: 2026-06-19T05:26:41Z

## Status

- Local/offline implementation score: 98/100.
- Live full-spec score: 91/100.
- No live topology mutation was performed in this pass.

## Completed In This Pass

- Added non-mutating `cutover_transaction_plan` generation to `scripts/governance/a2a_live_topology_probe.py`.
- The transaction plan simulates the legacy stream subject narrowing in memory, then re-renders the post-cutover canonical stream and durable consumer steps that become unblocked.
- Added helpers for extracting cutover subjects from quoted NATS CLI commands and deriving a synthetic post-legacy-cutover stream observation.
- Updated live topology receipts to include:
  - `cutover_rollback_plan`
  - `cutover_transaction_plan.legacy_cutover_steps`
  - `cutover_transaction_plan.post_cutover_steps_after_legacy_cutover`
  - `cutover_transaction_plan.post_cutover_blockers_after_legacy_cutover`
  - `cutover_transaction_plan.rollback_plan`
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` to require the transaction plan.
- Updated `scripts/governance/check_nats_substrate_contract.py` to lock the transaction-plan requirement.

## Verification

- `uv run pytest -q tests/test_a2a_live_topology_probe.py tests/test_a2a_jetstream_topology.py --tb=short`
  - Result: 25 passed.
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - Result: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- `python3 -m compileall -q scripts/governance/a2a_live_topology_probe.py scripts/governance/check_nats_substrate_contract.py`
  - Result: passed.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - Result: 240 passed, 1 warning.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Result: contract OK, 104 tests passed.
- `.venv/bin/python scripts/governance/a2a_live_topology_probe.py --context agni-wss --cutover-topology --dry-run-cutover --json`
  - Result: expected exit 1 due current live topology drift; dry-run cutover step passed with `effective_returncode: 0`, `mutation_performed: false`, rollback metadata present, and transaction plan present.
  - Receipt: `reports/a2a/live_topology/20260619T052621Z-a2a-live-topology-probe.json`.
- `git diff --check`
  - Result: passed.

## Latest Live Dry-Run Evidence

The v12j live dry-run receipt includes:

- `cutover_transaction_plan.mutation_gate`: `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`
- `cutover_transaction_plan.post_cutover_blockers_after_legacy_cutover`: `[]`
- `cutover_transaction_plan.post_cutover_steps_after_legacy_cutover` contains:
  - `add_A2A_TASKS`
  - `add_A2A_RECEIPTS`
  - `add_consumer_a2a_task_claimant`
  - `add_consumer_a2a_task_closer`
  - `add_consumer_a2a_receipt_indexer`
- `cutover_transaction_plan.rollback_plan.cutover_DHARMA_A2A.command`: `nats --context agni-wss stream edit DHARMA_A2A --subjects 'dharma.a2a.>' --force`
- `mutation_performed`: `false`

## Live Blockers Remaining

- `DHARMA_A2A` still owns `dharma.a2a.>`, so canonical `A2A_TASKS` and `A2A_RECEIPTS` cannot be installed live without explicit cutover approval.
- Actual cutover still requires `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Non-Codex counted seats still lack fresh target-owned domain and semantic receipts.
- `qwen_code` still lacks real wake-loop evidence.

