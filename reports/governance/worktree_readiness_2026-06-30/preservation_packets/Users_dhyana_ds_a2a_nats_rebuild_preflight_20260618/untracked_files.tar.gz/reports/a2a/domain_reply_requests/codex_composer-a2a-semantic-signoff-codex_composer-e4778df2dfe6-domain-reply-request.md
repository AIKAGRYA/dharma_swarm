---
schema_version: dharma.a2a.domain_reply_request.v1
agent_uid: codex_composer
packet_id: a2a-semantic-signoff-codex_composer-e4778df2dfe6
task_hash: sha256:6190aeac350df56079426f6eaaecca4e85a62cc0b0c7a7b95fefa22956cb6945
locked_spec_sha256: e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899
---

# A2A Target-Owned Domain Reply Artifact Request

Target agent: `codex_composer`
Expected target-owned artifact path: `/Users/dhyana/.dharma/a2a_bus/outboxes/codex_composer/a2a-semantic-signoff-codex_composer-e4778df2dfe6.json`
Send receipt: `reports/a2a/send_receipts/20260619T071228Z-codex_composer-a2a-semantic-signoff-codex_composer-e4778df2dfe6.json`
Reply subject: `dharma.agent.codex_composer.inbox.reply.a2a-semantic-signoff-codex_composer-e4778df2dfe6`

This request is not the reply artifact. A target-owned process or model must
write the artifact at the expected outbox path before the domain reply worker
or semantic receipt verifier can promote the evidence.

Required artifact JSON:

```json
{
  "authored_by": "codex_composer",
  "blockers": [],
  "confidence": 0.0,
  "evidence_refs": [
    "docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md"
  ],
  "failure_digest": "what confused me; what I tried; what failed; what finally worked",
  "locked_spec_sha256": "e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899",
  "model_identity": "<target provider/model or executable seat>",
  "packet_id": "a2a-semantic-signoff-codex_composer-e4778df2dfe6",
  "peer_model_processed_claim": true,
  "reply_subject": "dharma.agent.codex_composer.inbox.reply.a2a-semantic-signoff-codex_composer-e4778df2dfe6",
  "schema_version": "dharma.a2a.domain_reply_artifact.v1",
  "semantic_reply_claim": true,
  "send_receipt_path": "reports/a2a/send_receipts/20260619T071228Z-codex_composer-a2a-semantic-signoff-codex_composer-e4778df2dfe6.json",
  "summary": "<target-authored semantic review>",
  "task_hash": "sha256:6190aeac350df56079426f6eaaecca4e85a62cc0b0c7a7b95fefa22956cb6945",
  "verdict": "approve|revise|reject|blocked"
}
```
