# A2A/NATS Rebuild Preflight Checkpoint v12l

Timestamp: 2026-06-19T05:38:11Z

## Status

- Local/offline implementation score: 98/100, with this pass closing a cutover compensation planning gap.
- Live full-spec score: 91/100.
- No live topology mutation was performed in this pass.

## Completed In This Pass

- Added `post_cutover_compensation_plan` to `cutover_transaction_plan` in `scripts/governance/a2a_live_topology_probe.py`.
- Compensation entries are rendered in reverse post-cutover order.
- Post-cutover consumer additions compensate with explicit `consumer rm` commands.
- Post-cutover stream additions compensate with explicit `stream rm` commands.
- Compensation commands are marked as `explicit_operator_action` and include a precondition that they apply only if the matching post-cutover step actually created the resource.
- Added per-step `compensation` metadata to post-cutover step previews.
- Added result-level `compensation` metadata for actual post-cutover follow-up execution rows, so a mid-sequence failure receipt is self-contained.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` to require the post-cutover compensation plan.
- Updated `scripts/governance/check_nats_substrate_contract.py` to lock the new compensation-plan requirement.

## Verification

- `uv run pytest -q tests/test_a2a_live_topology_probe.py tests/test_a2a_jetstream_topology.py --tb=short`
  - Result: 29 passed.
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - Result: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- `python3 -m compileall -q scripts/governance/a2a_live_topology_probe.py scripts/governance/check_nats_substrate_contract.py`
  - Result: passed.
- Context+ static analysis on `/Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618/scripts/governance/a2a_live_topology_probe.py`
  - Result: no issues found.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - Result: 244 passed, 1 warning.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Result: contract OK, 108 tests passed.
- `.venv/bin/python scripts/governance/a2a_live_topology_probe.py --context agni-wss --cutover-topology --dry-run-cutover --json`
  - Result: expected exit 1 due current live topology drift; `mutation_performed: false`; dry-run legacy cutover step passed with `effective_returncode: 0`; transaction plan includes reverse-order compensation commands.
  - Receipt: `reports/a2a/live_topology/20260619T053803Z-a2a-live-topology-probe.json`.
- `git diff --check`
  - Result: passed before checkpoint creation.
- `git checkout -- uv.lock`
  - Result: removed verification-induced lockfile churn.

## Latest Live Dry-Run Evidence

The v12l live dry-run receipt includes:

- `mutation_performed`: `false`
- `cutover_results[0].passed`: `true`
- `cutover_results[0].effective_returncode`: `0`
- `cutover_results[0].dry_run_diff_detected`: `true`
- `cutover_transaction_plan.post_cutover_blockers_after_legacy_cutover`: `[]`
- `cutover_transaction_plan.post_cutover_compensation_plan` in `reverse_post_cutover_order`, including:
  - `consumer rm A2A_RECEIPTS a2a_receipt_indexer --force`
  - `consumer rm A2A_TASKS a2a_task_closer --force`
  - `consumer rm A2A_TASKS a2a_task_claimant --force`
  - `stream rm A2A_RECEIPTS --force`
  - `stream rm A2A_TASKS --force`
- `post_cutover_steps_after_legacy_cutover` entries include per-step `compensation` metadata.

## Live Blockers Remaining

- `DHARMA_A2A` still owns `dharma.a2a.>`, so canonical `A2A_TASKS` and `A2A_RECEIPTS` cannot be installed live without explicit cutover approval.
- Actual cutover still requires `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Non-Codex counted seats still lack fresh target-owned domain and semantic receipts.
- `qwen_code` still lacks real wake-loop evidence.
