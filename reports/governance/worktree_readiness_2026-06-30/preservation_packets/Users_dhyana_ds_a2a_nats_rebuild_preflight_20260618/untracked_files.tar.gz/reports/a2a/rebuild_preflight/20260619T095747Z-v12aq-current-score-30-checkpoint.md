# A2A/NATS Full Spec Current Score Checkpoint

Timestamp: 2026-06-19T09:57:47Z

Score: 30/100

Aggregate readiness:

- `reports/a2a/full_spec_readiness/20260619T095722_601476Z-a2a-full-spec-readiness.json`
- `full_spec_ready=false`
- `readiness_score=30`
- `target_score=100`

Passing components:

- `acl_probe_contract`
- `semantic_task_packets`
- `semantic_send_receipts`
- `identity_presence`

Failing components:

- `live_topology`
- `cutover_completion`
- `domain_reply_artifacts`
- `wake_loop_preflight`
- `counted_agent_readiness`

Fresh non-mutating evidence included in this checkpoint:

- Live topology dry-run/cutover evidence: `reports/a2a/live_topology/20260619T095222Z-a2a-live-topology-probe.json`
- Topology observation: `reports/a2a/topology/20260619T095722_584982Z-a2a-jetstream-topology.json`
- Live ACL dry-run plan: `reports/a2a/live_acl/20260619T095543_106368Z-a2a-live-acl-probe.json`
- Standing agent preflight: `reports/a2a/standing_agent_preflight/20260619T095543_113584Z-a2a-standing-agent-preflight.json`
- Wake-loop preflight: `reports/a2a/wake_loop_preflight/20260619T095543_113789Z-a2a-wake-loop-preflight.json`
- Domain reply artifact preflight: `reports/a2a/domain_reply_artifact_preflight/20260619T095543_256246Z-a2a-domain-reply-artifact-preflight.json`

Current blockers:

- Live canonical streams `A2A_TASKS` and `A2A_RECEIPTS` are not present.
- Legacy `DHARMA_A2A` remains live and overlaps canonical `dharma.a2a.task.>`.
- Live cutover remains gated by explicit operator approval for `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Devin is missing target-owned domain reply and semantic evidence; latest capture failed due external model command failure/rate limit.
- Opus is missing target-owned domain reply and semantic evidence; latest capture failed because Claude credit balance is too low.
- Codex, Devin, Qwen, and Opus remain session/evidence scoped for standing-agent readiness.
- Codex, Devin, Qwen, and Opus lack durable standing wake-loop proof with `StandingWakeLoop`, `WakeLease`, and `WakeCircuitBreaker`.
- Qwen dispatch remains disabled until standing wake-loop and semantic receipt evidence are durable.

Explicitly not run:

- No live topology cutover was executed.
- No live ACL `--execute` probe was executed.
- No target-owned evidence was fabricated for Devin, Opus, Codex, or Qwen.

Verification:

- `make a2a-full-spec-readiness AGENT=all MODE=prevalidate ARGS='--run-topology --json'` produced the aggregate readiness receipt above and exited nonzero because the spec is not ready.
- `make nats-substrate-contract` passed: `NATS_CONTRACT_OK`, 172 tests passed.
- `make lint-blockers` passed: no undefined names.

Next unblock commands requiring explicit operator approval before live mutation:

```bash
A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover make a2a-live-topology ARGS='--cutover-topology --json --timeout-s 20'
```

Live ACL execution remains separately gated and should only be run after the operator explicitly approves the live ACL probe.
