# A2A/NATS Full Spec Checkpoint - 2026-06-19T09:32:14Z

## Current Score

- Readiness score: 30/100
- Full spec ready: false
- Latest full-readiness receipt: `reports/a2a/full_spec_readiness/20260619T093150_241028Z-a2a-full-spec-readiness.json`

The score did not increase because the remaining failed components are still all-or-nothing: live topology/cutover, target-owned domain artifacts for all counted agents, wake-loop preflight for all counted agents, and counted-agent readiness for all counted agents.

## Work Completed In This Continuation

- Retried Devin target-owned model capture.
  - Receipt: `reports/a2a/model_reply_captures/20260619T092840Z-devin-roaming-2987d222-a2a-semantic-signoff-devin-roaming-2987d222-e4778df2dfe6.json`
  - Result: `MODEL_COMMAND_FAILED`
  - External blocker: Devin model rate limit remains active with about 2h54m remaining.
  - No artifact was written.
- Retried Opus/Claude target-owned model capture.
  - Receipt: `reports/a2a/model_reply_captures/20260619T093140Z-opus_composer-a2a-semantic-signoff-opus_composer-e4778df2dfe6.json`
  - Result: `MODEL_COMMAND_FAILED`
  - External blocker: `stdout_tail` now records `Credit balance is too low`.
  - No artifact was written.
- Hardened `scripts/runtime/a2a_model_reply_capture.py`.
  - Failed or invalid model command receipts now include bounded `stdout_tail`, not only `stderr_tail`.
  - The CLI now accepts the conventional `--command -- tool ...` separator form from both in-process tests and real command-line invocation.
- Expanded `tests/test_a2a_model_reply_capture.py`.
  - Covers stdout-only command failures.
  - Covers `sys.argv` invocation with `--command --`.
- Added `tests/test_a2a_model_reply_capture.py` to `make nats-substrate-contract` so the critical target-model capture path is part of the A2A/NATS governance bundle.

## Still Blocked

- Live canonical streams `A2A_TASKS` and `A2A_RECEIPTS` are absent.
- Legacy `DHARMA_A2A` remains live and overlaps canonical `dharma.a2a.task.>`.
- Live topology cutover remains gated by explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Live ACL probe remains gated by explicit `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`.
- `devin-roaming-2987d222` still lacks a target-owned domain reply artifact, domain receipt, semantic receipt, and standing wake-loop evidence.
- `opus_composer` still lacks a target-owned domain reply artifact, domain receipt, semantic receipt, and standing wake-loop evidence.
- `codex_composer` and `qwen_code` still have domain/semantic receipts but remain session/evidence scoped, so wake-loop readiness correctly fails closed.

## Verification

- `pytest -q tests/test_a2a_model_reply_capture.py --tb=short`
  - Result: 4 passed
- `uv run ruff check scripts/runtime/a2a_model_reply_capture.py tests/test_a2a_model_reply_capture.py --select=F821,F401,F541,E501`
  - Result: all checks passed
- `python3 -m compileall scripts/runtime/a2a_model_reply_capture.py tests/test_a2a_model_reply_capture.py`
  - Result: compiled cleanly
- `make nats-substrate-contract`
  - Result: `NATS_CONTRACT_OK`; 170 tests passed
- `make lint-blockers`
  - Result: OK, no undefined names

