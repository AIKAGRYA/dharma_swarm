# A2A/NATS Rebuild Preflight Checkpoint v12i

Timestamp: 2026-06-19T05:21:02Z

## Status

- Local/offline implementation score: 98/100.
- Live full-spec score: 91/100.
- No live topology mutation was performed in this pass.

## Completed In This Pass

- Added pre-cutover rollback command generation to `scripts/governance/a2a_live_topology_probe.py`.
- Added `cutover_rollback_plan` to live topology probe receipts.
- Attached rollback metadata to each legacy cutover dry-run/result entry.
- Preserved the pre-cutover rollback plan even if later same-run observations change after cutover steps.
- Added tests proving rollback plans restore the original legacy stream subject list.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` to require pre-cutover rollback commands in legacy stream cutover receipts.
- Updated `scripts/governance/check_nats_substrate_contract.py` to lock the rollback requirement.

## Verification

- `uv run pytest -q tests/test_a2a_live_topology_probe.py tests/test_a2a_jetstream_topology.py --tb=short`
  - Result: 23 passed.
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - Result: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- `python3 -m compileall -q scripts/governance/a2a_live_topology_probe.py scripts/governance/check_nats_substrate_contract.py dharma_swarm/a2a/jetstream_topology.py`
  - Result: passed.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - Result: 238 passed, 1 warning.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Result: contract OK, 102 tests passed.
- `.venv/bin/python scripts/governance/a2a_live_topology_probe.py --context agni-wss --cutover-topology --dry-run-cutover --json`
  - Result: expected exit 1 due current live topology drift; dry-run cutover step passed with `effective_returncode: 0`, `mutation_performed: false`, and rollback receipt metadata present.
  - Receipt: `reports/a2a/live_topology/20260619T052025Z-a2a-live-topology-probe.json`.
- `git diff --check`
  - Result: passed.

## Live Blockers Remaining

- `DHARMA_A2A` still owns `dharma.a2a.>`, so canonical `A2A_TASKS` and `A2A_RECEIPTS` cannot be installed live without explicit cutover approval.
- Actual cutover still requires `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Non-Codex counted seats still lack fresh target-owned domain and semantic receipts.
- `qwen_code` still lacks real wake-loop evidence.

## Latest Live Dry-Run Evidence

The v12i live dry-run receipt includes:

- `cutover_rollback_plan.cutover_DHARMA_A2A.command`: `nats --context agni-wss stream edit DHARMA_A2A --subjects 'dharma.a2a.>' --force`
- `cutover_results[0].rollback.available`: `true`
- `cutover_results[0].dry_run_diff_detected`: `true`
- `mutation_performed`: `false`

