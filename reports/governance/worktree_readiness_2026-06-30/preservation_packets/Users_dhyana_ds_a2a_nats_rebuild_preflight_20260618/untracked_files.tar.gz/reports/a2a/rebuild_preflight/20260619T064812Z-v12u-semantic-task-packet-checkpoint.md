# v12u Semantic Task Packet Checkpoint

Timestamp: 2026-06-19T06:48:12Z

## Scope

- Added `scripts/governance/a2a_semantic_task_packet.py`, a locked-spec
  semantic role-call packet generator.
- Added `tests/test_a2a_semantic_task_packet.py`.
- Added `make a2a-semantic-task-packet` and included the tests in
  `make nats-substrate-contract`.
- Added `render_semantic_task_packet` to `a2a_onboard.py` operator command
  bundles.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py` so the packet generator
  is part of the guarded A2A/NATS contract.

## Packet Receipt

- `reports/a2a/semantic_task_packets/20260619T064716_415828Z-a2a-semantic-task-packet.json`

Generated packets:

- `codex_composer`:
  `reports/a2a/semantic_tasks/codex_composer-packet.md`
  - task hash: `sha256:6190aeac350df56079426f6eaaecca4e85a62cc0b0c7a7b95fefa22956cb6945`
- `devin-roaming-2987d222`:
  `reports/a2a/semantic_tasks/devin-roaming-2987d222-packet.md`
  - task hash: `sha256:27e2abe2d55a46795f2890e77849f8703ae9b9bb44839b599639b9c29eea7a23`
- `hermes-m5`:
  `reports/a2a/semantic_tasks/hermes-m5-packet.md`
  - task hash: `sha256:1fd90abecec99494ff929c03f5f47f1b33960eb9b370b102e16befd6bce96148`
- `qwen_code`:
  `reports/a2a/semantic_tasks/qwen_code-packet.md`
  - task hash: `sha256:695ef818b088656b176206ed8cf19511aa495e1ac7b862aacedbf7d8b73b4317`
- `opus_composer`:
  `reports/a2a/semantic_tasks/opus_composer-packet.md`
  - task hash: `sha256:ce042069cbf97e9ff7f39a48a121b08448f881a18107e58569f968924b16cd05`

Each packet is bound to
`docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md` at SHA-256
`e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899`, requires
`dharma.a2a.domain_reply_artifact.v1`, and names `failure_digest` as a required
semantic signoff field.

## Refreshed Receipts

- Onboard receipt:
  `reports/a2a/onboard_receipts/20260619T064723.507208Z-a2a_onboard_20260619T064723_507208Z_084ddb29.json`
- Wake-loop preflight:
  `reports/a2a/wake_loop_preflight/20260619T064728_732708Z-a2a-wake-loop-preflight.json`
- Aggregate readiness:
  `reports/a2a/full_spec_readiness/20260619T064734_598528Z-a2a-full-spec-readiness.json`

## Current Aggregate Readiness

Readiness remains `15/100`, fail-closed:

- `live_topology`: red
- `cutover_completion`: red
- `acl_probe_contract`: green
- `wake_loop_preflight`: red
- `counted_agent_readiness`: red

The readiness score did not increase because packets are not peer replies. They
are the required role-call artifacts that agents must answer before
`DOMAIN_RECEIPTED` and `SEMANTIC_SIGNED` can become true.

## Verification

- Focused tests:
  `uv run pytest -q tests/test_a2a_semantic_task_packet.py tests/test_a2a_onboard.py --tb=short`
  - `11 passed`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `130 passed`
- Broad regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_semantic_task_packet.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `266 passed`, one existing FastAPI/Starlette deprecation warning.
- `python3 -m compileall -q ...`
  - passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `git diff --check`
  - passed
- Context+ static analysis on `scripts/governance/a2a_semantic_task_packet.py`
  - no issues found
- `uv.lock` was reverted after `uv run` churn.

## Remaining 100/100 Gates

- Explicit approval and execution for canonical live topology cutover.
- Explicit approval and execution for live ACL probes.
- Real target-owned standing wake-loop heartbeats for counted agents.
- Per-counted-agent target-owned domain receipts answering the generated
  semantic packets.
- Per-counted-agent current semantic receipts for the locked spec, using the
  generated task hashes and including `failure_digest`.
- Removal or replacement of session-scoped/evidence-only counted agents before
  they can satisfy standing-agent readiness.
