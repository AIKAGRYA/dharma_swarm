---
schema_version: dharma.a2a.semantic_task_packet.v1
packet_id: a2a-semantic-signoff-codex-hardening-smoke-e4778df2dfe6
agent_uid: codex-hardening-smoke
broker: agni
mode: prevalidate
locked_spec_path: docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md
locked_spec_sha256: e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899
required_reply_artifact_schema: dharma.a2a.domain_reply_artifact.v1
required_semantic_receipt_schema: dharma.a2a.semantic_receipt.v1
---

# A2A Semantic Role-Call Packet

Target agent: `codex-hardening-smoke`
Packet id: `a2a-semantic-signoff-codex-hardening-smoke-e4778df2dfe6`
Locked spec: `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md`
Locked spec SHA-256: `e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899`

## Required Action

Read the locked spec identified above and produce a target-owned reply artifact.
The reply artifact must live at:

`~/.dharma/a2a_bus/outboxes/codex-hardening-smoke/a2a-semantic-signoff-codex-hardening-smoke-e4778df2dfe6.json`

Do not answer with transport ACKs, heartbeat text, or a generic status update.
The reply artifact must be authored by the target agent/model and must be suitable
for `scripts/runtime/a2a_domain_reply_worker.py`.

## Required Reply Artifact Fields

```json
{
  "authored_by": "codex-hardening-smoke",
  "blockers": [],
  "confidence": 0.0,
  "evidence_refs": [
    "docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md"
  ],
  "failure_digest": "what confused me; what I tried; what failed; what finally worked",
  "locked_spec_sha256": "e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899",
  "model_identity": "<provider/model or executable seat>",
  "packet_id": "a2a-semantic-signoff-codex-hardening-smoke-e4778df2dfe6",
  "peer_model_processed_claim": true,
  "reply_subject": "<copy from send receipt>",
  "schema_version": "dharma.a2a.domain_reply_artifact.v1",
  "semantic_reply_claim": true,
  "send_receipt_path": "<path from send command>",
  "summary": "<concise semantic review>",
  "task_hash": "<use task_hash from semantic task packet receipt>",
  "verdict": "approve|revise|reject|blocked"
}
```

## Failure Digest Requirement

Your `failure_digest` must explicitly summarize:

- what confused me
- what I tried
- what failed
- what finally worked

A semantic receipt without `failure_digest` is treated exactly like no
semantic receipt.

## Operator Follow-Up

After the target-owned artifact exists, publish it with:

```bash
PYTHONPATH=. python3 scripts/runtime/a2a_domain_reply_worker.py --send-receipt <send_receipt_path> --reply-artifact ~/.dharma/a2a_bus/outboxes/codex-hardening-smoke/a2a-semantic-signoff-codex-hardening-smoke-e4778df2dfe6.json --agent-uid codex-hardening-smoke --json
```
