# v12x Semantic Send Readiness Gate Checkpoint

Timestamp: 2026-06-19T07:11:00Z

## Implemented

- `scripts/governance/a2a_full_spec_readiness.py` now has a dedicated
  `semantic_send_receipts` component.
- The component validates one `dharma.a2a.send_receipt.v1` per counted semantic
  task packet and fails closed unless each send receipt preserves:
  - target `agent_uid`;
  - `agent-inbox` route and canonical inbox/reply subjects;
  - semantic packet `packet_id`;
  - `semantic_task_packet_sha256`;
  - `task_hash`;
  - `locked_spec_sha256`;
  - publish-proof `status` and `ack_tier`.
- Readiness weights still sum to 100:
  - `live_topology`: 35
  - `cutover_completion`: 20
  - `acl_probe_contract`: 15
  - `semantic_task_packets`: 5
  - `semantic_send_receipts`: 5
  - `wake_loop_preflight`: 10
  - `counted_agent_readiness`: 10
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` now names semantic send
  receipts as part of the aggregate full-spec gate.
- `scripts/governance/check_nats_substrate_contract.py` now guards the
  `semantic_send_receipts` component, blocker text, and CLI override.

## Verification

- `uv run pytest -q tests/test_a2a_full_spec_readiness.py --tb=short`
  - 9 passed.
- `uv run pytest -q tests/test_a2a_send.py tests/test_a2a_domain_reply_worker.py --tb=short`
  - 38 passed.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Contract checker passed.
  - 137 passed.
- Broad A2A/runtime regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_semantic_task_packet.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - 273 passed.
  - Existing FastAPI/Starlette deprecation warning only.
- Context+ static analysis on `scripts/governance/a2a_full_spec_readiness.py`
  - Clean.
- `python3 -m compileall -q scripts/governance/a2a_full_spec_readiness.py scripts/governance/check_nats_substrate_contract.py tests/test_a2a_full_spec_readiness.py`
  - Clean.
- `git diff --check`
  - Clean.

## Readiness

Latest aggregate receipt:
`reports/a2a/full_spec_readiness/20260619T071055_034164Z-a2a-full-spec-readiness.json`

Current score remains 20/100:

- `live_topology`: red
- `cutover_completion`: red
- `acl_probe_contract`: green
- `semantic_task_packets`: green
- `semantic_send_receipts`: red
- `wake_loop_preflight`: red
- `counted_agent_readiness`: red

The new red component is intentional. The worktree has hash-bound semantic task
packets, but no real send receipts proving those packets were issued to the
counted agents.
