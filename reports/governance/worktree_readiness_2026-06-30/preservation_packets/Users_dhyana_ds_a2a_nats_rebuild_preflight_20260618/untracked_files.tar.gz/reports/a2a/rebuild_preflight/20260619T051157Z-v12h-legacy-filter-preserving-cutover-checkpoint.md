# v12h Legacy-Filter-Preserving Cutover Checkpoint

Timestamp: 2026-06-19T05:11:57Z

## Honest Score

- Local/offline implementation: 98/100.
- Live full-spec implementation: 91/100.

This pass improved the live cutover recipe, not the live score. The live broker
is still blocked by `DHARMA_A2A` owning `dharma.a2a.>`, and actual mutation
still requires explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.

## What Changed

- `dharma_swarm/a2a/jetstream_topology.py` now builds legacy cutover subjects
  from:
  - currently active legacy stream subjects; and
  - dormant legacy consumer filter subjects.
- The planner excludes any legacy subject that overlaps canonical
  `A2A_TASKS` or `A2A_RECEIPTS` subjects.
- If no non-overlapping subject binding remains, the cutover step is blocked
  instead of emitting a destructive `stream edit` recipe.
- The spec now states that cutover must preserve non-overlapping legacy consumer
  filter subjects.
- The contract checker now enforces the helper and spec language.
- Added regression coverage proving `dharma.a2a.hermes` is preserved while
  `dharma.a2a.task.claim` is excluded from the legacy stream.

## Live Evidence

Read-only live topology receipt:
`reports/a2a/live_topology/20260619T050800Z-a2a-live-topology-probe.json`

Dry-run cutover receipt:
`reports/a2a/live_topology/20260619T051055Z-a2a-live-topology-probe.json`

The new dry-run cutover command preserves these non-overlapping legacy subjects:

- `dharma.a2a.codex`
- `dharma.a2a.codex.ack.phone-codex-003-1781798439`
- `dharma.a2a.codex.ack.phone-codex-004`
- `dharma.a2a.codex.ack.phone-codex-005`
- `dharma.a2a.codex_agni_drill_20260613`
- `dharma.a2a.codex_agni_drill_20260613.reply.6b6a6de35b46`
- `dharma.a2a.devin`
- `dharma.a2a.fable_5_cursor`
- `dharma.a2a.fable_composer`
- `dharma.a2a.fleet`
- `dharma.a2a.hermes`
- `dharma.a2a.merge_master_mike`
- `dharma.a2a.perplexity`
- `dharma.a2a.warp_oz`
- `dharma.a2a.claude`

The dry-run still records:

- `mutation_performed: false`
- `cutover_results[0].passed: true`
- `cutover_results[0].returncode: 1`
- `cutover_results[0].effective_returncode: 0`
- `cutover_results[0].dry_run_diff_detected: true`

## Current Live Blockers

- Missing canonical streams: `A2A_TASKS`, `A2A_RECEIPTS`.
- Legacy stream still present: `DHARMA_A2A`.
- Live subject overlap remains:
  `DHARMA_A2A:dharma.a2a.> overlaps canonical dharma.a2a.task.>`.
- Actual live cutover remains fail-closed without
  `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.

## Current Onboard Blockers

Latest onboard run:
`a2a_onboard_20260619T050703.282770Z_84aa1738`

- `codex_composer`: `DOMAIN_RECEIPTED`, `SEMANTIC_SIGNED`, but
  `DEGRADED_SESSION_SCOPED`.
- `devin-roaming-2987d222`: `DEGRADED_SESSION_SCOPED`,
  `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.
- `hermes-m5`: `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.
- `qwen_code`: `BLOCKED_WAKE_LOOP`, `DEGRADED_SESSION_SCOPED`,
  `BLOCKED_DOMAIN_RECEIPT`, `BLOCKED_SEMANTIC_RECEIPT`.
- `opus_composer`: `DEGRADED_SESSION_SCOPED`, `BLOCKED_DOMAIN_RECEIPT`,
  `BLOCKED_SEMANTIC_RECEIPT`.

Process inspection found standing Hermes gateway, local NATS, Palantir worker,
and Codex-related MCP/CLI processes. It did not show a standing Qwen, Opus, or
Devin wake loop, so the onboard failures are not safe to clear with metadata
edits.

## Verification

- `uv run pytest -q tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py --tb=short`
  - `21 passed`
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `.venv/bin/python scripts/governance/a2a_live_topology_probe.py --context agni-wss --cutover-topology --dry-run-cutover --json`
  - exited `1` because live topology still fails overall;
  - dry-run cutover step passed;
  - wrote `reports/a2a/live_topology/20260619T051055Z-a2a-live-topology-probe.json`.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `236 passed, 1 warning`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `100 passed`
- `python3 -m compileall -q scripts/runtime scripts/governance dharma_swarm/a2a`
  - passed
- `git diff --check`
  - passed

## Next Move

The next score-moving live topology action is now a safer, verified command,
but it is still a real broker mutation:

```bash
A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover \
  .venv/bin/python scripts/governance/a2a_live_topology_probe.py \
  --context agni-wss --cutover-topology --json
```

After that, rerun live topology and onboard. If topology goes green, the
remaining non-topology work is counted-seat reality: promote standing loops and
obtain target-owned domain plus semantic receipts for non-Codex agents.
