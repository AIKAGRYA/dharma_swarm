# v12z Reply Capture Stream Checkpoint

Timestamp: 2026-06-19T07:18:55Z

## Fixed

- `scripts/runtime/a2a_reply_capture.py` now defaults reply capture to
  `A2A_INBOX`.
- `scripts/runtime/a2a_domain_reply_worker.py` now records/publishes reply
  work against default stream `A2A_INBOX`.
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` now makes explicit that
  `A2A_INBOX` owns `dharma.agent.*.inbox.>` and that recorded reply subjects
  live under `dharma.agent.<agent_uid>.inbox.reply.*`.
- `scripts/governance/check_nats_substrate_contract.py` now guards the
  `A2A_INBOX` default for reply capture and domain reply publication.

Root cause: generated reply subjects are
`dharma.agent.<agent_uid>.inbox.reply.<packet_id>`. The canonical topology owns
those subjects under `A2A_INBOX` via `dharma.agent.*.inbox.>`, not under
`A2A_RECEIPTS`. Looking in `A2A_RECEIPTS` would miss valid replies.

## Reply Capture Evidence

Ran `scripts/runtime/a2a_reply_capture.py` against all five semantic task send
receipts using `NATS_CONTEXT=agni-wss` and the new default stream.

All five capture receipts are honest `NO_REPLY`:

- `reports/a2a/reply_receipts/20260619T071845Z-codex_composer-a2a-semantic-signoff-codex_composer-e4778df2dfe6.json`
- `reports/a2a/reply_receipts/20260619T071845Z-devin-roaming-2987d222-a2a-semantic-signoff-devin-roaming-2987d222-e4778df2dfe6.json`
- `reports/a2a/reply_receipts/20260619T071845Z-hermes-m5-a2a-semantic-signoff-hermes-m5-e4778df2dfe6.json`
- `reports/a2a/reply_receipts/20260619T071845Z-qwen_code-a2a-semantic-signoff-qwen_code-e4778df2dfe6.json`
- `reports/a2a/reply_receipts/20260619T071845Z-opus_composer-a2a-semantic-signoff-opus_composer-e4778df2dfe6.json`

Each receipt has:

- `status=NO_REPLY`
- `stream=A2A_INBOX`
- `reply_evidence_tier=NO_REPLY`
- `domain_receipt_claim=false`
- `semantic_reply_claim=false`

## Verification

- Focused:
  `uv run pytest -q tests/test_a2a_reply_capture.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_jetstream_topology.py --tb=short`
  - 36 passed.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Contract checker passed.
  - 137 passed.
- Broad A2A/runtime regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_semantic_task_packet.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - 273 passed.
  - Existing FastAPI/Starlette deprecation warning only.
- Context+ static analysis:
  - `scripts/runtime/a2a_reply_capture.py` clean.
  - `scripts/runtime/a2a_domain_reply_worker.py` clean.
- Compileall and `git diff --check` clean.

## Readiness

Latest readiness remains:
`reports/a2a/full_spec_readiness/20260619T071254_498167Z-a2a-full-spec-readiness.json`

Current score remains 25/100. No reply capture receipt can satisfy
`DOMAIN_RECEIPTED` or `SEMANTIC_SIGNED` because all five are `NO_REPLY`.
