# v12ad Presence Projector + Receipt-Backed Presence Preflight Checkpoint

## Scope

- Added `scripts/governance/a2a_presence_projector.py`.
- Added `make a2a-presence-projector`.
- Added receipt schema `dharma.a2a.presence_projector.v1`.
- Added projection schema `dharma.a2a.presence_projection.v1`.
- Kept projector dry-run by default; `--write-projections` is explicit.
- Preserved anti-fabrication boundary: transport heartbeat evidence never sets `peer_model_processed_claim=true` unless a valid current semantic receipt already exists.
- Updated `a2a_presence_preflight.py` to read latest valid projector receipts as projection evidence before falling back to raw heartbeats.
- Updated onboard operator commands with separate `project_presence` and `write_presence_projection` commands.
- Updated `NATS_SUBSTRATE_MASTER_SPEC.md` and `check_nats_substrate_contract.py`.
- Added `tests/test_a2a_presence_projector.py` and receipt-backed presence preflight coverage.

## Verification

- `uv run pytest -q tests/test_a2a_presence_projector.py tests/test_a2a_presence_preflight.py tests/test_a2a_onboard.py tests/test_a2a_full_spec_readiness.py --tb=short` -> 25 passed.
- `PYTHONPATH=. python3 scripts/governance/check_nats_substrate_contract.py` -> `NATS_CONTRACT_OK`.
- `python3 -m compileall -q scripts/governance/a2a_presence_projector.py scripts/governance/a2a_presence_preflight.py scripts/governance/a2a_onboard.py scripts/governance/check_nats_substrate_contract.py` -> clean.
- `uv run ruff check scripts/governance/a2a_presence_projector.py scripts/governance/a2a_presence_preflight.py tests/test_a2a_presence_projector.py tests/test_a2a_presence_preflight.py scripts/governance/a2a_onboard.py tests/test_a2a_onboard.py scripts/governance/check_nats_substrate_contract.py --select=F821,F401,F541` -> clean.
- `make lint-blockers` -> clean.
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short` -> 334 passed, 1 existing Starlette/httpx warning.
- `make nats-substrate-contract` -> 148 passed.

## Runtime Truth

- Dry-run projector receipt: `reports/a2a/presence_projection/20260619T075743_285060Z-a2a-presence-projector.json`.
- Refreshed presence preflight receipt: `reports/a2a/presence_preflight/20260619T080006_480317Z-a2a-presence-preflight.json`.
- Refreshed readiness receipt: `reports/a2a/full_spec_readiness/20260619T080013_029636Z-a2a-full-spec-readiness.json`.
- Prevalidate readiness remains 25/100.
- Identity presence is now reduced to two concrete blockers:
  - `qwen_code`: stale/expired presence evidence.
  - `opus_composer`: `claude-opus` alias collision with top-level `claude-opus`.

## Remaining Blockers

- Live topology still lacks `A2A_TASKS` and `A2A_RECEIPTS`.
- Legacy `DHARMA_A2A` still overlaps canonical subject space.
- Actual live cutover requires explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Actual live ACL probe execution requires explicit `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`.
- All counted agents still need target-owned domain reply artifacts and current `SEMANTIC_SIGNED` evidence.
- Wake-loop readiness remains red for standing target-owned semantic loops.
