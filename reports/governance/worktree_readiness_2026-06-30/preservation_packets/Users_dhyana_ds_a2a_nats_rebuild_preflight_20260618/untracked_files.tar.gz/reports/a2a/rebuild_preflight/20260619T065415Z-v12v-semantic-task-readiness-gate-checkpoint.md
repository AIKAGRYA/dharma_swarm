# v12v Semantic Task Readiness Gate Checkpoint

Timestamp: 2026-06-19T06:54:15Z

## Scope

- Integrated `dharma.a2a.semantic_task_packet.v1` receipts into the single
  full-spec readiness gate.
- Added semantic task packet receipt loading, optional generation via
  `--run-semantic-task-packet`, and explicit receipt-path override support in
  `scripts/governance/a2a_full_spec_readiness.py`.
- Added a `semantic_task_packets` readiness component that verifies:
  - counted-agent denominator;
  - locked spec SHA-256;
  - per-agent packet path;
  - recomputed packet SHA-256;
  - `task_hash == sha256:<packet_sha256>`;
  - required reply artifact schema;
  - required semantic receipt schema;
  - required `failure_digest` prompt.
- Split readiness weights so semantic task packets contribute `5/100` and
  counted-agent readiness contributes `15/100`.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py` so packet verification
  is a guarded part of the aggregate gate.

## Current Aggregate Readiness

Latest readiness receipt:
`reports/a2a/full_spec_readiness/20260619T065335_291720Z-a2a-full-spec-readiness.json`

Readiness is now `20/100`, fail-closed:

- `live_topology`: red
- `cutover_completion`: red
- `acl_probe_contract`: green
- `semantic_task_packets`: green
- `wake_loop_preflight`: red
- `counted_agent_readiness`: red

This is a real score movement: the task packets are now verified by the same
gate that will later judge domain and semantic receipts. It is not a peer-reply
claim.

## Evidence

- Semantic task packet receipt:
  `reports/a2a/semantic_task_packets/20260619T064716_415828Z-a2a-semantic-task-packet.json`
- Onboard receipt:
  `reports/a2a/onboard_receipts/20260619T064723.507208Z-a2a_onboard_20260619T064723_507208Z_084ddb29.json`
- Wake-loop preflight:
  `reports/a2a/wake_loop_preflight/20260619T064728_732708Z-a2a-wake-loop-preflight.json`

## Verification

- Focused tests:
  `uv run pytest -q tests/test_a2a_full_spec_readiness.py tests/test_a2a_semantic_task_packet.py --tb=short`
  - `11 passed`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `131 passed`
- Broad regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_semantic_task_packet.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `267 passed`, one existing FastAPI/Starlette deprecation warning.
- `python3 -m compileall -q ...`
  - passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `git diff --check`
  - passed
- Context+ static analysis on `scripts/governance/a2a_full_spec_readiness.py`
  - no issues found
- `uv.lock` was reverted after `uv run` churn.

## Remaining 100/100 Gates

- Explicit approval and execution for canonical live topology cutover.
- Explicit approval and execution for live ACL probes.
- Real target-owned standing wake-loop heartbeats for counted agents.
- Per-counted-agent target-owned domain receipts answering the generated
  semantic packets.
- Per-counted-agent current semantic receipts for the locked spec, using the
  generated task hashes and including `failure_digest`.
- Removal or replacement of session-scoped/evidence-only counted agents before
  they can satisfy standing-agent readiness.
