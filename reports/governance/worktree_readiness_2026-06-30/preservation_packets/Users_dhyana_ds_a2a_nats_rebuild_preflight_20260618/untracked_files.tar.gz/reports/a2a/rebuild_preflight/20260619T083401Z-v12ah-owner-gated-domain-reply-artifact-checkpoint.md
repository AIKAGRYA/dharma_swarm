# v12ah Owner-Gated Domain Reply Artifact Checkpoint

Timestamp: 2026-06-19T08:34:01Z

## Scope

Hardened and wired the target-owned domain reply artifact authoring path.

This slice updates:

- `scripts/runtime/a2a_domain_reply_artifact.py`
- `tests/test_a2a_domain_reply_artifact.py`
- `Makefile`
- `scripts/governance/a2a_onboard.py`
- `tests/test_a2a_onboard.py`
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `scripts/governance/check_nats_substrate_contract.py`

## Boundary

`make a2a-domain-reply-artifact` now writes an artifact only when:

- `A2A_DOMAIN_REPLY_ARTIFACT_AGENT` exactly matches the target `agent_uid`
- the artifact path is `~/.dharma/a2a_bus/outboxes/<agent_uid>/<packet_id>.json`
- semantic claims include `--peer-model-processed`, `--semantic-reply`, `model_identity`, receipt-bound `task_hash`, receipt-bound `locked_spec_sha256`, numeric `confidence`, at least one `evidence_ref`, and a `failure_digest` covering confused/tried/failed/worked

Owner mismatch writes a red `dharma.a2a.domain_reply_artifact_author_receipt.v1` receipt and writes no artifact.

No target outbox artifacts were authored in this checkpoint.

## Current Receipts

Domain reply artifact preflight:

- `reports/a2a/domain_reply_artifact_preflight/20260619T083342_229662Z-a2a-domain-reply-artifact-preflight.json`

Full-spec readiness refresh:

- `reports/a2a/full_spec_readiness/20260619T083346_420662Z-a2a-full-spec-readiness.json`

## Current Readiness

Score remains `25/100`.

The latest domain artifact preflight is red for the correct reason: each counted agent is missing an actual target-owned `dharma.a2a.domain_reply_artifact.v1` file at the expected owner-gated path.

## Verification

Passed:

- `uv run pytest -q tests/test_a2a_domain_reply_artifact.py tests/test_a2a_domain_reply_artifact_preflight.py tests/test_a2a_domain_reply_request.py tests/test_a2a_onboard.py --tb=short`
- `PYTHONPATH=. python3 scripts/governance/check_nats_substrate_contract.py`
- `python3 -m compileall -q scripts/runtime/a2a_domain_reply_artifact.py scripts/governance/a2a_onboard.py scripts/governance/check_nats_substrate_contract.py tests/test_a2a_domain_reply_artifact.py tests/test_a2a_onboard.py`
- `uv run ruff check scripts/runtime/a2a_domain_reply_artifact.py scripts/governance/a2a_onboard.py scripts/governance/check_nats_substrate_contract.py tests/test_a2a_domain_reply_artifact.py tests/test_a2a_onboard.py --select=F821,F401,F541`
- `make lint-blockers`
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short`
- `make nats-substrate-contract`

Expected red:

- `make a2a-domain-reply-artifact-preflight AGENT=all ARGS='--json'`
- `make a2a-full-spec-readiness AGENT=all MODE=prevalidate ARGS='--json'`

Both write receipts and exit nonzero because required target-owned artifacts and other live readiness evidence remain missing.

## Remaining Blockers

- live topology cutover remains gated by `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`
- actual live ACL execution remains gated by `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`
- qwen presence is stale/expired
- `opus_composer` alias collision remains unresolved
- target-owned domain reply artifacts are missing for all counted agents
- target-owned `DOMAIN_RECEIPTED` and current `SEMANTIC_SIGNED` evidence are missing for counted agents
- standing wake-loop evidence is still missing or session-scoped
