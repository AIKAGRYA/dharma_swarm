# A2A/NATS Full Spec Checkpoint - 2026-06-19T09:46:13Z

## Current Score

- Readiness score: 30/100
- Full spec ready: false
- Latest full-readiness receipt: `reports/a2a/full_spec_readiness/20260619T094826_715310Z-a2a-full-spec-readiness.json`
- Latest offline topology receipt: `reports/a2a/topology/20260619T094729_052358Z-a2a-jetstream-topology.json`
- Latest live topology receipt in aggregate: `reports/a2a/live_topology/20260619T094826Z-a2a-live-topology-probe.json`

## Work Completed

- Tightened `scripts/governance/a2a_full_spec_readiness.py` cutover accounting.
  - Failed live topology now carries the current offline topology proof as evidence.
  - Failed cutover completion now carries both the live topology probe and the offline topology proof.
  - When live topology is blocked by legacy overlap, the aggregate now validates that the cutover transaction receipt includes legacy cutover steps, rollback coverage, post-cutover follow-up steps, exact consumer config previews, and compensation coverage.
  - Green live topology remains green without requiring a stale cutover transaction.
- Updated `tests/test_a2a_full_spec_readiness.py` to assert topology evidence propagation and malformed cutover receipt detection.
- Generated fresh offline topology, read-only live topology, and full-readiness receipts with the stricter accounting.

## Current Topology/Cutover Evidence

- `live_topology` component evidence now includes:
  - `reports/a2a/live_topology/20260619T094826Z-a2a-live-topology-probe.json`
  - `reports/a2a/topology/20260619T094729_052358Z-a2a-jetstream-topology.json`
- `cutover_completion` component evidence now includes the same two receipts.
- The live cutover blocker remains:
  - `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`

## Still Not 100/100

- Live canonical streams `A2A_TASKS` and `A2A_RECEIPTS` are absent.
- Legacy `DHARMA_A2A` is still live and overlaps canonical A2A subjects.
- Live topology cutover remains explicitly gated and was not run.
- Live ACL probe remains explicitly gated and was not run.
- Devin and Opus still lack target-owned artifacts, domain receipts, semantic receipts, and standing wake-loop evidence.
- Codex and Qwen still have session/evidence-scoped wake-loop blockers.

## Verification

- `pytest -q tests/test_a2a_full_spec_readiness.py --tb=short`
  - Result: 9 passed
- `python3 -m compileall scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_full_spec_readiness.py`
  - Result: compiled cleanly
- `ruff check scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_full_spec_readiness.py --select=F821,F401,F541`
  - Result: all checks passed
- `make nats-substrate-contract`
  - Result: `NATS_CONTRACT_OK`; 172 tests passed
- `make lint-blockers`
  - Result: OK, no undefined names
- `make a2a-full-spec-readiness AGENT=all MODE=prevalidate ARGS='--run-topology --run-live-probe --json'`
  - Result: expected nonzero because full spec is not ready; wrote `reports/a2a/full_spec_readiness/20260619T094826_715310Z-a2a-full-spec-readiness.json` with score 30/100
