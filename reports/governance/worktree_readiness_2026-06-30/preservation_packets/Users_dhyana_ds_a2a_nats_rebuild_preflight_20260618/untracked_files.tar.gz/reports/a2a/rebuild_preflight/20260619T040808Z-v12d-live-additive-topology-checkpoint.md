# V12d Live Additive Topology Checkpoint

timestamp: 2026-06-19T04:08:08Z
branch: runtime-truth/nats-rebuild-preflight-20260618
worktree: /Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618

## Score

- Local/offline V12 implementation surface: 97/100.
- Full live 100/100 target: 88/100.

This pass moved Agni from pure legacy topology to a partial canonical live
topology without editing `DHARMA_A2A`.

## Live Changes Applied

Guarded command:

```bash
A2A_LIVE_TOPOLOGY_APPLY=approved-additive make a2a-live-topology ARGS='--json --apply-additive'
```

The additive guard allowed only non-overlapping canonical streams, KV buckets,
and consumers. It did not edit `DHARMA_A2A` and did not create cutover-blocked
`A2A_TASKS` or `A2A_RECEIPTS`.

Live Agni now has:

- `A2A_INBOX`
- `A2A_DLQ`
- `PRESENCE` KV bucket
- `A2A_INBOX/a2a_codex_composer_inbox`
- `A2A_INBOX/a2a_devin-roaming-2987d222_inbox`
- `A2A_INBOX/a2a_hermes-m5_inbox`
- `A2A_INBOX/a2a_qwen_code_inbox`
- `A2A_INBOX/a2a_opus_composer_inbox`
- `A2A_DLQ/a2a_dlq_operator_replay`

Evidence:

- Additive stream/KV install receipt:
  `reports/a2a/live_topology/20260619T040106Z-a2a-live-topology-probe.json`
- Additive consumer install receipt:
  `reports/a2a/live_topology/20260619T040240Z-a2a-live-topology-probe.json`
- Final read-only verification receipt:
  `reports/a2a/live_topology/20260619T040652Z-a2a-live-topology-probe.json`

## Corrections Found During Live Apply

Live Agni rejected `A2A_DLQ` with both `dharma.dlq.*` and `dharma.dlq.>` in
one stream. The canonical topology was corrected to `dharma.dlq.>` only.

The same correction was applied preemptively to `A2A_TASKS`: it now uses
`dharma.a2a.task.>` only, avoiding intra-stream subject overlap.

Live Agni also rejected `MaxDeliver=5` with five backoff values. The topology
verifier now requires `len(backoff) < MaxDeliver`; canonical backoffs are now:

- inbox / receipt indexer: `5s,30s,2m,10m` with `MaxDeliver=5`
- task consumers: `10s,1m` with `MaxDeliver=3`

## Verification

- `python3 scripts/governance/check_nats_substrate_contract.py` -> OK
- `uv run pytest ...` focused A2A/NATS/public/semantic suite -> 178 passed, 1 warning
- `make nats-substrate-contract PYTEST='uv run pytest'` -> 86 passed
- `python3 -m compileall -q dharma_swarm/a2a scripts/governance scripts/runtime` -> OK
- `git diff --check` -> OK
- `make a2a-topology AGENT=all ARGS=--json` -> passed and wrote
  `reports/a2a/topology/20260619T040759Z-a2a-jetstream-topology.json`

## Remaining Live Blockers

The final read-only live probe still fails, correctly:

- `A2A_TASKS` missing.
- `A2A_RECEIPTS` missing.
- `DHARMA_A2A` still owns `dharma.a2a.>`.
- That wildcard overlaps canonical `dharma.a2a.task.>`.

The migration plan now has no additive work left:

- `can_apply_additive=false`
- `can_apply_cutover=false`

Remaining work requires explicit cutover of the legacy wildcard stream:

1. Narrow `DHARMA_A2A` away from `dharma.a2a.>` to observed legacy subjects.
2. Create `A2A_TASKS`.
3. Create `A2A_RECEIPTS`.
4. Add task and receipt consumers.

This cutover can strand future legacy producers that still rely on
`dharma.a2a.>`, so it must not be done as an automatic additive step.

## Remaining Non-Topology 100/100 Blockers

- Per-agent ACL specs are rendered and offline-verified, but live scoped
  per-agent credentials/probes are not installed or executed.
- `make a2a-onboard` still fails closed on standing-loop and semantic receipt
  evidence:
  - `codex_composer`, `devin-roaming-2987d222`, and `opus_composer` are
    session/evidence scoped.
  - `hermes-m5` lacks a current valid `SEMANTIC_SIGNED` receipt.
  - `qwen_code` lacks a standing wake loop/handler ACK path.
- Mac-to-Agni leaf `/leafz` and both-way semantic request/reply acceptance are
  still unverified.
