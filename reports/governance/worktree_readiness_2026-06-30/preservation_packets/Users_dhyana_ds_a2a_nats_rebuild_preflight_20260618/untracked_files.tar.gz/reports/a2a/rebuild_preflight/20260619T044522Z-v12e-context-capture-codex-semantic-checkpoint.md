# A2A/NATS Rebuild Checkpoint: Context Capture + Codex Semantic Receipt

Timestamp: 2026-06-19T04:45:22Z

## What Changed

- `make a2a-onboard` now defaults to `NATS_CONTEXT=agni-wss` and forwards `ARGS`.
- NATS publish paths now support context-only configuration without falling back to local `NATS_URL`.
- `a2a_send.py` can publish through the NATS CLI when `NATS_CONTEXT` is selected.
- `a2a_domain_reply_worker.py` can publish target-owned domain replies through the NATS CLI context path.
- `a2a_reply_capture.py` can capture live JetStream reply payloads through `nats --context <name> stream get <stream> --last-for <reply_subject> --json` without creating consumers.
- `a2a_onboard.py` now carries full `failure_states` in rows, presence projections, and per-agent domain receipts.

## New Live Evidence

- Send receipt: `reports/a2a/send_receipts/20260619T043633Z-codex_composer-codex_onboard_semantic_20260619T0437Z.json`
- Domain reply publish receipt: `reports/a2a/domain_reply_receipts/20260619T043708Z-codex_composer-codex_onboard_semantic_20260619T0437Z.json`
- Semantic receipt: `reports/a2a/semantic_receipts/20260619T043708Z-codex_composer-codex_onboard_semantic_20260619T0437Z-semantic.json`
- Live reply capture receipt: `reports/a2a/reply_receipts/20260619T044423Z-codex_composer-codex_onboard_semantic_20260619T0437Z.json`
- Latest onboard run: `a2a_onboard_20260619T044433.567778Z_0a4624c5`

## Current Score

- Local/offline implementation: 98/100.
- Live full-spec implementation: 92/100.

## Current Live Blockers

- `codex_composer`: semantic signed and live domain reply captured, but still `DEGRADED_SESSION_SCOPED`.
- `devin-roaming-2987d222`: `DEGRADED_SESSION_SCOPED`, missing `SEMANTIC_SIGNED`.
- `hermes-m5`: missing `SEMANTIC_SIGNED`.
- `qwen_code`: `BLOCKED_WAKE_LOOP`, `DEGRADED_SESSION_SCOPED`, missing `SEMANTIC_SIGNED`, no handler ACK.
- `opus_composer`: `DEGRADED_SESSION_SCOPED`, missing `SEMANTIC_SIGNED`.
- Live topology still has legacy `DHARMA_A2A` owning `dharma.a2a.>`, so `A2A_TASKS` and `A2A_RECEIPTS` cannot be installed without a cutover/narrowing decision.
- Live ACL probes and Mac-to-Agni semantic roundtrip proof are still incomplete.

## Verification

- `uv run pytest -q tests/test_a2a_reply_capture.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_pr_merge_control.py tests/test_a2a_send.py tests/test_a2a_domain_reply_worker.py --tb=short` -> 98 passed.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short` -> 230 passed, 1 FastAPI/Starlette warning.
- `make nats-substrate-contract PYTEST='uv run pytest'` -> `NATS_CONTRACT_OK`, 94 passed.
- `python3 -m compileall -q scripts/runtime scripts/governance dharma_swarm/a2a` -> passed.
- `git diff --check` -> passed.
