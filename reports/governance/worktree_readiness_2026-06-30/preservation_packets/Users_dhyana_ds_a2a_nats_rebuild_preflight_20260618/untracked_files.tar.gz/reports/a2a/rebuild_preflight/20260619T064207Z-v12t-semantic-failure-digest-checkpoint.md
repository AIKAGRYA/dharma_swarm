# v12t Semantic Failure Digest Checkpoint

Timestamp: 2026-06-19T06:42:07Z

## Scope

- Tightened `scripts/runtime/a2a_domain_reply_worker.py` so semantic reply
  artifacts must include `failure_digest` before they can emit
  `dharma.a2a.semantic_receipt.v1`.
- Tightened `scripts/governance/a2a_onboard.py` so semantic receipts without
  `failure_digest` no longer count as `SEMANTIC_SIGNED`.
- Updated test fixtures and added explicit rejection coverage for
  missing-digest semantic receipts.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py` to guard the
  failure-digest requirement.

## Why This Matters

The locked spec requires each agent to publish a short failure digest before
signoff: what confused it, what it tried, what failed, and what finally worked.
This change prevents a model-authored semantic receipt from satisfying readiness
with only a verdict, confidence, and evidence refs.

## Receipts

- Wake-loop preflight:
  `reports/a2a/wake_loop_preflight/20260619T064122_048504Z-a2a-wake-loop-preflight.json`
- Aggregate readiness:
  `reports/a2a/full_spec_readiness/20260619T064126_221132Z-a2a-full-spec-readiness.json`

## Current Aggregate Readiness

Readiness remains `15/100`, fail-closed:

- `live_topology`: red
- `cutover_completion`: red
- `acl_probe_contract`: green
- `wake_loop_preflight`: red
- `counted_agent_readiness`: red

The latest preflight now also marks `codex_composer` as
`BLOCKED_SEMANTIC_RECEIPT` because the prior semantic receipt did not include
the newly required `failure_digest`.

## Verification

- Focused tests:
  `uv run pytest -q tests/test_a2a_domain_reply_worker.py tests/test_a2a_onboard.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_standing_wake_loop.py --tb=short`
  - `22 passed`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `127 passed`
- Broad regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `263 passed`, one existing FastAPI/Starlette deprecation warning.
- `python3 -m compileall -q ...`
  - passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `git diff --check`
  - passed
- Context+ static analysis on `scripts/runtime/a2a_domain_reply_worker.py`
  and `scripts/governance/a2a_onboard.py`
  - no issues found
- `uv.lock` was reverted after `uv run` churn.

## Remaining 100/100 Gates

- Explicit approval and execution for canonical live topology cutover.
- Explicit approval and execution for live ACL probes.
- Real target-owned standing wake-loop heartbeats for counted agents.
- Per-counted-agent target-owned domain receipts.
- Per-counted-agent current semantic receipts for the locked spec, now with
  `failure_digest`.
- Removal or replacement of session-scoped/evidence-only counted agents before
  they can satisfy standing-agent readiness.
