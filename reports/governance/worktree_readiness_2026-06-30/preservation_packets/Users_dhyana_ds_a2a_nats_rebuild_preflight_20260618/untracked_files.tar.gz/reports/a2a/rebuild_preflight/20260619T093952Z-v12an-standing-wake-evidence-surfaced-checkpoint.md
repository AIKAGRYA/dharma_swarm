# A2A/NATS Full Spec Checkpoint - 2026-06-19T09:39:52Z

## Current Score

- Readiness score: 30/100
- Full spec ready: false
- Latest full-readiness receipt: `reports/a2a/full_spec_readiness/20260619T093924_659967Z-a2a-full-spec-readiness.json`
- Latest wake-loop preflight receipt: `reports/a2a/wake_loop_preflight/20260619T093924_657265Z-a2a-wake-loop-preflight.json`

## Work Completed

- `a2a_wake_loop_preflight.py` now surfaces the latest standing wake-loop receipt per agent.
  - Rows include latest standing wake-loop receipt path, status, blockers, wrote-heartbeat flag, and session-scoped flag.
  - Session/evidence-scoped failures now carry receipt-backed blocker lines.
- `a2a_full_spec_readiness.py` now propagates row-level wake-loop evidence paths into the wake-loop component and top-level evidence list.
- Generated non-mutating dry-run standing wake-loop attempt receipts for the remaining non-ready lanes:
  - `codex_composer`
  - `devin-roaming-2987d222`
  - `qwen_code`
  - `opus_composer`
- These dry-runs wrote no heartbeats and correctly failed closed with `DEGRADED_SESSION_SCOPED`.

## Current Wake-Loop Evidence

- `hermes-m5` remains the only non-session-scoped lane with a written standing wake-loop heartbeat.
- `codex_composer`, `devin-roaming-2987d222`, `qwen_code`, and `opus_composer` now have explicit standing wake-loop attempt receipts proving `wrote_heartbeat=false` and `session_scoped=true`.
- The aggregate readiness evidence list now includes those standing wake-loop receipts.

## Still Not 100/100

- Live canonical streams `A2A_TASKS` and `A2A_RECEIPTS` are absent.
- Legacy `DHARMA_A2A` is still live and overlaps canonical A2A subjects.
- Live topology cutover remains explicitly gated.
- Live ACL probe remains explicitly gated.
- Devin and Opus still lack target-owned artifacts, domain receipts, semantic receipts, and standing wake-loop evidence.
- Codex and Qwen still have session/evidence-scoped wake-loop blockers.

## Verification

- `pytest -q tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py --tb=short`
  - Result: 13 passed
- `uv run ruff check scripts/governance/a2a_wake_loop_preflight.py scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py --select=F821,F401,F541`
  - Result: all checks passed
- `python3 -m compileall scripts/governance/a2a_wake_loop_preflight.py scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py`
  - Result: compiled cleanly
- `make nats-substrate-contract`
  - Result: `NATS_CONTRACT_OK`; 172 tests passed
- `make lint-blockers`
  - Result: OK, no undefined names

