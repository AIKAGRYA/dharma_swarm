# A2A/NATS Full Spec Checkpoint - 2026-06-19T09:36:22Z

## Current Score

- Readiness score: 30/100
- Full spec ready: false
- Latest full-readiness receipt: `reports/a2a/full_spec_readiness/20260619T093600_741133Z-a2a-full-spec-readiness.json`
- Latest domain artifact preflight receipt: `reports/a2a/domain_reply_artifact_preflight/20260619T093600_737774Z-a2a-domain-reply-artifact-preflight.json`

## Work Completed

- `a2a_domain_reply_artifact_preflight.py` now surfaces latest target-model capture evidence per semantic packet.
  - Rows include latest model-capture receipt path, status, blockers, stdout tail, stderr tail, and wrote-artifact flag.
  - Missing target-owned artifacts now include capture status/blocker lines when a capture attempt exists.
- `a2a_full_spec_readiness.py` now propagates row-level domain-artifact evidence paths into the domain component and top-level evidence list.
- Focused regression tests cover:
  - Missing target-owned artifact with a failed model-capture receipt.
  - Aggregate readiness evidence propagation for row-level capture evidence.

## Current External Blockers Preserved In Evidence

- `devin-roaming-2987d222`
  - Latest capture receipt: `reports/a2a/model_reply_captures/20260619T092840Z-devin-roaming-2987d222-a2a-semantic-signoff-devin-roaming-2987d222-e4778df2dfe6.json`
  - Status: `MODEL_COMMAND_FAILED`
  - Artifact written: false
- `opus_composer`
  - Latest capture receipt: `reports/a2a/model_reply_captures/20260619T093140Z-opus_composer-a2a-semantic-signoff-opus_composer-e4778df2dfe6.json`
  - Status: `MODEL_COMMAND_FAILED`
  - Artifact written: false
  - The receipt records the stdout-only blocker from Claude.

## Still Not 100/100

- Live canonical streams `A2A_TASKS` and `A2A_RECEIPTS` are absent.
- Legacy `DHARMA_A2A` is still live and overlaps canonical A2A subjects.
- Live topology cutover remains explicitly gated.
- Live ACL probe remains explicitly gated.
- Devin and Opus still lack target-owned artifacts, domain receipts, semantic receipts, and standing wake-loop evidence.
- Codex and Qwen still have session/evidence-scoped wake-loop blockers.

## Verification

- `pytest -q tests/test_a2a_domain_reply_artifact_preflight.py tests/test_a2a_full_spec_readiness.py --tb=short`
  - Result: 13 passed
- `uv run ruff check scripts/governance/a2a_domain_reply_artifact_preflight.py scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_domain_reply_artifact_preflight.py tests/test_a2a_full_spec_readiness.py --select=F821,F401,F541`
  - Result: all checks passed
- `python3 -m compileall scripts/governance/a2a_domain_reply_artifact_preflight.py scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_domain_reply_artifact_preflight.py tests/test_a2a_full_spec_readiness.py`
  - Result: compiled cleanly
- `make nats-substrate-contract`
  - Result: `NATS_CONTRACT_OK`; 171 tests passed
- `make lint-blockers`
  - Result: OK, no undefined names

