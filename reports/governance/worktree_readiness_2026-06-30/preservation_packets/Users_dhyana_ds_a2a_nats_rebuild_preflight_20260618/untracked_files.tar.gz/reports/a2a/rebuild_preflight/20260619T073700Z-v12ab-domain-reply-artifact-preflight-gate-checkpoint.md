# v12ab Domain Reply Artifact Preflight Gate Checkpoint

## Summary

Added a read-only domain reply artifact preflight and wired it into the A2A/NATS full-spec readiness gate.

The rebuild remains **25/100** in prevalidate mode and **10/100** in live mode. This is expected: the operator has valid semantic task packets and semantic send receipts, but the counted target agents have not produced target-owned semantic reply artifacts in their outboxes.

## Implementation

- Added `scripts/governance/a2a_domain_reply_artifact_preflight.py`.
- Added `make a2a-domain-reply-artifact-preflight`.
- Added `domain_reply_artifacts` to `scripts/governance/a2a_full_spec_readiness.py`.
- Kept the readiness total at 100 by moving `counted_agent_readiness` from 10 to 5 points.
- Updated `make a2a-onboard` operator commands to include the artifact preflight.
- Corrected reply capture operator guidance to use `A2A_INBOX`.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- Updated `scripts/governance/check_nats_substrate_contract.py`.
- Added `tests/test_a2a_domain_reply_artifact_preflight.py`.
- Updated readiness and onboard tests for the new gate.

## Receipts

- Domain artifact preflight: `reports/a2a/domain_reply_artifact_preflight/20260619T073619_002086Z-a2a-domain-reply-artifact-preflight.json`
- Prevalidate readiness: `reports/a2a/full_spec_readiness/20260619T073619_004451Z-a2a-full-spec-readiness.json`
- Live readiness: `reports/a2a/full_spec_readiness/20260619T073623_596183Z-a2a-full-spec-readiness.json`

## Verification

- `uv run pytest -q tests/test_a2a_domain_reply_artifact_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py --tb=short` => 20 passed
- `make nats-substrate-contract` => 140 passed
- `uv run pytest -q tests/test_a2a*.py tests/test_nats*.py --tb=short` => 326 passed, 1 existing FastAPI/Starlette warning
- `.venv/bin/python -m compileall -q ...` on touched Python files => clean
- `uv run ruff check ... --select=F821,F401,F541` => clean
- `make lint-blockers` => clean

## Remaining Blockers

- Live topology still lacks `A2A_TASKS` and `A2A_RECEIPTS`.
- Legacy `DHARMA_A2A` still owns canonical subject space.
- Actual topology cutover requires explicit `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover` approval.
- Live ACL execution requires explicit `A2A_LIVE_ACL_PROBE=approved-live-acl-probe` approval.
- All five counted agents are missing target-owned `dharma.a2a.domain_reply_artifact.v1` artifacts.
- Wake-loop and counted-agent readiness remain red because standing target-owned domain/semantic evidence is absent.
