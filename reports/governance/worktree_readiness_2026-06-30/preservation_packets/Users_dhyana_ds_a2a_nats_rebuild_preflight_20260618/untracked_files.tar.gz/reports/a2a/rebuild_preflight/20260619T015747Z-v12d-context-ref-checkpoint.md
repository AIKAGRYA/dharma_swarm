# A2A/NATS v12d Context-Reference Checkpoint

Timestamp: 2026-06-19T01:57:47Z

Branch: runtime-truth/nats-rebuild-preflight-20260618
Base commit: 86418541a99c265c09040b9bfc064625c6d59994
HEAD: 86418541a99c265c09040b9bfc064625c6d59994
Worktree: /Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618

## Result

Local/offline implementation and verification are complete. The saved NATS context `agni-wss` now satisfies the onboarding credential-reference prevalidate gate via `NATS_CONTEXT=agni-wss` or `AGNI_NATS_CONTEXT=agni-wss`.

Live mode remains fail-closed until explicit operator approval is present. With `NATS_CONTEXT=agni-wss` but no `A2A_LIVE_OPERATOR_APPROVAL=approved-a2a-live`, every counted seat returns `BLOCKED_LIVE_CALL_FORBIDDEN`.

## Counted seats

- codex_composer
- devin-roaming-2987d222
- hermes-m5
- qwen_code
- opus_composer

## Current receipts

- Topology verifier: `reports/a2a/topology/20260619T015714Z-a2a-jetstream-topology.json`
- Prevalidate contract verifier run: `a2a_onboard_20260619T015659.860232Z_a5452420`
- Prevalidate domain receipts:
  - `reports/a2a/domain_receipts/20260619T015659.860232Z-a2a_onboard_20260619T015659_860232Z_a5452420-codex_composer.json`
  - `reports/a2a/domain_receipts/20260619T015659.860232Z-a2a_onboard_20260619T015659_860232Z_a5452420-devin-roaming-2987d222.json`
  - `reports/a2a/domain_receipts/20260619T015659.860232Z-a2a_onboard_20260619T015659_860232Z_a5452420-hermes-m5.json`
  - `reports/a2a/domain_receipts/20260619T015659.860232Z-a2a_onboard_20260619T015659_860232Z_a5452420-opus_composer.json`
  - `reports/a2a/domain_receipts/20260619T015659.860232Z-a2a_onboard_20260619T015659_860232Z_a5452420-qwen_code.json`
- Live-guard proof run: `a2a_onboard_20260619T015709.931383Z_0ee2e012`

## Verification

- `uv run pytest -q tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_jetstream_topology.py --tb=short`
  - PASS: 14 passed
- `uv run pytest -q tests/test_a2a_jetstream_topology.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py --tb=short`
  - PASS: 65 passed
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - PASS: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - PASS: substrate contract check plus 62 passed
- `NATS_CONTEXT=agni-wss make a2a-onboard AGENT=all BROKER=agni MODE=prevalidate`
  - Expected fail-closed exit through make: final aggregate exit 16
  - No `BLOCKED_SECRET_REFERENCE`
  - Current blockers: `DEGRADED_SESSION_SCOPED`, `BLOCKED_SEMANTIC_RECEIPT`, `BLOCKED_WAKE_LOOP`
- `NATS_CONTEXT=agni-wss python3 scripts/governance/check_a2a_onboard_contract.py --agent all --broker agni --mode prevalidate --json`
  - PASS: all five fresh domain receipts verified; `HANDLER_ACKED` recorded as rejected-as-sufficient
- `NATS_CONTEXT=agni-wss make a2a-onboard AGENT=all BROKER=agni MODE=live`
  - Expected fail-closed exit through make: final aggregate exit 17
  - All five counted seats returned `BLOCKED_LIVE_CALL_FORBIDDEN`
- `make a2a-topology AGENT=all ARGS=--json`
  - PASS: writes topology receipt and command recipe for `A2A_INBOX`, `A2A_TASKS`, `A2A_RECEIPTS`, `A2A_DLQ`, `PRESENCE`, durable consumers, duplicate windows, max-deliver/backoff, DLQ replay, and migration aliases.

## Changed files

Tracked modifications:

- `Makefile`
- `dharma_swarm/a2a/__init__.py`
- `dharma_swarm/a2a/nats_transport.py`
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `reports/governance/active_track_evidence.json`
- `reports/governance/active_track_evidence.md`
- `reports/governance/track_portfolio.json`
- `scripts/governance/check_nats_substrate_contract.py`
- `scripts/runtime/a2a_domain_reply_worker.py`
- `scripts/runtime/a2a_inbox_bridge.py`
- `scripts/runtime/a2a_reply_capture.py`
- `scripts/runtime/a2a_send.py`
- `tests/test_a2a_domain_reply_worker.py`
- `tests/test_a2a_inbox_bridge.py`
- `tests/test_a2a_reply_capture.py`
- `tests/test_a2a_send.py`
- `tests/test_nats_transport.py`

New files/directories:

- `dharma_swarm/a2a/jetstream_topology.py`
- `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md`
- `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.sha256`
- `reports/a2a/rebuild_preflight/`
- `reports/a2a/topology/`
- `scripts/governance/a2a_jetstream_topology.py`
- `scripts/governance/a2a_onboard.py`
- `scripts/governance/check_a2a_onboard_contract.py`
- `tests/test_a2a_jetstream_topology.py`
- `tests/test_a2a_onboard.py`
- `tests/test_a2a_onboard_contract_verifier.py`

## Remaining external blockers

- Operator approval is absent: `A2A_LIVE_OPERATOR_APPROVAL=approved-a2a-live` is not set.
- Live Agni contact has not been attempted in this checkpoint; the selected context is only accepted as a credential reference until live approval is explicitly present.
- Runtime readiness is not green:
  - `qwen_code` still lacks a fresh receipt-producing wake loop.
  - `hermes-m5` lacks a model-processed semantic receipt.
  - `codex_composer`, `devin-roaming-2987d222`, and `opus_composer` remain session/evidence scoped instead of standing loops.

## Continue commands

Prevalidate with the saved Agni context:

```bash
NATS_CONTEXT=agni-wss make a2a-onboard AGENT=all BROKER=agni MODE=prevalidate
NATS_CONTEXT=agni-wss python3 scripts/governance/check_a2a_onboard_contract.py --agent all --broker agni --mode prevalidate --json
```

Show the topology installation recipe:

```bash
make a2a-topology AGENT=all ARGS='--commands'
```

Live rollout after explicit operator approval:

```bash
export NATS_CONTEXT=agni-wss
export A2A_LIVE_OPERATOR_APPROVAL=approved-a2a-live
make a2a-onboard AGENT=all BROKER=agni MODE=live
python3 scripts/governance/check_a2a_onboard_contract.py --agent all --broker agni --mode live --json
make nats-substrate-contract PYTEST='uv run pytest'
```
