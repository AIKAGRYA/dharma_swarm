# v12g Cutover Dry-Run Checkpoint

Timestamp: 2026-06-19T05:02:04Z

## Honest Score

- Local/offline implementation: 98/100.
- Live full-spec implementation: 91/100.

The score did not move to 100/100 because the live broker still has an
uncut legacy stream: `DHARMA_A2A` owns `dharma.a2a.>`, so `A2A_TASKS` and
`A2A_RECEIPTS` remain absent and cannot be safely installed without the
explicit legacy cutover approval gate.

## Completed In This Pass

- Hardened live cutover dry-run handling in
  `scripts/governance/a2a_live_topology_probe.py`.
- `nats stream edit --dry-run` returns exit code `1` when it prints a valid
  diff. That case is now treated as a successful dry-run validation only when:
  - the command is `stream edit`;
  - `--dry-run` is present;
  - stdout begins with `Differences`;
  - stderr is empty.
- The original NATS return code remains in the receipt, while
  `effective_returncode: 0` and `dry_run_diff_detected: true` record the
  normalized validation outcome.
- Added focused regression coverage in `tests/test_a2a_live_topology_probe.py`.

## Live Dry-Run Receipt

Receipt:
`reports/a2a/live_topology/20260619T050108Z-a2a-live-topology-probe.json`

Key facts:

- `cutover_topology_requested: true`
- `cutover_topology_dry_run: true`
- `mutation_performed: false`
- `cutover_results[0].passed: true`
- `cutover_results[0].returncode: 1`
- `cutover_results[0].effective_returncode: 0`
- `cutover_results[0].dry_run_diff_detected: true`

The dry-run validated the exact proposed narrowing of `DHARMA_A2A` from
`dharma.a2a.>` to currently active observed subjects:

- `dharma.a2a.codex`
- `dharma.a2a.codex.ack.phone-codex-003-1781798439`
- `dharma.a2a.codex.ack.phone-codex-004`
- `dharma.a2a.codex.ack.phone-codex-005`
- `dharma.a2a.devin`
- `dharma.a2a.fleet`
- `dharma.a2a.merge_master_mike`

## Current Live Blockers

- Missing canonical streams: `A2A_TASKS`, `A2A_RECEIPTS`.
- Legacy stream still present: `DHARMA_A2A`.
- Live subject overlap remains:
  `DHARMA_A2A:dharma.a2a.> overlaps canonical dharma.a2a.task.>`.
- Actual mutation remains fail-closed unless
  `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover` is set.
- Non-Codex counted seats still lack target-owned domain effect receipts and
  semantic receipts after proof-tier hardening.

## Verification

- `uv run pytest -q tests/test_a2a_live_topology_probe.py tests/test_a2a_jetstream_topology.py --tb=short`
  - `20 passed`
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `.venv/bin/python scripts/governance/a2a_live_topology_probe.py --context agni-wss --cutover-topology --dry-run-cutover --json`
  - exited `1` because the live topology still fails overall;
  - dry-run cutover step itself passed;
  - wrote `reports/a2a/live_topology/20260619T050108Z-a2a-live-topology-probe.json`.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - `235 passed, 1 warning`
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - `99 passed`
- `python3 -m compileall -q scripts/runtime scripts/governance dharma_swarm/a2a`
  - passed
- `git diff --check`
  - passed

## Next Move

The implementation is ready for either:

1. an explicit live topology cutover run with
   `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`, followed by installing
   `A2A_TASKS`, `A2A_RECEIPTS`, and their exact-config consumers; or
2. continued non-mutating work on the remaining counted seats: produce
   target-owned domain effect receipts and semantic receipts for non-Codex
   agents, and resolve the `qwen_code` wake loop.
