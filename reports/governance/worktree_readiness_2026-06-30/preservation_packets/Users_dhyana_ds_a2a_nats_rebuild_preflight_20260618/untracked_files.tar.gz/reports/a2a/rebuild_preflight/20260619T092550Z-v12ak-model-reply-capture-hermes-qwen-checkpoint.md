# A2A/NATS Full Spec Checkpoint - 2026-06-19T09:25:50Z

## Current Score

- Readiness score: 30/100
- Full spec ready: false
- Latest full-readiness receipt: `reports/a2a/full_spec_readiness/20260619T092451_265225Z-a2a-full-spec-readiness.json`
- Rule: 100/100 still requires live canonical topology, completed cutover, per-agent ACL evidence, semantic task/send receipts, fresh identity/presence, target-owned semantic domain replies, wake-loop preflight, and counted agent readiness for all required agents.

## Verified Passed Components

- `acl_probe_contract`
- `semantic_task_packets`
- `semantic_send_receipts`
- `identity_presence`

## Newly Closed Work

- Added provenance-preserving target-model stdout capture:
  - `scripts/runtime/a2a_model_reply_capture.py`
  - `tests/test_a2a_model_reply_capture.py`
  - Make target: `a2a-model-reply-capture`
- The helper writes a target outbox artifact only after validating the model-authored JSON against delivery, send receipt, locked spec hash, model identity, semantic/peer claims, and failure digest requirements.
- Hermes now has a target-model-captured domain reply artifact, domain receipt, semantic receipt, standing wake-loop heartbeat, and `READY_PREVALIDATED` onboard state.
- Qwen now has a target-model-captured domain reply artifact plus domain and semantic receipts, but remains session-scoped and therefore not wake-loop ready.

## Current Agent State

- `hermes-m5`: `READY_PREVALIDATED`.
- `qwen_code`: domain/semantic signed, but `DEGRADED_SESSION_SCOPED`; missing standing wake-loop lease and circuit-breaker evidence.
- `codex_composer`: domain/semantic signed, but `DEGRADED_SESSION_SCOPED`; missing standing wake-loop lease and circuit-breaker evidence.
- `devin-roaming-2987d222`: missing target-owned domain reply artifact, domain receipt, and semantic receipt. Current external blocker: model message rate limit.
- `opus_composer`: missing target-owned domain reply artifact, domain receipt, and semantic receipt. Current external blocker: Claude CLI credit balance too low.

## Remaining Blocker Classes

- Live canonical topology is not installed: `A2A_TASKS` and `A2A_RECEIPTS` are absent live.
- Legacy `DHARMA_A2A` stream is still present and overlaps canonical `dharma.a2a.task.>`.
- Live topology cutover remains explicitly gated by `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Live ACL probe remains explicitly gated by `A2A_LIVE_ACL_PROBE=approved-live-acl-probe`.
- Devin and Opus need target-owned model artifacts before their domain/semantic receipts can be validly published.
- Codex and Qwen need standing target-owned wake-loop identities; session-scoped evidence is intentionally fail-closed.

## Verification

- `pytest -q tests/test_a2a_model_reply_capture.py tests/test_a2a_domain_reply_artifact_preflight.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_onboard.py --tb=short`
  - Result: 34 passed
- `uv run ruff check scripts/runtime/a2a_model_reply_capture.py tests/test_a2a_model_reply_capture.py --select=F821,F401,F541,E501`
  - Result: all checks passed
- `python3 -m compileall scripts/runtime/a2a_model_reply_capture.py tests/test_a2a_model_reply_capture.py`
  - Result: compiled cleanly
- `make nats-substrate-contract`
  - Result: `NATS_CONTRACT_OK`; 166 tests passed
- `make lint-blockers`
  - Result: OK, no undefined names

