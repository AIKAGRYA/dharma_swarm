# A2A/NATS Rebuild Lane Ownership Map

Mission: v12d A2A/NATS rebuild preflight/scaffold.

Track binding: `runtime-truth-nats-2026-06`.

Worktree: `/Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618`.

Branch: `runtime-truth/nats-rebuild-preflight-20260618`.

Base commit: `86418541a99c265c09040b9bfc064625c6d59994`.

Locked spec: `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md`.

Locked spec SHA-256: `e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899`.

Global verifier: `python3 scripts/governance/check_a2a_onboard_contract.py --json`.

## Coordination Rules

- Do not edit `/Users/dhyana/dharma_swarm`; it is dirty and not on `origin/main`.
- Do not change the locked spec during implementation.
- Do not claim readiness from `HANDLER_ACKED`; `DOMAIN_RECEIPTED` is required for the onboard verifier.
- Keep lane 6 evaluator-only. It may write reports and tests, but it must not edit core implementation files.
- Every lane must name changed files and verifier output before handoff.

## Lanes

| Lane | Owner Role | Write Scope | Primary Deliverable | Lane Verifier | Stop Condition |
|---|---|---|---|---|---|
| 1 | CLI/build-contract worker | `Makefile`, `scripts/runtime/a2a_onboard.py`, `tests/test_a2a_onboard_contract*.py`, `reports/a2a/onboard/**` | `make a2a-onboard AGENT=all BROKER=agni MODE=prevalidate` exists, prints explicit per-agent states, and writes machine JSON receipts. | `python3 scripts/governance/check_a2a_onboard_contract.py --json` plus targeted pytest for onboard parsing/exit codes. | Target exists and fails loud with actionable blockers until real receipts exist. |
| 2 | NATS topology worker | `scripts/runtime/a2a_nats_topology.py`, `scripts/governance/check_a2a_nats_topology.py`, `tests/test_a2a_nats_topology*.py`, `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` | Installer/verifier for `A2A_INBOX`, `A2A_TASKS`, `A2A_RECEIPTS`, `A2A_DLQ`, durable consumers, duplicate windows, max deliver, DLQ policy, and migration aliases. | Topology verifier against local fixtures; live mode must remain explicit. | Local fixture verifier proves intended stream/consumer contract or emits exact live blocker. |
| 3 | Send/dedup/receipts/DLQ worker | `scripts/runtime/a2a_send.py`, `scripts/runtime/a2a_reply_capture.py`, `scripts/runtime/a2a_domain_reply_worker.py`, `dharma_swarm/a2a/nats_transport.py`, matching tests | Canonical send path carries `Nats-Msg-Id`, dedup identity, typed DLQ/quarantine, and real `DOMAIN_RECEIPTED` receipt handling. | Existing A2A send/reply/domain worker tests plus new DOMAIN_RECEIPTED negative/positive tests. | `HANDLER_ACKED` cannot satisfy the global verifier; fake domain receipts are rejected. |
| 4 | Registry/Semantic Commons/A2AInboxRoute worker | `docs/ontology/**`, `dharma_swarm/a2a/agent_card.py`, registry/projection code, A2A card tests | One canonical UID/alias/inbox route projection; no duplicate inbox identities count as seats. | Semantic Commons and A2A card tests; onboard receipt fixture uses canonical UIDs only. | Five-seat denominator is explicit or blocked, never inferred from folders/cards. |
| 5 | Presence/liveness/wake-loop worker | presence projection modules, wake-loop code, `reports/a2a/onboard/**`, targeted tests | Two-axis liveness: transport state, heartbeat freshness, domain receipt freshness, semantic receipt freshness, and wake-loop blocker states. | Fixture-driven presence/liveness tests; no stale success allowed. | Onboard output can distinguish `READY_TRANSPORT`, `READY_DOMAIN`, `READY_SEMANTIC`, and `BLOCKED_*`. |
| 6 | Evaluator-only adversary | `reports/a2a/rebuild_preflight/**`, evaluator tests/reports only | Break false-green claims, verify lane outputs against locked spec, and inspect for overclaiming around `HANDLER_ACKED`, stale heartbeats, and filesystem mirror evidence. | Re-run global verifier and lane verifiers from fresh context; produce evaluator report. | Any broad claim without locked-spec evidence is marked blocker; no core edits. |
