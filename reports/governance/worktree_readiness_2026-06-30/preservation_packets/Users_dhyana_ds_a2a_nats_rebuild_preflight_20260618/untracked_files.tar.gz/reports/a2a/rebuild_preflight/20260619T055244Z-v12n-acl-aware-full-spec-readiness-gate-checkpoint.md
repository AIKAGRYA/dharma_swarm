# A2A/NATS Rebuild Preflight Checkpoint v12n

Timestamp: 2026-06-19T05:52:44Z

## Status

- Local/offline gate coverage remains 99/100, with the aggregate gate now covering ACL/security proof instead of only topology plus semantic readiness.
- Live full-spec score remains 91/100.
- Current aggregate readiness score is 15/100 because the ACL prevalidate component is green while live topology, cutover, and counted-agent readiness remain red.
- No live topology mutation was performed in this pass.

## Completed In This Pass

- Extended `scripts/governance/a2a_full_spec_readiness.py` with an `acl_probe_contract` component.
- Added `--run-topology` and `--topology-receipt` support to the full-spec readiness gate.
- The gate now verifies:
  - counted ACL denominator matches the canonical counted seats;
  - each counted seat has canonical `a2a_<agent_uid>` principal form;
  - required positive probes are present;
  - required negative probes are present;
  - broad fleet subscription and JetStream mutation API denies are present;
  - live mode does not pass without `live_acl_probe_verification.passed=true`.
- Updated `tests/test_a2a_full_spec_readiness.py` with ACL denominator drift, live ACL missing, and live ACL present cases.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` so the full-spec readiness gate explicitly includes ACL proof.
- Updated `scripts/governance/check_nats_substrate_contract.py` to require the ACL-aware readiness gate phrases.

## Verification

- `uv run pytest -q tests/test_a2a_full_spec_readiness.py --tb=short`
  - Result: 6 passed.
- `python3 -m compileall -q scripts/governance/a2a_full_spec_readiness.py tests/test_a2a_full_spec_readiness.py`
  - Result: passed.
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - Result: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- `uv run pytest -q tests/test_a2a_full_spec_readiness.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py --tb=short`
  - Result: 35 passed.
- Context+ static analysis on `/Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618/scripts/governance/a2a_full_spec_readiness.py`
  - Result: no issues found.
- `make a2a-full-spec-readiness PYTEST='uv run pytest' ARGS='--run-topology --run-onboard --json'`
  - Result: expected non-zero make exit because full-spec readiness remains red; ACL component passed.
  - Receipt: `reports/a2a/full_spec_readiness/20260619T055121_955549Z-a2a-full-spec-readiness.json`.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Result: contract OK, 114 tests passed.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - Result: 250 passed, 1 warning.
- `make a2a-full-spec-readiness PYTEST='uv run pytest' ARGS='--run-topology --run-onboard --run-live-probe --json'`
  - Result: expected non-zero make exit; fresh read-only live probe was run; no mutation.
  - Receipt: `reports/a2a/full_spec_readiness/20260619T055237_632548Z-a2a-full-spec-readiness.json`.
  - Live topology evidence: `reports/a2a/live_topology/20260619T055237Z-a2a-live-topology-probe.json`.
  - Topology/ACL evidence: `reports/a2a/topology/20260619T055140_394929Z-a2a-jetstream-topology.json`.
  - Onboard evidence: `reports/a2a/onboard_receipts/20260619T055140.395477Z-a2a_onboard_20260619T055140_395477Z_ef416cd8.json`.
- `git diff --check`
  - Result: passed before checkpoint creation.
- `git checkout -- uv.lock`
  - Result: removed verification-induced lockfile churn.

## Current Full-Spec Readiness Receipt

`reports/a2a/full_spec_readiness/20260619T055237_632548Z-a2a-full-spec-readiness.json` records:

- `acl_probe_contract`: passed.
- `live_topology`: failed because `A2A_TASKS` and `A2A_RECEIPTS` are not live and `DHARMA_A2A` still owns `dharma.a2a.>`.
- `cutover_completion`: failed because `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover` has not been set and applied.
- `counted_agent_readiness`: failed because counted seats still lack target-owned domain/semantic receipts or standing wake-loop evidence.

## Live Blockers Remaining

- Actual topology cutover still requires explicit approval before any live mutation.
- `A2A_TASKS` and `A2A_RECEIPTS` are still not live.
- `DHARMA_A2A` still overlaps canonical subject space.
- Non-Codex counted seats still need target-owned domain and semantic receipts.
- Session-scoped seats need standing wake-loop promotion or an explicit denominator ruling.
- `qwen_code` still needs real wake-loop evidence.
- Live mode additionally needs live ACL positive/negative probe evidence.
