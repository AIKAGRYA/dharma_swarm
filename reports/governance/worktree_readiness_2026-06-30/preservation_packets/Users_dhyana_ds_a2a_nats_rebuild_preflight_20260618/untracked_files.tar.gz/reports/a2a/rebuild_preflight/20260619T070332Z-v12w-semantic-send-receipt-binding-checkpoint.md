# v12w Semantic Send Receipt Binding Checkpoint

Timestamp: 2026-06-19T07:03:32Z

## Implemented

- `scripts/runtime/a2a_send.py` now recognizes
  `dharma.a2a.semantic_task_packet.v1` front matter and uses the packet
  `packet_id` as the send `packet_id` and NATS `message_id`.
- Semantic send receipts now persist `semantic_task_packet`,
  `semantic_task_packet_sha256`, `task_hash`, and `locked_spec_sha256`.
- Runtime truth metadata and dispatch evidence now carry the same task hash and
  locked-spec hash when the send file is a semantic task packet.
- `scripts/runtime/a2a_domain_reply_worker.py` now requires semantic reply
  artifacts to include `locked_spec_sha256` and rejects semantic claims whose
  `task_hash` or `locked_spec_sha256` disagrees with the send receipt.
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` and
  `scripts/governance/check_nats_substrate_contract.py` now guard the continuity
  invariant from semantic task packet to send receipt to semantic reply.

## Verification

- `uv run pytest -q tests/test_a2a_send.py tests/test_a2a_domain_reply_worker.py --tb=short`
  - 38 passed.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Contract checker passed.
  - 136 passed.
- Broad A2A/runtime regression:
  `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_live_acl_probe.py tests/test_a2a_semantic_task_packet.py tests/test_a2a_standing_wake_loop.py tests/test_a2a_wake_loop_preflight.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - 272 passed.
  - Existing FastAPI/Starlette deprecation warning only.
- `python3 -m compileall -q scripts/runtime/a2a_send.py scripts/runtime/a2a_domain_reply_worker.py scripts/governance/check_nats_substrate_contract.py`
  - Clean.
- `git diff --check`
  - Clean.
- Context+ static analysis:
  - `scripts/runtime/a2a_send.py` clean.
  - `scripts/runtime/a2a_domain_reply_worker.py` clean.

## Readiness

Latest aggregate receipt:
`reports/a2a/full_spec_readiness/20260619T070310_667135Z-a2a-full-spec-readiness.json`

Current score remains 20/100:

- `live_topology`: red
- `cutover_completion`: red
- `acl_probe_contract`: green
- `semantic_task_packets`: green
- `wake_loop_preflight`: red
- `counted_agent_readiness`: red

The score did not increase because this slice removed an integration gap but did
not perform live topology cutover, live ACL execution, standing wake-loop
ownership, or target-owned domain/semantic replies.
