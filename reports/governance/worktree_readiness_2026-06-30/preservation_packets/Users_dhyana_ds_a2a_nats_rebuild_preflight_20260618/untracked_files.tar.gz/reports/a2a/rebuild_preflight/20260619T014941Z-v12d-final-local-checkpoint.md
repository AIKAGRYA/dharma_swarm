# A2A/NATS v12d Final Local Checkpoint

Timestamp: 2026-06-19T01:49:41Z

## Worktree

- Worktree: `/Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618`
- Branch: `runtime-truth/nats-rebuild-preflight-20260618`
- Base commit: `86418541a99c265c09040b9bfc064625c6d59994`
- Locked spec: `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md`
- Locked spec SHA-256: `e4778df2dfe63c82f301f8136acbdb6939d7a79d561626081f39f718e9dad899`

## Current Local Result

Local/offline v12d implementation is complete and verified. Live Agni rollout is still blocked by external dependencies:

- Missing Agni credential references in this shell.
- No explicit operator approval for live A2A calls.
- No fresh typed `SEMANTIC_SIGNED` receipt for each counted seat in the local evidence store.

`make a2a-onboard AGENT=all BROKER=agni MODE=prevalidate` writes per-agent typed domain receipts and reports the honest blocker state `BLOCKED_SECRET_REFERENCE` / exit code `12`. GNU make itself returns `2` for that recipe failure; `scripts/governance/check_a2a_onboard_contract.py` accepts this only when a fresh `onboard_run_id` and per-agent `DOMAIN_RECEIPTED` receipts are present.

## Implemented Surfaces

- `make a2a-onboard AGENT=all BROKER=agni MODE=prevalidate`
  - Canonical counted seats: `codex_composer`, `devin-roaming-2987d222`, `hermes-m5`, `qwen_code`, `opus_composer`.
  - Writes `dharma.a2a.onboard_receipt.v1` and per-agent `dharma.a2a.domain_receipt.v1`.
  - Presence projection distinguishes transport, handler ACK, domain receipt, semantic receipt, and wake-loop state.
  - Live mode requires `A2A_LIVE_OPERATOR_APPROVAL=approved-a2a-live` plus credentials.

- A2A JetStream topology verifier/installer
  - Module: `dharma_swarm/a2a/jetstream_topology.py`
  - CLI: `scripts/governance/a2a_jetstream_topology.py`
  - Make target: `make a2a-topology AGENT=all ARGS=--json`
  - Canonical streams: `A2A_INBOX`, `A2A_TASKS`, `A2A_RECEIPTS`, `A2A_DLQ`.
  - Verifies duplicate windows, bounded stream limits, durable pull consumers, max-deliver, DLQ replay, migration aliases, and `PRESENCE` bucket recipe.

- Send/receive path hardening
  - `scripts/runtime/a2a_send.py` now builds canonical envelope fields and sets `Nats-Msg-Id` on Python and CLI JetStream publish paths.
  - `dharma_swarm/a2a/nats_transport.py` defaults to `A2A_TASKS`, sets `Nats-Msg-Id`, dedupes consume effects, ACKs invalid envelopes only after typed DLQ/quarantine, and sends terminal max-deliver failures to DLQ.
  - `scripts/runtime/a2a_inbox_bridge.py` defaults to `A2A_INBOX` and turns invalid envelopes into `dharma.a2a.dlq_record.v1`.
  - `scripts/runtime/a2a_domain_reply_worker.py` produces typed `dharma.a2a.domain_receipt.v1` and separate `dharma.a2a.semantic_receipt.v1` artifacts when model-processed semantic fields are present.
  - `scripts/runtime/a2a_reply_capture.py` records `SEMANTIC_SIGNED` as a distinct tier, not as domain receipt prose.

## Receipts

- Topology verifier receipt:
  - `reports/a2a/topology/20260619T014810Z-a2a-jetstream-topology.json`
- Latest direct onboard run:
  - `reports/a2a/onboard_receipts/20260619T014713.796653Z-a2a_onboard_20260619T014713_796653Z_eec1c58c.json`
  - Per-agent domain receipts with the same run id under `reports/a2a/domain_receipts/`.
- Latest onboard contract verifier run:
  - `reports/a2a/onboard_receipts/20260619T014713.796653Z-a2a_onboard_20260619T014713_796653Z_ad317456.json`
  - Per-agent domain receipts with the same run id under `reports/a2a/domain_receipts/`.

## Verification

Passed:

```bash
uv run pytest -q tests/test_a2a_jetstream_topology.py tests/test_a2a_onboard.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py --tb=short
# 58 passed
```

```bash
python3 scripts/governance/check_nats_substrate_contract.py
# NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md
```

```bash
make a2a-topology AGENT=all ARGS=--json
# passed=true, failures=[]
```

```bash
make nats-substrate-contract PYTEST='uv run pytest'
# 62 passed
```

```bash
uv run pytest -q tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_jetstream_topology.py --tb=short
# 13 passed
```

Expected blocker evidence:

```bash
make a2a-onboard AGENT=all BROKER=agni MODE=prevalidate
# writes per-agent receipts, reports BLOCKED_SECRET_REFERENCE / exit_code 12
```

```bash
python3 scripts/governance/check_a2a_onboard_contract.py --agent all --broker agni --mode prevalidate --json
# passed=true; verifies all five fresh DOMAIN_RECEIPTED receipts and rejects HANDLER_ACKED as sufficient
```

## Current Changed Files

Core local/offline implementation:

- `Makefile`
- `dharma_swarm/a2a/__init__.py`
- `dharma_swarm/a2a/jetstream_topology.py`
- `dharma_swarm/a2a/nats_transport.py`
- `scripts/governance/a2a_jetstream_topology.py`
- `scripts/governance/a2a_onboard.py`
- `scripts/governance/check_a2a_onboard_contract.py`
- `scripts/governance/check_nats_substrate_contract.py`
- `scripts/runtime/a2a_send.py`
- `scripts/runtime/a2a_inbox_bridge.py`
- `scripts/runtime/a2a_domain_reply_worker.py`
- `scripts/runtime/a2a_reply_capture.py`

Tests:

- `tests/test_a2a_jetstream_topology.py`
- `tests/test_a2a_onboard.py`
- `tests/test_a2a_onboard_contract_verifier.py`
- `tests/test_a2a_send.py`
- `tests/test_nats_transport.py`
- `tests/test_a2a_inbox_bridge.py`
- `tests/test_a2a_domain_reply_worker.py`
- `tests/test_a2a_reply_capture.py`

Preflight/spec/governance artifacts carried in this worktree:

- `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.md`
- `docs/governance/a2a/LONGRUN_BUILD_SPEC.locked.sha256`
- `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`
- `reports/a2a/rebuild_preflight/`
- `reports/a2a/topology/`
- `reports/governance/active_track_evidence.json`
- `reports/governance/active_track_evidence.md`
- `reports/governance/track_portfolio.json`

## Live Rollout Commands

Run only after Agni credentials are present and the operator explicitly approves live A2A calls:

```bash
make a2a-topology AGENT=all ARGS='--commands'
```

Apply the rendered NATS stream/consumer/KV commands against Agni with the operator-managed credential context.

Then:

```bash
export A2A_LIVE_OPERATOR_APPROVAL=approved-a2a-live
make a2a-onboard AGENT=all BROKER=agni MODE=live
python3 scripts/governance/check_a2a_onboard_contract.py --agent all --broker agni --mode live --json
make nats-substrate-contract PYTEST='uv run pytest'
```

Do not claim `READY_LIVE` or five-agent semantic quorum until each counted seat has fresh typed `SEMANTIC_SIGNED` evidence for the current locked spec/task hash.
