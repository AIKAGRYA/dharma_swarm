# A2A/NATS Rebuild Preflight Checkpoint v12m

Timestamp: 2026-06-19T05:45:10Z

## Status

- Local/offline implementation score: 99/100 for gate coverage; the remaining local gap is still real external/live evidence, not an unguarded code path.
- Live full-spec score remains 91/100.
- No live topology mutation was performed in this pass.

## Completed In This Pass

- Added `scripts/governance/a2a_full_spec_readiness.py`.
- Added `tests/test_a2a_full_spec_readiness.py`.
- Added `make a2a-full-spec-readiness`.
- Wired the new readiness tests into `make nats-substrate-contract`.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` with a "Full-Spec Readiness Gate" section.
- Updated `scripts/governance/check_nats_substrate_contract.py` so the readiness gate is repo-checked.

## Gate Semantics

`a2a_full_spec_readiness.py` writes `dharma.a2a.full_spec_readiness.v1` receipts and fails unless these are simultaneously true:

- live topology passes and observes `A2A_INBOX`, `A2A_TASKS`, `A2A_RECEIPTS`, and `A2A_DLQ`;
- no legacy stream owns canonical subject space;
- cutover/install is not still blocked by `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`;
- the counted-agent denominator matches the canonical five seats;
- every counted agent has target-owned `DOMAIN_RECEIPTED` evidence;
- every counted agent has current `SEMANTIC_SIGNED` evidence;
- no counted agent is `BLOCKED_WAKE_LOOP` or `DEGRADED_SESSION_SCOPED`.

This makes a final 100/100 claim machine-verifiable instead of checkpoint-prose-verifiable.

## Verification

- `uv run pytest -q tests/test_a2a_full_spec_readiness.py --tb=short`
  - Result: 3 passed.
- `uv run pytest -q tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_live_topology_probe.py --tb=short`
  - Result: 22 passed.
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - Result: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- `python3 -m compileall -q scripts/governance/a2a_full_spec_readiness.py scripts/governance/check_nats_substrate_contract.py tests/test_a2a_full_spec_readiness.py`
  - Result: passed.
- Context+ static analysis on `/Users/dhyana/ds_a2a_nats_rebuild_preflight_20260618/scripts/governance/a2a_full_spec_readiness.py`
  - Result: no issues found.
- `make a2a-full-spec-readiness PYTEST='uv run pytest' ARGS='--run-onboard --json'`
  - Result: expected non-zero make exit because the aggregate full-spec gate is red.
  - Receipt: `reports/a2a/full_spec_readiness/20260619T054434_204771Z-a2a-full-spec-readiness.json`.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Result: contract OK, 111 tests passed.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_full_spec_readiness.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - Result: 247 passed, 1 warning.
- `git diff --check`
  - Result: passed before checkpoint creation.
- `git checkout -- uv.lock`
  - Result: removed verification-induced lockfile churn.

## Current Full-Spec Readiness Receipt

The aggregate readiness gate is red for the correct reasons:

- live topology still lacks `A2A_TASKS` and `A2A_RECEIPTS`;
- `DHARMA_A2A` still owns `dharma.a2a.>`;
- cutover/install still requires `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`;
- `codex_composer` has semantic/domain evidence but remains `DEGRADED_SESSION_SCOPED`;
- `devin-roaming-2987d222`, `hermes-m5`, `qwen_code`, and `opus_composer` still lack target-owned domain and/or semantic evidence;
- `qwen_code` is still `BLOCKED_WAKE_LOOP` and `DEGRADED_SESSION_SCOPED`.

## Live Blockers Remaining

- Actual topology cutover still requires explicit approval before any live mutation.
- Non-Codex counted seats still need target-owned domain and semantic receipts.
- Session-scoped seats need standing wake-loop promotion or an explicit denominator ruling.
- `qwen_code` needs real wake-loop evidence.
