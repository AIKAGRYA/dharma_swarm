# A2A/NATS Rebuild Preflight Checkpoint v12k

Timestamp: 2026-06-19T05:30:44Z

## Status

- Local/offline implementation score: 98/100.
- Live full-spec score: 91/100.
- No live topology mutation was performed in this pass.

## Completed In This Pass

- Hardened `cutover_transaction_plan` in `scripts/governance/a2a_live_topology_probe.py` so post-cutover consumer additions are previewed with exact generated NATS consumer config.
- Added `_cutover_followup_step_preview(...)` to keep the original planner command for traceability while exposing operator-facing execution semantics separately.
- Each simulated post-cutover durable consumer step now includes:
  - `planner_command`
  - `execution_uses_exact_config: true`
  - `execution_command_template`
  - `desired_consumer_config`
- The execution template uses `nats --context <context> consumer add <stream> <consumer> --config <generated-consumer-config-json> --defaults`, preserving exact nanosecond `ack_wait` and `backoff` arrays instead of relying on approximate CLI flags.
- Updated `docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md` to require exact desired consumer config and execution templates in the transaction preview.
- Updated `scripts/governance/check_nats_substrate_contract.py` to lock the exact-config preview requirement.

## Verification

- `uv run pytest -q tests/test_a2a_live_topology_probe.py tests/test_a2a_jetstream_topology.py --tb=short`
  - Result: 26 passed.
- `python3 scripts/governance/check_nats_substrate_contract.py`
  - Result: `NATS_CONTRACT_OK docs/governance/NATS_SUBSTRATE_MASTER_SPEC.md`.
- `python3 -m compileall -q scripts/governance/a2a_live_topology_probe.py scripts/governance/check_nats_substrate_contract.py`
  - Result: passed.
- `uv run pytest -q tests/test_a2a_spec_conformance.py tests/test_a2a_e2e.py tests/test_a2a_card_semantic_commons.py tests/test_a2a_jetstream_topology.py tests/test_a2a_live_topology_probe.py tests/test_a2a_onboard.py tests/test_a2a_onboard_contract_verifier.py tests/test_a2a_send.py tests/test_nats_transport.py tests/test_a2a_inbox_bridge.py tests/test_a2a_domain_reply_worker.py tests/test_a2a_reply_capture.py tests/test_semantic_receipt.py tests/test_model_critic_runner.py tests/test_pr_merge_control.py --tb=short`
  - Result: 241 passed, 1 warning.
- `make nats-substrate-contract PYTEST='uv run pytest'`
  - Result: contract OK, 105 tests passed.
- `.venv/bin/python scripts/governance/a2a_live_topology_probe.py --context agni-wss --cutover-topology --dry-run-cutover --json`
  - Result: expected exit 1 due current live topology drift; dry-run cutover step passed with `effective_returncode: 0`, `mutation_performed: false`, and exact-config transaction plan present.
  - Receipt: `reports/a2a/live_topology/20260619T052918Z-a2a-live-topology-probe.json`.
- `git diff --check`
  - Result: passed before checkpoint creation.
- `git checkout -- uv.lock`
  - Result: removed verification-induced lockfile churn.

## Latest Live Dry-Run Evidence

The v12k live dry-run receipt includes:

- `mutation_performed`: `false`
- `cutover_results[0].passed`: `true`
- `cutover_results[0].effective_returncode`: `0`
- `cutover_results[0].dry_run_diff_detected`: `true`
- `cutover_transaction_plan.post_cutover_blockers_after_legacy_cutover`: `[]`
- `cutover_transaction_plan.post_cutover_steps_after_legacy_cutover` contains:
  - `add_A2A_TASKS`
  - `add_A2A_RECEIPTS`
  - `add_consumer_a2a_task_claimant`
  - `add_consumer_a2a_task_closer`
  - `add_consumer_a2a_receipt_indexer`
- Consumer steps include `execution_uses_exact_config: true`, `execution_command_template`, and `desired_consumer_config` with exact backoff arrays.

## Live Blockers Remaining

- `DHARMA_A2A` still owns `dharma.a2a.>`, so canonical `A2A_TASKS` and `A2A_RECEIPTS` cannot be installed live without explicit cutover approval.
- Actual cutover still requires `A2A_LIVE_TOPOLOGY_CUTOVER=approved-legacy-cutover`.
- Non-Codex counted seats still lack fresh target-owned domain and semantic receipts.
- `qwen_code` still lacks real wake-loop evidence.
