# D-Score Report: codex_composer

- generated_at: `2026-06-25T16:33:40Z`
- total_score: `48/50`
- raw_score_level: `D5`
- verified_level: `D3`
- promotion_claimed: `false`
- semantic_object: `semobj.codex_composer`
- policy_gate_status: `fail_closed`
- scheduler_proof_status: `missing`

## Axis Scores

- `identity_and_admission`: 5/5
- `canonical_home`: 5/5
- `runtime_persistence`: 5/5
- `a2a_transport`: 5/5
- `delegation_hierarchy`: 4/5
- `authority_and_policy`: 5/5
- `receipts_and_lineage`: 5/5
- `verification`: 4/5
- `operator_surface`: 5/5
- `evolution_loop`: 5/5

## Gate Statuses

- `a2a_proof`: green
- `decorrelated_verification`: green
- `domain_receipt`: blocked
- `fail_closed_authority`: green
- `model_responsiveness`: green
- `scheduler_proof`: blocked
- `semantic_receipt`: green

## Hard Gate Failures

- `d4_domain_receipt_missing`
- `d4_scheduler_proof_missing`

## Evidence Paths

- `/Users/dhyana/ds_semantic_commons_100/docs/ontology/semantic_objects.yaml`
- `/Users/dhyana/ds_semantic_commons_100/docs/ontology/semantic_aliases.yaml`
- `/Users/dhyana/.dharma/agents/codex_composer/identity.json`
- `/Users/dhyana/.dharma/agents/codex_composer/living_agent.json`
- `/Users/dhyana/.dharma/agents/codex_composer/service_heartbeats.jsonl`
- `/Users/dhyana/.dharma/agents/codex_composer/transport_heartbeats.jsonl`
- `/Users/dhyana/.dharma/agents/codex_composer/dialogue/operator_sessions.jsonl`
- `/Users/dhyana/.dharma/agents/codex_composer/dialogue/relationship_memory.jsonl`
- `/Users/dhyana/.dharma/agents/codex_composer/dialogue/conversation_receipts`
- `/Users/dhyana/.dharma/agents/codex_composer/sanctum/codex`
- `/Users/dhyana/.dharma/agents/codex_composer/sanctum/vault`
- `/Users/dhyana/.dharma/agents/codex_composer/sanctum/dojo`
- `/Users/dhyana/.dharma/agents/codex_composer/sanctum/ingest_gate`
- `/Users/dhyana/.dharma/agents/codex_composer/sanctum/tools`
- `/Users/dhyana/.dharma/agents/codex_composer/sanctum/receipts`
- `/Users/dhyana/.dharma/agents/codex_composer`
- `/Users/dhyana/.dharma/agent_passports/codex_composer.json`
- `/Users/dhyana/.dharma/a2a/cards/codex_composer.json`
- `/Users/dhyana/ds_semantic_commons_100/dharma_swarm/persistent_agent.py`
- `/Users/dhyana/.dharma/agents/codex_composer/last_receipt.json`
- `/Users/dhyana/.dharma/agents/codex_composer/talk_receipts.jsonl`
- `/Users/dhyana/.dharma/agents/codex_composer/dialogue/conversation_receipts/2026-06-25T160757.518390+0000-codex_composer.json`
- `/Users/dhyana/ds_semantic_commons_100/reports/agentops/semantic_receipts/20260611T162352Z-ollama-glm-5_cloud-receipt_ollama_glm5_8291_v1.json`
- `/Users/dhyana/.dharma/a2a_bus/outboxes/codex_composer/hermes-codex-holon-peer-contract-79b9f667f3-domain-reply.json`
- `/Users/dhyana/.dharma/a2a_bus/outboxes/codex_composer/a2a-semantic-signoff-codex_composer-e4778df2dfe6.json`
- `/Users/dhyana/.dharma/a2a_bus/outboxes/codex_composer/codex_onboard_semantic_20260619T0437Z-domain-reply.json`
- `/Users/dhyana/.dharma/a2a_bus/outboxes/codex_composer/codex_onboard_semantic_20260619T0432Z-domain-reply.json`
- `/Users/dhyana/ds_semantic_commons_100/dharma_swarm/operator_core/semantic_receipt.py`
- `/Users/dhyana/ds_semantic_commons_100/scripts/runtime/model_critic_runner.py`
- `/Users/dhyana/ds_semantic_commons_100/tests/test_semantic_receipt.py`
- `/Users/dhyana/ds_semantic_commons_100/tests/test_model_critic_runner.py`
