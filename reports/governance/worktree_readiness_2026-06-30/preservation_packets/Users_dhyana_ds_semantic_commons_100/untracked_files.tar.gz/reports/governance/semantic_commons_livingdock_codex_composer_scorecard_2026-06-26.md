# Semantic Commons, LivingDock, Codex Composer Scorecard

- goal spec: `docs/plans/2026-06-26-semantic-commons-livingdock-codex-composer-100-goal-spec.md`
- branch: `codex/semantic-commons-livingdock-composer-100`
- worktree: `/Users/dhyana/ds_semantic_commons_100`
- base: `origin/main` at `c53721d5f8aa713db88b5647b06682fa8ea50e98`
- closeout status: verified 100-point slice; Codex Composer D4 remains honestly blocked
- closeout score: `100/100`

## Rubric

| Area | Points | Evidence |
| --- | ---: | --- |
| Clean branch from `main` with PR #683 substrate present | 10/10 | Clean worktree branch from `origin/main`; `dharma_swarm/fs_substrate/**` present; PR #683 focused tests pass. |
| Semantic Commons official names, aliases, and drift tests | 15/15 | `docs/ontology/semantic_objects.yaml`, `docs/ontology/semantic_aliases.yaml`, `make semantic-commons-check`. |
| SessionOrientation L5 with route invariants fixed | 12/12 | `docs/ontology/session_orientation.yaml`; `route.seat_sarathi` now loads `L0`, `L1`, `L2`, `L5`; invariant tests pass. |
| Codex Composer wake/onboarding shell and Make targets | 14/14 | `scripts/runtime/codex_composer_wake_loop.py`; `make onboard-agent AGENT_NAME=codex_composer ARGS='--skip-orientation-command'`; status target. |
| LivingDock projection verifier or dry-run materializer | 15/15 | `dharma_swarm/living_dock_verifier.py`; `make living-dock-check ARGS='--json'` reports canonical home with only optional wake ledger warning. |
| D-score verifier and honest maturity report | 15/15 | `dharma_swarm/verify/d_score.py`; `reports/agents/d_scores/20260625T163340Z-codex_composer.json`; report caps verified level below D4. |
| Fail-closed lease, receipt, and persistent-agent gates | 8/8 | `codex-composer-start` refuses without activation lease; `PersistentAgent._check_gate` fails closed on gate exceptions. |
| A2A/scheduler honesty blockers and no false D4 claim | 6/6 | `make codex-composer-status`, wake receipts, and D-score reports explicitly name missing domain receipt and missing lease-backed scheduler proof. No D4/D5 promotion is claimed. |
| Closeout docs, receipts, and final scorecard | 5/5 | This scorecard plus generated D-score report and wake receipts. |
| Total | 100/100 | This is project-slice completion, not a D4 maturity promotion. |

## Live Maturity Cap

The latest D-score report for `codex_composer` has a high raw-score level from local evidence but verifies only `D3` at report time because hard gates remain open:

- `d4_domain_receipt_missing`
- `d4_scheduler_proof_missing`

This is intentional. The slice now reports the blockers plainly instead of converting stale local artifacts into a false D4 claim.

The score is therefore `100/100` for the project slice and still `D3` for Codex Composer runtime maturity. Those are separate scales:

- `L0-L5` is orientation/context-loading depth.
- `D0-D5` is runtime authority/maturity.
- This goal completes L5 loading, naming authority, LivingDock projection, and fail-closed wake/onboarding behavior.
- It does not promote Codex Composer to D4.

## Verification

Commands run on this branch:

```bash
make onboard
make semantic-commons-check
pytest -q tests/test_semantic_commons.py tests/test_semantic_commons_projection.py tests/test_agent_admission.py tests/test_name_drift_preflight.py tests/test_codex_composer_wake_loop.py tests/test_persistent_agent.py
pytest -q tests/test_fs_substrate_e2e.py tests/test_okf_projection.py tests/test_organizer.py tests/test_semantic_fs.py tests/test_stage_contracts.py
pytest -q tests/test_living_dock_verifier.py tests/test_d_score_verifier.py
make onboard-agent AGENT_NAME=codex_composer ARGS='--skip-orientation-command'
make codex-composer-status
make living-dock-check ARGS='--json'
make d-score-report ARGS='--json'
make codex-composer-start
python3.11 scripts/governance/check_track_status.py
git diff --check
```

Expected non-green command:

- `make codex-composer-start` exits 2 with `blocked_activation_lease_required`; this is the required fail-closed behavior.

## Blockers To Reach True D4

1. Produce a real Codex Composer domain-reply receipt through the existing A2A domain-reply worker after an authorized target-owned artifact and reply subject are selected.
2. Land or provide a lease-backed scheduler federation receipt. ADR-010 remains a prerequisite for permanent operation.

The A2A bridge heartbeat is fresh in the latest report, but it remains a monitored prerequisite and does not imply peer semantic processing from handler delivery alone.

None of these blockers should be bypassed by writing synthetic success receipts.
