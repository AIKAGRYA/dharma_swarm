from __future__ import annotations

from pathlib import Path

from scripts.runtime.forge_external_benchmark_proof import validate_harbor_terminal_bench_proof
from scripts.runtime.forge_proving_ground_lib import write_json


def write_harbor_job(job_dir: Path, *, errored: bool = False) -> None:
    trial_dir = job_dir / "make-mips-interpreter__abc123"
    trial_dir.mkdir(parents=True)
    write_json(
        job_dir / "config.json",
        {
            "agents": [{"name": "oracle"}],
            "environment": {"type": "docker"},
            "datasets": [{"name": "terminal-bench/terminal-bench-2", "ref": "sha256:dataset"}],
        },
    )
    write_json(
        job_dir / "result.json",
        {
            "n_total_trials": 1,
            "stats": {
                "n_completed_trials": 1,
                "n_errored_trials": 1 if errored else 0,
                "evals": {
                    "oracle__terminal-bench/terminal-bench-2": {
                        "n_trials": 0 if errored else 1,
                        "n_errors": 1 if errored else 0,
                        "metrics": [{"mean": 0.0 if errored else 1.0}],
                    }
                },
            },
        },
    )
    write_json(
        trial_dir / "result.json",
        {
            "task_name": "terminal-bench/make-mips-interpreter",
            "task_id": {"org": "terminal-bench", "name": "make-mips-interpreter", "ref": "sha256:task"},
            "source": "terminal-bench/terminal-bench-2",
            "task_checksum": "abc",
            "verifier_result": {"rewards": {"reward": 0.0 if errored else 1.0}},
            "exception_info": {"type": "RuntimeError"} if errored else None,
        },
    )


def test_external_benchmark_proof_accepts_passing_harbor_oracle_job(tmp_path: Path) -> None:
    write_harbor_job(tmp_path)
    proof = validate_harbor_terminal_bench_proof(tmp_path)
    assert proof["status"] == "pass"
    assert proof["dataset"] == "terminal-bench/terminal-bench-2"
    assert proof["mean"] == 1.0
    assert proof["public_submission_performed"] is False


def test_external_benchmark_proof_rejects_errored_harbor_job(tmp_path: Path) -> None:
    write_harbor_job(tmp_path, errored=True)
    proof = validate_harbor_terminal_bench_proof(tmp_path)
    assert proof["status"] == "fail"
    assert "errored_trials_present" in proof["blockers"]
    assert "trial_exception_present" in proof["blockers"]
