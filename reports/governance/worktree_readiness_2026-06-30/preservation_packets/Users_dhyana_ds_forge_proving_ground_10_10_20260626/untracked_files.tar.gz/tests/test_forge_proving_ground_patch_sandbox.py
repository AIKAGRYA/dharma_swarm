from __future__ import annotations

import sys
from pathlib import Path

from scripts.runtime.forge_proving_ground_patch_sandbox import run_patch_trial


def test_patch_sandbox_keeps_improved_passing_mutation(tmp_path: Path) -> None:
    target = tmp_path / "target.txt"
    target.write_text("base\n", encoding="utf-8")
    command = [sys.executable, "-c", "from pathlib import Path; assert Path('target.txt').exists()"]
    receipt = run_patch_trial(target, "better\n", 0.1, 0.9, [command], tmp_path, "keep", allowed_patch_surface=[target])
    assert receipt["decision"] == "keep"
    assert target.read_text(encoding="utf-8").endswith("better\n")


def test_patch_sandbox_reverts_regression_cleanly(tmp_path: Path) -> None:
    target = tmp_path / "target.txt"
    target.write_text("base\n", encoding="utf-8")
    command = [sys.executable, "-c", "from pathlib import Path; assert Path('target.txt').exists()"]
    receipt = run_patch_trial(target, "worse\n", 0.9, 0.1, [command], tmp_path, "revert", allowed_patch_surface=[target])
    assert receipt["decision"] == "revert"
    assert receipt["target_file_restored"] is True
    assert target.read_text(encoding="utf-8") == "base\n"


def test_patch_sandbox_blocks_targets_outside_patch_surface(tmp_path: Path) -> None:
    target = tmp_path / "target.txt"
    other = tmp_path / "other.txt"
    other.write_text("base\n", encoding="utf-8")
    receipt = run_patch_trial(target, "bad\n", 0.1, 0.9, [], tmp_path, "blocked", allowed_patch_surface=[other])
    assert receipt["decision"] == "blocked"
    assert "target_not_in_patch_surface" in receipt["blockers"]
    assert not target.exists()


def test_patch_sandbox_reverts_new_file_by_removing_it(tmp_path: Path) -> None:
    target = tmp_path / "created.txt"
    command = [sys.executable, "-c", "from pathlib import Path; assert Path('created.txt').exists()"]
    receipt = run_patch_trial(target, "new\n", 0.9, 0.1, [command], tmp_path, "remove-created", allowed_patch_surface=[target])
    assert receipt["decision"] == "revert"
    assert receipt["target_file_restored"] is True
    assert receipt["target_file_existed_before"] is False
    assert not target.exists()
