from __future__ import annotations

from pathlib import Path

from scripts.runtime.forge_proving_ground_autoresearch import build_mutation_plan, is_mutable_surface


def test_autoresearch_plan_selects_scoped_mutable_target(tmp_path: Path) -> None:
    receipt = {
        "receipt_id": "r1",
        "benchmark_family": "terminal_bench_compatible_local",
        "failure_class": "json_parse_failed",
    }
    plan = build_mutation_plan(receipt, tmp_path, dry_run=True, output_dir=tmp_path)
    assert plan["planner_status"] == "candidate"
    assert plan["single_edit_trial"] is True
    assert plan["writes_performed"] is False
    assert plan["patch_surface"] == ["scripts/runtime/forge_swarm_evolution_arena_v0_measurement_runner.py"]
    assert (tmp_path / "autoresearch_plan.json").exists()


def test_autoresearch_rejects_immutable_surfaces() -> None:
    assert is_mutable_surface("tests/test_x.py") is False
    assert is_mutable_surface("benchmarks/fixtures/terminal_bench_smoke/hidden/scorer.py") is False
    assert is_mutable_surface("dharma_swarm/agent_runner.py") is True


def test_autoresearch_rejects_path_traversal_and_absolute_paths(tmp_path: Path) -> None:
    assert is_mutable_surface("../outside.py", tmp_path) is False
    assert is_mutable_surface("/tmp/outside.py", tmp_path) is False
    receipt = {
        "receipt_id": "r2",
        "benchmark_family": "terminal_bench_compatible_local",
        "failure_class": "benchmark_score_low",
        "evolution_signal": "../outside.py",
    }
    plan = build_mutation_plan(receipt, tmp_path, dry_run=True, output_dir=tmp_path)
    assert plan["patch_surface"] == ["dharma_swarm/agent_runner.py"]
