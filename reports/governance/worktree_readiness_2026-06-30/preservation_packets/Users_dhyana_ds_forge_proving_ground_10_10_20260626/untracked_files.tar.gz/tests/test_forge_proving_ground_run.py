from __future__ import annotations

from pathlib import Path

from scripts.runtime import forge_proving_ground_run as runner


def test_scaling_request_covers_1_10_25_100() -> None:
    assert runner.validate_scaling_request(1, "smoke")["valid"] is True
    assert runner.validate_scaling_request(10, "bounded")["valid"] is True
    assert runner.validate_scaling_request(25, "soak")["valid"] is True
    full = runner.validate_scaling_request(100, "full")
    assert full["valid"] is True
    assert [gate["iterations"] for gate in full["required_gates"]] == [1, 10, 25, 100]


def test_scaling_request_rejects_illegal_jump_shape() -> None:
    result = runner.validate_scaling_request(100, "smoke")
    assert result["valid"] is False
    assert "mode_iteration_mismatch" in result["blocker"]


def test_runner_writes_required_receipts_without_live_network(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(runner, "git_commit", lambda _repo_root: "abc123")
    monkeypatch.setattr(
        runner,
        "build_provider_oracle",
        lambda repo_root: {
            "status": "pass",
            "blockers": [],
            "provider_roster_hash": "sha256:provider",
            "live_cluster_count": 3,
        },
    )
    monkeypatch.setattr(
        runner,
        "run_real_benchmark_smoke",
        lambda output_dir: {
            "passed": True,
            "benchmark_family": "terminal_bench_compatible_local",
            "task_id": "terminal-bench-smoke-echo-arithmetic-v1",
            "benchmark_pack_hash": "sha256:benchmark",
            "candidate_visible_hashes": {"visible/input.txt": "sha256:visible"},
            "hidden_artifact_hashes": {"hidden/expected.json": "sha256:hidden"},
            "scorer_artifact_hashes": {"scorer/scorer.py": "sha256:scorer"},
            "score": 1.0,
            "score_path": str(output_dir / "score.json"),
        },
    )
    monkeypatch.setattr(runner, "run_synthetic_gate", lambda _run_dir, _repo_root: {"passed": True})
    monkeypatch.setattr(
        runner,
        "build_mutation_plan",
        lambda failure_receipt, repo_root, dry_run, output_dir: {
            "blocked": False,
            "planner_status": "candidate",
            "patch_surface": ["dharma_swarm/agent_runner.py"],
        },
    )
    monkeypatch.setattr(
        runner,
        "run_patch_sandbox_self_test",
        lambda output_dir: [
            {"kept": True, "decision": "keep"},
            {"reverted": True, "target_file_restored": True, "decision": "revert"},
        ],
    )
    monkeypatch.setattr(
        runner,
        "verify_artifact",
        lambda *args, **kwargs: {"verified": True, "verifier_id": "v1", "blockers": []},
    )
    manifest = runner.run_proving_ground(1, "smoke", "test-run", tmp_path, tmp_path)
    run_dir = tmp_path / "test-run"
    assert manifest["status"] == "ready_10_of_10_candidate"
    for name in runner.__dict__["AUTHORITY_FALSE"]:
        assert manifest["authority"][name] is False
    assert (run_dir / "RUN_MANIFEST.json").exists()
    assert (run_dir / "iteration_receipts.jsonl").exists()
