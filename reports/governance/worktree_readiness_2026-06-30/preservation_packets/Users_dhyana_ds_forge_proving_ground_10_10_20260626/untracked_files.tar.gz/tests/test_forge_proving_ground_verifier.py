from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from scripts.runtime.forge_proving_ground_lib import write_json
from scripts.runtime.forge_proving_ground_verifier import verify_artifact


def test_verifier_rejects_missing_artifact(tmp_path: Path) -> None:
    receipt = verify_artifact(tmp_path / "missing.json", [], tmp_path)
    assert receipt["verified"] is False
    assert "artifact_missing" in receipt["blockers"]


def test_verifier_rejects_stale_artifact(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.json"
    old = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat().replace("+00:00", "Z")
    write_json(artifact, {"generated_at": old, "status": "candidate"})
    receipt = verify_artifact(artifact, [], tmp_path, max_age_seconds=60)
    assert receipt["verified"] is False
    assert "artifact_stale" in receipt["blockers"]


def test_verifier_accepts_fresh_passing_smoke_fixture(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.json"
    write_json(artifact, {"generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), "status": "candidate"})
    receipt = verify_artifact(artifact, [[sys.executable, "-c", "print('ok')"]], tmp_path)
    assert receipt["verified"] is True
    assert receipt["builder_status"] == "candidate"


def test_verifier_rejects_empty_command_set_for_fresh_artifact(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.json"
    write_json(artifact, {"generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), "status": "candidate"})
    receipt = verify_artifact(artifact, [], tmp_path)
    assert receipt["verified"] is False
    assert "verifier_commands_missing" in receipt["blockers"]


def test_verifier_rejects_non_candidate_builder_status(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.json"
    write_json(artifact, {"generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), "status": "verified"})
    receipt = verify_artifact(artifact, [[sys.executable, "-c", "print('ok')"]], tmp_path)
    assert receipt["verified"] is False
    assert "builder_status_not_candidate" in receipt["blockers"]
