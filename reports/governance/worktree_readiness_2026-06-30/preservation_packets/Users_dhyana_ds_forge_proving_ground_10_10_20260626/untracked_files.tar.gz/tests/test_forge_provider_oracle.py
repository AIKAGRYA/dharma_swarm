from __future__ import annotations

import json
import time
from pathlib import Path

from scripts.runtime.forge_provider_oracle import build_provider_oracle


def write_cache(path: Path, last_test_ts: float | None = None) -> None:
    rows = {
        "claude_code": {"name": "claude_code", "cluster": "anthropic", "env_var": "CLAUDE_CODE_OAUTH", "glyph": "✓", "status": "oauth present"},
        "gemini": {"name": "gemini", "cluster": "deepmind", "env_var": "GEMINI_API_KEY", "glyph": "✓", "http": 200, "status": "live"},
        "nvidia": {"name": "nvidia_nim", "cluster": "nvidia", "env_var": "NVIDIA_API_KEY", "glyph": "✓", "http": 200, "status": "live"},
        "openrouter": {"name": "openrouter", "cluster": "multi", "env_var": "OPENROUTER_API_KEY", "glyph": "✗", "status": "HTTP 404", "masked": "secret"},
    }
    path.write_text(json.dumps({"last_test_ts": last_test_ts or time.time(), "rows": rows}), encoding="utf-8")


def test_provider_oracle_accepts_three_fresh_decorrelated_clusters(tmp_path: Path) -> None:
    cache = tmp_path / "keys_status.json"
    write_cache(cache)
    oracle = build_provider_oracle(tmp_path, cache_path=cache, dkeys_path=tmp_path / "missing", run_live_probe=False)
    assert oracle["status"] == "pass"
    assert oracle["live_cluster_count"] == 3
    assert oracle["secret_values_printed"] is False
    assert "masked" not in json.dumps(oracle)


def test_provider_oracle_blocks_stale_cache(tmp_path: Path) -> None:
    cache = tmp_path / "keys_status.json"
    write_cache(cache, last_test_ts=time.time() - 10_000)
    oracle = build_provider_oracle(tmp_path, cache_path=cache, run_live_probe=False, ttl_seconds=900)
    assert oracle["status"] == "blocked"
    assert "provider_status_stale" in oracle["blockers"]


def test_provider_oracle_redacts_live_probe_output(tmp_path: Path) -> None:
    cache = tmp_path / "keys_status.json"
    write_cache(cache)
    dkeys = tmp_path / "dkeys.py"
    dkeys.write_text("import sys\nprint('key | secret-token-123')\nsys.exit(0)\n", encoding="utf-8")
    oracle = build_provider_oracle(tmp_path, cache_path=cache, dkeys_path=dkeys, run_live_probe=True)
    assert oracle["status"] == "pass"
    assert oracle["commands"][0]["stdout_redacted"] is True
    assert "secret-token-123" not in json.dumps(oracle)


def test_provider_oracle_does_not_promote_broken_glyph_rows(tmp_path: Path) -> None:
    cache = tmp_path / "keys_status.json"
    rows = {
        "a": {"name": "a", "cluster": "a", "glyph": "✓", "http": 200, "status": "live"},
        "b": {"name": "b", "cluster": "b", "glyph": "✓", "http": 200, "status": "live"},
        "broken": {"name": "broken", "cluster": "broken", "glyph": "✓", "http": 404, "status": "HTTP 404"},
    }
    cache.write_text(json.dumps({"last_test_ts": time.time(), "rows": rows}), encoding="utf-8")
    oracle = build_provider_oracle(tmp_path, cache_path=cache, run_live_probe=False)
    assert oracle["status"] == "blocked"
    assert oracle["live_cluster_count"] == 2
