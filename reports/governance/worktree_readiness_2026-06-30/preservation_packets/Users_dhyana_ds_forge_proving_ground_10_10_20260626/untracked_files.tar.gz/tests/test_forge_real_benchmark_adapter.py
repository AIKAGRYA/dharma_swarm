from __future__ import annotations

from pathlib import Path

from benchmarks.forge_real_benchmark_adapter import run_real_benchmark_smoke


def test_real_benchmark_smoke_separates_visible_hidden_and_scorer(tmp_path: Path) -> None:
    receipt = run_real_benchmark_smoke(tmp_path)
    assert receipt["passed"] is True
    assert receipt["synthetic_forge_arena"] is False
    assert receipt["candidate_visible_hashes"]
    assert receipt["hidden_artifact_hashes"]
    assert receipt["scorer_artifact_hashes"]
    assert (tmp_path / "candidate_visible" / "instructions.md").exists()
    assert (tmp_path / "trusted_hidden" / "expected.json").exists()
    assert (tmp_path / "trusted_scorer" / "scorer.py").exists()
    command = receipt["command"]["command"]
    assert str(tmp_path / "trusted_hidden") in command
    assert str(tmp_path / "trusted_scorer") in command
    assert "benchmarks/fixtures/terminal_bench_smoke/hidden" not in command
    assert (tmp_path / "benchmark_pack.json").exists()
