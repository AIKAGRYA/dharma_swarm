from __future__ import annotations

import time
from pathlib import Path

from scripts.runtime import forge_proving_ground_readiness as readiness
from scripts.runtime.forge_proving_ground_lib import append_jsonl, utc_now, write_json


class FakeCommand:
    def __init__(self, command: str = "cmd", stdout: str = "ok") -> None:
        self.command = command
        self.returncode = 0
        self.stdout = stdout
        self.stderr = ""
        self.duration_ms = 1

    def to_json(self):
        return {
            "command": self.command,
            "returncode": self.returncode,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration_ms": self.duration_ms,
        }


def make_complete_run(root: Path) -> Path:
    run_dir = root / "run"
    run_dir.mkdir(parents=True)
    authority = {
        "archive_fitness_mutated": False,
        "production_router_mutated": False,
        "trusted_memory_promoted": False,
        "public_submission_performed": False,
        "external_action_performed": False,
    }
    write_json(
        run_dir / "RUN_MANIFEST.json",
        {
            "generated_at": utc_now(),
            "run_id": "run",
            "iterations": 100,
            "scaling_gates": [
                {"iterations": 1, "mode": "smoke", "status": "pass", "commit_sha": "c", "provider_roster_hash": "p", "benchmark_pack_hash": "b"},
                {"iterations": 10, "mode": "bounded", "status": "pass", "commit_sha": "c", "provider_roster_hash": "p", "benchmark_pack_hash": "b"},
                {"iterations": 25, "mode": "soak", "status": "pass", "commit_sha": "c", "provider_roster_hash": "p", "benchmark_pack_hash": "b"},
                {"iterations": 100, "mode": "full", "status": "pass", "commit_sha": "c", "provider_roster_hash": "p", "benchmark_pack_hash": "b"},
            ],
        },
    )
    write_json(run_dir / "readiness.json", {"generated_at": utc_now()})
    write_json(run_dir / "provider_roster.json", {"generated_at": utc_now(), "ttl_seconds": 900, "status": "pass", "live_cluster_count": 3, "secret_values_printed": False})
    write_json(
        run_dir / "benchmark_pack.json",
        {
            "passed": True,
            "synthetic_forge_arena": False,
            "benchmark_family": "terminal_bench_compatible_local",
            "candidate_visible_hashes": {"a": "sha256:x"},
            "hidden_artifact_hashes": {"b": "sha256:y"},
            "scorer_artifact_hashes": {"c": "sha256:z"},
        },
    )
    write_json(run_dir / "synthetic_forge_arena_gate.json", {"passed": True})
    write_json(
        run_dir / "autoresearch_plan.json",
        {
            "planner_status": "candidate",
            "single_edit_trial": True,
            "patch_surface": ["dharma_swarm/agent_runner.py"],
            "writes_performed": False,
        },
    )
    append_jsonl(run_dir / "mutation_receipts.jsonl", [{"kept": True, "decision": "keep"}, {"reverted": True, "target_file_restored": True}])
    append_jsonl(run_dir / "verification_receipts.jsonl", [{"verified": True, "builder_status": "candidate"}])
    rows = []
    for iteration in range(1, 101):
        rows.append(
            {
                "run_id": "run",
                "iteration": iteration,
                "commit_sha": "c",
                "task_id": "t",
                "benchmark_family": "terminal_bench_compatible_local",
                "candidate_visible_artifact_hashes": {},
                "hidden_scorer_artifact_hashes": {},
                "provider_roster_hash": "p",
                "arm_scores": {},
                "swarm_lift": 0.1,
                "uncertainty": {},
                "proposed_mutation_id": "m",
                "keep_revert_decision": "keep",
                "verifier_receipt_id": "v",
                "authority": authority,
            }
        )
    append_jsonl(run_dir / "iteration_receipts.jsonl", rows)
    append_jsonl(run_dir / "budget_ledger.jsonl", [{"iteration": 1}])
    (run_dir / "decision_packet.md").write_text("ok", encoding="utf-8")
    (run_dir / "failure_harvest.md").write_text("ok", encoding="utf-8")
    return run_dir


def test_readiness_rejects_hand_forged_receipt_bundle(monkeypatch, tmp_path: Path) -> None:
    make_complete_run(tmp_path)
    monkeypatch.setattr(readiness, "run_command", lambda *args, **kwargs: FakeCommand(stdout="forge_proving_ground_run.py\n1 passed"))
    report = readiness.build_readiness_report(Path.cwd(), tmp_path)
    assert report["readiness"] != "10/10"
    assert report["blockers"]


def test_readiness_reports_missing_run_as_incomplete(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(readiness, "run_command", lambda *args, **kwargs: FakeCommand(stdout="forge_proving_ground_run.py\n1 passed"))
    report = readiness.build_readiness_report(Path.cwd(), tmp_path)
    assert report["score"] < 10
    assert report["blockers"]
