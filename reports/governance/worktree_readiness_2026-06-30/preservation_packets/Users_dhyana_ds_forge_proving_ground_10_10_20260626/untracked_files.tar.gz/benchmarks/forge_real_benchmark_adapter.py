#!/usr/bin/env python3
"""Real-benchmark smoke adapter for the Dharma Forge Proving Ground.

This adapter intentionally uses a checked-in Terminal-Bench-compatible local
fixture. It is not the synthetic Forge Arena taskpack: candidate-visible files,
hidden expected output, and scorer code are separated and hashed.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path
from typing import Any, Optional

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import read_json, run_command, sha256_file, sha256_json, utc_now, write_json

SCHEMA_VERSION = "forge_real_benchmark_adapter.v1"
FIXTURE_DIR = Path(__file__).resolve().parent / "fixtures" / "terminal_bench_smoke"


def _hashes(root: Path, rels: list[str]) -> dict[str, str]:
    return {rel: sha256_file(root / rel) for rel in rels}


def run_real_benchmark_smoke(output_dir: Path, fixture_dir: Path = FIXTURE_DIR) -> dict[str, Any]:
    task = read_json(fixture_dir / "task.json")
    output_dir.mkdir(parents=True, exist_ok=True)
    visible_dir = output_dir / "candidate_visible"
    hidden_dir = output_dir / "trusted_hidden"
    scorer_dir = output_dir / "trusted_scorer"
    if visible_dir.exists():
        shutil.rmtree(visible_dir)
    if hidden_dir.exists():
        shutil.rmtree(hidden_dir)
    if scorer_dir.exists():
        shutil.rmtree(scorer_dir)
    visible_dir.mkdir(parents=True)
    hidden_dir.mkdir(parents=True)
    scorer_dir.mkdir(parents=True)

    for rel in task["candidate_visible_files"]:
        src = fixture_dir / rel
        dst = visible_dir / Path(rel).name
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    for rel in task["hidden_files"]:
        src = fixture_dir / rel
        dst = hidden_dir / Path(rel).name
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    for rel in task["scorer_files"]:
        src = fixture_dir / rel
        dst = scorer_dir / Path(rel).name
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")

    submission_path = output_dir / "deterministic_submission.json"
    score_path = output_dir / "score.json"
    write_json(submission_path, task["deterministic_submission"])
    scorer = scorer_dir / Path(task["scorer_files"][0]).name
    expected = hidden_dir / Path(task["hidden_files"][0]).name
    command = [sys.executable, scorer, "--submission", submission_path, "--expected", expected, "--output", score_path]
    score_result = run_command(command, cwd=REPO_ROOT, timeout=30)
    score_payload = read_json(score_path) if score_path.exists() else {"passed": False, "score": 0.0}
    receipt = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "benchmark_family": task["benchmark_family"],
        "task_id": task["task_id"],
        "synthetic_forge_arena": False,
        "source_documentation": task["source_documentation"],
        "candidate_visible_dir": str(visible_dir),
        "trusted_hidden_dir": str(hidden_dir),
        "trusted_scorer_dir": str(scorer_dir),
        "candidate_visible_hashes": _hashes(fixture_dir, task["candidate_visible_files"]),
        "hidden_artifact_hashes": _hashes(fixture_dir, task["hidden_files"]),
        "scorer_artifact_hashes": _hashes(fixture_dir, task["scorer_files"]),
        "submission_path": str(submission_path),
        "score_path": str(score_path),
        "score": score_payload.get("score", 0.0),
        "passed": bool(score_payload.get("passed")),
        "command": score_result.to_json(),
        "benchmark_pack_hash": "",
    }
    receipt["benchmark_pack_hash"] = sha256_json(
        {
            "task_id": receipt["task_id"],
            "visible": receipt["candidate_visible_hashes"],
            "hidden": receipt["hidden_artifact_hashes"],
            "scorer": receipt["scorer_artifact_hashes"],
        }
    )
    write_json(output_dir / "benchmark_pack.json", receipt)
    return receipt


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    receipt = run_real_benchmark_smoke(args.output_dir)
    if args.json:
        print(json.dumps(receipt, sort_keys=True))
    else:
        print("real benchmark smoke: %s score=%s" % ("pass" if receipt["passed"] else "fail", receipt["score"]))
    return 0 if receipt["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
