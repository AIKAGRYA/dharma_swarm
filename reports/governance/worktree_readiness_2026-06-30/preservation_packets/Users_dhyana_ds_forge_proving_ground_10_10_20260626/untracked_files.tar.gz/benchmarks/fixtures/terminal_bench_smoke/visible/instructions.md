# Terminal-Bench Compatible Smoke Task

Read `input.txt` and produce JSON with an integer `answer` field. Do not read
hidden files or scorer files.
