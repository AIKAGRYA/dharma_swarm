#!/usr/bin/env python3
"""Fresh non-secret provider oracle for Dharma Forge Proving Ground."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import read_json, run_command, sha256_json, utc_now, write_json

SCHEMA_VERSION = "forge_provider_oracle.v1"
DEFAULT_CACHE = Path.home() / ".dharma" / "keys_status.json"
DEFAULT_DKEYS = Path.home() / ".dharma" / "bin" / "dkeys"
LIVE_GLYPH = "✓"
BROKEN_STATUS_MARKERS = (
    "401",
    "403",
    "404",
    "error",
    "fail",
    "funds",
    "invalid",
    "missing",
    "quota",
    "rate",
)
SECRET_OUTPUT_MARKERS = ("masked", "sk-", "token=", "secret=", "credential=")


def _repo_python(repo_root: Path) -> Path:
    venv_python = repo_root / ".venv" / "bin" / "python"
    if venv_python.exists():
        return venv_python
    return Path(sys.executable)


def _safe_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": str(row.get("name") or ""),
        "cluster": str(row.get("cluster") or ""),
        "env_var": str(row.get("env_var") or ""),
        "glyph": str(row.get("glyph") or ""),
        "http": row.get("http"),
        "status": str(row.get("status") or ""),
        "ms": int(row.get("ms") or 0),
    }


def _safe_command_receipt(result: Any) -> dict[str, Any]:
    return {
        "command": result.command,
        "returncode": result.returncode,
        "duration_ms": result.duration_ms,
        "stdout_redacted": True,
        "stderr_redacted": True,
    }


def _is_live_provider(row: dict[str, Any]) -> bool:
    if row["glyph"] != LIVE_GLYPH:
        return False
    if not row["name"] or not row["cluster"]:
        return False
    http_status = row.get("http")
    if http_status is not None:
        try:
            if int(http_status) < 200 or int(http_status) >= 300:
                return False
        except (TypeError, ValueError):
            return False
    status = row["status"].lower()
    return not any(marker in status for marker in BROKEN_STATUS_MARKERS)


def _secret_values_printed(payload: dict[str, Any]) -> bool:
    text = json.dumps(payload, sort_keys=True).lower()
    return any(marker in text for marker in SECRET_OUTPUT_MARKERS)


def _load_cache(cache_path: Path) -> tuple[dict[str, Any], list[str]]:
    blockers: list[str] = []
    if not cache_path.exists():
        return {}, ["dkeys_cache_missing"]
    try:
        payload = read_json(cache_path)
    except Exception as exc:
        return {}, ["dkeys_cache_unreadable:%s" % type(exc).__name__]
    rows = payload.get("rows")
    if not isinstance(rows, dict):
        blockers.append("dkeys_cache_rows_missing")
    return payload, blockers


def build_provider_oracle(
    repo_root: Path,
    cache_path: Path = DEFAULT_CACHE,
    dkeys_path: Path = DEFAULT_DKEYS,
    ttl_seconds: int = 900,
    run_live_probe: bool = True,
    timeout: int = 45,
) -> dict[str, Any]:
    generated_at = utc_now()
    commands: list[dict[str, Any]] = []
    blockers: list[str] = []

    if run_live_probe:
        if not dkeys_path.exists():
            blockers.append("dkeys_executable_missing")
        else:
            cmd = [_repo_python(repo_root), dkeys_path, "test"]
            result = run_command(cmd, cwd=repo_root, timeout=timeout)
            commands.append(_safe_command_receipt(result))
            if result.returncode != 0:
                blockers.append("dkeys_test_failed")

    payload, cache_blockers = _load_cache(cache_path)
    blockers.extend(cache_blockers)
    last_test_ts = float(payload.get("last_test_ts") or 0.0) if payload else 0.0
    status_age_seconds: Optional[float] = None
    if last_test_ts > 0:
        status_age_seconds = max(0.0, time.time() - last_test_ts)
        if status_age_seconds > ttl_seconds:
            blockers.append("provider_status_stale")
    else:
        blockers.append("provider_status_timestamp_missing")

    raw_rows = payload.get("rows") if isinstance(payload.get("rows"), dict) else {}
    rows = [_safe_row(row) for row in raw_rows.values() if isinstance(row, dict)]
    live_rows = [row for row in rows if _is_live_provider(row)]
    live_clusters: dict[str, dict[str, Any]] = {}
    for row in live_rows:
        cluster = row["cluster"]
        if cluster and cluster not in live_clusters:
            live_clusters[cluster] = row
    roles = []
    role_names = ["builder", "verifier_adversary", "alternate_builder", "reporter_routeability_auditor"]
    for index, row in enumerate(live_clusters.values()):
        roles.append(
            {
                "role": role_names[index] if index < len(role_names) else "decorrelated_role_%d" % (index + 1),
                "provider": row["name"],
                "cluster": row["cluster"],
                "status": row["status"],
                "liveness_check": "pass",
                "source": "dkeys live probe cache",
            }
        )
    if len(live_clusters) < 3:
        blockers.append("blocked_provider_roster_below_minimum")

    status = "pass" if not blockers and len(live_clusters) >= 3 else "blocked"
    oracle = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": generated_at,
        "status": status,
        "ttl_seconds": ttl_seconds,
        "status_age_seconds": status_age_seconds,
        "live_provider_count": len(live_rows),
        "live_cluster_count": len(live_clusters),
        "live_clusters": sorted(live_clusters),
        "roles": roles,
        "providers": rows,
        "commands": commands,
        "blockers": sorted(set(blockers)),
        "secret_values_printed": False,
        "provider_roster_hash": "",
    }
    oracle["secret_values_printed"] = _secret_values_printed({"providers": rows, "commands": commands})
    if oracle["secret_values_printed"]:
        oracle["blockers"] = sorted(set([*oracle["blockers"], "secret_values_printed"]))
        oracle["status"] = "blocked"
    oracle["provider_roster_hash"] = sha256_json(
        {
            "generated_at": oracle["generated_at"],
            "roles": oracle["roles"],
            "live_clusters": oracle["live_clusters"],
            "status_age_seconds": oracle["status_age_seconds"],
        }
    )
    return oracle


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=REPO_ROOT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--ttl-seconds", type=int, default=900)
    parser.add_argument("--no-live-probe", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    oracle = build_provider_oracle(
        repo_root=args.repo_root.resolve(),
        ttl_seconds=args.ttl_seconds,
        run_live_probe=not args.no_live_probe,
    )
    if args.output:
        write_json(args.output, oracle)
    if args.json:
        print(json.dumps(oracle, sort_keys=True))
    else:
        print("%s provider oracle: %s clusters=%s" % (oracle["generated_at"], oracle["status"], oracle["live_cluster_count"]))
    return 0 if oracle["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
