#!/usr/bin/env python3
"""Shared helpers for the Dharma Forge Proving Ground runtime scripts."""

from __future__ import annotations

import hashlib
import json
import subprocess
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence


@dataclass
class CommandResult:
    command: str
    returncode: int
    stdout: str
    stderr: str
    duration_ms: int

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


def repo_root_from_file(path: Path) -> Path:
    return path.resolve().parents[2]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def parse_utc(value: str) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def age_seconds(value: str) -> Optional[float]:
    stamp = parse_utc(value)
    if stamp is None:
        return None
    return max(0.0, (datetime.now(timezone.utc) - stamp).total_seconds())


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def append_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    materialized = list(rows)
    if not materialized:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        for row in materialized:
            handle.write(json.dumps(row, sort_keys=True) + "\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def sha256_text(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_json(payload: dict[str, Any]) -> str:
    text = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return sha256_text(text)


def short_output(text: str, limit: Optional[int] = 1200) -> str:
    if limit is None:
        return text
    if len(text) <= limit:
        return text
    return text[:limit] + "...[truncated]"


def command_to_text(command: Sequence[str]) -> str:
    return " ".join(str(part) for part in command)


def run_command(command: Sequence[str], cwd: Path, timeout: int = 60, output_limit: Optional[int] = 1200) -> CommandResult:
    started = time.perf_counter()
    try:
        proc = subprocess.run(
            [str(part) for part in command],
            cwd=str(cwd),
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        return CommandResult(
            command=command_to_text(command),
            returncode=proc.returncode,
            stdout=short_output(proc.stdout, output_limit),
            stderr=short_output(proc.stderr, output_limit),
            duration_ms=int((time.perf_counter() - started) * 1000),
        )
    except subprocess.TimeoutExpired as exc:
        return CommandResult(
            command=command_to_text(command),
            returncode=124,
            stdout=short_output(exc.stdout or "", output_limit),
            stderr="timeout after %ss" % timeout,
            duration_ms=int((time.perf_counter() - started) * 1000),
        )
    except OSError as exc:
        return CommandResult(
            command=command_to_text(command),
            returncode=127,
            stdout="",
            stderr="%s: %s" % (type(exc).__name__, exc),
            duration_ms=int((time.perf_counter() - started) * 1000),
        )
