#!/usr/bin/env python3
"""Bridge benchmark failure receipts into scoped Forge autoresearch mutations."""

from __future__ import annotations

import argparse
import json
import sys
import uuid
from pathlib import Path
from typing import Any, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import read_json, utc_now, write_json

SCHEMA_VERSION = "forge_proving_ground_autoresearch.v1"
IMMUTABLE_PREFIXES = (
    "tests/",
    "benchmarks/fixtures/",
    "reports/",
    "docs/governance/FORGE_NAMING_BOUNDARY.md",
)
IMMUTABLE_PARTS = ("hidden", "scorer", "readiness")


def _normalized_relative_path(path: str, repo_root: Optional[Path] = None) -> Optional[str]:
    raw = path.strip().replace("\\", "/")
    if not raw or raw.startswith("/") or Path(raw).is_absolute():
        return None
    candidate = Path(raw)
    if any(part in ("", "..") for part in candidate.parts):
        return None
    normalized = candidate.as_posix()
    if repo_root is not None:
        root = repo_root.resolve()
        resolved = (root / normalized).resolve(strict=False)
        try:
            resolved.relative_to(root)
        except ValueError:
            return None
    return normalized


def is_mutable_surface(path: str, repo_root: Optional[Path] = None) -> bool:
    normalized = _normalized_relative_path(path, repo_root)
    if normalized is None:
        return False
    if not normalized.endswith(".py"):
        return False
    if any(normalized.startswith(prefix) for prefix in IMMUTABLE_PREFIXES):
        return False
    parts = {part.lower() for part in normalized.split("/")}
    if any(part in parts or part in normalized.lower() for part in IMMUTABLE_PARTS):
        return False
    return True


def target_for_failure(receipt: dict[str, Any], repo_root: Path) -> tuple[str, str]:
    failure_class = str(receipt.get("failure_class") or receipt.get("failure_mode") or "").lower()
    signal = str(receipt.get("evolution_signal") or "").strip()
    if signal and is_mutable_surface(signal, repo_root):
        return signal, "failure receipt named a mutable evolution_signal"
    if "provider" in failure_class or "quota" in failure_class or "route" in failure_class:
        return "dharma_swarm/runtime_provider.py", "provider failure maps to runtime provider routing"
    if "json" in failure_class or "parse" in failure_class:
        return "scripts/runtime/forge_swarm_evolution_arena_v0_measurement_runner.py", "JSON parse failure maps to response normalization"
    if "contamination" in failure_class:
        return "benchmarks/forge_real_benchmark_adapter.py", "contamination failure maps to benchmark boundary adapter"
    if "no_lift" in failure_class or "repeated" in failure_class:
        return "scripts/runtime/forge_proving_ground_autoresearch.py", "repeated no-lift maps to search policy"
    return "dharma_swarm/agent_runner.py", "benchmark failure maps to agent execution surface"


def build_mutation_plan(
    failure_receipt: dict[str, Any],
    repo_root: Path,
    dry_run: bool = True,
    output_dir: Optional[Path] = None,
) -> dict[str, Any]:
    target, rationale = target_for_failure(failure_receipt, repo_root)
    mutable = is_mutable_surface(target, repo_root)
    plan = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "mutation_id": "fpg-mut-%s" % uuid.uuid4().hex[:12],
        "source_failure_receipt_id": str(failure_receipt.get("receipt_id") or failure_receipt.get("task_id") or "unknown"),
        "benchmark_family": str(failure_receipt.get("benchmark_family") or ""),
        "failure_class": str(failure_receipt.get("failure_class") or failure_receipt.get("failure_mode") or ""),
        "target_module": target,
        "patch_surface": [target] if mutable else [],
        "immutable_surfaces": list(IMMUTABLE_PREFIXES) + list(IMMUTABLE_PARTS),
        "rationale": rationale,
        "single_edit_trial": True,
        "planner_status": "candidate",
        "dry_run": dry_run,
        "writes_performed": False,
        "blocked": not mutable,
        "blockers": [] if mutable else ["selected_target_is_immutable"],
    }
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        write_json(output_dir / "autoresearch_plan.json", plan)
        if not dry_run:
            write_json(output_dir / ("%s.plan.json" % plan["mutation_id"]), plan)
            plan["writes_performed"] = True
            write_json(output_dir / "autoresearch_plan.json", plan)
    return plan


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--failure-receipt", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    receipt = read_json(args.failure_receipt)
    plan = build_mutation_plan(receipt, REPO_ROOT, dry_run=not args.live, output_dir=args.output_dir)
    if args.json:
        print(json.dumps(plan, sort_keys=True))
    else:
        print("autoresearch plan: %s -> %s" % (plan["planner_status"], plan["target_module"]))
    return 0 if not plan["blocked"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
