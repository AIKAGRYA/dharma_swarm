#!/usr/bin/env python3
"""Machine readiness grader for the Dharma Forge Proving Ground."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import age_seconds, read_json, read_jsonl, run_command, utc_now, write_json

SCHEMA_VERSION = "forge_proving_ground_readiness.v1"
REPORT_ROOT = Path("reports/forge/proving_ground")
REQUIRED_RECEIPT_FILES = [
    "RUN_MANIFEST.json",
    "readiness.json",
    "provider_roster.json",
    "benchmark_pack.json",
    "gate_receipts.jsonl",
    "iteration_receipts.jsonl",
    "mutation_receipts.jsonl",
    "verification_receipts.jsonl",
    "budget_ledger.jsonl",
    "decision_packet.md",
    "failure_harvest.md",
]
REQUIRED_ITERATION_FIELDS = {
    "run_id",
    "iteration",
    "commit_sha",
    "task_id",
    "benchmark_family",
    "candidate_visible_artifact_hashes",
    "hidden_scorer_artifact_hashes",
    "provider_roster_hash",
    "arm_scores",
    "swarm_lift",
    "uncertainty",
    "proposed_mutation_id",
    "keep_revert_decision",
    "verifier_receipt_id",
    "authority",
}
AUTHORITY_FIELDS = [
    "archive_fitness_mutated",
    "production_router_mutated",
    "trusted_memory_promoted",
    "public_submission_performed",
    "external_action_performed",
]


def repo_python(repo_root: Path) -> Path:
    venv_python = repo_root / ".venv" / "bin" / "python"
    return venv_python if venv_python.exists() else Path(sys.executable)


def latest_run_dir(reports_root: Path) -> Optional[Path]:
    if not reports_root.exists():
        return None
    candidates = [path for path in reports_root.iterdir() if path.is_dir() and (path / "RUN_MANIFEST.json").exists()]
    if not candidates:
        return None
    return max(candidates, key=lambda path: (path / "RUN_MANIFEST.json").stat().st_mtime)


def item(item_id: str, name: str, passed: bool, evidence: dict[str, Any], blocker: str = "", blocked: bool = False) -> dict[str, Any]:
    status = "pass" if passed else "blocked" if blocked else "fail"
    return {
        "id": item_id,
        "name": name,
        "points": 1,
        "status": status,
        "evidence": evidence,
        "blocker": blocker,
    }


def _run_dir_or_block(run_dir: Optional[Path]) -> tuple[Optional[dict[str, Any]], Optional[dict[str, Any]]]:
    if run_dir is None:
        return None, None
    manifest_path = run_dir / "RUN_MANIFEST.json"
    if not manifest_path.exists():
        return None, None
    return read_json(manifest_path), {"run_dir": str(run_dir), "artifact": str(manifest_path)}


def current_commit(repo_root: Path) -> str:
    result = run_command(["git", "rev-parse", "HEAD"], repo_root, timeout=10)
    return result.stdout.strip() if result.returncode == 0 else ""


def check_r1(repo_root: Path) -> dict[str, Any]:
    make = run_command(["make", "-n", "forge-proving-ground-100"], repo_root, timeout=20)
    help_result = run_command([repo_python(repo_root), repo_root / "scripts/runtime/forge_proving_ground_run.py", "--help"], repo_root, timeout=20)
    tests_exist = (repo_root / "tests/test_forge_proving_ground_run.py").exists()
    passed = make.returncode == 0 and "forge_proving_ground_run.py" in make.stdout and help_result.returncode == 0 and tests_exist
    return item(
        "FPG-R1",
        "one-command target exists",
        passed,
        {"command": make.command, "artifact": "Makefile", "summary": make.stdout.strip(), "help_returncode": help_result.returncode},
        "one_command_target_missing_or_not_runner_backed",
    )


def check_r2(run_dir: Optional[Path]) -> dict[str, Any]:
    if run_dir is None:
        return item(
            "FPG-R2",
            "provider oracle is fresh and usable",
            False,
            {"command": "scripts/runtime/forge_provider_oracle.py", "artifact": "", "summary": "no run directory"},
            "blocked_provider_roster_below_minimum_or_stale",
            blocked=True,
        )
    provider_path = run_dir / "provider_roster.json" if run_dir else Path("")
    provider = read_json(provider_path) if provider_path.exists() else {}
    age = age_seconds(str(provider.get("generated_at") or ""))
    passed = (
        provider.get("status") == "pass"
        and int(provider.get("live_cluster_count") or 0) >= 3
        and age is not None
        and age <= int(provider.get("ttl_seconds") or 900)
        and provider.get("secret_values_printed") is False
    )
    return item(
        "FPG-R2",
        "provider oracle is fresh and usable",
        passed,
        {"command": "scripts/runtime/forge_provider_oracle.py", "artifact": str(provider_path), "summary": "clusters=%s age=%s" % (provider.get("live_cluster_count"), age)},
        "blocked_provider_roster_below_minimum_or_stale",
        blocked=provider.get("status") == "blocked",
    )


def check_r3(run_dir: Optional[Path]) -> dict[str, Any]:
    if run_dir is None:
        return item(
            "FPG-R3",
            "real benchmark adapter smoke",
            False,
            {"command": "benchmarks/forge_real_benchmark_adapter.py", "artifact": "", "summary": "no run directory"},
            "real_benchmark_smoke_missing_or_synthetic",
        )
    path = run_dir / "benchmark_pack.json" if run_dir else Path("")
    payload = read_json(path) if path.exists() else {}
    command_text = str((payload.get("command") or {}).get("command") or "")
    trusted_hidden_dir = str(payload.get("trusted_hidden_dir") or "")
    trusted_scorer_dir = str(payload.get("trusted_scorer_dir") or "")
    passed = (
        payload.get("passed") is True
        and payload.get("synthetic_forge_arena") is False
        and bool(payload.get("candidate_visible_hashes"))
        and bool(payload.get("hidden_artifact_hashes"))
        and bool(payload.get("scorer_artifact_hashes"))
        and trusted_hidden_dir
        and trusted_scorer_dir
        and trusted_hidden_dir in command_text
        and trusted_scorer_dir in command_text
    )
    return item(
        "FPG-R3",
        "real benchmark adapter smoke",
        passed,
        {"command": "benchmarks/forge_real_benchmark_adapter.py", "artifact": str(path), "summary": str(payload.get("benchmark_family") or "")},
        "real_benchmark_smoke_missing_or_synthetic",
    )


def check_r4(repo_root: Path, run_dir: Optional[Path]) -> dict[str, Any]:
    if run_dir is None:
        return item(
            "FPG-R4",
            "synthetic Forge Arena still green",
            False,
            {"command": "synthetic gate", "artifact": "", "summary": "no run directory"},
            "synthetic_forge_arena_gate_failed",
        )
    path = run_dir / "synthetic_forge_arena_gate.json" if run_dir else Path("")
    payload = read_json(path) if path.exists() else {}
    tests = run_command(
        [
            repo_python(repo_root),
            "-m",
            "pytest",
            "-q",
            "tests/test_forge_swarm_evolution_arena_v0_taskpack_builder.py",
            "tests/test_forge_swarm_evolution_arena_v0_preflight.py",
            "tests/test_forge_swarm_evolution_arena_v0_measurement_runner.py",
            "--tb=short",
        ],
        repo_root,
        timeout=120,
    )
    passed = payload.get("passed") is True and tests.returncode == 0
    return item(
        "FPG-R4",
        "synthetic Forge Arena still green",
        passed,
        {"command": tests.command, "artifact": str(path), "summary": tests.stdout.strip().splitlines()[-1:]},
        "synthetic_forge_arena_gate_failed",
    )


def check_r5(run_dir: Optional[Path]) -> dict[str, Any]:
    if run_dir is None:
        return item(
            "FPG-R5",
            "autoresearch mutation loop is wired to benchmarks",
            False,
            {"command": "scripts/runtime/forge_proving_ground_autoresearch.py", "artifact": "", "summary": "no run directory"},
            "autoresearch_bridge_plan_missing_or_unscoped",
        )
    path = run_dir / "autoresearch_plan.json" if run_dir else Path("")
    payload = read_json(path) if path.exists() else {}
    passed = (
        payload.get("planner_status") == "candidate"
        and payload.get("single_edit_trial") is True
        and bool(payload.get("patch_surface"))
        and payload.get("writes_performed") is False
    )
    return item(
        "FPG-R5",
        "autoresearch mutation loop is wired to benchmarks",
        passed,
        {"command": "scripts/runtime/forge_proving_ground_autoresearch.py", "artifact": str(path), "summary": str(payload.get("target_module") or "")},
        "autoresearch_bridge_plan_missing_or_unscoped",
    )


def check_r6(run_dir: Optional[Path]) -> dict[str, Any]:
    if run_dir is None:
        return item(
            "FPG-R6",
            "keep/revert is proven",
            False,
            {"command": "scripts/runtime/forge_proving_ground_patch_sandbox.py --self-test", "artifact": "", "summary": "no run directory"},
            "keep_revert_receipts_missing",
        )
    path = run_dir / "mutation_receipts.jsonl" if run_dir else Path("")
    rows = read_jsonl(path) if path.exists() else []
    accepted = any(row.get("kept") is True and row.get("decision") == "keep" for row in rows)
    reverted = any(row.get("reverted") is True and row.get("target_file_restored") is True for row in rows)
    passed = accepted and reverted
    return item(
        "FPG-R6",
        "keep/revert is proven",
        passed,
        {"command": "scripts/runtime/forge_proving_ground_patch_sandbox.py --self-test", "artifact": str(path), "summary": "accepted=%s reverted=%s" % (accepted, reverted)},
        "keep_revert_receipts_missing",
    )


def check_r7(run_dir: Optional[Path]) -> dict[str, Any]:
    if run_dir is None:
        return item(
            "FPG-R7",
            "independent verification exists",
            False,
            {"command": "scripts/runtime/forge_proving_ground_verifier.py", "artifact": "", "summary": "no run directory"},
            "independent_verifier_receipt_missing",
        )
    path = run_dir / "verification_receipts.jsonl" if run_dir else Path("")
    rows = read_jsonl(path) if path.exists() else []
    verified = any(
        row.get("verified") is True
        and row.get("builder_status") == "candidate"
        and bool(row.get("commands"))
        and not row.get("blockers")
        and (row.get("bundle_replay") or {}).get("status") == "pass"
        for row in rows
    )
    passed = verified
    return item(
        "FPG-R7",
        "independent verification exists",
        passed,
        {"command": "scripts/runtime/forge_proving_ground_verifier.py", "artifact": str(path), "summary": "verified=%s" % verified},
        "independent_verifier_receipt_missing",
    )


def check_r8(run_dir: Optional[Path], repo_root: Path) -> dict[str, Any]:
    manifest, base = _run_dir_or_block(run_dir)
    gates = manifest.get("scaling_gates") if manifest else []
    gate_rows = read_jsonl(run_dir / "gate_receipts.jsonl") if run_dir and (run_dir / "gate_receipts.jsonl").exists() else []
    required = {(1, "smoke"), (10, "bounded"), (25, "soak"), (100, "full")}
    observed = {(int(gate.get("iterations") or 0), str(gate.get("mode") or "")) for gate in gates if isinstance(gate, dict) and gate.get("status") == "pass"}
    observed_receipts = {(int(gate.get("iterations") or 0), str(gate.get("mode") or "")) for gate in gate_rows if gate.get("status") == "pass"}
    current = current_commit(repo_root)
    same_commit_hashes = all(
        gate.get("commit_sha") == current
        and gate.get("provider_roster_hash") == manifest.get("provider_roster_hash")
        and gate.get("benchmark_pack_hash") == manifest.get("benchmark_pack_hash")
        and int(gate.get("iteration_receipt_count") or 0) == int(gate.get("iterations") or 0)
        and int(gate.get("budget_receipt_count") or 0) == int(gate.get("iterations") or 0)
        for gate in gate_rows
    )
    passed = required.issubset(observed) and required.issubset(observed_receipts) and len(gate_rows) == 4 and same_commit_hashes
    return item(
        "FPG-R8",
        "1-10-25-100 scaling gates exist",
        passed,
        {"command": "scripts/runtime/forge_proving_ground_run.py --iterations 100 --mode full", "artifact": str(run_dir / "RUN_MANIFEST.json") if run_dir else "", "summary": sorted(list(observed_receipts))},
        "scaling_gate_receipts_missing",
    )


def check_r9(run_dir: Optional[Path], repo_root: Path) -> dict[str, Any]:
    if run_dir is None:
        return item("FPG-R9", "receipts are complete and replayable", False, {"command": "filesystem", "artifact": "", "summary": "no run"}, "receipt_dir_missing")
    files_ok = all((run_dir / name).exists() for name in REQUIRED_RECEIPT_FILES)
    rows = read_jsonl(run_dir / "iteration_receipts.jsonl")
    budget_rows = read_jsonl(run_dir / "budget_ledger.jsonl")
    manifest = read_json(run_dir / "RUN_MANIFEST.json") if (run_dir / "RUN_MANIFEST.json").exists() else {}
    expected_iterations = int(manifest.get("iterations") or 0)
    current = current_commit(repo_root)
    sequence_ok = [int(row.get("iteration") or 0) for row in rows] == list(range(1, expected_iterations + 1))
    budget_ok = [int(row.get("iteration") or 0) for row in budget_rows] == list(range(1, expected_iterations + 1))
    rows_ok = (
        len(rows) == expected_iterations
        and expected_iterations > 0
        and all(REQUIRED_ITERATION_FIELDS.issubset(row) for row in rows)
        and all(row.get("run_id") == manifest.get("run_id") for row in rows)
        and all(row.get("commit_sha") == manifest.get("commit_sha") == current for row in rows)
        and all(row.get("provider_roster_hash") == manifest.get("provider_roster_hash") for row in rows)
        and all(bool(row.get("candidate_visible_artifact_hashes")) for row in rows)
        and all(bool(row.get("hidden_scorer_artifact_hashes")) for row in rows)
        and sequence_ok
    )
    authority_ok = bool(rows) and all(row.get("authority", {}).get(field) is False for row in rows for field in AUTHORITY_FIELDS)
    failure_harvest_ok = True
    failure_path = run_dir / "benchmark_failure_receipt.json"
    if failure_path.exists() and (run_dir / "failure_harvest.md").exists():
        failure = read_json(failure_path)
        harvest_text = (run_dir / "failure_harvest.md").read_text(encoding="utf-8")
        failure_harvest_ok = all(str(failure.get(field) or "") in harvest_text for field in ("receipt_id", "failure_class", "task_id"))
    passed = files_ok and rows_ok and len(budget_rows) == expected_iterations and budget_ok and authority_ok and failure_harvest_ok
    return item(
        "FPG-R9",
        "receipts are complete and replayable",
        passed,
        {"command": "filesystem receipt replay", "artifact": str(run_dir), "summary": "files_ok=%s rows=%s budget_rows=%s" % (files_ok, len(rows), len(budget_rows))},
        "receipt_bundle_incomplete",
    )


def check_r10(repo_root: Path) -> dict[str, Any]:
    python = repo_python(repo_root)
    compile_result = run_command(
        [
            python,
            "-m",
            "py_compile",
            "scripts/runtime/forge_proving_ground_readiness.py",
            "scripts/runtime/forge_proving_ground_run.py",
            "scripts/runtime/forge_provider_oracle.py",
            "scripts/runtime/forge_external_benchmark_proof.py",
            "scripts/runtime/forge_proving_ground_autoresearch.py",
            "scripts/runtime/forge_proving_ground_patch_sandbox.py",
            "scripts/runtime/forge_proving_ground_verifier.py",
            "benchmarks/forge_real_benchmark_adapter.py",
        ],
        repo_root,
        timeout=60,
    )
    pytest_result = run_command(
        [
            python,
            "-m",
            "pytest",
            "-q",
            "tests/test_forge_proving_ground_readiness.py",
            "tests/test_forge_proving_ground_run.py",
            "tests/test_forge_provider_oracle.py",
            "tests/test_forge_external_benchmark_proof.py",
            "tests/test_forge_real_benchmark_adapter.py",
            "tests/test_forge_proving_ground_autoresearch.py",
            "tests/test_forge_proving_ground_patch_sandbox.py",
            "tests/test_forge_proving_ground_verifier.py",
            "--tb=short",
        ],
        repo_root,
        timeout=120,
    )
    diff_result = run_command(["git", "diff", "--check"], repo_root, timeout=60)
    passed = compile_result.returncode == 0 and pytest_result.returncode == 0 and diff_result.returncode == 0
    return item(
        "FPG-R10",
        "CI and local verification pass",
        passed,
        {"command": pytest_result.command, "artifact": "targeted tests", "summary": pytest_result.stdout.strip().splitlines()[-1:]},
        "local_verification_failed",
    )


def build_readiness_report(repo_root: Path, reports_root: Path) -> dict[str, Any]:
    run_dir = latest_run_dir(reports_root)
    checks = [
        check_r1(repo_root),
        check_r2(run_dir),
        check_r3(run_dir),
        check_r4(repo_root, run_dir),
        check_r5(run_dir),
        check_r6(run_dir),
        check_r7(run_dir),
        check_r8(run_dir, repo_root),
        check_r9(run_dir, repo_root),
        check_r10(repo_root),
    ]
    score = sum(1 for row in checks if row["status"] == "pass")
    blockers = [row["blocker"] for row in checks if row["status"] != "pass" and row.get("blocker")]
    next_actions = ["repair %s: %s" % (row["id"], row["blocker"]) for row in checks if row["status"] != "pass"]
    return {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "score": score,
        "max_score": 10,
        "readiness": "%d/10" % score,
        "latest_run_dir": str(run_dir) if run_dir else "",
        "items": checks,
        "blockers": blockers,
        "next_actions": next_actions,
    }


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=REPO_ROOT)
    parser.add_argument("--reports-root", type=Path, default=REPORT_ROOT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args(argv)
    report = build_readiness_report(args.repo_root.resolve(), args.reports_root)
    if args.output:
        write_json(args.output, report)
    if args.json:
        print(json.dumps(report, sort_keys=True))
    else:
        print("Dharma Forge Proving Ground readiness: %s" % report["readiness"])
        for row in report["items"]:
            print("%s %s %s" % (row["id"], row["status"], row["name"]))
    if args.strict and report["score"] != report["max_score"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
