#!/usr/bin/env python3
"""Validate external benchmark proof for Dharma Forge Proving Ground."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import read_json, sha256_file, utc_now, write_json

SCHEMA_VERSION = "forge_external_benchmark_proof.v1"
EXPECTED_DATASET = "terminal-bench/terminal-bench-2"
EXPECTED_AGENT = "oracle"
AUTHORITY_FALSE = {
    "archive_fitness_mutated": False,
    "production_router_mutated": False,
    "trusted_memory_promoted": False,
    "public_submission_performed": False,
    "external_action_performed": False,
    "paid_action_performed": False,
    "protected_identity_mutated": False,
    "self_merge_performed": False,
}


def _first_eval(result: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    evals = ((result.get("stats") or {}).get("evals") or {})
    if not evals:
        return "", {}
    key = sorted(evals)[0]
    return key, evals[key]


def _trial_results(job_dir: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(job_dir.glob("*/result.json")):
        try:
            rows.append(read_json(path))
        except Exception:
            rows.append({"path": str(path), "unreadable": True})
    return rows


def validate_harbor_terminal_bench_proof(job_dir: Path) -> dict[str, Any]:
    blockers: list[str] = []
    config_path = job_dir / "config.json"
    result_path = job_dir / "result.json"
    if not config_path.exists():
        blockers.append("harbor_config_missing")
    if not result_path.exists():
        blockers.append("harbor_result_missing")
    config = read_json(config_path) if config_path.exists() else {}
    result = read_json(result_path) if result_path.exists() else {}

    datasets = config.get("datasets") if isinstance(config.get("datasets"), list) else []
    dataset = datasets[0] if datasets else {}
    dataset_ref = str(dataset.get("ref") or "")
    if dataset.get("name") != EXPECTED_DATASET:
        blockers.append("dataset_not_terminal_bench_2")
    if not dataset_ref.startswith("sha256:"):
        blockers.append("dataset_ref_missing_sha256")
    if ((config.get("agents") or [{}])[0]).get("name") != EXPECTED_AGENT:
        blockers.append("agent_not_oracle")
    if (config.get("environment") or {}).get("type") != "docker":
        blockers.append("environment_not_docker")

    stats = result.get("stats") or {}
    if int(result.get("n_total_trials") or 0) < 1:
        blockers.append("no_trials_requested")
    if int(stats.get("n_completed_trials") or 0) != int(result.get("n_total_trials") or 0):
        blockers.append("completed_trial_count_mismatch")
    if int(stats.get("n_errored_trials") or 0) != 0:
        blockers.append("errored_trials_present")
    eval_key, eval_payload = _first_eval(result)
    if eval_key != "%s__%s" % (EXPECTED_AGENT, EXPECTED_DATASET):
        blockers.append("eval_key_mismatch")
    if int(eval_payload.get("n_trials") or 0) < 1:
        blockers.append("eval_trials_missing")
    if int(eval_payload.get("n_errors") or 0) != 0:
        blockers.append("eval_errors_present")
    metrics = eval_payload.get("metrics") if isinstance(eval_payload.get("metrics"), list) else []
    mean = metrics[0].get("mean") if metrics and isinstance(metrics[0], dict) else None
    if mean != 1.0:
        blockers.append("mean_not_1_0")

    trials = _trial_results(job_dir)
    if not trials:
        blockers.append("trial_result_missing")
    trial_summaries = []
    for trial in trials:
        task_id = trial.get("task_id") if isinstance(trial.get("task_id"), dict) else {}
        reward = ((trial.get("verifier_result") or {}).get("rewards") or {}).get("reward")
        if trial.get("source") != EXPECTED_DATASET:
            blockers.append("trial_source_mismatch")
        if task_id.get("org") != "terminal-bench":
            blockers.append("trial_task_org_mismatch")
        if not str(task_id.get("ref") or "").startswith("sha256:"):
            blockers.append("trial_task_ref_missing_sha256")
        if reward != 1.0:
            blockers.append("trial_reward_not_1_0")
        if trial.get("exception_info") is not None:
            blockers.append("trial_exception_present")
        trial_summaries.append(
            {
                "task_name": trial.get("task_name"),
                "task_ref": task_id.get("ref"),
                "task_checksum": trial.get("task_checksum"),
                "reward": reward,
            }
        )

    proof = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "status": "pass" if not blockers else "fail",
        "blockers": sorted(set(blockers)),
        "job_dir": str(job_dir),
        "job_result": str(result_path),
        "job_result_hash": sha256_file(result_path) if result_path.exists() else "",
        "job_config": str(config_path),
        "job_config_hash": sha256_file(config_path) if config_path.exists() else "",
        "dataset": EXPECTED_DATASET,
        "dataset_ref": dataset_ref,
        "agent": EXPECTED_AGENT,
        "environment": "docker",
        "n_total_trials": result.get("n_total_trials"),
        "n_completed_trials": stats.get("n_completed_trials"),
        "n_errored_trials": stats.get("n_errored_trials"),
        "mean": mean,
        "trial_summaries": trial_summaries,
        "public_submission_performed": False,
        "upload_performed": False,
        "authority": AUTHORITY_FALSE,
    }
    return proof


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    proof = validate_harbor_terminal_bench_proof(args.job_dir)
    if args.output:
        write_json(args.output, proof)
    if args.json:
        print(json.dumps(proof, sort_keys=True))
    else:
        print("external benchmark proof: %s" % proof["status"])
    return 0 if proof["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
