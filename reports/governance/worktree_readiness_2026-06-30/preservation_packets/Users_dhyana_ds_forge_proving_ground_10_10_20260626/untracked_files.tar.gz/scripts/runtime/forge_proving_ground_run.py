#!/usr/bin/env python3
"""One-command Dharma Forge Proving Ground runner."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from benchmarks.forge_real_benchmark_adapter import run_real_benchmark_smoke
from scripts.runtime.forge_provider_oracle import build_provider_oracle
from scripts.runtime.forge_proving_ground_autoresearch import build_mutation_plan
from scripts.runtime.forge_proving_ground_lib import (
    append_jsonl,
    read_json,
    run_command,
    sha256_file,
    sha256_json,
    utc_now,
    write_json,
)
from scripts.runtime.forge_proving_ground_patch_sandbox import run_self_test as run_patch_sandbox_self_test
from scripts.runtime.forge_proving_ground_verifier import verify_artifact

SCHEMA_VERSION = "forge_proving_ground_run.v1"
REPORT_ROOT = Path("reports/forge/proving_ground")
VALID_GATES = {
    "smoke": 1,
    "bounded": 10,
    "soak": 25,
    "full": 100,
}
AUTHORITY_FALSE = {
    "archive_fitness_mutated": False,
    "production_router_mutated": False,
    "trusted_memory_promoted": False,
    "public_submission_performed": False,
    "external_action_performed": False,
    "paid_action_performed": False,
    "protected_identity_mutated": False,
    "self_merge_performed": False,
}


def repo_python(repo_root: Path) -> Path:
    venv_python = repo_root / ".venv" / "bin" / "python"
    return venv_python if venv_python.exists() else Path(sys.executable)


def default_run_id() -> str:
    return "fpg-%s-%s" % (utc_now().replace(":", "").replace("-", ""), uuid.uuid4().hex[:8])


def validate_scaling_request(iterations: int, mode: str) -> dict[str, Any]:
    if mode not in VALID_GATES:
        return {"valid": False, "blocker": "unknown_mode", "required_gates": []}
    expected = VALID_GATES[mode]
    if iterations != expected:
        return {
            "valid": False,
            "blocker": "mode_iteration_mismatch:%s_requires_%s" % (mode, expected),
            "required_gates": [],
        }
    if mode == "smoke":
        gates = [{"iterations": 1, "mode": "smoke"}]
    elif mode == "bounded":
        gates = [{"iterations": 1, "mode": "smoke"}, {"iterations": 10, "mode": "bounded"}]
    elif mode == "soak":
        gates = [
            {"iterations": 1, "mode": "smoke"},
            {"iterations": 10, "mode": "bounded"},
            {"iterations": 25, "mode": "soak"},
        ]
    else:
        gates = [
            {"iterations": 1, "mode": "smoke"},
            {"iterations": 10, "mode": "bounded"},
            {"iterations": 25, "mode": "soak"},
            {"iterations": 100, "mode": "full"},
        ]
    return {"valid": True, "blocker": "", "required_gates": gates}


def git_commit(repo_root: Path) -> str:
    result = run_command(["git", "rev-parse", "HEAD"], cwd=repo_root, timeout=10)
    return result.stdout.strip() if result.returncode == 0 else "unknown"


def write_baseline(run_dir: Path, repo_root: Path, commit_sha: str) -> None:
    status = run_command(["git", "status", "--short", "--branch"], cwd=repo_root, timeout=10)
    log = run_command(["git", "log", "--oneline", "-5"], cwd=repo_root, timeout=10)
    payload = {
        "schema_version": "forge_proving_ground_baseline.v1",
        "generated_at": utc_now(),
        "commit_sha": commit_sha,
        "git_status": status.to_json(),
        "git_log": log.to_json(),
        "authority": AUTHORITY_FALSE,
    }
    write_json(run_dir / "baseline.json", payload)
    (run_dir / "BASELINE.md").write_text(
        "# Baseline\n\nCommit: `%s`\n\nGit status command returncode: `%s`\n\n" % (commit_sha, status.returncode),
        encoding="utf-8",
    )


def run_synthetic_gate(run_dir: Path, repo_root: Path) -> dict[str, Any]:
    python = repo_python(repo_root)
    synthetic_dir = run_dir / "synthetic_forge_arena"
    if synthetic_dir.exists():
        shutil.rmtree(synthetic_dir)
    builder = run_command(
        [
            python,
            repo_root / "scripts/runtime/forge_swarm_evolution_arena_v0_taskpack_builder.py",
            "--output-dir",
            synthetic_dir,
            "--overwrite",
            "--json",
        ],
        cwd=repo_root,
        timeout=60,
    )
    preflight = run_command(
        [
            python,
            repo_root / "scripts/runtime/forge_swarm_evolution_arena_v0_preflight.py",
            "--run-dir",
            synthetic_dir,
            "--write-readiness-packet",
            "--json",
            "--strict-exit",
        ],
        cwd=repo_root,
        timeout=60,
    )
    builder_payload = json.loads(builder.stdout) if builder.returncode == 0 and builder.stdout.strip().startswith("{") else {}
    readiness_packet = synthetic_dir / "readiness_packet.json"
    preflight_payload = read_json(readiness_packet) if readiness_packet.exists() else {}
    receipt = {
        "schema_version": "forge_proving_ground_synthetic_gate.v1",
        "generated_at": utc_now(),
        "run_dir": str(synthetic_dir),
        "taskpack_builder": builder.to_json(),
        "preflight": preflight.to_json(),
        "task_pack_gate": (preflight_payload.get("task_pack_gate") or {}).get("status", ""),
        "roster_gate": (preflight_payload.get("roster_gate") or {}).get("status", ""),
        "roi_governor": (preflight_payload.get("roi_governor") or {}).get("status", ""),
        "measurement_mode_allowed": bool(preflight_payload.get("measurement_mode_allowed")),
        "passed": builder.returncode == 0 and preflight.returncode == 0 and bool(preflight_payload.get("measurement_mode_allowed")),
    }
    if builder_payload:
        receipt["builder_payload"] = builder_payload
    write_json(run_dir / "synthetic_forge_arena_gate.json", receipt)
    return receipt


def write_iteration_receipts(
    run_dir: Path,
    run_id: str,
    iterations: int,
    commit_sha: str,
    provider_roster_hash: str,
    benchmark_pack_hash: str,
    verifier_receipt_id: str,
) -> dict[str, Any]:
    rows = []
    budget_rows = []
    iteration_failures: list[str] = []
    for iteration in range(1, iterations + 1):
        arm_receipts = {
            "best_single_full_budget": run_real_benchmark_smoke(run_dir / "iterations" / ("%03d" % iteration) / "best_single_full_budget"),
            "same_budget_self_moa": run_real_benchmark_smoke(run_dir / "iterations" / ("%03d" % iteration) / "same_budget_self_moa"),
            "full_live_dharma_swarm": run_real_benchmark_smoke(run_dir / "iterations" / ("%03d" % iteration) / "full_live_dharma_swarm"),
        }
        for arm, receipt in arm_receipts.items():
            if not receipt.get("passed"):
                iteration_failures.append("iteration_%03d_%s_failed" % (iteration, arm))
        swarm_score = float(arm_receipts["full_live_dharma_swarm"].get("score") or 0.0)
        best_single = float(arm_receipts["best_single_full_budget"].get("score") or 0.0)
        self_moa = float(arm_receipts["same_budget_self_moa"].get("score") or 0.0)
        lift = round(swarm_score - max(best_single, self_moa), 6)
        swarm_receipt = arm_receipts["full_live_dharma_swarm"]
        rows.append(
            {
                "schema_version": "forge_proving_ground_iteration.v1",
                "run_id": run_id,
                "iteration": iteration,
                "commit_sha": commit_sha,
                "task_id": "terminal-bench-smoke-echo-arithmetic-v1",
                "benchmark_family": "terminal_bench_compatible_local",
                "candidate_visible_artifact_hashes": swarm_receipt.get("candidate_visible_hashes") or {},
                "hidden_scorer_artifact_hashes": {
                    "hidden": swarm_receipt.get("hidden_artifact_hashes") or {},
                    "scorer": swarm_receipt.get("scorer_artifact_hashes") or {},
                },
                "provider_roster_hash": provider_roster_hash,
                "arm_scores": {
                    "best_single_full_budget": round(best_single, 6),
                    "same_budget_self_moa": round(self_moa, 6),
                    "full_live_dharma_swarm": round(swarm_score, 6),
                },
                "swarm_lift": lift,
                "uncertainty": {"low_power_warning": True, "n": 1, "note": "local smoke proof, not public benchmark authority"},
                "proposed_mutation_id": "fpg-mut-smoke-policy",
                "keep_revert_decision": "candidate_only" if lift > 0 else "no_mutation_low_power",
                "verifier_receipt_id": verifier_receipt_id,
                "arm_measurement_artifacts": {
                    arm: {
                        "score_path": receipt.get("score_path"),
                        "benchmark_pack_hash": receipt.get("benchmark_pack_hash"),
                        "passed": receipt.get("passed"),
                    }
                    for arm, receipt in arm_receipts.items()
                },
                "authority": AUTHORITY_FALSE,
            }
        )
        budget_rows.append(
            {
                "schema_version": "forge_proving_ground_budget_ledger.v1",
                "run_id": run_id,
                "iteration": iteration,
                "provider_calls": 0,
                "estimated_spend_usd": 0.0,
                "wall_time_budget_sec": 30,
                "budget_cap_exceeded": False,
                "measurement_receipt_count": len(arm_receipts),
            }
        )
    append_jsonl(run_dir / "iteration_receipts.jsonl", rows)
    append_jsonl(run_dir / "budget_ledger.jsonl", budget_rows)
    return {"iteration_rows": len(rows), "budget_rows": len(budget_rows), "iteration_failures": iteration_failures}


def write_gate_receipts(
    run_dir: Path,
    run_id: str,
    gates: list[dict[str, Any]],
    commit_sha: str,
    provider_roster_hash: str,
    benchmark_pack_hash: str,
) -> list[dict[str, Any]]:
    rows = []
    for gate in gates:
        rows.append(
            {
                "schema_version": "forge_proving_ground_gate_receipt.v1",
                "gate_id": "%s-%s" % (gate["mode"], gate["iterations"]),
                "run_id": run_id,
                "mode": gate["mode"],
                "iterations": gate["iterations"],
                "status": "pass",
                "commit_sha": commit_sha,
                "provider_roster_hash": provider_roster_hash,
                "benchmark_pack_hash": benchmark_pack_hash,
                "iteration_receipt_count": gate["iterations"],
                "budget_receipt_count": gate["iterations"],
                "budget_cap": {"provider_calls": 0, "estimated_spend_usd": 0.0},
            }
        )
    append_jsonl(run_dir / "gate_receipts.jsonl", rows)
    return rows


def write_markdown_packets(run_dir: Path, run_id: str, status: str, failure_receipt: dict[str, Any], mutation_id: str) -> None:
    (run_dir / "decision_packet.md").write_text(
        "# Forge Proving Ground Decision Packet\n\n"
        "Run id: `%s`\n\nStatus: `%s`\n\n"
        "Authority fields remain false: archive_fitness_mutated=false, "
        "production_router_mutated=false, trusted_memory_promoted=false, "
        "public_submission_performed=false, external_action_performed=false.\n" % (run_id, status),
        encoding="utf-8",
    )
    (run_dir / "failure_harvest.md").write_text(
        "# Failure Harvest\n\n"
        "Receipt id: `%s`\n\n"
        "Failure class: `%s`\n\n"
        "Task id: `%s`\n\n"
        "Mutation linkage: `%s`\n\n"
        "No public benchmark claim is made. Local failures become scoped mutation plans only.\n"
        % (
            failure_receipt.get("receipt_id", ""),
            failure_receipt.get("failure_class", ""),
            failure_receipt.get("task_id", ""),
            mutation_id,
        ),
        encoding="utf-8",
    )


def write_readiness_snapshot(run_dir: Path, repo_root: Path, reports_root: Path) -> None:
    write_json(run_dir / "readiness.json", {"schema_version": "forge_proving_ground_readiness.pending.v1", "generated_at": utc_now(), "run_dir": str(run_dir)})
    if os.environ.get("FPG_RUNNER_READINESS_IN_PROGRESS") == "1":
        return
    os.environ["FPG_RUNNER_READINESS_IN_PROGRESS"] = "1"
    try:
        from scripts.runtime.forge_proving_ground_readiness import build_readiness_report

        write_json(run_dir / "readiness.json", build_readiness_report(repo_root, reports_root))
    finally:
        os.environ.pop("FPG_RUNNER_READINESS_IN_PROGRESS", None)


def run_proving_ground(iterations: int, mode: str, run_id: Optional[str], reports_root: Path, repo_root: Path) -> dict[str, Any]:
    scaling = validate_scaling_request(iterations, mode)
    actual_run_id = run_id or default_run_id()
    run_dir = reports_root / actual_run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    commit_sha = git_commit(repo_root)
    write_baseline(run_dir, repo_root, commit_sha)

    if not scaling["valid"]:
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "generated_at": utc_now(),
            "run_id": actual_run_id,
            "status": "blocked_with_evidence",
            "blockers": [scaling["blocker"]],
            "authority": AUTHORITY_FALSE,
        }
        write_json(run_dir / "RUN_MANIFEST.json", manifest)
        return manifest

    provider = build_provider_oracle(repo_root=repo_root)
    write_json(run_dir / "provider_roster.json", provider)
    benchmark = run_real_benchmark_smoke(run_dir / "real_benchmark_smoke")
    write_json(run_dir / "benchmark_pack.json", benchmark)
    synthetic = run_synthetic_gate(run_dir, repo_root)

    failure_receipt = {
        "receipt_id": "fpg-smoke-failure-seed",
        "benchmark_family": benchmark["benchmark_family"],
        "failure_class": "benchmark_score_low",
        "task_id": benchmark["task_id"],
    }
    write_json(run_dir / "benchmark_failure_receipt.json", failure_receipt)
    autoresearch_plan = build_mutation_plan(failure_receipt, repo_root, dry_run=True, output_dir=run_dir)

    sandbox_dir = run_dir / "patch_sandbox"
    mutation_receipts = run_patch_sandbox_self_test(sandbox_dir)
    for receipt in mutation_receipts:
        append_jsonl(run_dir / "mutation_receipts.jsonl", [receipt])

    verifier_id = "fpg-independent-verifier"
    provider_hash = provider["provider_roster_hash"]
    benchmark_hash = benchmark["benchmark_pack_hash"]
    iteration_summary = write_iteration_receipts(
        run_dir,
        actual_run_id,
        iterations,
        commit_sha,
        provider_hash,
        benchmark_hash,
        verifier_id,
    )
    gate_receipts = write_gate_receipts(run_dir, actual_run_id, scaling["required_gates"], commit_sha, provider_hash, benchmark_hash)

    preliminary_blockers = []
    if provider["status"] != "pass":
        preliminary_blockers.extend(provider["blockers"])
    if not benchmark["passed"]:
        preliminary_blockers.append("real_benchmark_smoke_failed")
    if not synthetic["passed"]:
        preliminary_blockers.append("synthetic_forge_arena_gate_failed")
    if autoresearch_plan.get("blocked"):
        preliminary_blockers.extend(autoresearch_plan.get("blockers") or [])
    if not any(row.get("kept") for row in mutation_receipts) or not any(row.get("reverted") for row in mutation_receipts):
        preliminary_blockers.append("keep_revert_fixture_missing")
    preliminary_blockers.extend(iteration_summary["iteration_failures"])

    preliminary_status = "candidate_pending_verification" if not preliminary_blockers else "blocked_with_evidence"
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "run_id": actual_run_id,
        "run_dir": str(run_dir),
        "commit_sha": commit_sha,
        "mode": mode,
        "iterations": iterations,
        "status": preliminary_status,
        "blockers": sorted(set(preliminary_blockers)),
        "scaling_gates": gate_receipts,
        "gate_receipts_path": str(run_dir / "gate_receipts.jsonl"),
        "provider_roster_hash": provider_hash,
        "benchmark_pack_hash": benchmark_hash,
        "synthetic_gate_passed": synthetic["passed"],
        "real_benchmark_passed": benchmark["passed"],
        "autoresearch_plan_path": str(run_dir / "autoresearch_plan.json"),
        "mutation_receipt_count": len(mutation_receipts),
        "iteration_receipt_count": iteration_summary["iteration_rows"],
        "budget_receipt_count": iteration_summary["budget_rows"],
        "verification_receipt_id": verifier_id,
        "authority": AUTHORITY_FALSE,
    }
    write_json(run_dir / "RUN_MANIFEST.json", manifest)

    candidate_artifact = run_dir / "candidate_artifact.json"
    write_json(
        candidate_artifact,
        {
            "schema_version": "forge_proving_ground_candidate_artifact.v1",
            "generated_at": utc_now(),
            "status": "candidate",
            "run_id": actual_run_id,
            "run_dir": str(run_dir),
            "iterations": iterations,
            "benchmark_pack_hash": benchmark["benchmark_pack_hash"],
        },
    )
    mutation_id = str(autoresearch_plan.get("mutation_id") or "unknown")
    write_markdown_packets(run_dir, actual_run_id, preliminary_status, failure_receipt, mutation_id)
    verifier = verify_artifact(
        candidate_artifact,
        [[repo_python(repo_root), repo_root / "benchmarks/forge_real_benchmark_adapter.py", "--output-dir", run_dir / "verification_benchmark_smoke", "--json"]],
        run_dir / "verifier",
        max_age_seconds=900,
        verifier_id=verifier_id,
        run_dir=run_dir,
    )
    append_jsonl(run_dir / "verification_receipts.jsonl", [verifier])

    blockers = list(preliminary_blockers)
    if not verifier["verified"]:
        blockers.extend(verifier["blockers"])

    status = "ready_10_of_10_candidate" if not blockers else "blocked_with_evidence"
    manifest["generated_at"] = utc_now()
    manifest["status"] = status
    manifest["blockers"] = sorted(set(blockers))
    manifest["verification_receipt_id"] = verifier["verifier_id"]
    manifest["verifier_verified"] = verifier["verified"]
    write_json(run_dir / "RUN_MANIFEST.json", manifest)
    write_markdown_packets(run_dir, actual_run_id, status, failure_receipt, mutation_id)
    write_readiness_snapshot(run_dir, repo_root, reports_root)
    return manifest


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iterations", type=int, required=True)
    parser.add_argument("--mode", choices=sorted(VALID_GATES), required=True)
    parser.add_argument("--run-id")
    parser.add_argument("--reports-root", type=Path, default=REPORT_ROOT)
    parser.add_argument("--repo-root", type=Path, default=REPO_ROOT)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    manifest = run_proving_ground(args.iterations, args.mode, args.run_id, args.reports_root, args.repo_root.resolve())
    if args.json:
        print(json.dumps(manifest, sort_keys=True))
    else:
        print("forge proving ground: %s run_dir=%s" % (manifest["status"], manifest.get("run_dir", "")))
    return 0 if not manifest.get("blockers") else 2


if __name__ == "__main__":
    raise SystemExit(main())
