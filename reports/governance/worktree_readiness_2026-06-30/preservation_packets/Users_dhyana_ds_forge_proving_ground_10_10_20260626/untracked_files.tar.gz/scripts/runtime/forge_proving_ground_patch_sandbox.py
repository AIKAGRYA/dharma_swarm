#!/usr/bin/env python3
"""Keep/revert patch sandbox for Dharma Forge Proving Ground mutations."""

from __future__ import annotations

import argparse
import json
import sys
import uuid
from pathlib import Path
from typing import Any, Optional, Sequence

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import append_jsonl, run_command, sha256_text, utc_now, write_json

SCHEMA_VERSION = "forge_proving_ground_patch_sandbox.v1"


def _resolved(path: Path) -> Path:
    return path.expanduser().resolve(strict=False)


def _target_allowed(target_file: Path, allowed_patch_surface: Optional[Sequence[Path | str]]) -> bool:
    if not allowed_patch_surface:
        return False
    target = _resolved(target_file)
    for allowed in allowed_patch_surface:
        allowed_path = _resolved(Path(allowed))
        if target == allowed_path:
            return True
    return False


def run_patch_trial(
    target_file: Path,
    mutation_text: str,
    score_before: float,
    score_after: float,
    test_commands: Sequence[Sequence[str]],
    output_dir: Path,
    mutation_id: Optional[str] = None,
    allowed_patch_surface: Optional[Sequence[Path | str]] = None,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    mutation_id = mutation_id or "mut-%s" % uuid.uuid4().hex[:10]
    if not _target_allowed(target_file, allowed_patch_surface):
        receipt = {
            "schema_version": SCHEMA_VERSION,
            "generated_at": utc_now(),
            "mutation_id": mutation_id,
            "target_file": str(target_file),
            "blocked": True,
            "blockers": ["target_not_in_patch_surface"],
            "decision": "blocked",
            "kept": False,
            "reverted": False,
            "target_file_restored": None,
            "baseline_tests_passed": False,
            "mutation_applied": False,
            "verification_tests_passed": False,
            "score_before": score_before,
            "score_after": score_after,
            "measured_improvement": round(score_after - score_before, 6),
            "allowed_patch_surface": [str(path) for path in allowed_patch_surface or []],
        }
        write_json(output_dir / ("%s_receipt.json" % mutation_id), receipt)
        append_jsonl(output_dir / "mutation_receipts.jsonl", [receipt])
        return receipt

    target_existed_before = target_file.exists()
    before = target_file.read_text(encoding="utf-8") if target_existed_before else ""
    before_hash = sha256_text(before) if target_existed_before else None
    baseline_results = [run_command(command, cwd=target_file.parent, timeout=30).to_json() for command in test_commands]
    baseline_passed = all(result["returncode"] == 0 for result in baseline_results)
    target_file.parent.mkdir(parents=True, exist_ok=True)
    target_file.write_text(before + mutation_text, encoding="utf-8")
    after_apply = target_file.read_text(encoding="utf-8")
    mutation_applied = after_apply != before
    verification_results = [run_command(command, cwd=target_file.parent, timeout=30).to_json() for command in test_commands]
    verification_passed = all(result["returncode"] == 0 for result in verification_results)
    improved = score_after > score_before
    keep = bool(baseline_passed and mutation_applied and verification_passed and improved)
    decision = "keep" if keep else "revert"
    restored_cleanly = False
    if not keep:
        if target_existed_before:
            target_file.write_text(before, encoding="utf-8")
        elif target_file.exists():
            target_file.unlink()
        restored_cleanly = target_file.exists() == target_existed_before
        if target_existed_before and restored_cleanly:
            restored_cleanly = target_file.read_text(encoding="utf-8") == before
    target_exists_after = target_file.exists()
    after_restore_text = target_file.read_text(encoding="utf-8") if target_exists_after else ""
    after_restore_hash = sha256_text(after_restore_text) if target_exists_after else None
    receipt = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "mutation_id": mutation_id,
        "target_file": str(target_file),
        "blocked": False,
        "blockers": [],
        "baseline_tests_passed": baseline_passed,
        "mutation_applied": mutation_applied,
        "verification_tests_passed": verification_passed,
        "score_before": score_before,
        "score_after": score_after,
        "measured_improvement": round(score_after - score_before, 6),
        "decision": decision,
        "kept": keep,
        "reverted": not keep,
        "target_file_restored": restored_cleanly if not keep else None,
        "target_file_existed_before": target_existed_before,
        "target_file_exists_after": target_exists_after,
        "target_file_hash_before": before_hash,
        "target_file_hash_after": after_restore_hash,
        "allowed_patch_surface": [str(path) for path in allowed_patch_surface or []],
        "baseline_results": baseline_results,
        "verification_results": verification_results,
    }
    write_json(output_dir / ("%s_receipt.json" % mutation_id), receipt)
    append_jsonl(output_dir / "mutation_receipts.jsonl", [receipt])
    return receipt


def run_self_test(output_dir: Path) -> list[dict[str, Any]]:
    target = output_dir / "sandbox_target.txt"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("baseline\n", encoding="utf-8")
    command = [sys.executable, "-c", "from pathlib import Path; assert Path('sandbox_target.txt').exists()"]
    allowed = [target]
    accepted = run_patch_trial(target, "accepted\n", 0.2, 0.8, [command], output_dir, "accepted-fixture", allowed_patch_surface=allowed)
    rejected = run_patch_trial(target, "rejected\n", 0.8, 0.1, [command], output_dir, "rejected-fixture", allowed_patch_surface=allowed)
    return [accepted, rejected]


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if not args.self_test:
        parser.error("--self-test is currently required for CLI use")
    receipts = run_self_test(args.output_dir)
    if args.json:
        print(json.dumps({"receipts": receipts}, sort_keys=True))
    else:
        print("patch sandbox self-test receipts=%d" % len(receipts))
    return 0 if any(row["kept"] for row in receipts) and any(row["reverted"] for row in receipts) else 2


if __name__ == "__main__":
    raise SystemExit(main())
