#!/usr/bin/env python3
"""Independent verifier for Dharma Forge Proving Ground candidate artifacts."""

from __future__ import annotations

import argparse
import json
import shlex
import sys
import uuid
from pathlib import Path
from typing import Any, Optional, Sequence

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.runtime.forge_proving_ground_lib import age_seconds, append_jsonl, read_json, read_jsonl, run_command, utc_now, write_json

SCHEMA_VERSION = "forge_proving_ground_verifier.v1"
AUTHORITY_FIELDS = (
    "archive_fitness_mutated",
    "production_router_mutated",
    "trusted_memory_promoted",
    "public_submission_performed",
    "external_action_performed",
)
REQUIRED_BUNDLE_FILES = (
    "RUN_MANIFEST.json",
    "provider_roster.json",
    "benchmark_pack.json",
    "iteration_receipts.jsonl",
    "mutation_receipts.jsonl",
    "budget_ledger.jsonl",
    "decision_packet.md",
    "failure_harvest.md",
)
REQUIRED_ITERATION_FIELDS = {
    "run_id",
    "iteration",
    "commit_sha",
    "task_id",
    "benchmark_family",
    "candidate_visible_artifact_hashes",
    "hidden_scorer_artifact_hashes",
    "provider_roster_hash",
    "arm_scores",
    "swarm_lift",
    "uncertainty",
    "proposed_mutation_id",
    "keep_revert_decision",
    "verifier_receipt_id",
    "authority",
}


def verify_receipt_bundle(run_dir: Path, verifier_id: str) -> dict[str, Any]:
    blockers: list[str] = []
    missing = [name for name in REQUIRED_BUNDLE_FILES if not (run_dir / name).exists()]
    if missing:
        blockers.append("bundle_files_missing:%s" % ",".join(missing))

    manifest = read_json(run_dir / "RUN_MANIFEST.json") if (run_dir / "RUN_MANIFEST.json").exists() else {}
    run_id = str(manifest.get("run_id") or "")
    expected_iterations = int(manifest.get("iterations") or 0)
    provider_hash = str(manifest.get("provider_roster_hash") or "")
    benchmark_hash = str(manifest.get("benchmark_pack_hash") or "")
    commit_sha = str(manifest.get("commit_sha") or "")
    iteration_rows = read_jsonl(run_dir / "iteration_receipts.jsonl")
    budget_rows = read_jsonl(run_dir / "budget_ledger.jsonl")

    if expected_iterations <= 0:
        blockers.append("manifest_iterations_missing")
    if len(iteration_rows) != expected_iterations:
        blockers.append("iteration_row_count_mismatch:%s!=%s" % (len(iteration_rows), expected_iterations))
    if len(budget_rows) != expected_iterations:
        blockers.append("budget_row_count_mismatch:%s!=%s" % (len(budget_rows), expected_iterations))

    expected_sequence = list(range(1, expected_iterations + 1))
    observed_sequence = [int(row.get("iteration") or 0) for row in iteration_rows]
    if observed_sequence != expected_sequence:
        blockers.append("iteration_sequence_mismatch")
    budget_sequence = [int(row.get("iteration") or 0) for row in budget_rows]
    if budget_sequence != expected_sequence:
        blockers.append("budget_sequence_mismatch")

    for index, row in enumerate(iteration_rows, start=1):
        missing_fields = REQUIRED_ITERATION_FIELDS.difference(row)
        if missing_fields:
            blockers.append("iteration_%s_fields_missing:%s" % (index, ",".join(sorted(missing_fields))))
        if row.get("run_id") != run_id:
            blockers.append("iteration_%s_run_id_mismatch" % index)
        if row.get("commit_sha") != commit_sha:
            blockers.append("iteration_%s_commit_mismatch" % index)
        if row.get("provider_roster_hash") != provider_hash:
            blockers.append("iteration_%s_provider_hash_mismatch" % index)
        if row.get("verifier_receipt_id") != verifier_id:
            blockers.append("iteration_%s_verifier_id_mismatch" % index)
        if not row.get("candidate_visible_artifact_hashes"):
            blockers.append("iteration_%s_visible_hashes_missing" % index)
        if not row.get("hidden_scorer_artifact_hashes"):
            blockers.append("iteration_%s_hidden_scorer_hashes_missing" % index)
        authority = row.get("authority") if isinstance(row.get("authority"), dict) else {}
        if any(authority.get(field) is not False for field in AUTHORITY_FIELDS):
            blockers.append("iteration_%s_authority_not_false" % index)
    benchmark = read_json(run_dir / "benchmark_pack.json") if (run_dir / "benchmark_pack.json").exists() else {}
    if benchmark_hash and benchmark.get("benchmark_pack_hash") != benchmark_hash:
        blockers.append("benchmark_pack_hash_mismatch")

    decision_packet = (run_dir / "decision_packet.md").read_text(encoding="utf-8") if (run_dir / "decision_packet.md").exists() else ""
    if not all("%s=false" % field in decision_packet for field in AUTHORITY_FIELDS):
        blockers.append("decision_packet_authority_missing")

    failure_receipt_path = run_dir / "benchmark_failure_receipt.json"
    failure_harvest = (run_dir / "failure_harvest.md").read_text(encoding="utf-8") if (run_dir / "failure_harvest.md").exists() else ""
    if failure_receipt_path.exists():
        failure = read_json(failure_receipt_path)
        for field in ("receipt_id", "failure_class", "task_id"):
            value = str(failure.get(field) or "")
            if value and value not in failure_harvest:
                blockers.append("failure_harvest_missing_%s" % field)

    return {
        "status": "pass" if not blockers else "fail",
        "blockers": sorted(set(blockers)),
        "run_dir": str(run_dir),
        "iteration_rows": len(iteration_rows),
        "budget_rows": len(budget_rows),
        "expected_iterations": expected_iterations,
    }


def verify_artifact(
    artifact_path: Path,
    commands: Sequence[Sequence[str]],
    output_dir: Path,
    max_age_seconds: int = 900,
    verifier_id: Optional[str] = None,
    run_dir: Optional[Path] = None,
    write_receipts: bool = True,
) -> dict[str, Any]:
    if write_receipts:
        output_dir.mkdir(parents=True, exist_ok=True)
    verifier_id = verifier_id or "verifier-%s" % uuid.uuid4().hex[:10]
    blockers: list[str] = []
    artifact_payload: dict[str, Any] = {}
    artifact_age: Optional[float] = None
    if not artifact_path.exists():
        blockers.append("artifact_missing")
    else:
        try:
            artifact_payload = read_json(artifact_path)
        except Exception as exc:
            blockers.append("artifact_unreadable:%s" % type(exc).__name__)
        generated_at = str(artifact_payload.get("generated_at") or artifact_payload.get("created_at") or "")
        artifact_age = age_seconds(generated_at)
        if artifact_age is None:
            blockers.append("artifact_timestamp_missing")
        elif artifact_age > max_age_seconds:
            blockers.append("artifact_stale")

    builder_status = str(artifact_payload.get("status") or "")
    if builder_status != "candidate":
        blockers.append("builder_status_not_candidate")

    if not commands:
        blockers.append("verifier_commands_missing")
    command_results = [run_command(command, cwd=REPO_ROOT, timeout=60, output_limit=None).to_json() for command in commands]
    if any(result["returncode"] != 0 for result in command_results):
        blockers.append("verifier_command_failed")
    bundle_replay = verify_receipt_bundle(run_dir, verifier_id) if run_dir is not None else None
    if bundle_replay is not None and bundle_replay["status"] != "pass":
        blockers.append("receipt_bundle_replay_failed")
    receipt = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "verifier_id": verifier_id,
        "artifact": str(artifact_path),
        "artifact_age_seconds": artifact_age,
        "max_age_seconds": max_age_seconds,
        "builder_status": builder_status,
        "verified": not blockers,
        "blockers": blockers,
        "commands": command_results,
        "bundle_replay": bundle_replay,
    }
    if write_receipts:
        write_json(output_dir / ("%s_receipt.json" % verifier_id), receipt)
        append_jsonl(output_dir / "verification_receipts.jsonl", [receipt])
    return receipt


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-age-seconds", type=int, default=900)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--command", action="append", default=[])
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    commands = [shlex.split(command) for command in args.command]
    receipt = verify_artifact(args.artifact, commands, args.output_dir, args.max_age_seconds, run_dir=args.run_dir, write_receipts=not args.dry_run)
    if args.json:
        print(json.dumps(receipt, sort_keys=True))
    else:
        print("verifier: %s" % ("verified" if receipt["verified"] else "failed"))
    return 0 if receipt["verified"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
