# Forge Naming Boundary

Status: active governance boundary
Owner: docs/governance/FORGE_NAMING_BOUNDARY.md
Updated: 2026-06-26

## Canonical Names

`Dharma Forge Proving Ground` is the canonical umbrella system for external
swarm evolution and benchmark hardening through measured reality.

`Forge Proving Ground` is the preferred short operator phrase.

`Dharma Forge` is a legacy/root machinery alias for reward forge, Hydra
lineage, receipt scoring, and historical Forge mechanisms. Use it only when
the historical machinery is the subject.

`Forge Arena` is the internal or local competitive/collaborative task arena.

`Forge Swarm Evolution Arena v0` is the current synthetic sealed microtask
measurement family.

`Pudgala Autopoiesis Protostar` is a separate anti-slop governance and evidence
mechanism. It is never the Forge Proving Ground and must not be renamed into
Forge.

## Preferred Operator Language

Preferred:

- run the Dharma Forge Proving Ground
- run the Forge Proving Ground
- run the canonical Forge Proving Ground external loop

Deprecated:

- run Forge

The deprecated phrase is too broad: it can mean historical Hydra machinery,
local Arena tasks, or anti-slop evidence gates. Operators and agents should
use the specific preferred phrase that matches the intended system.

## Authority Boundary

The Dharma Forge Proving Ground may produce local receipts, benchmark smoke
proof, provider roster proof, mutation keep/revert proof, and verifier proof.
It does not authorize public benchmark submission, external outreach, paid
action, production router mutation, archive-fitness mutation, trusted-memory
promotion, self-merge, or protected identity mutation without a separate
current operator lease.
