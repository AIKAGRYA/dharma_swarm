#!/usr/bin/env python3
"""Forge NVIDIA Guard: deterministic claim gates plus optional NVIDIA NIM critique.

This runner is intentionally receipt-first. It does not run benchmarks, mutate
archive fitness, or make public claims. It reads a Forge packet directory,
checks the canonical claim gates from reports/forge/FORGE_CANONICAL_INDEX.md,
and can ask an NVIDIA NIM model to review the same packet summary as an
external critic lane.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dharma_swarm.models import LLMRequest, ProviderType  # noqa: E402
from dharma_swarm.runtime_provider import (  # noqa: E402
    create_runtime_provider,
    resolve_runtime_provider_config,
)

SCHEMA_VERSION = "forge_nvidia_guard.v0"
DEFAULT_MODEL = "deepseek-ai/deepseek-v4-flash"
DEFAULT_OUT_NAME = "nvidia_guard_review.json"
DEFAULT_MD_NAME = "nvidia_guard_review.md"

VALID_CLOSEOUT_STATES = {
    "positive_lift_candidate",
    "measured_negative",
    "inconclusive_low_power",
    "contaminated_quarantine",
    "blocked_with_evidence",
}

REQUIRED_PACKET_FILES = [
    "run_manifest.json",
    "task_manifest.jsonl",
    "model_roster.json",
    "budget_ledger.jsonl",
    "coordination_edges.jsonl",
    "results.jsonl",
    "control_comparison.md",
    "failure_taxonomy.md",
    "decision_record.md",
]

REQUIRED_CONTROL_ARMS = {
    "frontier_single_full_budget",
    "best_single_full_budget",  # v0/v1 alias for frontier_single_full_budget
    "best_of_n_same_model",
    "same_budget_self_moa",
    "planner_builder_verifier_no_a2a",
    "labels_only_sham_swarm",  # v0 alias for no-a2a PBV-ish control
    "full_a2a_swarm",
    "full_live_dharma_swarm",  # v0 alias for full A2A swarm
}

MUTATION_FLAGS = [
    "trainer_built",
    "production_router_mutated",
    "archive_fitness_mutated",
    "official_score_claimed",
    "public_submission_performed",
    "external_confirmed",
]

SUPERIORITY_PATTERNS = [
    "beats the best single model",
    "swarm beats",
    "dharma swarm beats",
    "superior to best single",
    "outperforms the best single",
]


@dataclass(frozen=True)
class Finding:
    severity: str
    code: str
    message: str
    evidence: list[str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "evidence": self.evidence,
        }


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def read_text(path: Path, *, limit_chars: int | None = None) -> str:
    text = path.read_text(encoding="utf-8", errors="replace")
    if limit_chars is not None and len(text) > limit_chars:
        return text[:limit_chars] + f"\n...[truncated {len(text) - limit_chars} chars]"
    return text


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return data if isinstance(data, dict) else {"_non_object_json": data}


def read_jsonl(path: Path, *, max_rows: int = 20_000) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            row = json.loads(stripped)
        except json.JSONDecodeError:
            rows.append({"_parse_error": stripped[:300]})
            continue
        rows.append(row if isinstance(row, dict) else {"_non_object_json": row})
        if len(rows) >= max_rows:
            break
    return rows


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def sha256_path(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    return sha256(path.read_bytes()).hexdigest()


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def extract_json_object(text: str) -> dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*", "", stripped)
        stripped = re.sub(r"\s*```$", "", stripped)
    try:
        data = json.loads(stripped)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", stripped, flags=re.S)
        if not match:
            raise
        data = json.loads(match.group(0))
    if not isinstance(data, dict):
        raise ValueError("expected JSON object")
    return data


def collect_packet(packet_dir: Path) -> dict[str, Any]:
    packet_dir = packet_dir.expanduser().resolve()
    run_report = read_json(packet_dir / "swarm_lift_report.json")
    measurement_reports = sorted(packet_dir.glob("measurement_runs/*/swarm_lift_report.json"))
    if not run_report and measurement_reports:
        run_report = read_json(measurement_reports[-1])

    result_rows = read_jsonl(packet_dir / "results.jsonl")
    budget_rows = read_jsonl(packet_dir / "budget_ledger.jsonl")
    edge_rows = read_jsonl(packet_dir / "coordination_edges.jsonl")
    task_rows = read_jsonl(packet_dir / "task_manifest.jsonl")
    model_roster = read_json(packet_dir / "model_roster.json")
    run_manifest = read_json(packet_dir / "run_manifest.json")

    score_rows: list[dict[str, Any]] = []
    for path in sorted(packet_dir.glob("measurement_runs/*/score_rows.jsonl")):
        score_rows.extend(read_jsonl(path))
    if not result_rows and score_rows:
        result_rows = score_rows

    decision_text = ""
    for name in ("decision_record.md", "decision_packet.md"):
        path = packet_dir / name
        if path.exists():
            decision_text = read_text(path, limit_chars=12000)
            break

    files = {
        name: {
            "exists": (packet_dir / name).exists(),
            "sha256": sha256_path(packet_dir / name),
        }
        for name in REQUIRED_PACKET_FILES
    }

    return {
        "packet_dir": str(packet_dir),
        "run_manifest": run_manifest,
        "task_manifest_rows": task_rows,
        "model_roster": model_roster,
        "budget_rows": budget_rows,
        "coordination_edges": edge_rows,
        "result_rows": result_rows,
        "run_report": run_report,
        "decision_text": decision_text,
        "files": files,
        "measurement_report_paths": [str(path) for path in measurement_reports],
    }


def task_count(packet: dict[str, Any]) -> int:
    report = packet.get("run_report") or {}
    if report.get("task_count") is not None:
        return safe_int(report.get("task_count"))
    rows = packet.get("task_manifest_rows") or []
    if rows:
        return len(rows)
    task_ids = {str(row.get("task_id") or row.get("instance_id") or "") for row in packet.get("result_rows") or []}
    return len({task_id for task_id in task_ids if task_id})


def closeout_state(packet: dict[str, Any]) -> str:
    report = packet.get("run_report") or {}
    status = str(report.get("status") or "").strip()
    if status:
        return status
    text = str(packet.get("decision_text") or "")
    for state in VALID_CLOSEOUT_STATES:
        if state in text:
            return state
    return ""


def arms_present(packet: dict[str, Any]) -> set[str]:
    arms: set[str] = set()
    for row in packet.get("result_rows") or []:
        arm = str(row.get("arm") or row.get("control_arm") or row.get("topology") or "").strip()
        if arm:
            arms.add(arm)
    roster = packet.get("model_roster") or {}
    for key in ("arms", "control_arms", "routes"):
        value = roster.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    arm = str(item.get("arm") or item.get("name") or "").strip()
                    if arm:
                        arms.add(arm)
                elif item:
                    arms.add(str(item))
    return arms


def canonical_arm_coverage(arms: set[str]) -> dict[str, bool]:
    return {
        "frontier_single_full_budget": bool({"frontier_single_full_budget", "best_single_full_budget"} & arms),
        "best_of_n_same_model": "best_of_n_same_model" in arms,
        "same_budget_self_moa": "same_budget_self_moa" in arms,
        "planner_builder_verifier_no_a2a": bool({"planner_builder_verifier_no_a2a", "labels_only_sham_swarm"} & arms),
        "full_a2a_swarm": bool({"full_a2a_swarm", "full_live_dharma_swarm"} & arms),
    }


def invalid_run_rate(packet: dict[str, Any]) -> float | None:
    rows = packet.get("result_rows") or []
    if not rows:
        return None
    invalid = 0
    total = 0
    for row in rows:
        if row.get("result_kind") == "sample":
            continue
        total += 1
        ok = row.get("candidate_ok")
        status = str(row.get("status") or row.get("result") or "").lower()
        if ok is False or status in {"invalid", "failed", "timeout", "error"}:
            invalid += 1
    if total == 0:
        return None
    return invalid / total


def final_use_ratio(packet: dict[str, Any]) -> float | None:
    rows = packet.get("coordination_edges") or []
    if not rows:
        return None
    swarm_only = [row for row in rows if row.get("swarm_only_win") or row.get("edge_kind") == "swarm_only_win"]
    target = swarm_only or rows
    if not target:
        return None
    used = 0
    for row in target:
        if row.get("final_use_proof") or row.get("consumed_by_final_action") or row.get("final_incorporated"):
            used += 1
    return used / len(target)


def budget_parity(packet: dict[str, Any]) -> dict[str, Any]:
    rows = packet.get("budget_rows") or []
    budgets: dict[str, float] = {}
    for row in rows:
        arm = str(row.get("arm") or row.get("control_arm") or "").strip()
        if not arm:
            continue
        amount = row.get("total_tokens") or row.get("tokens") or row.get("budget_tokens") or row.get("cost_usd") or row.get("actual_cost_usd")
        budgets[arm] = budgets.get(arm, 0.0) + safe_float(amount)
    if not budgets:
        return {"status": "missing", "by_arm": {}}
    values = [value for value in budgets.values() if value > 0]
    if len(values) < 2:
        return {"status": "insufficient", "by_arm": budgets}
    low = min(values)
    high = max(values)
    ratio = high / low if low else float("inf")
    return {
        "status": "pass" if ratio <= 1.10 else "mismatch",
        "max_to_min_ratio": ratio,
        "by_arm": budgets,
    }


def claim_requests_superiority(claim_text: str, report: dict[str, Any]) -> bool:
    claim_lower = claim_text.lower()
    if any(pattern in claim_lower for pattern in SUPERIORITY_PATTERNS):
        return True
    explicit = report.get("claim_superiority")
    if isinstance(explicit, bool):
        return explicit
    return False


def evaluate_deterministic(packet: dict[str, Any], *, claim_text: str = "") -> dict[str, Any]:
    findings: list[Finding] = []
    files = packet.get("files") or {}
    missing = [name for name, meta in files.items() if not meta.get("exists")]
    if missing:
        findings.append(
            Finding(
                "warning",
                "minimum_packet_incomplete",
                "Canonical Forge minimum packet files are missing; this may be a v0/v1 compatibility packet, not the full external-loop packet.",
                missing,
            )
        )

    state = closeout_state(packet)
    if not state:
        findings.append(Finding("error", "closeout_state_missing", "No valid closeout state found.", []))
    elif state not in VALID_CLOSEOUT_STATES:
        findings.append(Finding("error", "closeout_state_invalid", f"Invalid closeout state: {state}", [state]))

    report = packet.get("run_report") or {}
    tasks = task_count(packet)
    rubric_items = safe_int(report.get("rubric_item_count"), 0)
    scores_raw = report.get("scores")
    scores: dict[str, Any] = scores_raw if isinstance(scores_raw, dict) else {}
    swarm_lift = safe_float(report.get("swarm_lift"), 0.0)
    ci_raw = report.get("paired_bootstrap_ci")
    ci: dict[str, Any] = ci_raw if isinstance(ci_raw, dict) else {}
    ci_lower = safe_float(ci.get("lower"), 0.0)
    invalid_rate = invalid_run_rate(packet)
    use_ratio = final_use_ratio(packet)
    parity = budget_parity(packet)
    arms = arms_present(packet)
    coverage = canonical_arm_coverage(arms)
    superiority_claim = claim_requests_superiority(claim_text, report)

    if tasks < 3:
        findings.append(Finding("warning", "low_power_under_3_tasks", "Fewer than 3 tasks; valid closeout should be inconclusive_low_power unless blocked.", [f"task_count={tasks}"]))
    if tasks < 100:
        findings.append(Finding("info", "below_public_claim_task_floor", "Fewer than 100 paired external tasks; superiority claim is forbidden.", [f"task_count={tasks}"]))
    if rubric_items and rubric_items < 30:
        findings.append(Finding("warning", "rubric_item_floor_missed", "Rubric item count is below Forge v0/v1 minimum power floor.", [f"rubric_item_count={rubric_items}"]))

    missing_arms = [arm for arm, ok in coverage.items() if not ok]
    if missing_arms:
        findings.append(Finding("warning", "control_arms_incomplete", "Not all canonical control arms are visible in the packet.", missing_arms))

    if parity["status"] == "missing":
        findings.append(Finding("warning", "budget_ledger_missing", "No budget ledger rows found; equal-budget claim cannot be verified.", []))
    elif parity["status"] == "mismatch":
        findings.append(Finding("error", "budget_parity_failed", "Budget parity exceeds 10% max/min tolerance.", [json.dumps(parity["by_arm"], sort_keys=True)]))

    if invalid_rate is None:
        findings.append(Finding("warning", "invalid_run_rate_unknown", "No result rows available to compute invalid-run rate.", []))
    elif invalid_rate >= 0.05:
        findings.append(Finding("error", "invalid_run_rate_too_high", "Invalid-run rate is >= 5%.", [f"invalid_run_rate={invalid_rate:.4f}"]))

    if use_ratio is None:
        findings.append(Finding("warning", "final_use_proof_missing", "No coordination-edge final-use proof found.", []))
    elif use_ratio < 0.30:
        findings.append(Finding("error", "final_use_proof_below_gate", "Final-use proof covers less than 30% of swarm-only/coordination edges.", [f"final_use_ratio={use_ratio:.4f}"]))

    authority_raw = report.get("authority")
    authority: dict[str, Any] = authority_raw if isinstance(authority_raw, dict) else {}
    mutated = [flag for flag in MUTATION_FLAGS if authority.get(flag) is True]
    if mutated:
        findings.append(Finding("error", "authority_boundary_mutated", "Forbidden authority boundary flag is true.", mutated))

    if state == "positive_lift_candidate" and swarm_lift <= 0:
        findings.append(Finding("error", "positive_lift_without_positive_delta", "Closeout is positive_lift_candidate but swarm_lift is not positive.", [f"swarm_lift={swarm_lift}"]))

    if superiority_claim:
        claim_blockers: list[str] = []
        if tasks < 100:
            claim_blockers.append("task_count<100")
        if any(not ok for ok in coverage.values()):
            claim_blockers.append("missing_control_arms")
        if ci_lower <= 0:
            claim_blockers.append("ci_lower<=0")
        if swarm_lift < 0.05:
            claim_blockers.append("swarm_lift<0.05")
        if invalid_rate is None or invalid_rate >= 0.05:
            claim_blockers.append("invalid_run_rate_missing_or_high")
        if use_ratio is None or use_ratio < 0.30:
            claim_blockers.append("final_use_proof<0.30")
        if claim_blockers:
            findings.append(Finding("error", "superiority_claim_forbidden", "The requested superiority claim fails Forge claim gates.", claim_blockers))

    severities = [finding.severity for finding in findings]
    if "error" in severities:
        verdict = "blocked_with_evidence"
    elif state in {"blocked_with_evidence", "contaminated_quarantine"}:
        verdict = state
    elif "warning" in severities or state == "inconclusive_low_power":
        verdict = "revise_protocol"
    else:
        verdict = "pass_for_next_scale"

    return {
        "verdict": verdict,
        "claim_superiority_requested": superiority_claim,
        "closeout_state": state,
        "task_count": tasks,
        "rubric_item_count": rubric_items,
        "scores": scores,
        "swarm_lift": swarm_lift,
        "paired_ci_lower": ci_lower,
        "invalid_run_rate": invalid_rate,
        "final_use_ratio": use_ratio,
        "budget_parity": parity,
        "arms_present": sorted(arms),
        "canonical_arm_coverage": coverage,
        "findings": [finding.as_dict() for finding in findings],
    }


def compact_packet_summary(packet: dict[str, Any], deterministic: dict[str, Any], *, max_chars: int) -> str:
    summary = {
        "schema_version": SCHEMA_VERSION,
        "packet_dir": packet.get("packet_dir"),
        "deterministic_review": deterministic,
        "run_manifest": packet.get("run_manifest") or {},
        "model_roster_keys": sorted((packet.get("model_roster") or {}).keys()),
        "file_presence": packet.get("files") or {},
        "result_rows_sample": (packet.get("result_rows") or [])[:20],
        "budget_rows_sample": (packet.get("budget_rows") or [])[:20],
        "coordination_edges_sample": (packet.get("coordination_edges") or [])[:20],
        "decision_text_excerpt": str(packet.get("decision_text") or "")[:4000],
    }
    text = json.dumps(summary, indent=2, sort_keys=True)
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + f"\n...[truncated {len(text) - max_chars} chars]"


def build_nim_prompt(packet: dict[str, Any], deterministic: dict[str, Any], *, claim_text: str, max_chars: int) -> str:
    packet_summary = compact_packet_summary(packet, deterministic, max_chars=max_chars)
    return f"""You are the NVIDIA/NIM external critic lane for Dharma Forge Proving Ground.

Your job is not to solve the benchmark. Your job is to prevent false victory from entering routing, memory, public claims, or archive fitness.

Return JSON only with this shape:
{{
  "verdict": "pass_for_next_scale|revise_protocol|blocked_with_evidence|contaminated_quarantine",
  "summary": "one concise paragraph",
  "strongest_blockers": ["..."],
  "claim_allowed": true,
  "next_experiment": "specific next build/run step",
  "nvidia_stack_use": ["nim_critic", "rag_receipt_retrieval", "data_designer_adversarial_cases", "nemo_evaluator", "aiq_workflow"],
  "confidence": 0.0
}}

Apply the Forge claim gates strictly:
- superiority requires at least 100 valid paired external tasks;
- strongest single frontier control has equal or greater budget;
- best-of-N, Self-MoA, no-A2A PBV, and full A2A swarm arms ran;
- paired confidence interval lower bound > 0;
- absolute lift >= 5 percentage points or arena-specific lower bound beats control;
- resolved-per-dollar/token beats strongest control by at least 10% unless explicitly not cost-efficient;
- invalid runs below 5%;
- final-use proof for at least 30% of swarm-only wins;
- no trainer/archive/router/memory/public mutation without separate lease.

Claim under review:
{claim_text or "(no explicit superiority claim)"}

Packet summary:
{packet_summary}
"""


async def call_nvidia_nim(prompt: str, *, model: str, timeout_seconds: int, max_tokens: int) -> dict[str, Any]:
    config = resolve_runtime_provider_config(
        ProviderType.NVIDIA_NIM,
        model=model,
        timeout_seconds=timeout_seconds,
    )
    if not config.available:
        raise RuntimeError("NVIDIA_NIM_API_KEY is not available")
    provider = create_runtime_provider(config)
    request = LLMRequest(
        model=config.default_model or model,
        system="Return JSON only. Be strict. Do not flatter.",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
        max_tokens=max_tokens,
    )
    try:
        response = await provider.complete(request)
        content = str(response.content or "")
        parsed: dict[str, Any]
        try:
            parsed = extract_json_object(content)
        except Exception as exc:  # noqa: BLE001 - include raw response as evidence
            parsed = {
                "verdict": "revise_protocol",
                "summary": "NIM critic returned non-JSON or unparsable JSON.",
                "strongest_blockers": [f"json_parse_failed: {type(exc).__name__}: {exc}"],
                "claim_allowed": False,
                "next_experiment": "Repair prompt/schema before trusting NIM critic output.",
                "nvidia_stack_use": ["nim_critic"],
                "confidence": 0.0,
                "raw_response_excerpt": content[:2000],
            }
        parsed["model_identity"] = {
            "provider": "nvidia_nim",
            "model": response.model or model,
        }
        parsed["usage"] = response.usage
        return parsed
    finally:
        close = getattr(provider, "close", None)
        if callable(close):
            result = close()
            if asyncio.iscoroutine(result):
                await result


def load_mock_nim_response(path: Path) -> dict[str, Any]:
    text = path.expanduser().resolve().read_text(encoding="utf-8")
    data = extract_json_object(text)
    data.setdefault("model_identity", {"provider": "mock_nvidia_nim", "model": "mock"})
    data.setdefault("usage", {})
    return data


def render_markdown(review: dict[str, Any]) -> str:
    deterministic = review["deterministic_review"]
    nim = review.get("nvidia_nim_review") or {}
    lines = [
        "# Forge NVIDIA Guard Review",
        "",
        f"- generated_at: `{review['generated_at']}`",
        f"- packet_dir: `{review['packet_dir']}`",
        f"- deterministic_verdict: `{deterministic['verdict']}`",
        f"- closeout_state: `{deterministic.get('closeout_state')}`",
        f"- task_count: `{deterministic.get('task_count')}`",
        f"- swarm_lift: `{deterministic.get('swarm_lift')}`",
        f"- invalid_run_rate: `{deterministic.get('invalid_run_rate')}`",
        f"- final_use_ratio: `{deterministic.get('final_use_ratio')}`",
        "",
        "## Deterministic Findings",
        "",
    ]
    findings = deterministic.get("findings") or []
    if not findings:
        lines.append("- none")
    else:
        for finding in findings:
            evidence = "; ".join(str(item) for item in finding.get("evidence") or [])
            suffix = f" Evidence: {evidence}" if evidence else ""
            lines.append(f"- `{finding.get('severity')}` `{finding.get('code')}`: {finding.get('message')}{suffix}")
    lines.extend(["", "## NVIDIA/NIM Critic", ""])
    if nim:
        lines.append(f"- verdict: `{nim.get('verdict', '')}`")
        lines.append(f"- model: `{(nim.get('model_identity') or {}).get('provider', '')}/{(nim.get('model_identity') or {}).get('model', '')}`")
        lines.append(f"- claim_allowed: `{nim.get('claim_allowed', '')}`")
        lines.append(f"- summary: {nim.get('summary', '')}")
        blockers = nim.get("strongest_blockers") or []
        if blockers:
            lines.append("- strongest_blockers:")
            for blocker in blockers:
                lines.append(f"  - {blocker}")
        if nim.get("next_experiment"):
            lines.append(f"- next_experiment: {nim.get('next_experiment')}")
    else:
        lines.append("- not run")
    lines.extend([
        "",
        "## Authority",
        "",
        "This guard does not run benchmarks, mutate archive fitness, mutate trainers, mutate routers, make public claims, or submit to external benchmarks.",
    ])
    return "\n".join(lines) + "\n"


def run_guard(
    *,
    packet_dir: Path,
    out_dir: Path | None = None,
    claim_text: str = "",
    with_nim: bool = False,
    nim_model: str = DEFAULT_MODEL,
    mock_nim_response_file: Path | None = None,
    timeout_seconds: int = 120,
    max_prompt_chars: int = 14000,
    max_tokens: int = 900,
) -> dict[str, Any]:
    packet = collect_packet(packet_dir)
    deterministic = evaluate_deterministic(packet, claim_text=claim_text)
    prompt = build_nim_prompt(packet, deterministic, claim_text=claim_text, max_chars=max_prompt_chars)
    prompt_hash = sha256(prompt.encode("utf-8")).hexdigest()

    nim_review: dict[str, Any] | None = None
    if mock_nim_response_file is not None:
        nim_review = load_mock_nim_response(mock_nim_response_file)
    elif with_nim:
        nim_review = asyncio.run(
            call_nvidia_nim(
                prompt,
                model=nim_model,
                timeout_seconds=timeout_seconds,
                max_tokens=max_tokens,
            )
        )

    review = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "packet_dir": str(Path(packet_dir).expanduser().resolve()),
        "guard_prompt_sha256": prompt_hash,
        "deterministic_review": deterministic,
        "nvidia_nim_review": nim_review,
        "authority": {
            "benchmarks_run": False,
            "trainer_mutated": False,
            "archive_fitness_mutated": False,
            "production_router_mutated": False,
            "public_claim_made": False,
            "external_submission_performed": False,
        },
    }

    target_dir = (out_dir or packet_dir).expanduser().resolve()
    json_path = target_dir / DEFAULT_OUT_NAME
    md_path = target_dir / DEFAULT_MD_NAME
    write_json(json_path, review)
    md_path.write_text(render_markdown(review), encoding="utf-8")
    review["artifact_paths"] = {"json": str(json_path), "markdown": str(md_path)}
    return review


def build_parser() -> argparse.ArgumentParser:
    description = (__doc__ or "Forge NVIDIA Guard").splitlines()[0]
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--packet-dir", required=True, help="Forge packet/run directory to audit")
    parser.add_argument("--out-dir", default="", help="Output directory; defaults to packet dir")
    parser.add_argument("--claim", default="", help="Claim text to test against Forge claim gates")
    parser.add_argument("--with-nim", action="store_true", help="Call NVIDIA NIM critic after deterministic review")
    parser.add_argument("--nim-model", default=DEFAULT_MODEL)
    parser.add_argument("--mock-nim-response-file", default="", help="Fixture JSON for tests/offline dry-runs")
    parser.add_argument("--timeout-seconds", type=int, default=120)
    parser.add_argument("--max-prompt-chars", type=int, default=14000)
    parser.add_argument("--max-tokens", type=int, default=900)
    parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    review = run_guard(
        packet_dir=Path(args.packet_dir),
        out_dir=Path(args.out_dir) if args.out_dir else None,
        claim_text=args.claim,
        with_nim=args.with_nim,
        nim_model=args.nim_model,
        mock_nim_response_file=Path(args.mock_nim_response_file) if args.mock_nim_response_file else None,
        timeout_seconds=args.timeout_seconds,
        max_prompt_chars=args.max_prompt_chars,
        max_tokens=args.max_tokens,
    )
    payload = {
        "status": "FORGE_NVIDIA_GUARD_REVIEW_WRITTEN",
        "deterministic_verdict": review["deterministic_review"]["verdict"],
        "nim_verdict": (review.get("nvidia_nim_review") or {}).get("verdict", ""),
        "artifact_paths": review.get("artifact_paths", {}),
    }
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(
            f"{payload['status']} deterministic={payload['deterministic_verdict']} "
            f"nim={payload['nim_verdict'] or 'not_run'}"
        )
        for key, path in payload["artifact_paths"].items():
            print(f"{key}: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
