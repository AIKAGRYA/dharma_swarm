from __future__ import annotations

import json
from pathlib import Path

import scripts.runtime.forge_nvidia_guard as guard


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def _write_full_packet(packet: Path, *, task_count: int = 100, status: str = "positive_lift_candidate") -> None:
    arms = [
        "frontier_single_full_budget",
        "best_of_n_same_model",
        "same_budget_self_moa",
        "planner_builder_verifier_no_a2a",
        "full_a2a_swarm",
    ]
    _write_json(packet / "run_manifest.json", {"schema_version": "test", "benchmark_family": "synthetic"})
    _write_json(packet / "model_roster.json", {"arms": [{"arm": arm, "model": "test-model"} for arm in arms]})
    _write_jsonl(packet / "task_manifest.jsonl", [{"task_id": f"task-{idx}", "split": "heldout"} for idx in range(task_count)])
    _write_jsonl(
        packet / "results.jsonl",
        [
            {
                "task_id": f"task-{idx}",
                "arm": arm,
                "candidate_ok": True,
                "score": 1.0 if arm == "full_a2a_swarm" else 0.9,
            }
            for idx in range(task_count)
            for arm in arms
        ],
    )
    _write_jsonl(packet / "budget_ledger.jsonl", [{"arm": arm, "total_tokens": 1000} for arm in arms])
    _write_jsonl(
        packet / "coordination_edges.jsonl",
        [
            {"edge_kind": "swarm_only_win", "final_use_proof": True, "from": "planner", "to": "builder"},
            {"edge_kind": "swarm_only_win", "final_use_proof": True, "from": "verifier", "to": "builder"},
            {"edge_kind": "swarm_only_win", "final_use_proof": False, "from": "critic", "to": "builder"},
        ],
    )
    (packet / "control_comparison.md").write_text("# Control comparison\n", encoding="utf-8")
    (packet / "failure_taxonomy.md").write_text("# Failure taxonomy\n", encoding="utf-8")
    (packet / "decision_record.md").write_text(f"# Decision\n\nVerdict: `{status}`\n", encoding="utf-8")
    _write_json(
        packet / "swarm_lift_report.json",
        {
            "schema_version": "forge_swarm_lift_report.v1",
            "status": status,
            "task_count": task_count,
            "rubric_item_count": 300,
            "scores": {
                "frontier_single_full_budget": 0.9,
                "best_of_n_same_model": 0.9,
                "same_budget_self_moa": 0.9,
                "planner_builder_verifier_no_a2a": 0.9,
                "full_a2a_swarm": 0.96,
            },
            "swarm_lift": 0.06,
            "paired_bootstrap_ci": {"lower": 0.01, "upper": 0.11, "n": task_count},
            "authority": {
                "trainer_built": False,
                "production_router_mutated": False,
                "archive_fitness_mutated": False,
                "official_score_claimed": False,
                "public_submission_performed": False,
                "external_confirmed": False,
            },
        },
    )


def test_superiority_claim_is_blocked_for_low_power_partial_packet(tmp_path: Path) -> None:
    packet = tmp_path / "partial"
    packet.mkdir()
    _write_json(
        packet / "swarm_lift_report.json",
        {
            "status": "positive_lift_candidate",
            "task_count": 10,
            "rubric_item_count": 20,
            "swarm_lift": 0.02,
            "paired_bootstrap_ci": {"lower": -0.01, "upper": 0.05},
            "authority": {"archive_fitness_mutated": False},
        },
    )

    review = guard.run_guard(packet_dir=packet, claim_text="Dharma Swarm beats the best single model")
    deterministic = review["deterministic_review"]

    assert deterministic["verdict"] == "blocked_with_evidence"
    codes = {finding["code"] for finding in deterministic["findings"]}
    assert "superiority_claim_forbidden" in codes
    assert "minimum_packet_incomplete" in codes
    assert deterministic["claim_superiority_requested"] is True


def test_full_packet_can_pass_for_next_scale_without_nim(tmp_path: Path) -> None:
    packet = tmp_path / "full"
    _write_full_packet(packet)

    review = guard.run_guard(packet_dir=packet)
    deterministic = review["deterministic_review"]

    assert deterministic["verdict"] == "pass_for_next_scale"
    assert deterministic["task_count"] == 100
    assert deterministic["canonical_arm_coverage"]["full_a2a_swarm"] is True
    assert deterministic["invalid_run_rate"] == 0.0
    assert deterministic["final_use_ratio"] >= 0.30
    assert (packet / "nvidia_guard_review.json").exists()
    assert (packet / "nvidia_guard_review.md").exists()


def test_mock_nim_response_is_recorded(tmp_path: Path) -> None:
    packet = tmp_path / "full"
    _write_full_packet(packet)
    mock = tmp_path / "mock_nim.json"
    _write_json(
        mock,
        {
            "verdict": "pass_for_next_scale",
            "summary": "Synthetic packet passes deterministic gates.",
            "strongest_blockers": [],
            "claim_allowed": True,
            "next_experiment": "Run the same guard on a real Forge packet.",
            "nvidia_stack_use": ["nim_critic", "rag_receipt_retrieval"],
            "confidence": 0.7,
        },
    )

    review = guard.run_guard(packet_dir=packet, mock_nim_response_file=mock)

    assert review["nvidia_nim_review"]["verdict"] == "pass_for_next_scale"
    payload = json.loads((packet / "nvidia_guard_review.json").read_text(encoding="utf-8"))
    assert payload["nvidia_nim_review"]["model_identity"]["provider"] == "mock_nvidia_nim"
