# Merge-Blocker Sprint Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Restore trust in `main` by fixing the current merge blockers in test collection, live side-effect governance, liveness shutdown/restart handling, and persistence crash-safety.

**Architecture:** Work from the narrowest red baseline outward. First restore clean import/collection, then harden the single highest-risk execution boundary, then fix daemon lifecycle handling, and finally normalize the most dangerous persistence seams. Each fix lands with direct tests on the real runtime boundary, not only isolated helpers.

**Tech Stack:** Python, pytest, asyncio, FastAPI, SQLite, JSONL persistence

---

### Task 1: Lock the red baseline for collection blockers

**Files:**
- Modify: `dharma_swarm/dharma_swarm/monad.py`
- Modify: `dharma_swarm/dharma_swarm/api_keys.py`
- Test: `tests/test_monad.py`
- Test: `tests/test_coalgebra.py`
- Test: `tests/test_monad_laws.py`
- Test: `tests/tui/test_tui_entrypoint.py`

**Step 1: Write or identify the failing collection command**

Run:

```bash
python3 -m pytest --collect-only -q tests/test_coalgebra.py tests/test_monad.py tests/test_monad_laws.py tests/tui/test_tui_entrypoint.py
```

Expected: import or syntax failures tied to `monad.py` and `provider_available`.

**Step 2: Make the smallest code fix for `monad.py`**

- Remove the duplicate `rv_reading=` keyword argument in `ObservedState.from_rv_reading`.

**Step 3: Restore the TUI import contract**

- Either reintroduce `provider_available()` in `dharma_swarm/api_keys.py` using existing env helpers, or change TUI imports to a current canonical helper if one already exists.
- Prefer restoring the public helper for compatibility.

**Step 4: Re-run the collection command**

Run:

```bash
python3 -m pytest --collect-only -q tests/test_coalgebra.py tests/test_monad.py tests/test_monad_laws.py tests/tui/test_tui_entrypoint.py
```

Expected: clean collection.

### Task 2: Put one enforced gate in front of live side effects

**Files:**
- Modify: `api/chat_tools.py`
- Modify: `api/routers/chat.py`
- Modify: `dharma_swarm/dharma_swarm/agent_runner.py`
- Test: `tests/test_chat_tools.py`
- Test: `tests/test_dashboard_chat_router.py`

**Step 1: Write failing boundary tests**

- Add tests that exercise real `exec_write_file`, `exec_edit_file`, and `exec_shell`.
- Cover a blocked shell case and a review-grade shell case.
- Cover write/edit paths requiring the same gate contract instead of bypassing it.

**Step 2: Run the targeted tests to verify they fail**

Run:

```bash
python3 -m pytest -q tests/test_chat_tools.py tests/test_dashboard_chat_router.py
```

Expected: failures showing missing gate coverage or incorrect `BLOCK` handling.

**Step 3: Implement the minimum shared enforcement**

- Introduce one helper on the live boundary that runs telos review before shell/write/edit side effects.
- Fix the `BLOCK`/`block` comparison bug.
- Keep root/path scoping intact.

**Step 4: Re-run the targeted tests**

Run:

```bash
python3 -m pytest -q tests/test_chat_tools.py tests/test_dashboard_chat_router.py
```

Expected: PASS.

### Task 3: Make orchestrator shutdown fail closed instead of orphaning work

**Files:**
- Modify: `dharma_swarm/dharma_swarm/orchestrator.py`
- Modify: `dharma_swarm/dharma_swarm/orchestrate_live.py`
- Modify: `dharma_swarm/dharma_swarm/loop_supervisor.py` only if required
- Test: `tests/test_async_safety.py`
- Test: `tests/test_orchestrator.py`
- Test: `tests/test_orchestrate_live.py`

**Step 1: Add failing tests**

- Add a shutdown cancellation test that verifies agents are released and task state is reconciled.
- Add a restart-budget exhaustion test that verifies required loops do not silently disappear.

**Step 2: Run the targeted tests to verify red**

Run:

```bash
python3 -m pytest -q tests/test_async_safety.py tests/test_orchestrator.py tests/test_orchestrate_live.py
```

Expected: failures around missing cancellation cleanup and restart semantics.

**Step 3: Implement the smallest safe lifecycle changes**

- Handle `CancelledError` in `_execute_task()`.
- Track lifecycle emission tasks instead of raw fire-and-forget.
- Replace silent loop abandonment with fail-fast or durable operator alerting for required loops.

**Step 4: Re-run the targeted tests**

Run:

```bash
python3 -m pytest -q tests/test_async_safety.py tests/test_orchestrator.py tests/test_orchestrate_live.py
```

Expected: PASS.

### Task 4: Normalize the highest-risk persistence seams

**Files:**
- Modify: `dharma_swarm/dharma_swarm/engine/event_memory.py`
- Modify: `dharma_swarm/dharma_swarm/engine/unified_index.py`
- Modify: `dharma_swarm/dharma_swarm/archive.py`
- Modify: `dharma_swarm/dharma_swarm/session_ledger.py`
- Modify: `dharma_swarm/dharma_swarm/vector_store.py`
- Test: `tests/test_archive.py`
- Test: `tests/test_vector_store.py`
- Test: add focused tests for WAL/atomic-write behavior if absent

**Step 1: Add failing persistence tests**

- Assert shared SQLite policy is used for the touched stores.
- Assert JSONL durable writes use atomic replace semantics.
- Assert vector-store GC fails closed on cleanup substep errors.

**Step 2: Run the targeted tests to verify red**

Run:

```bash
python3 -m pytest -q tests/test_archive.py tests/test_vector_store.py
```

Expected: failures or missing coverage for the new behavior.

**Step 3: Implement the smallest persistence hardening**

- Route SQLite opens through shared pragmas.
- Make durable JSONL writes atomic.
- Make vector-store GC transactional or rollback on cleanup failure.

**Step 4: Re-run the targeted tests**

Run:

```bash
python3 -m pytest -q tests/test_archive.py tests/test_vector_store.py
```

Expected: PASS.

### Task 5: Widen verification to the scoped definition of done

**Files:**
- No new code expected

**Step 1: Run collection for the scoped blockers**

Run:

```bash
python3 -m pytest --collect-only -q
```

Expected: clean collection or a smaller residual set clearly outside this sprint.

**Step 2: Run all targeted suites touched in this sprint**

Run:

```bash
python3 -m pytest -q \
  tests/test_chat_tools.py \
  tests/test_dashboard_chat_router.py \
  tests/test_async_safety.py \
  tests/test_orchestrator.py \
  tests/test_orchestrate_live.py \
  tests/test_archive.py \
  tests/test_vector_store.py
```

Expected: PASS.

**Step 3: Compile the touched Python surfaces**

Run:

```bash
python3 -m compileall api dharma_swarm tests
```

Expected: PASS.
