# Codex Long-Running Autonomy for dharma_swarm

Date: 2026-03-29
Scope: local Codex CLI first, Codex cloud second

## Plain-language summary

The right Codex pattern for `dharma_swarm` is not one giant endless prompt.
It is a repeated fresh-context loop:

1. the supervisor selects one bounded task from a persistent queue
2. `codex exec` runs one cycle with a fresh context window
3. state persists on disk, not in model context
4. the queue and progress log decide what happens next

This repo already had the core supervisor in `dharma_swarm/codex_overnight.py`.
What was missing was the stricter queue discipline from the long-running-agent research.

## What now exists

- `dharma_swarm/codex_overnight.py`
  The repeated fresh-context supervisor.
- `dharma_swarm/codex_build_queue.py`
  Deterministic queue manager for `pending -> completed|failed`.
- `scripts/codex_build_queue.py`
  Shell-facing wrapper so Codex can update queue state during a run.
- `scripts/start_codex_overnight_tmux.sh`
  tmux launcher with optional queue/progress file wiring.

## Recommended operating model

### Mode 1: queue-driven local build loop

Use this for bounded repo work like Phase B+C wires, merge-blocker sweeps, or one subsystem hardening pass.

Queue item shape:

```json
[
  {
    "id": "B6",
    "task": "Register default ingestion sources",
    "files": ["dharma_swarm/semantic_ingestion.py"],
    "test": "pytest tests/test_semantic_ingestion.py -q",
    "status": "pending",
    "attempts": 0
  }
]
```

Run shape:

```bash
python3 scripts/codex_overnight_autopilot.py \
  --repo-root ~/dharma_swarm \
  --state-dir ~/.dharma \
  --queue-file ~/.dharma/build_queue.json \
  --progress-file ~/.dharma/build_progress.txt \
  --hours 8 \
  --cycle-timeout 5400
```

tmux shape:

```bash
DGC_CODEX_NIGHT_QUEUE_FILE=~/.dharma/build_queue.json \
DGC_CODEX_NIGHT_PROGRESS_FILE=~/.dharma/build_progress.txt \
bash scripts/start_codex_overnight_tmux.sh 8
```

### Mode 2: open-ended mission loop

Use the original mission-brief mode when the goal is exploration, triage, or broad opportunistic improvement instead of a strict backlog.

## Why this is the Codex-native version

Local Codex already exposes the right primitive for this pattern:

- non-interactive `codex exec`
- repo-scoped working directory via `-C`
- extra writable state via `--add-dir`
- final-message capture via `-o`
- repeated fresh invocations instead of one context growing forever

The key Codex-specific difference from the Claude research packet is that this repo already has a local overnight supervisor, so the highest-ROI move is to harden that substrate instead of creating a second parallel loop.

## Guardrails

- one task per cycle
- queue truth is mandatory
- no commit/push/reset in the overnight loop
- focused verification after edits
- progress log survives across cycles
- when the queue is empty, the supervisor stops cleanly

## When to use Codex cloud later

Use Codex cloud for parallel long-running implementation after the local queue lane is proven boring and reliable. Local CLI should remain the primary lane for repo-sensitive work where direct filesystem state, custom scripts, and dirty-tree awareness matter.

## Source anchors

Official OpenAI docs consulted on 2026-03-29:

- Codex workflows: https://developers.openai.com/codex/workflows
- Codex AGENTS.md guidance: https://developers.openai.com/codex/guides/agents-md

Local CLI surface verified from:

- `codex --help`
- `codex exec --help`
