# Repo Cleanup Sprint Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Reduce repo ambiguity by cleaning obvious generated noise, codifying the DGC command authority boundary, and promoting the forge/build stack from floating implementation to an explicit subsystem.

**Architecture:** Preserve the current local-first trajectory without large moves in a dirty checkout. Treat cleanup as boundary hardening: generated artifacts leave the source contract, `dgc` remains the public front door while `dharma_swarm/dgc/` becomes the implementation home, and `codex_build_packet.py` plus `forge/` become the canonical contained-build substrate.

**Tech Stack:** Python 3, pytest, gitignore policy, existing `dharma_swarm.dgc`, existing `dharma_swarm.forge`, existing build packet/queue helpers.

---

### Task 1: Reduce Generated Dashboard Noise

**Files:**
- Modify: `.gitignore`
- Test: `tests/test_repo_cleanup_contracts.py`

**Step 1: Write the failing test**

Add a repo hygiene contract that asserts generated dashboard audit directories and smoke-test screenshots are ignored.

**Step 2: Run test to verify it fails**

Run: `python3 -m pytest -q tests/test_repo_cleanup_contracts.py`

Expected: failure because the ignore patterns do not exist yet.

**Step 3: Write minimal implementation**

Add ignore entries for dashboard audit output and smoke-test screenshots only. Do not broaden the ignore policy beyond known generated artifacts.

**Step 4: Run test to verify it passes**

Re-run the same command and confirm the ignore assertions pass.

### Task 2: Codify DGC And Forge Authority Boundaries

**Files:**
- Modify: `dharma_swarm/dgc/commands/dharma_ops.py`
- Modify: `dharma_swarm/dgc_cli.py`
- Test: `tests/test_dgc_modular_forge.py`
- Test: `tests/test_repo_cleanup_contracts.py`

**Step 1: Write the failing test**

Assert that the modular `cmd_forge()` wrapper remains forward-compatible with new control flags and that the generic forge path stays routed through the modular DGC surface.

**Step 2: Run test to verify it fails**

Run: `python3 -m pytest -q tests/test_dgc_modular_forge.py tests/test_repo_cleanup_contracts.py`

Expected: failure if the wrapper stops accepting new keyword controls or if the hygiene contract is stale.

**Step 3: Write minimal implementation**

Keep `dgc` as the front door, keep `dgc_cli.py` as the transitional compatibility shell, and keep `dharma_swarm/dgc/commands/*` as the modular parser/dispatch layer. Avoid creating a second CLI or a second forge command surface.

**Step 4: Run test to verify it passes**

Re-run the same command and confirm the modular boundary is preserved.

### Task 3: Promote Generic Forge Build Packet Helpers

**Files:**
- Modify: `dharma_swarm/codex_build_packet.py`
- Test: `tests/test_forge_packet_writer.py`
- Test: `tests/test_repo_cleanup_contracts.py`

**Step 1: Write the failing test**

Assert that the generic forge helpers are part of the public packet API, not just incidental functions.

**Step 2: Run test to verify it fails**

Run: `python3 -m pytest -q tests/test_forge_packet_writer.py tests/test_repo_cleanup_contracts.py`

Expected: failure because the public export list omits the generic forge helpers.

**Step 3: Write minimal implementation**

Add explicit module documentation and export `render_forge_mission` and `write_forge_packet` from the packet helper module.

**Step 4: Run test to verify it passes**

Re-run the same command and confirm the packet surface is explicit.

### Task 4: Verify The Cleanup Slice End To End

**Files:**
- Test: `tests/test_repo_cleanup_contracts.py`
- Test: `tests/test_forge_packet_writer.py`
- Test: `tests/test_forge_operator.py`
- Test: `tests/test_dgc_modular_forge.py`

**Step 1: Run focused verification**

Run:

```bash
python3 -m pytest -q \
  tests/test_repo_cleanup_contracts.py \
  tests/test_forge_packet_writer.py \
  tests/test_forge_operator.py \
  tests/test_dgc_modular_forge.py
```

Expected: all tests pass.

**Step 2: Record residual debt**

Note the bigger refactors left for later:
- split `dgc_cli.py` further
- classify the full dirty worktree
- decide which mirrors and experimental artifacts belong outside the repo

## Current Dirty Worktree Snapshot

This sprint does not attempt to normalize every dirty path. It creates a first-pass bucket map so cleanup work can be sequenced instead of improvised.

### Bucket A: Product Runtime And API

Examples:
- `api/*`
- `dashboard/src/*`
- `dharma_swarm/orchestrator.py`
- `dharma_swarm/orchestrate_live.py`
- `dharma_swarm/evolution.py`

Why this bucket exists:
- high-value product/runtime code
- likely intentional in-flight work
- should be cleaned via feature-specific integration, not broad repo surgery

### Bucket B: Control Plane Decomposition

Examples:
- `dharma_swarm/dgc_cli.py`
- `dharma_swarm/dgc/`
- `tests/test_dgc_*`

Why this bucket exists:
- active transition from monolith to command packs
- merge hotspot if left conceptually muddy
- needs explicit “front door vs implementation” authority

### Bucket C: Contained Evolution Forge

Examples:
- `dharma_swarm/forge/`
- `dharma_swarm/codex_build_packet.py`
- `dharma_swarm/codex_build_queue.py`
- `tests/test_forge_*`
- `tests/test_codex_build_*`

Why this bucket exists:
- new contained-build substrate
- already useful, but easy to mistake as detached scaffolding unless promoted
- should be reviewed as one subsystem

### Bucket D: Research, Experiments, And Mirrors

Examples:
- `references/adjacent/*`
- `references/research/*`
- `experiments/*`
- `docs/plans/*`

Why this bucket exists:
- high signal, but not all of it should live under the same source contract
- needs a later decision on what is committed source, what is mirror, and what is archive

### Bucket E: Generated And Local Artifacts

Examples:
- `dashboard/audit-data/`
- `dashboard/audit-screenshots/`
- `dashboard/smoke-test-*.png`
- caches under `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`

Why this bucket exists:
- should not compete with source files for operator attention
- this sprint begins cleanup by ignoring the dashboard-generated subset explicitly
