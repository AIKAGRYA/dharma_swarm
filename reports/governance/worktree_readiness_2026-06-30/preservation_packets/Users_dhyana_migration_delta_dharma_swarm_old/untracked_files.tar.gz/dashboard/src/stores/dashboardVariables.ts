import { create } from "zustand";

interface DashboardVariables {
  selectedAgentId: string | null;
  fitnessThreshold: number;
  timeRange: string;
  activeCascadeDomain: string | null;
  focusedPanel: string | null;
  selectAgent: (id: string | null) => void;
  setCascadeDomain: (domain: string | null) => void;
  setFocusedPanel: (panel: string | null) => void;
}

export const useDashboardVariables = create<DashboardVariables>((set) => ({
  selectedAgentId: null,
  fitnessThreshold: 0.5,
  timeRange: "24h",
  activeCascadeDomain: null,
  focusedPanel: null,
  selectAgent: (id) => set({ selectedAgentId: id }),
  setCascadeDomain: (domain) => set({ activeCascadeDomain: domain }),
  setFocusedPanel: (panel) => set({ focusedPanel: panel }),
}));
