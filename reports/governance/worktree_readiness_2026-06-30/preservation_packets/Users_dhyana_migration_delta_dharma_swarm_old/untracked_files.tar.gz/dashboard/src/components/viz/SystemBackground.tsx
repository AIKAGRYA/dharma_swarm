"use client";

import dynamic from "next/dynamic";
import { useOverview } from "@/hooks/useOverview";
import { useHealth } from "@/hooks/useHealth";

const NeuroNoise = dynamic(
  () => import("@paper-design/shaders-react").then((m) => m.NeuroNoise),
  { ssr: false },
);

export function SystemBackground() {
  const { overview } = useOverview();
  const { health } = useHealth();

  const healthStatus = overview?.health_status ?? health?.overall_status ?? "unknown";
  const activeAgents = overview?.active_agents ?? 0;
  const totalAgents = overview?.agent_count ?? 1;

  const colorFront =
    healthStatus === "critical"
      ? "#201015"
      : healthStatus === "degraded"
        ? "#1A1020"
        : "#0F1218";

  const activity = totalAgents > 0 ? activeAgents / totalAgents : 0;
  const speed = 0.05 + activity * 0.3;

  return (
    <div className="pointer-events-none fixed inset-0 z-0" aria-hidden="true">
      <NeuroNoise
        colorFront={colorFront}
        colorMid="#0B0E14"
        colorBack="#0B0E14"
        speed={speed}
        scale={1.5}
        brightness={0.4}
        contrast={0.3}
        style={{ width: "100%", height: "100%", opacity: 0.5 }}
      />
    </div>
  );
}
