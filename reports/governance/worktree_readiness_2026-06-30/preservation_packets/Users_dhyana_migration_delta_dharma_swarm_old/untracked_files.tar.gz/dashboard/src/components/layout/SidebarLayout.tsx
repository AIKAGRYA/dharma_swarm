"use client";

import { Sidebar } from "./Sidebar";
import { useSidebarStore } from "@/stores/sidebarStore";

export function SidebarLayout({ children }: { children: React.ReactNode }) {
  const collapsed = useSidebarStore((s) => s.collapsed);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main
        className="flex-1 transition-all duration-200"
        style={{ marginLeft: collapsed ? 56 : 220 }}
      >
        {children}
      </main>
    </div>
  );
}
