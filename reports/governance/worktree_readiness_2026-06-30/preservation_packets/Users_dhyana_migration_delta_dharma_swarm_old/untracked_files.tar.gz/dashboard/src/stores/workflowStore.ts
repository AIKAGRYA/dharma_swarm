import { create } from "zustand";
import type { Node, Edge } from "@xyflow/react";

export type WorkflowNodeType = "trigger" | "agent" | "condition" | "action" | "output" | "gate" | "transform" | "llm" | "archive" | "human" | "subflow";

interface WorkflowState {
  workflowId: string | null;
  workflowName: string;
  nodes: Node[];
  edges: Edge[];
  isDirty: boolean;
  setWorkflowMeta: (id: string | null, name: string) => void;
  setNodes: (nodes: Node[] | ((prev: Node[]) => Node[])) => void;
  setEdges: (edges: Edge[] | ((prev: Edge[]) => Edge[])) => void;
  addNode: (node: Node) => void;
  markClean: () => void;
  reset: () => void;
}

export const useWorkflowStore = create<WorkflowState>((set) => ({
  workflowId: null,
  workflowName: "",
  nodes: [],
  edges: [],
  isDirty: false,
  setWorkflowMeta: (id, name) => set({ workflowId: id, workflowName: name }),
  setNodes: (updater) =>
    set((s) => ({
      nodes: typeof updater === "function" ? updater(s.nodes) : updater,
      isDirty: true,
    })),
  setEdges: (updater) =>
    set((s) => ({
      edges: typeof updater === "function" ? updater(s.edges) : updater,
      isDirty: true,
    })),
  addNode: (node) => set((s) => ({ nodes: [...s.nodes, node], isDirty: true })),
  markClean: () => set({ isDirty: false }),
  reset: () => set({ workflowId: null, workflowName: "", nodes: [], edges: [], isDirty: false }),
}));
