"""Tests for dharma_swarm.agentic_corporation.models -- 32 tests."""

from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

import pytest

from dharma_swarm.agentic_corporation.models import (
    Agent,
    AgentLifecycleStatus,
    Approval,
    ApprovalStatus,
    Artifact,
    Capability,
    Checkpoint,
    Connector,
    CostEvent,
    MutationRequest,
    Outcome,
    RevenueEvent,
    Role,
    Run,
    RunStatus,
    Step,
    WorkUnit,
)
from dharma_swarm.models import (
    AgentConfig,
    AgentRole,
    AgentState,
    AgentStatus,
    GateCheckResult,
    GateDecision,
    ProviderType,
    Task,
    TaskPriority,
)


class TestEnums:
    def test_agent_lifecycle_values(self) -> None:
        assert AgentLifecycleStatus.DRAFT.value == "draft"
        assert AgentLifecycleStatus.ACTIVE.value == "active"
        assert AgentLifecycleStatus.SUSPENDED.value == "suspended"
        assert AgentLifecycleStatus.RETIRED.value == "retired"

    def test_run_status_values(self) -> None:
        assert RunStatus.PENDING.value == "pending"
        assert RunStatus.RUNNING.value == "running"
        assert RunStatus.PAUSED.value == "paused"
        assert RunStatus.COMPLETED.value == "completed"
        assert RunStatus.FAILED.value == "failed"

    def test_approval_status_values(self) -> None:
        assert ApprovalStatus.PENDING.value == "pending"
        assert ApprovalStatus.APPROVED.value == "approved"
        assert ApprovalStatus.REJECTED.value == "rejected"
        assert ApprovalStatus.EXPIRED.value == "expired"


class TestAgent:
    def test_defaults(self) -> None:
        a = Agent(name="test")
        assert a.name == "test"
        assert a.role == "general"
        assert a.status == AgentLifecycleStatus.DRAFT
        assert a.vendor == "internal"
        assert a.version == "0.1.0"
        assert a.provider == ProviderType.OPENROUTER
        assert a.level == 1
        assert a.xp == 0.0
        assert a.reputation == 0.0
        assert a.trust_band == "unknown"
        assert isinstance(a.id, str) and len(a.id) > 0
        assert isinstance(a.created_at, datetime)

    def test_from_legacy_config_only(self) -> None:
        cfg = AgentConfig(name="alpha", role=AgentRole.CODER, model="test-model")
        a = Agent.from_legacy(cfg)
        assert a.name == "alpha"
        assert a.role == "coder"
        assert a.status == AgentLifecycleStatus.DRAFT
        assert a.model == "test-model"

    def test_from_legacy_with_state_idle(self) -> None:
        cfg = AgentConfig(name="beta", role=AgentRole.RESEARCHER)
        state = AgentState(id=cfg.id, name="beta", role=AgentRole.RESEARCHER, status=AgentStatus.IDLE)
        a = Agent.from_legacy(cfg, state)
        assert a.status == AgentLifecycleStatus.ACTIVE

    def test_from_legacy_with_state_busy(self) -> None:
        cfg = AgentConfig(name="gamma")
        state = AgentState(id=cfg.id, name="gamma", role=AgentRole.GENERAL, status=AgentStatus.BUSY)
        a = Agent.from_legacy(cfg, state)
        assert a.status == AgentLifecycleStatus.ACTIVE

    def test_from_legacy_with_state_starting(self) -> None:
        cfg = AgentConfig(name="delta")
        state = AgentState(id=cfg.id, name="delta", role=AgentRole.GENERAL, status=AgentStatus.STARTING)
        a = Agent.from_legacy(cfg, state)
        assert a.status == AgentLifecycleStatus.DRAFT

    def test_from_legacy_with_state_stopping(self) -> None:
        cfg = AgentConfig(name="epsilon")
        state = AgentState(id=cfg.id, name="epsilon", role=AgentRole.GENERAL, status=AgentStatus.STOPPING)
        a = Agent.from_legacy(cfg, state)
        assert a.status == AgentLifecycleStatus.SUSPENDED

    def test_from_legacy_with_state_dead(self) -> None:
        cfg = AgentConfig(name="zeta")
        state = AgentState(id=cfg.id, name="zeta", role=AgentRole.GENERAL, status=AgentStatus.DEAD)
        a = Agent.from_legacy(cfg, state)
        assert a.status == AgentLifecycleStatus.RETIRED

    def test_json_round_trip(self) -> None:
        a = Agent(name="round_trip", capabilities=["code", "test"])
        data = a.model_dump_json()
        restored = Agent.model_validate_json(data)
        assert restored.name == "round_trip"
        assert restored.capabilities == ["code", "test"]


class TestRole:
    def test_defaults(self) -> None:
        r = Role(name="worker")
        assert r.name == "worker"
        assert r.autonomy_level == 3

    def test_from_legacy(self) -> None:
        r = Role.from_legacy(AgentRole.CODER)
        assert r.name == "coder"
        assert "code" in r.description.lower()

    def test_from_legacy_general(self) -> None:
        r = Role.from_legacy(AgentRole.GENERAL)
        assert r.name == "general"


class TestCapability:
    def test_defaults(self) -> None:
        c = Capability(name="python")
        assert c.name == "python"
        assert c.certified is False
        assert c.measured_performance is None


class TestWorkUnit:
    def test_defaults(self) -> None:
        wu = WorkUnit(title="Build it")
        assert wu.title == "Build it"
        assert wu.status == "pending"
        assert wu.priority == "normal"
        assert wu.created_by == "system"

    def test_from_legacy(self) -> None:
        t = Task(title="Fix bug", description="critical", priority=TaskPriority.HIGH)
        wu = WorkUnit.from_legacy(t)
        assert wu.title == "Fix bug"
        assert wu.priority == "high"
        assert wu.id == t.id


class TestRun:
    def test_defaults(self) -> None:
        r = Run(work_unit_id="wu_1")
        assert r.work_unit_id == "wu_1"
        assert r.status == RunStatus.PENDING


class TestStep:
    def test_defaults(self) -> None:
        s = Step(run_id="r1", node_name="plan")
        assert s.run_id == "r1"
        assert s.status == "pending"
        assert s.retry_count == 0


class TestCheckpoint:
    def test_defaults(self) -> None:
        cp = Checkpoint(run_id="r1", state={"x": 1})
        assert cp.run_id == "r1"
        assert cp.step_index == 0
        assert cp.state == {"x": 1}


class TestArtifact:
    def test_defaults(self) -> None:
        a = Artifact(content="hello")
        assert a.artifact_type == "unknown"
        assert a.content == "hello"

    def test_from_legacy_duck_typed(self) -> None:
        legacy = SimpleNamespace(
            artifact_type="analysis",
            content="result",
            summary="one liner",
            files_touched=["a.py"],
            metadata={"key": "val"},
        )
        a = Artifact.from_legacy(legacy)
        assert a.artifact_type == "analysis"
        assert a.content == "result"
        assert a.summary == "one liner"
        assert a.files_touched == ["a.py"]
        assert a.metadata == {"key": "val"}

    def test_from_legacy_minimal(self) -> None:
        legacy = SimpleNamespace()
        a = Artifact.from_legacy(legacy)
        assert a.artifact_type == "unknown"
        assert a.content == ""


class TestConnector:
    def test_defaults(self) -> None:
        c = Connector(name="github")
        assert c.name == "github"
        assert c.health_status == "unknown"


class TestApproval:
    def test_defaults(self) -> None:
        a = Approval(gate_name="safety")
        assert a.status == ApprovalStatus.PENDING
        assert a.timeout_hours == 24.0

    def test_from_legacy_allow(self) -> None:
        gcr = GateCheckResult(decision=GateDecision.ALLOW, reason="safe", gate="g1")
        a = Approval.from_legacy(gcr)
        assert a.status == ApprovalStatus.APPROVED
        assert a.gate_name == "g1"

    def test_from_legacy_block(self) -> None:
        gcr = GateCheckResult(decision=GateDecision.BLOCK, reason="unsafe", gate="g2")
        a = Approval.from_legacy(gcr)
        assert a.status == ApprovalStatus.REJECTED

    def test_from_legacy_review(self) -> None:
        gcr = GateCheckResult(decision=GateDecision.REVIEW, reason="needs review", gate="g3")
        a = Approval.from_legacy(gcr)
        assert a.status == ApprovalStatus.PENDING


class TestOutcome:
    def test_defaults(self) -> None:
        o = Outcome(agent_id="a1", outcome_type="task_completion", success=True)
        assert o.success is True
        assert o.agent_id == "a1"


class TestCostEvent:
    def test_defaults(self) -> None:
        c = CostEvent(provider="openrouter", model="llama-70b")
        assert c.input_tokens == 0
        assert c.estimated_cost_usd == 0.0

    def test_from_legacy(self) -> None:
        entry = SimpleNamespace(
            timestamp=1700000000.0,
            provider="openrouter",
            model="llama-3.3-70b",
            input_tokens=1000,
            output_tokens=500,
            estimated_cost_usd=0.001,
            task_id="t1",
            agent_name="coder",
            tier="free",
        )
        c = CostEvent.from_legacy(entry)
        assert c.provider == "openrouter"
        assert c.model == "llama-3.3-70b"
        assert c.input_tokens == 1000
        assert c.agent_id == "coder"
        assert isinstance(c.timestamp, datetime)


class TestRevenueEvent:
    def test_defaults(self) -> None:
        r = RevenueEvent(event_kind="sale", amount=100.0)
        assert r.currency == "USD"
        assert r.amount == 100.0


class TestMutationRequest:
    def test_defaults(self) -> None:
        m = MutationRequest(component="foo.py", change_type="mutation", description="tweak")
        assert m.predicted_fitness == 0.0
        assert m.actual_fitness is None

    def test_from_legacy(self) -> None:
        proposal = SimpleNamespace(
            id="p1",
            component="bar.py",
            change_type="crossover",
            description="merge",
            status=SimpleNamespace(value="pending"),
            parent_id=None,
            diff="--- a\n+++ b",
            predicted_fitness=0.75,
            actual_fitness=SimpleNamespace(total=0.82),
            gate_decision="allow",
            gate_reason="safe",
            metadata={"cycle": 3},
        )
        m = MutationRequest.from_legacy(proposal)
        assert m.id == "p1"
        assert m.component == "bar.py"
        assert m.actual_fitness == 0.82
        assert m.status == "pending"
        assert m.metadata == {"cycle": 3}

    def test_from_legacy_no_fitness(self) -> None:
        proposal = SimpleNamespace(
            id="p2",
            component="baz.py",
            change_type="ablation",
            description="remove",
            status="evaluated",
            parent_id="p1",
            diff="",
            predicted_fitness=0.0,
            actual_fitness=None,
            gate_decision=None,
            gate_reason=None,
            metadata=None,
        )
        m = MutationRequest.from_legacy(proposal)
        assert m.actual_fitness is None
        assert m.metadata == {}
