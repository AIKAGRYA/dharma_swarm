"""Tests for dharma_swarm.agentic_corporation.control_tower -- 15 tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from dharma_swarm.agentic_corporation.control_tower import (
    ControlTower,
    _DECIDED_DIR,
    _PENDING_DIR,
)
from dharma_swarm.agentic_corporation.models import (
    Agent,
    AgentLifecycleStatus,
    Approval,
    ApprovalStatus,
)
from dharma_swarm.agentic_corporation.workforce_registry import WorkforceRegistry
from dharma_swarm.telemetry_plane import TelemetryPlaneStore


@pytest.fixture()
def tmp_db(tmp_path: Path) -> Path:
    return tmp_path / "test_ct.db"


@pytest.fixture()
def tmp_approval_dirs(tmp_path: Path):
    pending = tmp_path / "approvals" / "pending"
    decided = tmp_path / "approvals" / "decided"
    pending.mkdir(parents=True)
    decided.mkdir(parents=True)
    with (
        patch("dharma_swarm.agentic_corporation.control_tower._PENDING_DIR", pending),
        patch("dharma_swarm.agentic_corporation.control_tower._DECIDED_DIR", decided),
    ):
        yield pending, decided


@pytest.fixture()
def tower(tmp_db: Path, tmp_approval_dirs) -> ControlTower:
    store = TelemetryPlaneStore(db_path=tmp_db)
    registry = WorkforceRegistry(telemetry_store=store)
    return ControlTower(registry=registry, telemetry=store)


class TestControlTowerAgentManagement:
    async def test_register_and_get(self, tower: ControlTower) -> None:
        agent = Agent(name="tower_agent", role="coder")
        saved = await tower.register_agent(agent)
        assert saved.name == "tower_agent"
        fetched = await tower.get_agent(agent.id)
        assert fetched is not None
        assert fetched.name == "tower_agent"

    async def test_list_agents(self, tower: ControlTower) -> None:
        await tower.register_agent(Agent(name="a1"))
        await tower.register_agent(Agent(name="a2"))
        agents = await tower.list_agents()
        assert len(agents) == 2

    async def test_retire_agent(self, tower: ControlTower) -> None:
        agent = Agent(name="to_retire", status=AgentLifecycleStatus.ACTIVE)
        await tower.register_agent(agent)
        retired = await tower.retire_agent(agent.id)
        assert retired is not None
        assert retired.status == AgentLifecycleStatus.RETIRED

    def test_get_certified_lanes(self, tower: ControlTower) -> None:
        lanes = tower.get_certified_lanes()
        assert isinstance(lanes, list)


class TestControlTowerGateChecks:
    def test_check_gate_returns_approval(self, tower: ControlTower) -> None:
        approval = tower.check_gate("test action")
        assert isinstance(approval, Approval)

    def test_check_gate_with_content(self, tower: ControlTower) -> None:
        approval = tower.check_gate("write file", content="safe content")
        assert isinstance(approval, Approval)


class TestControlTowerApprovals:
    async def test_request_approval(self, tower: ControlTower) -> None:
        approval = await tower.request_approval(
            gate_name="deploy",
            requested_by="human",
            context={"env": "prod"},
        )
        assert approval.status == ApprovalStatus.PENDING
        assert approval.gate_name == "deploy"
        assert approval.context == {"env": "prod"}

    async def test_approve(self, tower: ControlTower) -> None:
        approval = await tower.request_approval(gate_name="deploy", requested_by="human")
        result = await tower.approve(approval.id, approver="admin", reason="lgtm")
        assert result is not None
        assert result.status == ApprovalStatus.APPROVED
        assert result.approver == "admin"
        assert result.reason == "lgtm"

    async def test_reject(self, tower: ControlTower) -> None:
        approval = await tower.request_approval(gate_name="risky_op", requested_by="bot")
        result = await tower.reject(approval.id, approver="admin", reason="too risky")
        assert result is not None
        assert result.status == ApprovalStatus.REJECTED

    async def test_approve_nonexistent(self, tower: ControlTower) -> None:
        result = await tower.approve("nonexistent", approver="admin")
        assert result is None

    async def test_list_pending_approvals(self, tower: ControlTower) -> None:
        await tower.request_approval("gate_a", "user1")
        await tower.request_approval("gate_b", "user2")
        pending = await tower.list_pending_approvals()
        assert len(pending) == 2

    async def test_approved_removed_from_pending(self, tower: ControlTower) -> None:
        a1 = await tower.request_approval("gate_a", "user1")
        await tower.request_approval("gate_b", "user2")
        await tower.approve(a1.id, "admin")
        pending = await tower.list_pending_approvals()
        assert len(pending) == 1


class TestControlTowerVisibility:
    async def test_get_failure_map(self, tower: ControlTower) -> None:
        result = await tower.get_failure_map()
        assert isinstance(result, list)

    async def test_get_value_map(self, tower: ControlTower) -> None:
        result = await tower.get_value_map()
        assert isinstance(result, dict)
        assert "total_revenue" in result
        assert "total_cost" in result
