"""Tests for dharma_swarm.agentic_corporation.workforce_registry -- 12 tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from dharma_swarm.agentic_corporation.models import Agent, AgentLifecycleStatus
from dharma_swarm.agentic_corporation.workforce_registry import WorkforceRegistry
from dharma_swarm.models import ProviderType
from dharma_swarm.telemetry_plane import TelemetryPlaneStore


@pytest.fixture()
def tmp_db(tmp_path: Path) -> Path:
    return tmp_path / "test_telemetry.db"


@pytest.fixture()
def registry(tmp_db: Path) -> WorkforceRegistry:
    store = TelemetryPlaneStore(db_path=tmp_db)
    return WorkforceRegistry(telemetry_store=store)


class TestWorkforceRegistryCRUD:
    async def test_register_and_get(self, registry: WorkforceRegistry) -> None:
        agent = Agent(name="alpha", role="coder", purpose="write code")
        saved = await registry.register_agent(agent)
        assert saved.name == "alpha"
        fetched = await registry.get_agent(agent.id)
        assert fetched is not None
        assert fetched.name == "alpha"
        assert fetched.role == "coder"
        assert fetched.purpose == "write code"

    async def test_get_nonexistent(self, registry: WorkforceRegistry) -> None:
        result = await registry.get_agent("nonexistent_id")
        assert result is None

    async def test_list_agents_empty(self, registry: WorkforceRegistry) -> None:
        agents = await registry.list_agents()
        assert agents == []

    async def test_list_agents_multiple(self, registry: WorkforceRegistry) -> None:
        await registry.register_agent(Agent(name="a1"))
        await registry.register_agent(Agent(name="a2"))
        await registry.register_agent(Agent(name="a3"))
        agents = await registry.list_agents()
        assert len(agents) == 3

    async def test_list_agents_with_status_filter(self, registry: WorkforceRegistry) -> None:
        a1 = Agent(name="active_one", status=AgentLifecycleStatus.ACTIVE)
        a2 = Agent(name="draft_one", status=AgentLifecycleStatus.DRAFT)
        await registry.register_agent(a1)
        await registry.register_agent(a2)
        active_only = await registry.list_agents(status="active")
        assert len(active_only) == 1
        assert active_only[0].name == "active_one"

    async def test_update_agent_status(self, registry: WorkforceRegistry) -> None:
        agent = Agent(name="will_retire", status=AgentLifecycleStatus.ACTIVE)
        await registry.register_agent(agent)
        updated = await registry.update_agent_status(agent.id, AgentLifecycleStatus.SUSPENDED)
        assert updated is not None
        assert updated.status == AgentLifecycleStatus.SUSPENDED

    async def test_update_nonexistent(self, registry: WorkforceRegistry) -> None:
        result = await registry.update_agent_status("nope", AgentLifecycleStatus.RETIRED)
        assert result is None

    async def test_retire_agent(self, registry: WorkforceRegistry) -> None:
        agent = Agent(name="retiree", status=AgentLifecycleStatus.ACTIVE)
        await registry.register_agent(agent)
        retired = await registry.retire_agent(agent.id)
        assert retired is not None
        assert retired.status == AgentLifecycleStatus.RETIRED


class TestWorkforceRegistryRoundTrip:
    async def test_extra_fields_survive(self, registry: WorkforceRegistry) -> None:
        agent = Agent(
            name="detailed",
            role="researcher",
            vendor="external",
            version="1.2.0",
            purpose="investigate",
            owner="dhyana",
            provider=ProviderType.ANTHROPIC,
            model="claude-sonnet-4-20250514",
            capabilities=["code", "research"],
            department="engineering",
            squad_id="squad_a",
            specialization="mech-interp",
            level=5,
            xp=42.0,
        )
        await registry.register_agent(agent)
        fetched = await registry.get_agent(agent.id)
        assert fetched is not None
        assert fetched.role == "researcher"
        assert fetched.vendor == "external"
        assert fetched.version == "1.2.0"
        assert fetched.purpose == "investigate"
        assert fetched.owner == "dhyana"
        assert fetched.provider == ProviderType.ANTHROPIC
        assert fetched.model == "claude-sonnet-4-20250514"
        assert fetched.capabilities == ["code", "research"]
        assert fetched.department == "engineering"
        assert fetched.squad_id == "squad_a"
        assert fetched.specialization == "mech-interp"
        assert fetched.level == 5
        assert fetched.xp == 42.0

    async def test_reputation_round_trip(self, registry: WorkforceRegistry) -> None:
        agent = Agent(name="reputable", reputation=0.95, trust_band="high")
        await registry.register_agent(agent)
        fetched = await registry.get_agent(agent.id)
        assert fetched is not None
        assert fetched.reputation == 0.95
        assert fetched.trust_band == "high"


class TestCertifiedLanes:
    def test_get_certified_lanes(self, registry: WorkforceRegistry) -> None:
        lanes = registry.get_certified_lanes()
        assert isinstance(lanes, list)
        for lane in lanes:
            assert isinstance(lane, Agent)
            assert lane.vendor == "certified"
