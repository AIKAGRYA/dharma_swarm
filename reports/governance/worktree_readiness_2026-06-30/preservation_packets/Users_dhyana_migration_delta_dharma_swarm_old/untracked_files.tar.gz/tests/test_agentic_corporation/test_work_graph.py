"""Tests for dharma_swarm.agentic_corporation.work_graph -- 23 tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from dharma_swarm.agentic_corporation.models import RunStatus
from dharma_swarm.agentic_corporation.work_graph import WorkGraph


@pytest.fixture()
def graph(tmp_path: Path) -> WorkGraph:
    db = tmp_path / "work_graph.db"
    lineage_db = tmp_path / "lineage.db"
    return WorkGraph(db_path=db, lineage_db_path=lineage_db)


class TestWorkGraphRuns:
    def test_create_run(self, graph: WorkGraph) -> None:
        run = graph.create_run(work_unit_id="wu1", agent_id="a1")
        assert run.work_unit_id == "wu1"
        assert run.agent_id == "a1"
        assert run.status == RunStatus.PENDING

    def test_get_run(self, graph: WorkGraph) -> None:
        run = graph.create_run(work_unit_id="wu2")
        fetched = graph.get_run(run.id)
        assert fetched is not None
        assert fetched.id == run.id
        assert fetched.work_unit_id == "wu2"

    def test_get_run_nonexistent(self, graph: WorkGraph) -> None:
        assert graph.get_run("nope") is None

    def test_list_runs_empty(self, graph: WorkGraph) -> None:
        assert graph.list_runs() == []

    def test_list_runs_multiple(self, graph: WorkGraph) -> None:
        graph.create_run(work_unit_id="wu1")
        graph.create_run(work_unit_id="wu1")
        graph.create_run(work_unit_id="wu2")
        all_runs = graph.list_runs()
        assert len(all_runs) == 3
        wu1_runs = graph.list_runs(work_unit_id="wu1")
        assert len(wu1_runs) == 2

    def test_list_runs_by_status(self, graph: WorkGraph) -> None:
        r1 = graph.create_run()
        graph.create_run()  # second run stays pending
        graph.update_run_status(r1.id, RunStatus.RUNNING)
        running = graph.list_runs(status="running")
        assert len(running) == 1
        assert running[0].id == r1.id

    def test_update_run_status_to_running(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        updated = graph.update_run_status(run.id, RunStatus.RUNNING)
        assert updated is not None
        assert updated.status == RunStatus.RUNNING
        assert updated.started_at is not None

    def test_update_run_status_to_completed(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        graph.update_run_status(run.id, RunStatus.RUNNING)
        updated = graph.update_run_status(run.id, RunStatus.COMPLETED)
        assert updated is not None
        assert updated.status == RunStatus.COMPLETED
        assert updated.completed_at is not None

    def test_update_run_status_to_failed(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        updated = graph.update_run_status(run.id, RunStatus.FAILED)
        assert updated is not None
        assert updated.status == RunStatus.FAILED
        assert updated.completed_at is not None

    def test_update_nonexistent_run(self, graph: WorkGraph) -> None:
        assert graph.update_run_status("nope", RunStatus.RUNNING) is None


class TestWorkGraphSteps:
    def test_add_step(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        step = graph.add_step(run.id, node_name="plan", agent_id="a1")
        assert step.run_id == run.id
        assert step.node_name == "plan"
        assert step.status == "running"
        assert step.started_at is not None

    def test_complete_step_success(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        step = graph.add_step(run.id, node_name="execute")
        completed = graph.complete_step(
            step.id,
            output_state={"result": "ok"},
            output_artifact_ids=["art1"],
        )
        assert completed is not None
        assert completed.status == "completed"
        assert completed.output_state == {"result": "ok"}
        assert completed.completed_at is not None

    def test_complete_step_failure(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        step = graph.add_step(run.id)
        completed = graph.complete_step(step.id, error="boom")
        assert completed is not None
        assert completed.status == "failed"
        assert completed.error == "boom"

    def test_complete_nonexistent_step(self, graph: WorkGraph) -> None:
        assert graph.complete_step("nope") is None

    def test_get_steps(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        graph.add_step(run.id, node_name="step1")
        graph.add_step(run.id, node_name="step2")
        steps = graph.get_steps(run.id)
        assert len(steps) == 2
        assert steps[0].node_name == "step1"


class TestWorkGraphCheckpoints:
    def test_create_checkpoint(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        cp = graph.checkpoint(run.id, state={"x": 1})
        assert cp.run_id == run.id
        assert cp.step_index == 0
        assert cp.state == {"x": 1}
        assert cp.parent_checkpoint_id == ""

    def test_auto_increment_step_index(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        cp1 = graph.checkpoint(run.id, state={"x": 1})
        cp2 = graph.checkpoint(run.id, state={"x": 2})
        cp3 = graph.checkpoint(run.id, state={"x": 3})
        assert cp1.step_index == 0
        assert cp2.step_index == 1
        assert cp3.step_index == 2

    def test_parent_checkpoint_chaining(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        cp1 = graph.checkpoint(run.id, state={"x": 1})
        cp2 = graph.checkpoint(run.id, state={"x": 2})
        assert cp2.parent_checkpoint_id == cp1.id

    def test_get_checkpoint(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        cp = graph.checkpoint(run.id, state={"y": 42})
        fetched = graph.get_checkpoint(cp.id)
        assert fetched is not None
        assert fetched.state == {"y": 42}

    def test_get_checkpoint_nonexistent(self, graph: WorkGraph) -> None:
        assert graph.get_checkpoint("nope") is None

    def test_list_checkpoints(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        graph.checkpoint(run.id, state={"a": 1})
        graph.checkpoint(run.id, state={"a": 2})
        cps = graph.list_checkpoints(run.id)
        assert len(cps) == 2
        assert cps[0].step_index < cps[1].step_index


class TestWorkGraphFork:
    def test_fork_creates_new_run(self, graph: WorkGraph) -> None:
        run = graph.create_run(work_unit_id="wu1", agent_id="a1")
        cp = graph.checkpoint(run.id, state={"x": 10})
        forked = graph.fork(cp.id, state_updates={"x": 20, "y": 30})
        assert forked.id != run.id
        assert forked.parent_run_id == run.id
        assert forked.work_unit_id == "wu1"
        cps = graph.list_checkpoints(forked.id)
        assert len(cps) == 1
        assert cps[0].state == {"x": 20, "y": 30}

    def test_fork_nonexistent_checkpoint(self, graph: WorkGraph) -> None:
        with pytest.raises(ValueError, match="Checkpoint not found"):
            graph.fork("nonexistent")


class TestWorkGraphEvents:
    def test_log_and_get_events(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        eid = graph.log_event(
            run_id=run.id,
            event_type="step_started",
            payload={"step": "plan"},
        )
        assert isinstance(eid, str) and len(eid) > 0
        events = graph.get_events(run_id=run.id)
        assert len(events) == 1
        assert events[0]["event_type"] == "step_started"
        assert events[0]["payload"] == {"step": "plan"}

    def test_get_events_by_type(self, graph: WorkGraph) -> None:
        run = graph.create_run()
        graph.log_event(run_id=run.id, event_type="start")
        graph.log_event(run_id=run.id, event_type="end")
        starts = graph.get_events(run_id=run.id, event_type="start")
        assert len(starts) == 1

    def test_get_events_empty(self, graph: WorkGraph) -> None:
        events = graph.get_events(run_id="nonexistent")
        assert events == []


class TestWorkGraphLineage:
    def test_record_lineage(self, graph: WorkGraph) -> None:
        edge_id = graph.record_lineage(
            task_id="t1",
            inputs=["src_a"],
            outputs=["out_b"],
            agent="coder",
            operation="transform",
        )
        if edge_id is not None:
            assert isinstance(edge_id, str)

    def test_provenance(self, graph: WorkGraph) -> None:
        graph.record_lineage("t1", ["a"], ["b"], agent="x")
        graph.record_lineage("t2", ["b"], ["c"], agent="y")
        prov = graph.get_provenance("c")
        if prov is not None:
            assert hasattr(prov, "chain")

    def test_impact(self, graph: WorkGraph) -> None:
        graph.record_lineage("t1", ["a"], ["b"])
        graph.record_lineage("t2", ["b"], ["c"])
        impact = graph.get_impact("a")
        if impact is not None:
            assert hasattr(impact, "affected_artifacts")
