from __future__ import annotations

import inspect
from pathlib import Path


def test_gitignore_excludes_generated_dashboard_artifacts() -> None:
    gitignore = Path(".gitignore").read_text(encoding="utf-8")

    assert "dashboard/audit-data/" in gitignore
    assert "dashboard/audit-screenshots/" in gitignore
    assert "dashboard/smoke-test-*.png" in gitignore


def test_modular_cmd_forge_accepts_forward_compatible_kwargs() -> None:
    from dharma_swarm.dgc.commands import dharma_ops

    signature = inspect.signature(dharma_ops.cmd_forge)

    assert any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in signature.parameters.values()
    )


def test_codex_build_packet_exports_generic_forge_helpers() -> None:
    from dharma_swarm import codex_build_packet

    assert "render_forge_mission" in getattr(codex_build_packet, "__all__", ())
    assert "write_forge_packet" in getattr(codex_build_packet, "__all__", ())
