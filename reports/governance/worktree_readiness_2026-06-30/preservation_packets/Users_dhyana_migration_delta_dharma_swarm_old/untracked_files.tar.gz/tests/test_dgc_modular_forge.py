from __future__ import annotations

from unittest.mock import patch


def test_modular_cmd_forge_forwards_extended_controls() -> None:
    from dharma_swarm.dgc.commands import dharma_ops

    with patch("dharma_swarm.dgc_cli.cmd_forge") as mock_forge:
        dharma_ops.cmd_forge(
            path=None,
            batch=None,
            plan=True,
            deficit_id="def-2",
            title="Forward controls",
            file_refs=["dharma_swarm/forge/operator.py"],
            test_refs=["tests/test_forge_operator.py"],
        )

    mock_forge.assert_called_once_with(
        path=None,
        batch=None,
        plan=True,
        deficit_id="def-2",
        title="Forward controls",
        file_refs=["dharma_swarm/forge/operator.py"],
        test_refs=["tests/test_forge_operator.py"],
    )


def test_dispatch_known_command_routes_forge_plan() -> None:
    from dharma_swarm.dgc.main import _dispatch_known_command

    with patch("dharma_swarm.dgc.commands.dharma_ops.cmd_forge") as mock_forge:
        handled = _dispatch_known_command(
            [
                "forge",
                "--plan",
                "--deficit-id",
                "def-1",
                "--title",
                "Plan contained forge",
                "--file-ref",
                "dharma_swarm/forge/kernel.py",
                "--test-ref",
                "tests/test_forge_kernel.py",
            ]
        )

    assert handled is True
    mock_forge.assert_called_once_with(
        path=None,
        batch=None,
        plan=True,
        run=False,
        status=False,
        receipt=False,
        state_dir=None,
        run_id=None,
        deficit_id="def-1",
        title="Plan contained forge",
        deficit_class="failing_test",
        summary="",
        file_refs=["dharma_swarm/forge/kernel.py"],
        test_refs=["tests/test_forge_kernel.py"],
        changed_files=[],
        dry_run=False,
    )


def test_dispatch_known_command_routes_forge_status() -> None:
    from dharma_swarm.dgc.main import _dispatch_known_command

    with patch("dharma_swarm.dgc.commands.dharma_ops.cmd_forge") as mock_forge:
        handled = _dispatch_known_command(["forge", "--status", "--run-id", "run-1", "--state-dir", "/tmp/dharma"])

    assert handled is True
    mock_forge.assert_called_once_with(
        path=None,
        batch=None,
        plan=False,
        run=False,
        status=True,
        receipt=False,
        state_dir="/tmp/dharma",
        run_id="run-1",
        deficit_id=None,
        title=None,
        deficit_class="failing_test",
        summary="",
        file_refs=[],
        test_refs=[],
        changed_files=[],
        dry_run=False,
    )
