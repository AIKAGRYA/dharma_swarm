"""Tests for the ontology meta-layer primitives and helpers."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from dharma_swarm.ontology import OntologyRegistry
from dharma_swarm.ontology_meta import (
    DelegationEntry,
    MetaPrimitive,
    OwnerChain,
    QualifiedRelationship,
    SemanticTag,
    TemporalPropertyValue,
    classify_types,
    validate_meta_coverage,
)


class TestMetaPrimitive:
    def test_has_expected_values(self) -> None:
        assert [primitive.value for primitive in MetaPrimitive] == [
            "ENTITY",
            "EVENT",
            "RELATIONSHIP",
            "PROPERTY",
            "ACTION",
            "CAPABILITY",
            "COMPOSITION",
        ]


class TestQualifiedRelationship:
    def test_confidence_must_be_between_zero_and_one(self) -> None:
        with pytest.raises(ValidationError):
            QualifiedRelationship(
                name="supports",
                source_type="Capability",
                target_type="TypedTask",
                qualifier="required",
                confidence=1.2,
            )


class TestTemporalPropertyValue:
    def test_is_active_respects_valid_window(self) -> None:
        now = datetime.now(timezone.utc)
        active = TemporalPropertyValue(
            property_name="status",
            value="active",
            valid_from=now - timedelta(minutes=5),
            valid_until=now + timedelta(minutes=5),
        )
        expired = TemporalPropertyValue(
            property_name="status",
            value="completed",
            valid_from=now - timedelta(days=2),
            valid_until=now - timedelta(days=1),
        )

        assert active.is_active(now) is True
        assert expired.is_active(now) is False


class TestOwnerChain:
    def test_delegate_tracks_root_and_current_owner(self) -> None:
        chain = OwnerChain(
            chain=[
                DelegationEntry(agent_id="agent_root"),
            ]
        )

        chain.delegate("agent_child")

        assert chain.root_owner == "agent_root"
        assert chain.current_owner == "agent_child"
        assert len(chain.chain) == 2


class TestSemanticTag:
    def test_round_trips_to_string(self) -> None:
        tag = SemanticTag(
            tag_namespace="aas",
            tag_key="semanticId",
            tag_value="capability://research",
            uri="https://example.com/capability/research",
        )

        restored = SemanticTag.from_string(str(tag))

        assert restored == tag


class TestMetaHelpers:
    def test_classify_types_groups_canonical_registry(self) -> None:
        registry = OntologyRegistry.create_dharma_registry()

        grouped = classify_types(registry)

        assert "ActionProposal" in grouped[MetaPrimitive.ACTION]
        assert "Capability" in grouped[MetaPrimitive.CAPABILITY]

    def test_validate_meta_coverage_finds_no_orphans(self) -> None:
        registry = OntologyRegistry.create_dharma_registry()

        assert validate_meta_coverage(registry) == []
