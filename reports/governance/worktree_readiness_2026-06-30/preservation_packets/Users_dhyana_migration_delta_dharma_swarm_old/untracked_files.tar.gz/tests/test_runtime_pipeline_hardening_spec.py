from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC_DIR = ROOT / "spec-forge" / "runtime-pipeline-hardening"


def _read_text(name: str) -> str:
    return (SPEC_DIR / name).read_text(encoding="utf-8")


def _read_json(name: str):
    return json.loads(_read_text(name))


def test_spec_package_contains_required_files() -> None:
    required = {
        "00-raw-requirements.md",
        "01-architecture.md",
        "CONSTITUTION.md",
        "RESEARCH_SYNTHESIS.md",
        "features.json",
        "05-traceability.md",
        "06-orthogonal-findings.md",
        "validation_manifest.json",
        "forge-prompt.md",
        "FORGE_COMPLETE.md",
    }
    present = {path.name for path in SPEC_DIR.iterdir() if path.is_file()}
    assert required <= present


def test_forge_prompt_contains_roles_and_ordered_phases() -> None:
    text = _read_text("forge-prompt.md")
    assert "complex systems engineer" in text
    assert "master DevOps/SRE operator" in text
    assert "autonomous systems reliability engineer" in text
    assert "1. close one real self-correcting routing loop" in text
    assert "2. collapse remaining spawn-path latency" in text
    assert "3. make coordination refresh incremental" in text
    assert "4. add hard supervision plus black-box and white-box health" in text
    assert "5. add retention policy and exception surfacing" in text


def test_features_manifest_has_all_five_phases_and_dense_coverage() -> None:
    features = _read_json("features.json")
    assert isinstance(features, list)
    assert len(features) >= 40

    ids = {feature["id"] for feature in features}
    assert len(ids) == len(features)

    phase_order = [
        "phase_1_self_correcting_routing",
        "phase_2_spawn_latency",
        "phase_3_coordination_incrementality",
        "phase_4_supervision_health",
        "phase_5_retention_exception_audit",
    ]
    phase_counts = {phase: 0 for phase in phase_order}
    for feature in features:
        assert set(feature) == {
            "id",
            "phase",
            "component",
            "category",
            "description",
            "steps",
            "verification",
            "dependencies",
            "estimated_minutes",
            "priority",
            "status",
        }
        assert feature["phase"] in phase_counts
        phase_counts[feature["phase"]] += 1
        assert isinstance(feature["steps"], list) and feature["steps"]
        assert isinstance(feature["dependencies"], list)
        assert feature["estimated_minutes"] >= 5
        assert feature["priority"] in {"P0", "P1", "P2"}
        assert feature["status"] == "not_started"

    assert all(count >= 8 for count in phase_counts.values())


def test_traceability_and_research_docs_cover_core_requirements() -> None:
    traceability = _read_text("05-traceability.md")
    raw_requirements = _read_text("00-raw-requirements.md")
    research = _read_text("RESEARCH_SYNTHESIS.md")

    for requirement_id in [
        "R-001",
        "R-002",
        "R-003",
        "R-004",
        "R-005",
        "R-006",
        "R-007",
        "R-008",
        "R-009",
        "R-010",
        "R-011",
        "R-012",
    ]:
        assert requirement_id in raw_requirements
        assert requirement_id in traceability

    assert "resources.anthropic.com" in research
    assert "developers.openai.com" in research
    assert "sre.google" in research


def test_validation_manifest_defines_phase_and_global_checks() -> None:
    manifest = _read_json("validation_manifest.json")
    assert manifest["artifact_root"] == "spec-forge/runtime-pipeline-hardening"
    assert len(manifest["phase_checks"]) == 5
    assert len(manifest["global_checks"]) >= 4

    for phase in manifest["phase_checks"]:
        assert {"id", "name", "unit_test_commands", "integration_commands", "live_checks", "acceptance"} <= set(phase)
        assert phase["unit_test_commands"]
        assert phase["live_checks"]
        assert phase["acceptance"]

    joined_globals = "\n".join(manifest["global_checks"])
    assert "git diff --check" in joined_globals
    assert "doctor --quick" in joined_globals
