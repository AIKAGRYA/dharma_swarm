# LangChain Deep Agents: Multi-Agent Patterns

Source:
- Title: Building Multi-Agent Applications with Deep Agents
- Date: 2026-01-21
- URL: https://blog.langchain.dev/building-multi-agent-applications-with-deep-agents/

Why it matters:

This source frames subagents and skills as first-class context-management tools, not just abstractions for organization. It is useful as a public reference point for planner/delegator separation and progressive disclosure of capability.

What dharma_swarm should steal:

- isolate exploratory work in sub-contexts instead of polluting the main thread
- make skill descriptions cheap and skill bodies expensive
- treat multi-model role separation as normal runtime structure

Concrete local mappings:

- `dharma_swarm/persistent_agent.py`
- `dharma_swarm/startup_crew.py`
- `dharma_swarm/skill_composer.py`
- `dharma_swarm/context.py`

Gap statement:

`dharma_swarm` has parallel agent vocabulary, but not a clean runtime split between main context and disposable exploratory subcontexts.
