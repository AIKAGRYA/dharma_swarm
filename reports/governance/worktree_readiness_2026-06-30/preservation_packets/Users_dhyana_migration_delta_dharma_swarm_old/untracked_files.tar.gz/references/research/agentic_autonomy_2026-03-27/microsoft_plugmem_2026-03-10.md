# Microsoft PlugMem

Source:
- Title: From raw interaction to reusable knowledge: rethinking memory for AI agents
- Date: 2026-03-10
- URL: https://www.microsoft.com/en-us/research/blog/from-raw-interaction-to-reusable-knowledge-rethinking-memory-for-ai-agents/

Why it matters:

PlugMem pushes a knowledge-centric view of memory: do not just accumulate raw logs, transform interaction history into reusable facts, procedures, and strategies that can be transferred across tasks.

What dharma_swarm should steal:

- move from raw episode retention toward reusable knowledge objects
- separate episodic logs from distilled skills and facts
- prefer retrieval over replay when carrying context between tasks

Concrete local mappings:

- `dharma_swarm/engine/conversation_memory.py`
- `dharma_swarm/engine/event_memory.py`
- `dharma_swarm/semantic_digester.py`
- `dharma_swarm/citation_index.py`

Gap statement:

`dharma_swarm` stores a lot of memory, but its transformation layer from event traces to reusable knowledge is still thin.
