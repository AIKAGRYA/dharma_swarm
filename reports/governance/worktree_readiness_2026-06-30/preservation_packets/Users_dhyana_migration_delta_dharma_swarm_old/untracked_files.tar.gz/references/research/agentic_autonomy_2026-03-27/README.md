# Agentic Autonomy Bundle

Date: 2026-03-27

Purpose: collect and localize external source material for long-horizon autonomy, harness self-evolution, persistent identity, and agent-economy closure so `dharma_swarm` can metabolize it with existing markdown/code digestion paths.

This bundle is intentionally additive. It does not change runtime behavior. It creates:

- local source notes for non-repo primary sources
- local clones of adjacent repos under `references/adjacent/`
- a machine-readable manifest with 24 metabolizable sources
- citation seeds that map external claims onto concrete `dharma_swarm` seams

Primary themes:

- REA-style planner/executor split with wait-state job resumption
- MiniMax-style self-evolution over memory, skills, harness, and evaluation loops
- Ouroboros-style identity persistence, constitution, and git-mediated self-rewrite
- CashClaw/HYRVE-style economic closure with jobs, delivery, payout, and payment rails
- DeepAgents/PlugMem/MemPO support for long-horizon memory and context handling

Key dharma_swarm seams these sources target:

- `dharma_swarm/checkpoint.py`
- `dharma_swarm/persistent_agent.py`
- `dharma_swarm/orchestrate_live.py`
- `dharma_swarm/economic_agent.py`
- `dharma_swarm/self_improve.py`
- `dharma_swarm/identity.py`
- `dharma_swarm/context.py`
- `dharma_swarm/engine/conversation_memory.py`
- `dharma_swarm/engine/event_memory.py`

Manifest:

- `references/research/agentic_autonomy_2026-03-27/sources.json`

External note files:

- `meta_rea_2026-03-17.md`
- `minimax_m27_2026-03-18.md`
- `microsoft_plugmem_2026-03-10.md`
- `langchain_deepagents_multi_agent_2026-01-21.md`
- `langchain_deepagents_context_2026-01-28.md`
- `mempo_2026-03-17.md`

Suggested next runtime pass after review:

1. Add a true wait-state job object that can park on external work and resume into the next planned action.
2. Upgrade `economic_agent.py` from vocabulary to a real job/payment state machine.
3. Treat memory, skills, prompts, and loop policy as mutable first-class objects in `self_improve.py`.
4. Bind identity and constitution changes to explicit lineage artifacts instead of ad hoc persistence.
