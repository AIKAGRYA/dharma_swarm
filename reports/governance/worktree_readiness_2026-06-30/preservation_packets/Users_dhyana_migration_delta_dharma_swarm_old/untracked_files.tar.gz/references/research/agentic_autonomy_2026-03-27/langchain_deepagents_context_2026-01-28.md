# LangChain Deep Agents: Context Management

Source:
- Title: Context Management for Deep Agents
- Date: 2026-01-28
- URL: https://blog.langchain.dev/context-management-for-deepagents/

Why it matters:

This is a concrete public write-up of filesystem-backed context offload, tool result eviction, structured summarization, and recoverability tests for long-running agents.

What dharma_swarm should steal:

- offload large tool results to durable storage and keep only pointers in active context
- evict large write/edit payloads once they are safely on disk
- summarize aggressively only when recoverability exists
- maintain targeted evals for goal preservation and needle-in-haystack recall

Concrete local mappings:

- `dharma_swarm/context.py`
- `dharma_swarm/checkpoint.py`
- `dharma_swarm/engine/conversation_memory.py`
- `dharma_swarm/engine/event_memory.py`

Gap statement:

`dharma_swarm` compacts and stores memory, but it lacks a sharply defined offload-and-recover contract for long tool traces.
