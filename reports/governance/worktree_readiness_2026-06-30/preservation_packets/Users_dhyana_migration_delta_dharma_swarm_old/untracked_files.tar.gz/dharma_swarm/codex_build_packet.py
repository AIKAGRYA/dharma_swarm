"""Public packet helpers for Codex/forge packet generation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Mapping


def render_forge_mission(packet: Mapping[str, object]) -> str:
    """Render a minimal human-readable forge packet summary."""
    title = str(packet.get("title") or "Forge Mission")
    summary = str(packet.get("summary") or "").strip()
    lines = [f"# {title}"]
    if summary:
        lines.extend(["", summary])
    return "\n".join(lines)


def write_forge_packet(
    packet: Mapping[str, object],
    *,
    output_path: str | Path,
) -> Path:
    """Write a forge packet JSON artifact and return its path."""
    target = Path(output_path).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(dict(packet), indent=2, sort_keys=True), encoding="utf-8")
    return target


__all__ = ["render_forge_mission", "write_forge_packet"]
