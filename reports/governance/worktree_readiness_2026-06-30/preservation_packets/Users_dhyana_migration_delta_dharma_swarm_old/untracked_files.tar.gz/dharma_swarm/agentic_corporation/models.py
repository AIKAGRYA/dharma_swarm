"""Pydantic v2 domain models for the Agentic Corporation layer.

Maps dharma_swarm's existing runtime types into a company-state vocabulary:
Agents, Roles, Capabilities, WorkUnits, Runs, Steps, Checkpoints, Artifacts,
Connectors, Approvals, Outcomes, CostEvents, RevenueEvents, MutationRequests.

All models use ``BaseModel`` with ``Field(default_factory=...)`` for mutable
defaults and round-trip cleanly through JSON.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from dharma_swarm.models import (
    AgentConfig,
    AgentRole,
    AgentState,
    AgentStatus,
    GateCheckResult,
    GateDecision,
    ProviderType,
    Task,
    _new_id,
    _utc_now,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class AgentLifecycleStatus(str, Enum):
    """Lifecycle status for agents in the corporation model."""

    DRAFT = "draft"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    RETIRED = "retired"


class RunStatus(str, Enum):
    """Status of a Run (work-unit execution thread)."""

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


class ApprovalStatus(str, Enum):
    """Status of an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class Agent(BaseModel):
    """Corporation-layer agent identity."""

    id: str = Field(default_factory=_new_id)
    name: str = ""
    role: str = "general"
    status: AgentLifecycleStatus = AgentLifecycleStatus.DRAFT
    vendor: str = "internal"
    version: str = "0.1.0"
    purpose: str = ""
    owner: str = ""
    provider: ProviderType = ProviderType.OPENROUTER
    model: str = ""
    capabilities: list[str] = Field(default_factory=list)
    department: str = ""
    squad_id: str = ""
    specialization: str = ""
    level: int = 1
    xp: float = 0.0
    reputation: float = 0.0
    trust_band: str = "unknown"
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_legacy(
        cls,
        config: AgentConfig,
        state: AgentState | None = None,
    ) -> Agent:
        """Create an Agent from legacy AgentConfig + optional AgentState."""
        status_map: dict[AgentStatus, AgentLifecycleStatus] = {
            AgentStatus.IDLE: AgentLifecycleStatus.ACTIVE,
            AgentStatus.BUSY: AgentLifecycleStatus.ACTIVE,
            AgentStatus.STARTING: AgentLifecycleStatus.DRAFT,
            AgentStatus.STOPPING: AgentLifecycleStatus.SUSPENDED,
            AgentStatus.DEAD: AgentLifecycleStatus.RETIRED,
        }
        lifecycle = AgentLifecycleStatus.DRAFT
        if state is not None:
            lifecycle = status_map.get(state.status, AgentLifecycleStatus.DRAFT)

        return cls(
            id=config.id,
            name=config.name,
            role=config.role.value if isinstance(config.role, AgentRole) else str(config.role),
            status=lifecycle,
            provider=config.provider,
            model=config.model,
            metadata=config.metadata.copy() if config.metadata else {},
        )


# ---------------------------------------------------------------------------
# Role
# ---------------------------------------------------------------------------

_ROLE_DESCRIPTIONS: dict[str, str] = {
    "coder": "Writes and modifies source code",
    "reviewer": "Reviews code and provides feedback",
    "researcher": "Conducts research and analysis",
    "tester": "Writes and runs tests",
    "orchestrator": "Coordinates multi-agent workflows",
    "general": "General-purpose agent",
    "cartographer": "Maps and documents the ecosystem",
    "archeologist": "Recovers and analyzes historical artifacts",
    "surgeon": "Precise, targeted code modifications",
    "architect": "Designs system architecture",
    "validator": "Validates outputs against specifications",
    "conductor": "Conducts orchestrated agent ensembles",
    "operator": "Day-to-day system operations",
    "archivist": "Manages knowledge archives",
    "research_director": "Directs research programs",
    "systems_architect": "Designs cross-system architecture",
    "strategist": "Strategic planning and decisions",
    "witness": "Observes and records system state",
    "worker": "Ephemeral task execution",
}


class Role(BaseModel):
    """A named role with capabilities and autonomy level."""

    name: str
    description: str = ""
    capabilities: list[str] = Field(default_factory=list)
    autonomy_level: int = 3

    @classmethod
    def from_legacy(cls, role: AgentRole) -> Role:
        """Create a Role from the legacy AgentRole enum."""
        return cls(
            name=role.value,
            description=_ROLE_DESCRIPTIONS.get(role.value, f"Agent role: {role.value}"),
        )


# ---------------------------------------------------------------------------
# Capability
# ---------------------------------------------------------------------------


class Capability(BaseModel):
    """A measurable agent capability."""

    id: str = Field(default_factory=_new_id)
    name: str = ""
    domain: str = ""
    tools: list[str] = Field(default_factory=list)
    measured_performance: float | None = None
    certified: bool = False


# ---------------------------------------------------------------------------
# WorkUnit
# ---------------------------------------------------------------------------


class WorkUnit(BaseModel):
    """A unit of work in the corporation (maps from legacy Task)."""

    id: str = Field(default_factory=_new_id)
    title: str = ""
    description: str = ""
    status: str = "pending"
    priority: str = "normal"
    assigned_to: str | None = None
    created_by: str = "system"
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime = Field(default_factory=_utc_now)
    depends_on: list[str] = Field(default_factory=list)
    result: str | None = None
    estimated_cost_usd: float | None = None
    actual_cost_usd: float | None = None
    sla_deadline: datetime | None = None
    checkpoint_ids: list[str] = Field(default_factory=list)
    artifact_ids: list[str] = Field(default_factory=list)
    parent_work_unit_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_legacy(cls, task: Task) -> WorkUnit:
        """Create a WorkUnit from a legacy Task."""
        return cls(
            id=task.id,
            title=task.title,
            description=task.description,
            status=task.status.value if hasattr(task.status, "value") else str(task.status),
            priority=task.priority.value if hasattr(task.priority, "value") else str(task.priority),
            assigned_to=task.assigned_to,
            created_by=task.created_by,
            created_at=task.created_at,
            updated_at=task.updated_at,
            depends_on=list(task.depends_on),
            result=task.result,
            metadata=task.metadata.copy() if task.metadata else {},
        )


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------


class Run(BaseModel):
    """A single execution thread against a work unit."""

    id: str = Field(default_factory=_new_id)
    work_unit_id: str = ""
    thread_id: str = ""
    status: RunStatus = RunStatus.PENDING
    agent_id: str = ""
    parent_run_id: str = ""
    started_at: datetime | None = None
    completed_at: datetime | None = None
    config: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=_utc_now)


# ---------------------------------------------------------------------------
# Step
# ---------------------------------------------------------------------------


class Step(BaseModel):
    """A single step within a Run."""

    id: str = Field(default_factory=_new_id)
    run_id: str = ""
    node_name: str = ""
    agent_id: str = ""
    status: str = "pending"
    input_state: dict[str, Any] = Field(default_factory=dict)
    output_state: dict[str, Any] | None = None
    input_artifact_ids: list[str] = Field(default_factory=list)
    output_artifact_ids: list[str] = Field(default_factory=list)
    error: str | None = None
    retry_count: int = 0
    started_at: datetime | None = None
    completed_at: datetime | None = None


# ---------------------------------------------------------------------------
# Checkpoint
# ---------------------------------------------------------------------------


class Checkpoint(BaseModel):
    """A snapshot of run state at a given step for resumption / forking."""

    id: str = Field(default_factory=_new_id)
    run_id: str = ""
    step_index: int = 0
    state: dict[str, Any] = Field(default_factory=dict)
    pending_writes: list[dict[str, Any]] = Field(default_factory=list)
    parent_checkpoint_id: str = ""
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Artifact (corporation-layer)
# ---------------------------------------------------------------------------


class Artifact(BaseModel):
    """A corporation-layer artifact produced by a run or step."""

    id: str = Field(default_factory=_new_id)
    artifact_type: str = "unknown"
    content: str = ""
    summary: str = ""
    files_touched: list[str] = Field(default_factory=list)
    run_id: str | None = None
    step_id: str | None = None
    input_artifact_ids: list[str] = Field(default_factory=list)
    content_hash: str | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_legacy(cls, artifact: Any) -> Artifact:
        """Create from a legacy artifact (duck-typed to avoid hard imports)."""
        artifact_type = "unknown"
        if hasattr(artifact, "artifact_type"):
            at = artifact.artifact_type
            artifact_type = at.value if hasattr(at, "value") else str(at)

        content = getattr(artifact, "content", "")
        summary = getattr(artifact, "summary", "")
        files_touched = list(getattr(artifact, "files_touched", []))
        metadata = dict(getattr(artifact, "metadata", {}))

        return cls(
            artifact_type=artifact_type,
            content=content,
            summary=summary,
            files_touched=files_touched,
            metadata=metadata,
        )


# ---------------------------------------------------------------------------
# Connector
# ---------------------------------------------------------------------------


class Connector(BaseModel):
    """An external system connector (e.g. GitHub, Jira, Slack)."""

    id: str = Field(default_factory=_new_id)
    name: str = ""
    connector_type: str = ""
    auth_config: dict[str, Any] = Field(default_factory=dict)
    source_config: dict[str, Any] = Field(default_factory=dict)
    sync_schedule: str | None = None
    last_sync_at: datetime | None = None
    health_status: str = "unknown"
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Approval
# ---------------------------------------------------------------------------


class Approval(BaseModel):
    """A gated approval request."""

    id: str = Field(default_factory=_new_id)
    gate_name: str = ""
    requested_by: str = ""
    requested_at: datetime = Field(default_factory=_utc_now)
    status: ApprovalStatus = ApprovalStatus.PENDING
    approver: str | None = None
    decided_at: datetime | None = None
    reason: str = ""
    timeout_hours: float = 24.0
    context: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_legacy(cls, gate_result: GateCheckResult) -> Approval:
        """Create an Approval from a legacy GateCheckResult."""
        status_map: dict[GateDecision, ApprovalStatus] = {
            GateDecision.ALLOW: ApprovalStatus.APPROVED,
            GateDecision.BLOCK: ApprovalStatus.REJECTED,
            GateDecision.REVIEW: ApprovalStatus.PENDING,
        }
        return cls(
            gate_name=gate_result.gate,
            status=status_map.get(gate_result.decision, ApprovalStatus.PENDING),
            reason=gate_result.reason,
            requested_at=gate_result.timestamp,
        )


# ---------------------------------------------------------------------------
# Outcome
# ---------------------------------------------------------------------------


class Outcome(BaseModel):
    """A measured outcome from agent work."""

    id: str = Field(default_factory=_new_id)
    agent_id: str = ""
    work_unit_id: str | None = None
    outcome_type: str = ""
    success: bool = False
    value_metric: float | None = None
    value_unit: str | None = None
    evidence: str = ""
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# CostEvent
# ---------------------------------------------------------------------------


class CostEvent(BaseModel):
    """An LLM cost event (maps from legacy CostEntry)."""

    id: str = Field(default_factory=_new_id)
    timestamp: datetime = Field(default_factory=_utc_now)
    provider: str = ""
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    estimated_cost_usd: float = 0.0
    task_id: str = ""
    agent_id: str = ""
    tier: str = ""

    @classmethod
    def from_legacy(cls, entry: Any) -> CostEvent:
        """Create from a CostEntry dataclass.

        Imports CostEntry lazily to avoid circular deps.
        """
        ts = datetime.fromtimestamp(entry.timestamp, tz=timezone.utc)
        return cls(
            timestamp=ts,
            provider=entry.provider,
            model=entry.model,
            input_tokens=entry.input_tokens,
            output_tokens=entry.output_tokens,
            estimated_cost_usd=entry.estimated_cost_usd,
            task_id=getattr(entry, "task_id", ""),
            agent_id=getattr(entry, "agent_name", ""),
            tier=getattr(entry, "tier", ""),
        )


# ---------------------------------------------------------------------------
# RevenueEvent
# ---------------------------------------------------------------------------


class RevenueEvent(BaseModel):
    """An economic revenue/income event."""

    id: str = Field(default_factory=_new_id)
    timestamp: datetime = Field(default_factory=_utc_now)
    event_kind: str = ""
    amount: float = 0.0
    currency: str = "USD"
    counterparty: str = ""
    work_unit_id: str | None = None
    description: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# MutationRequest
# ---------------------------------------------------------------------------


class MutationRequest(BaseModel):
    """A proposed mutation from the DarwinEngine (maps from Proposal)."""

    id: str = Field(default_factory=_new_id)
    component: str = ""
    change_type: str = ""
    description: str = ""
    status: str = ""
    parent_id: str | None = None
    diff: str = ""
    predicted_fitness: float = 0.0
    actual_fitness: float | None = None
    gate_decision: str | None = None
    gate_reason: str | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_legacy(cls, proposal: Any) -> MutationRequest:
        """Create from a DarwinEngine Proposal."""
        actual_fitness: float | None = None
        af = getattr(proposal, "actual_fitness", None)
        if af is not None:
            if hasattr(af, "total"):
                actual_fitness = float(af.total)
            else:
                actual_fitness = float(af)

        raw_status = getattr(proposal, "status", "")
        status_val = getattr(raw_status, "value", raw_status)
        if not isinstance(status_val, str):
            status_val = str(status_val)

        metadata_raw = getattr(proposal, "metadata", None)
        metadata = dict(metadata_raw) if metadata_raw else {}

        return cls(
            id=proposal.id,
            component=proposal.component,
            change_type=proposal.change_type,
            description=proposal.description,
            status=str(status_val),
            parent_id=proposal.parent_id,
            diff=proposal.diff,
            predicted_fitness=proposal.predicted_fitness,
            actual_fitness=actual_fitness,
            gate_decision=proposal.gate_decision,
            gate_reason=proposal.gate_reason,
            metadata=metadata,
        )
