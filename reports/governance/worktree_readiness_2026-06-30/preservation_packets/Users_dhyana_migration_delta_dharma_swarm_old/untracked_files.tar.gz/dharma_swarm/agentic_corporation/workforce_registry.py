"""Workforce Registry -- agent CRUD backed by the telemetry plane."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from dharma_swarm.agentic_corporation.models import Agent, AgentLifecycleStatus
from dharma_swarm.telemetry_plane import (
    AgentIdentityRecord,
    AgentReputationRecord,
    TelemetryPlaneStore,
)

logger = logging.getLogger(__name__)

_EXTRA_KEYS = (
    "role", "vendor", "version", "purpose", "owner", "provider", "model", "capabilities",
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _agent_to_identity_record(agent: Agent) -> AgentIdentityRecord:
    extra: dict[str, Any] = {}
    for key in _EXTRA_KEYS:
        val = getattr(agent, key, None)
        if val is not None:
            if hasattr(val, "value"):
                extra[key] = val.value
            elif isinstance(val, list):
                extra[key] = list(val)
            else:
                extra[key] = str(val) if not isinstance(val, (str, int, float, bool)) else val
    if agent.metadata:
        extra["_agent_metadata"] = dict(agent.metadata)
    return AgentIdentityRecord(
        agent_id=agent.id,
        codename=agent.name,
        department=agent.department,
        squad_id=agent.squad_id,
        specialization=agent.specialization,
        level=agent.level,
        xp=agent.xp,
        status=agent.status.value,
        last_active=_utc_now(),
        metadata=extra,
        created_at=agent.created_at,
        updated_at=agent.updated_at,
    )


def _identity_to_agent(rec: AgentIdentityRecord) -> Agent:
    meta = dict(rec.metadata) if rec.metadata else {}
    from dharma_swarm.models import ProviderType

    role = meta.pop("role", "general")
    vendor = meta.pop("vendor", "internal")
    version = meta.pop("version", "0.1.0")
    purpose = meta.pop("purpose", "")
    owner = meta.pop("owner", "")
    provider_raw = meta.pop("provider", "openrouter")
    model = meta.pop("model", "")
    capabilities = meta.pop("capabilities", [])
    agent_metadata = meta.pop("_agent_metadata", {})
    try:
        provider = ProviderType(provider_raw)
    except (ValueError, KeyError):
        provider = ProviderType.OPENROUTER
    try:
        status = AgentLifecycleStatus(rec.status)
    except (ValueError, KeyError):
        status = AgentLifecycleStatus.DRAFT
    return Agent(
        id=rec.agent_id,
        name=rec.codename,
        role=role,
        status=status,
        vendor=vendor,
        version=version,
        purpose=purpose,
        owner=owner,
        provider=provider,
        model=model,
        capabilities=list(capabilities) if isinstance(capabilities, list) else [],
        department=rec.department,
        squad_id=rec.squad_id,
        specialization=rec.specialization,
        level=rec.level,
        xp=rec.xp,
        reputation=0.0,
        trust_band="unknown",
        created_at=rec.created_at,
        updated_at=rec.updated_at,
        metadata=agent_metadata if isinstance(agent_metadata, dict) else {},
    )


def _lane_to_agent(lane: Any) -> Agent:
    from dharma_swarm.models import ProviderType
    provider = ProviderType.OPENROUTER
    model = ""
    if lane.default_provider_order:
        provider = lane.default_provider_order[0]
    if lane.default_models:
        model = next(iter(lane.default_models.values()), "")
    return Agent(
        id=lane.profile_id,
        name=lane.display_name,
        role="general",
        status=AgentLifecycleStatus.ACTIVE,
        vendor="certified",
        purpose=lane.summary,
        provider=provider,
        model=model,
    )


class WorkforceRegistry:
    """Async agent registry backed by the telemetry plane."""

    def __init__(self, telemetry_store: TelemetryPlaneStore | None = None) -> None:
        self._store = telemetry_store or TelemetryPlaneStore()

    async def register_agent(self, agent: Agent) -> Agent:
        rec = _agent_to_identity_record(agent)
        saved = await self._store.upsert_agent_identity(rec)
        if agent.reputation != 0.0 or agent.trust_band != "unknown":
            rep = AgentReputationRecord(
                agent_id=agent.id,
                reputation=agent.reputation,
                trust_band=agent.trust_band,
            )
            await self._store.upsert_agent_reputation(rep)
        return _identity_to_agent(saved)

    async def get_agent(self, agent_id: str) -> Agent | None:
        rec = await self._store.get_agent_identity(agent_id)
        if rec is None:
            return None
        agent = _identity_to_agent(rec)
        rep = await self._store.get_agent_reputation(agent_id)
        if rep is not None:
            agent.reputation = rep.reputation
            agent.trust_band = rep.trust_band
        return agent

    async def list_agents(self, *, status: str | None = None, limit: int = 100) -> list[Agent]:
        recs = await self._store.list_agent_identities(status=status, limit=limit)
        return [_identity_to_agent(r) for r in recs]

    async def update_agent_status(self, agent_id: str, status: AgentLifecycleStatus) -> Agent | None:
        agent = await self.get_agent(agent_id)
        if agent is None:
            return None
        agent.status = status
        agent.updated_at = _utc_now()
        return await self.register_agent(agent)

    async def retire_agent(self, agent_id: str) -> Agent | None:
        return await self.update_agent_status(agent_id, AgentLifecycleStatus.RETIRED)

    def get_certified_lanes(self) -> list[Agent]:
        try:
            from dharma_swarm.certified_lanes import CERTIFIED_LANES
        except ImportError:
            logger.debug("certified_lanes module not available")
            return []
        return [_lane_to_agent(lane) for lane in CERTIFIED_LANES]
