"""Control Tower -- gated agent management and operational visibility."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from dharma_swarm.agentic_corporation.models import (
    Agent,
    Approval,
    ApprovalStatus,
    _new_id,
    _utc_now,
)
from dharma_swarm.agentic_corporation.workforce_registry import WorkforceRegistry

logger = logging.getLogger(__name__)

_PENDING_DIR = Path.home() / ".dharma" / "approvals" / "pending"
_DECIDED_DIR = Path.home() / ".dharma" / "approvals" / "decided"


def _ensure_approval_dirs() -> None:
    _PENDING_DIR.mkdir(parents=True, exist_ok=True)
    _DECIDED_DIR.mkdir(parents=True, exist_ok=True)


try:
    from dharma_swarm.telos_gates import check_action as _check_action
except ImportError:
    _check_action = None  # type: ignore[assignment]

try:
    from dharma_swarm.monitor import SystemMonitor as _SystemMonitor
    from dharma_swarm.traces import TraceStore as _TraceStore
except ImportError:
    _SystemMonitor = None  # type: ignore[assignment]
    _TraceStore = None  # type: ignore[assignment]


class ControlTower:
    """Central control plane for the agentic corporation."""

    def __init__(
        self,
        registry: WorkforceRegistry | None = None,
        telemetry: Any | None = None,
    ) -> None:
        from dharma_swarm.telemetry_plane import TelemetryPlaneStore
        self._telemetry: TelemetryPlaneStore | None = telemetry
        if registry is not None:
            self._registry = registry
        else:
            self._registry = WorkforceRegistry(telemetry_store=self._telemetry)

    async def register_agent(self, agent: Agent) -> Agent:
        return await self._registry.register_agent(agent)

    async def get_agent(self, agent_id: str) -> Agent | None:
        return await self._registry.get_agent(agent_id)

    async def list_agents(self, *, status: str | None = None, limit: int = 100) -> list[Agent]:
        return await self._registry.list_agents(status=status, limit=limit)

    async def retire_agent(self, agent_id: str) -> Agent | None:
        return await self._registry.retire_agent(agent_id)

    def get_certified_lanes(self) -> list[Agent]:
        return self._registry.get_certified_lanes()

    def check_gate(self, action: str, content: str = "") -> Approval:
        if _check_action is None:
            return Approval(
                gate_name="telos_gate",
                status=ApprovalStatus.APPROVED,
                reason="telos_gates not available; defaulting to APPROVED",
            )
        result = _check_action(action, content)
        return Approval.from_legacy(result)

    async def request_approval(
        self,
        gate_name: str,
        requested_by: str,
        context: dict[str, Any] | None = None,
        timeout_hours: float = 24.0,
    ) -> Approval:
        _ensure_approval_dirs()
        approval = Approval(
            id=_new_id(),
            gate_name=gate_name,
            requested_by=requested_by,
            requested_at=_utc_now(),
            status=ApprovalStatus.PENDING,
            timeout_hours=timeout_hours,
            context=context or {},
        )
        path = _PENDING_DIR / f"{approval.id}.json"
        path.write_text(approval.model_dump_json(indent=2), encoding="utf-8")
        return approval

    async def approve(self, approval_id: str, approver: str, reason: str = "") -> Approval | None:
        return await self._decide(approval_id, approver, reason, ApprovalStatus.APPROVED)

    async def reject(self, approval_id: str, approver: str, reason: str = "") -> Approval | None:
        return await self._decide(approval_id, approver, reason, ApprovalStatus.REJECTED)

    async def _decide(
        self,
        approval_id: str,
        approver: str,
        reason: str,
        status: ApprovalStatus,
    ) -> Approval | None:
        _ensure_approval_dirs()
        pending_path = _PENDING_DIR / f"{approval_id}.json"
        if not pending_path.exists():
            return None
        try:
            data = json.loads(pending_path.read_text(encoding="utf-8"))
            approval = Approval.model_validate(data)
        except (json.JSONDecodeError, ValueError, OSError) as exc:
            logger.error("Corrupt approval file %s: %s — removing", pending_path, exc)
            pending_path.unlink(missing_ok=True)
            return None
        approval.status = status
        approval.approver = approver
        approval.reason = reason
        approval.decided_at = _utc_now()
        decided_path = _DECIDED_DIR / f"{approval_id}.json"
        decided_path.write_text(approval.model_dump_json(indent=2), encoding="utf-8")
        pending_path.unlink(missing_ok=True)
        return approval

    async def list_pending_approvals(self) -> list[Approval]:
        _ensure_approval_dirs()
        approvals: list[Approval] = []
        for path in sorted(_PENDING_DIR.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                approvals.append(Approval.model_validate(data))
            except (json.JSONDecodeError, ValueError, OSError) as exc:
                logger.warning("Skipping corrupt approval file %s: %s", path, exc)
        return approvals

    async def get_failure_map(self) -> list[dict[str, Any]]:
        if _SystemMonitor is None or _TraceStore is None:
            return []
        try:
            monitor = _SystemMonitor(_TraceStore())
            anomalies = await monitor.detect_anomalies()
            return [
                {
                    "id": a.id,
                    "type": a.anomaly_type,
                    "severity": a.severity,
                    "description": a.description,
                    "detected_at": a.detected_at.isoformat(),
                }
                for a in anomalies
            ]
        except Exception as exc:
            logger.warning("Failed to get failure map: %s", exc)
            return []

    async def get_value_map(self) -> dict[str, Any]:
        if self._telemetry is None:
            return {"total_revenue": 0.0, "total_cost": 0.0, "events": []}
        try:
            import sqlite3
            await self._telemetry.init_db()
            db_path = self._telemetry.db_path
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            try:
                rows = conn.execute(
                    "SELECT event_kind, SUM(amount) as total, COUNT(*) as count"
                    " FROM economic_events GROUP BY event_kind"
                    " ORDER BY total DESC LIMIT 50"
                ).fetchall()
                events = [
                    {"kind": row["event_kind"], "total": float(row["total"]), "count": int(row["count"])}
                    for row in rows
                ]
                total_revenue = sum(e["total"] for e in events if "revenue" in e["kind"].lower())
                total_cost = sum(e["total"] for e in events if "cost" in e["kind"].lower())
                return {"total_revenue": total_revenue, "total_cost": total_cost, "events": events}
            finally:
                conn.close()
        except Exception as exc:
            logger.warning("Failed to get value map: %s", exc)
            return {"total_revenue": 0.0, "total_cost": 0.0, "events": []}
