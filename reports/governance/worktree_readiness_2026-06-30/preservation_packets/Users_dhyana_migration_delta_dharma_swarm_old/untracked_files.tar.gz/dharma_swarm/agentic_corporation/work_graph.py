"""Work Graph — SQLite-backed run/step/checkpoint/event persistence.

Provides synchronous CRUD for the execution graph:
  - Runs: create, get, list, update status
  - Steps: add, complete, get
  - Checkpoints: save, get, list, fork
  - Events: log, get
  - Lineage: record, provenance, impact (delegates to LineageGraph)

All methods are synchronous. SQLite WAL mode is used for safe concurrency.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Generator

from dharma_swarm.agentic_corporation.models import (
    Checkpoint,
    Run,
    RunStatus,
    Step,
    _new_id,
    _utc_now,
)

logger = logging.getLogger(__name__)

_DEFAULT_DB = Path.home() / ".dharma" / "state" / "work_graph.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY,
    work_unit_id TEXT NOT NULL DEFAULT '',
    thread_id TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    agent_id TEXT NOT NULL DEFAULT '',
    parent_run_id TEXT NOT NULL DEFAULT '',
    started_at TEXT,
    completed_at TEXT,
    config_json TEXT NOT NULL DEFAULT '{}',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS steps (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    node_name TEXT NOT NULL DEFAULT '',
    agent_id TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    input_state_json TEXT NOT NULL DEFAULT '{}',
    output_state_json TEXT,
    input_artifact_ids_json TEXT NOT NULL DEFAULT '[]',
    output_artifact_ids_json TEXT NOT NULL DEFAULT '[]',
    error TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    started_at TEXT,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS checkpoints (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    step_index INTEGER NOT NULL DEFAULT 0,
    state_json TEXT NOT NULL DEFAULT '{}',
    pending_writes_json TEXT NOT NULL DEFAULT '[]',
    parent_checkpoint_id TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL DEFAULT '',
    step_id TEXT NOT NULL DEFAULT '',
    event_type TEXT NOT NULL DEFAULT '',
    payload_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_steps_run ON steps(run_id);
CREATE INDEX IF NOT EXISTS idx_checkpoints_run ON checkpoints(run_id);
CREATE INDEX IF NOT EXISTS idx_events_run ON events(run_id);
CREATE INDEX IF NOT EXISTS idx_events_step ON events(step_id);
"""


def _utc_now_iso() -> str:
    return _utc_now().isoformat()


def _dt_iso(dt: datetime | None) -> str | None:
    return dt.isoformat() if dt is not None else None


def _parse_dt(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw)
    except Exception:
        return None


def _json_dumps(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=True, default=str)


def _json_loads(raw: str | None, fallback: Any = None) -> Any:
    if not raw:
        return fallback if fallback is not None else {}
    try:
        return json.loads(raw)
    except Exception:
        return fallback if fallback is not None else {}


# ---------------------------------------------------------------------------
# WorkGraph
# ---------------------------------------------------------------------------


class WorkGraph:
    """Synchronous SQLite-backed execution graph."""

    def __init__(
        self,
        db_path: Path | str | None = None,
        lineage_db_path: Path | str | None = None,
    ) -> None:
        self.db_path = Path(db_path) if db_path else _DEFAULT_DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self._lineage_db_path = Path(lineage_db_path) if lineage_db_path else None
        self._lineage: Any = None  # lazy

        self._init_schema()

    def _init_schema(self) -> None:
        with self._conn() as conn:
            conn.executescript(_SCHEMA)

    @contextmanager
    def _conn(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _get_lineage(self) -> Any:
        """Lazy-init lineage graph."""
        if self._lineage is None:
            try:
                from dharma_swarm.lineage import LineageGraph

                self._lineage = LineageGraph(
                    db_path=self._lineage_db_path or self.db_path.parent / "lineage.db"
                )
            except ImportError:
                logger.debug("LineageGraph not available")
        return self._lineage

    # -- Runs --------------------------------------------------------------

    def create_run(
        self,
        work_unit_id: str = "",
        thread_id: str = "",
        agent_id: str = "",
        parent_run_id: str = "",
        config: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Run:
        """Create a new run."""
        run = Run(
            id=_new_id(),
            work_unit_id=work_unit_id,
            thread_id=thread_id,
            status=RunStatus.PENDING,
            agent_id=agent_id,
            parent_run_id=parent_run_id,
            config=config or {},
            metadata=metadata or {},
            created_at=_utc_now(),
        )
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO runs (id, work_unit_id, thread_id, status, agent_id,"
                " parent_run_id, started_at, completed_at, config_json,"
                " metadata_json, created_at)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (
                    run.id,
                    run.work_unit_id,
                    run.thread_id,
                    run.status.value,
                    run.agent_id,
                    run.parent_run_id,
                    _dt_iso(run.started_at),
                    _dt_iso(run.completed_at),
                    _json_dumps(run.config),
                    _json_dumps(run.metadata),
                    run.created_at.isoformat(),
                ),
            )
        return run

    def get_run(self, run_id: str) -> Run | None:
        """Retrieve a run by ID."""
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM runs WHERE id = ?", (run_id,)
            ).fetchone()
        if row is None:
            return None
        return self._row_to_run(row)

    def list_runs(
        self,
        *,
        work_unit_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[Run]:
        """List runs with optional filters."""
        query = "SELECT * FROM runs WHERE 1=1"
        params: list[Any] = []
        if work_unit_id is not None:
            query += " AND work_unit_id = ?"
            params.append(work_unit_id)
        if status is not None:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        with self._conn() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_run(r) for r in rows]

    def update_run_status(
        self,
        run_id: str,
        status: RunStatus,
    ) -> Run | None:
        """Update a run's status. Sets started_at/completed_at as appropriate."""
        now = _utc_now()
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
            if row is None:
                return None

            updates = {"status": status.value}
            if status == RunStatus.RUNNING and row["started_at"] is None:
                updates["started_at"] = now.isoformat()
            if status in (RunStatus.COMPLETED, RunStatus.FAILED):
                updates["completed_at"] = now.isoformat()

            set_clause = ", ".join(f"{k} = ?" for k in updates)
            vals = list(updates.values()) + [run_id]
            conn.execute(f"UPDATE runs SET {set_clause} WHERE id = ?", vals)

        return self.get_run(run_id)

    def _row_to_run(self, row: sqlite3.Row) -> Run:
        try:
            status = RunStatus(row["status"])
        except (ValueError, KeyError):
            status = RunStatus.PENDING
        return Run(
            id=row["id"],
            work_unit_id=row["work_unit_id"],
            thread_id=row["thread_id"],
            status=status,
            agent_id=row["agent_id"],
            parent_run_id=row["parent_run_id"],
            started_at=_parse_dt(row["started_at"]),
            completed_at=_parse_dt(row["completed_at"]),
            config=_json_loads(row["config_json"], {}),
            metadata=_json_loads(row["metadata_json"], {}),
            created_at=_parse_dt(row["created_at"]) or _utc_now(),
        )

    # -- Steps -------------------------------------------------------------

    def add_step(
        self,
        run_id: str,
        node_name: str = "",
        agent_id: str = "",
        input_state: dict[str, Any] | None = None,
        input_artifact_ids: list[str] | None = None,
    ) -> Step:
        """Add a step to a run."""
        step = Step(
            id=_new_id(),
            run_id=run_id,
            node_name=node_name,
            agent_id=agent_id,
            status="running",
            input_state=input_state or {},
            input_artifact_ids=input_artifact_ids or [],
            started_at=_utc_now(),
        )
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO steps (id, run_id, node_name, agent_id, status,"
                " input_state_json, output_state_json, input_artifact_ids_json,"
                " output_artifact_ids_json, error, retry_count, started_at,"
                " completed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    step.id,
                    step.run_id,
                    step.node_name,
                    step.agent_id,
                    step.status,
                    _json_dumps(step.input_state),
                    None,
                    _json_dumps(step.input_artifact_ids),
                    _json_dumps(step.output_artifact_ids),
                    step.error,
                    step.retry_count,
                    _dt_iso(step.started_at),
                    _dt_iso(step.completed_at),
                ),
            )
        return step

    def complete_step(
        self,
        step_id: str,
        output_state: dict[str, Any] | None = None,
        output_artifact_ids: list[str] | None = None,
        error: str | None = None,
    ) -> Step | None:
        """Complete a step with output state or error."""
        now = _utc_now()
        status = "failed" if error else "completed"
        out_arts = output_artifact_ids or []

        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM steps WHERE id = ?", (step_id,)
            ).fetchone()
            if row is None:
                return None

            conn.execute(
                "UPDATE steps SET status = ?, output_state_json = ?,"
                " output_artifact_ids_json = ?, error = ?, completed_at = ?"
                " WHERE id = ?",
                (
                    status,
                    _json_dumps(output_state) if output_state else None,
                    _json_dumps(out_arts),
                    error,
                    now.isoformat(),
                    step_id,
                ),
            )

        step = self._get_step_by_id(step_id)

        # Auto-record lineage when both input and output artifact IDs exist
        if step is not None and step.input_artifact_ids and out_arts:
            lineage = self._get_lineage()
            if lineage is not None:
                try:
                    lineage.record_transformation(
                        task_id=step.run_id,
                        inputs=step.input_artifact_ids,
                        outputs=out_arts,
                        agent=step.agent_id,
                        operation=step.node_name,
                    )
                except Exception as exc:
                    logger.debug("Lineage recording failed: %s", exc)

        return step

    def get_steps(self, run_id: str) -> list[Step]:
        """Get all steps for a run, ordered by started_at."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM steps WHERE run_id = ? ORDER BY started_at",
                (run_id,),
            ).fetchall()
        return [self._row_to_step(r) for r in rows]

    def _get_step_by_id(self, step_id: str) -> Step | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM steps WHERE id = ?", (step_id,)
            ).fetchone()
        return self._row_to_step(row) if row else None

    def _row_to_step(self, row: sqlite3.Row) -> Step:
        return Step(
            id=row["id"],
            run_id=row["run_id"],
            node_name=row["node_name"],
            agent_id=row["agent_id"],
            status=row["status"],
            input_state=_json_loads(row["input_state_json"], {}),
            output_state=_json_loads(row["output_state_json"], None),
            input_artifact_ids=_json_loads(row["input_artifact_ids_json"], []),
            output_artifact_ids=_json_loads(row["output_artifact_ids_json"], []),
            error=row["error"],
            retry_count=int(row["retry_count"]),
            started_at=_parse_dt(row["started_at"]),
            completed_at=_parse_dt(row["completed_at"]),
        )

    # -- Checkpoints -------------------------------------------------------

    def checkpoint(
        self,
        run_id: str,
        state: dict[str, Any],
        pending_writes: list[dict[str, Any]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Checkpoint:
        """Save a checkpoint. Auto-increments step_index and chains parent.

        Read + write happen in a single transaction to prevent race
        conditions on step_index.
        """
        cp_id = _new_id()
        now = _utc_now()
        pw = pending_writes or []
        meta = metadata or {}

        with self._conn() as conn:
            # Atomic: read latest + insert in one transaction
            row = conn.execute(
                "SELECT id, step_index FROM checkpoints WHERE run_id = ?"
                " ORDER BY step_index DESC LIMIT 1",
                (run_id,),
            ).fetchone()

            parent_id = ""
            step_index = 0
            if row is not None:
                parent_id = row["id"]
                step_index = int(row["step_index"]) + 1

            conn.execute(
                "INSERT INTO checkpoints (id, run_id, step_index, state_json,"
                " pending_writes_json, parent_checkpoint_id, created_at,"
                " metadata_json) VALUES (?,?,?,?,?,?,?,?)",
                (cp_id, run_id, step_index, _json_dumps(state),
                 _json_dumps(pw), parent_id, now.isoformat(),
                 _json_dumps(meta)),
            )

        return Checkpoint(
            id=cp_id, run_id=run_id, step_index=step_index, state=state,
            pending_writes=pw, parent_checkpoint_id=parent_id,
            created_at=now, metadata=meta,
        )

    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint | None:
        """Get a checkpoint by ID."""
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM checkpoints WHERE id = ?", (checkpoint_id,)
            ).fetchone()
        return self._row_to_checkpoint(row) if row else None

    def list_checkpoints(self, run_id: str) -> list[Checkpoint]:
        """List all checkpoints for a run, ordered by step_index."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM checkpoints WHERE run_id = ?"
                " ORDER BY step_index",
                (run_id,),
            ).fetchall()
        return [self._row_to_checkpoint(r) for r in rows]

    def _row_to_checkpoint(self, row: sqlite3.Row) -> Checkpoint:
        return Checkpoint(
            id=row["id"],
            run_id=row["run_id"],
            step_index=int(row["step_index"]),
            state=_json_loads(row["state_json"], {}),
            pending_writes=_json_loads(row["pending_writes_json"], []),
            parent_checkpoint_id=row["parent_checkpoint_id"],
            created_at=_parse_dt(row["created_at"]) or _utc_now(),
            metadata=_json_loads(row["metadata_json"], {}),
        )

    # -- Fork --------------------------------------------------------------

    def fork(
        self,
        checkpoint_id: str,
        state_updates: dict[str, Any] | None = None,
    ) -> Run:
        """Fork a new run from a checkpoint with optional state overrides."""
        cp = self.get_checkpoint(checkpoint_id)
        if cp is None:
            raise ValueError(f"Checkpoint not found: {checkpoint_id}")

        parent_run = self.get_run(cp.run_id)

        # Create new run
        new_run = self.create_run(
            work_unit_id=parent_run.work_unit_id if parent_run else "",
            thread_id=parent_run.thread_id if parent_run else "",
            agent_id=parent_run.agent_id if parent_run else "",
            parent_run_id=cp.run_id,
            metadata={"forked_from_checkpoint": checkpoint_id},
        )

        # Create initial checkpoint with merged state
        merged = dict(cp.state)
        if state_updates:
            merged.update(state_updates)

        self.checkpoint(
            run_id=new_run.id,
            state=merged,
            metadata={"forked_from": checkpoint_id},
        )

        return new_run

    # -- Events ------------------------------------------------------------

    def log_event(
        self,
        run_id: str = "",
        step_id: str = "",
        event_type: str = "",
        payload: dict[str, Any] | None = None,
    ) -> str:
        """Log an event and return its ID."""
        event_id = _new_id()
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO events (id, run_id, step_id, event_type,"
                " payload_json, created_at) VALUES (?,?,?,?,?,?)",
                (
                    event_id,
                    run_id,
                    step_id,
                    event_type,
                    _json_dumps(payload or {}),
                    _utc_now_iso(),
                ),
            )
        return event_id

    def get_events(
        self,
        run_id: str | None = None,
        *,
        step_id: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query events with optional filters."""
        query = "SELECT * FROM events WHERE 1=1"
        params: list[Any] = []
        if run_id is not None:
            query += " AND run_id = ?"
            params.append(run_id)
        if step_id is not None:
            query += " AND step_id = ?"
            params.append(step_id)
        if event_type is not None:
            query += " AND event_type = ?"
            params.append(event_type)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        with self._conn() as conn:
            rows = conn.execute(query, params).fetchall()

        return [
            {
                "id": row["id"],
                "run_id": row["run_id"],
                "step_id": row["step_id"],
                "event_type": row["event_type"],
                "payload": _json_loads(row["payload_json"], {}),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    # -- Lineage (delegates to LineageGraph) -------------------------------

    def record_lineage(
        self,
        task_id: str,
        inputs: list[str],
        outputs: list[str],
        agent: str = "",
        operation: str = "",
    ) -> str | None:
        """Record an artifact lineage edge."""
        lineage = self._get_lineage()
        if lineage is None:
            return None
        return lineage.record_transformation(
            task_id=task_id,
            inputs=inputs,
            outputs=outputs,
            agent=agent,
            operation=operation,
        )

    def get_provenance(self, artifact_id: str) -> Any:
        """Get provenance chain for an artifact."""
        lineage = self._get_lineage()
        if lineage is None:
            return None
        return lineage.provenance(artifact_id)

    def get_impact(self, artifact_id: str) -> Any:
        """Get downstream impact report for an artifact."""
        lineage = self._get_lineage()
        if lineage is None:
            return None
        return lineage.impact(artifact_id)
