"""Ontology meta-primitives for the dharma_swarm ontology spine.

The 7 meta-primitives converge across BFO/IOF formal ontology,
Palantir/Celonis/Siemens/Anduril/SAP industrial practice, and
Jain metaphysical categories.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from dharma_swarm.ontology import OntologyRegistry


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class MetaPrimitive(str, Enum):
    """Irreducible ontology categories that shape the spine."""

    ENTITY = "ENTITY"
    EVENT = "EVENT"
    RELATIONSHIP = "RELATIONSHIP"
    PROPERTY = "PROPERTY"
    ACTION = "ACTION"
    CAPABILITY = "CAPABILITY"
    COMPOSITION = "COMPOSITION"


class QualifiedRelationship(BaseModel):
    """Link-like relationship metadata with role qualification."""

    name: str
    source_type: str
    target_type: str
    cardinality: str = "N:1"
    required: bool = False
    inverse_name: str = ""
    description: str = ""
    qualifier: str = ""
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


class TemporalPropertyValue(BaseModel):
    """A property value with an explicit validity window."""

    property_name: str
    value: Any
    valid_from: datetime
    valid_until: datetime | None = None

    def is_active(self, at: datetime | None = None) -> bool:
        moment = at or _utc_now()
        if moment < self.valid_from:
            return False
        if self.valid_until is not None and moment > self.valid_until:
            return False
        return True


class DelegationEntry(BaseModel):
    """One delegation hop in an ownership chain."""

    agent_id: str
    delegated_at: datetime = Field(default_factory=_utc_now)


class OwnerChain(BaseModel):
    """Tracks delegation from root owner to current owner."""

    chain: list[DelegationEntry] = Field(default_factory=list)

    @property
    def root_owner(self) -> str | None:
        if not self.chain:
            return None
        return self.chain[0].agent_id

    @property
    def current_owner(self) -> str | None:
        if not self.chain:
            return None
        return self.chain[-1].agent_id

    def delegate(self, agent_id: str) -> DelegationEntry:
        entry = DelegationEntry(agent_id=agent_id)
        self.chain.append(entry)
        return entry


class SemanticTag(BaseModel):
    """External semantic pointer attached to an ontology element."""

    tag_namespace: str
    tag_key: str
    tag_value: str
    uri: str = ""

    def __str__(self) -> str:
        core = f"{self.tag_namespace}:{self.tag_key}={self.tag_value}"
        if self.uri:
            return f"{core}|{self.uri}"
        return core

    @classmethod
    def from_string(cls, raw: str) -> "SemanticTag":
        core, _, uri = raw.partition("|")
        namespace_key, _, value = core.partition("=")
        namespace, _, key = namespace_key.partition(":")
        return cls(
            tag_namespace=namespace,
            tag_key=key,
            tag_value=value,
            uri=uri,
        )


def classify_types(registry: "OntologyRegistry") -> dict[MetaPrimitive, list[str]]:
    """Group registered ObjectTypes by meta-primitive."""

    grouped: dict[MetaPrimitive, list[str]] = {
        primitive: [] for primitive in MetaPrimitive
    }
    for obj_type in registry.get_types():
        meta_raw = getattr(obj_type, "meta_type", MetaPrimitive.ENTITY)
        meta_type = meta_raw if isinstance(meta_raw, MetaPrimitive) else MetaPrimitive(str(meta_raw))
        grouped[meta_type].append(obj_type.name)
    for names in grouped.values():
        names.sort()
    return grouped


def validate_meta_coverage(registry: "OntologyRegistry") -> list[str]:
    """Return registered types that are missing a valid meta-primitive."""

    missing: list[str] = []
    for obj_type in registry.get_types():
        meta_raw = getattr(obj_type, "meta_type", None)
        try:
            if meta_raw is None:
                raise ValueError("missing")
            MetaPrimitive(meta_raw)
        except (TypeError, ValueError):
            missing.append(obj_type.name)
    return sorted(missing)


__all__ = [
    "DelegationEntry",
    "MetaPrimitive",
    "OwnerChain",
    "QualifiedRelationship",
    "SemanticTag",
    "TemporalPropertyValue",
    "classify_types",
    "validate_meta_coverage",
]
