"""Compatibility shims for extracted dharmic operator commands."""

from __future__ import annotations


def cmd_forge(
    path: str | None = None,
    batch: str | None = None,
    *,
    plan: bool = False,
    run: bool = False,
    status: bool = False,
    receipt: bool = False,
    state_dir: str | None = None,
    run_id: str | None = None,
    deficit_id: str | None = None,
    title: str | None = None,
    deficit_class: str = "failing_test",
    summary: str = "",
    file_refs: list[str] | None = None,
    test_refs: list[str] | None = None,
    changed_files: list[str] | None = None,
    dry_run: bool = False,
    **_: object,
) -> None:
    """Forward-compatible forge shim routed through the legacy CLI."""
    from dharma_swarm import dgc_cli

    kwargs: dict[str, object] = {
        "path": path,
        "batch": batch,
    }
    if plan:
        kwargs["plan"] = plan
    if run:
        kwargs["run"] = run
    if status:
        kwargs["status"] = status
    if receipt:
        kwargs["receipt"] = receipt
    if state_dir is not None:
        kwargs["state_dir"] = state_dir
    if run_id is not None:
        kwargs["run_id"] = run_id
    if deficit_id is not None:
        kwargs["deficit_id"] = deficit_id
    if title is not None:
        kwargs["title"] = title
    if deficit_class != "failing_test":
        kwargs["deficit_class"] = deficit_class
    if summary:
        kwargs["summary"] = summary
    if file_refs is not None:
        kwargs["file_refs"] = file_refs
    if test_refs is not None:
        kwargs["test_refs"] = test_refs
    if changed_files is not None:
        kwargs["changed_files"] = changed_files
    if dry_run:
        kwargs["dry_run"] = dry_run

    dgc_cli.cmd_forge(**kwargs)
