"""Runtime-facing command shims used by the modular DGC surface."""

from __future__ import annotations

import asyncio
import os
import subprocess
import sys
from pathlib import Path


def _legacy_cli():
    from dharma_swarm import dgc_cli

    return dgc_cli


def _live_pid(pid_path: Path) -> int | None:
    try:
        pid = int(pid_path.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)
        return pid
    except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, OSError):
        return None


def _discover_process_id(pattern: str) -> int | None:
    cli = _legacy_cli()
    try:
        result = cli.subprocess.run(
            ["ps", "ax", "-o", "pid=,command="],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return None

    for line in result.stdout.splitlines():
        if pattern not in line:
            continue
        pid_text = line.strip().split(maxsplit=1)[0]
        try:
            return int(pid_text)
        except ValueError:
            return None
    return None


def cmd_pulse() -> None:
    """Best-effort pulse shim."""
    print("Pulse command is available through the legacy runtime surface.")


def cmd_orchestrate_live(background: bool = False) -> None:
    """Start or report the live orchestrator process."""
    cli = _legacy_cli()

    daemon_pid = _live_pid(cli.DHARMA_STATE / "daemon.pid")
    if daemon_pid is not None:
        print(f"Orchestrator already running (daemon PID {daemon_pid})")
        return

    existing_pid = _discover_process_id("dharma_swarm.orchestrate_live")
    if existing_pid is not None:
        print(f"Orchestrator already running (PID {existing_pid})")
        return

    if background:
        subprocess.Popen(
            [sys.executable, "-m", "dharma_swarm.orchestrate_live", "--background"],
            cwd=str(cli.DHARMA_SWARM),
        )
        print("Orchestrator launched in background.")
        return

    async def _noop() -> None:
        print("Orchestrator launch requested.")

    asyncio.run(_noop())


def cmd_up(background: bool = False) -> None:
    """Start or report the canonical daemon process."""
    cli = _legacy_cli()

    daemon_pid = _live_pid(cli.DHARMA_STATE / "daemon.pid")
    if daemon_pid is not None:
        print(f"Daemon already running (PID {daemon_pid})")
        return

    existing_pid = _discover_process_id("run_daemon.sh")
    if existing_pid is not None:
        print(f"Daemon already running (PID {existing_pid})")
        return

    command = [str(cli.DHARMA_SWARM / "run_daemon.sh")]
    if background:
        subprocess.Popen(command, cwd=str(cli.DHARMA_SWARM))
        print("Daemon launched in background.")
        return

    subprocess.run(command, cwd=str(cli.DHARMA_SWARM), check=False)


def cmd_down() -> None:
    """Best-effort daemon stop shim."""
    cli = _legacy_cli()
    daemon_pid = _live_pid(cli.DHARMA_STATE / "daemon.pid")
    if daemon_pid is None:
        print("Daemon not running.")
        return
    try:
        os.kill(daemon_pid, 15)
        print(f"Sent SIGTERM to daemon PID {daemon_pid}.")
    except OSError as exc:
        print(f"Failed to stop daemon PID {daemon_pid}: {exc}")


def cmd_daemon_status() -> None:
    """Render canonical daemon state using the legacy pulse summary helper."""
    cli = _legacy_cli()
    daemon_pid = _live_pid(cli.DHARMA_STATE / "daemon.pid")
    if daemon_pid is None:
        print("Daemon status: not running")
    else:
        print(f"Daemon status: running (PID {daemon_pid})")

    pulse_count, last_pulse, pulse_source = cli._canonical_pulse_summary()
    if last_pulse:
        source_text = f" via {pulse_source}" if pulse_source is not None else ""
        print(f"Last pulse: {last_pulse}{source_text}")
        print(f"Pulse count: {pulse_count}")
    else:
        print("Last pulse: unavailable")
