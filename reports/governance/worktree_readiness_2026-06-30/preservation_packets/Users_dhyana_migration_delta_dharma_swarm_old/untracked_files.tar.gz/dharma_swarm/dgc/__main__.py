"""python -m dharma_swarm.dgc entrypoint."""

from .main import main


if __name__ == "__main__":
    main()
