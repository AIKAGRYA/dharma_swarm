"""Compatibility dispatcher for the modular DGC package."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Sequence


def _legacy_cli():
    from dharma_swarm import dgc_cli

    return dgc_cli


def main() -> None:
    """Package entrypoint forwarding to the legacy CLI."""
    from dharma_swarm.dgc_cli import main as legacy_main

    legacy_main()


@dataclass
class _Registry:
    def populate_subparsers(self, sub: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
        _add_parse_surface(sub)


def _build_registry() -> _Registry:
    return _Registry()


def _add_parse_surface(sub: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    dharma = sub.add_parser("dharma")
    dharma_sub = dharma.add_subparsers(dest="dharma_cmd")
    dharma_sub.add_parser("status")
    corpus = dharma_sub.add_parser("corpus")
    corpus.add_argument("--status", dest="corpus_status")
    corpus.add_argument("--category", dest="corpus_category")
    review = dharma_sub.add_parser("review")
    review.add_argument("claim_id")

    evolve = sub.add_parser("evolve")
    evolve_sub = evolve.add_subparsers(dest="evolve_cmd")
    apply_parser = evolve_sub.add_parser("apply")
    apply_parser.add_argument("component")
    apply_parser.add_argument("description")
    promote = evolve_sub.add_parser("promote")
    promote.add_argument("entry_id")
    rollback = evolve_sub.add_parser("rollback")
    rollback.add_argument("entry_id")
    rollback.add_argument("--reason", default="")

    stigmergy = sub.add_parser("stigmergy")
    stigmergy.add_argument("--file", dest="stig_file")

    sub.add_parser("hum")

    free_fleet = sub.add_parser("free-fleet")
    free_fleet.add_argument("--tier", type=int)
    free_fleet.add_argument("--json", action="store_true", dest="json")
    free_fleet.add_argument("--set-env", action="store_true", dest="set_env")

    model_catalog = sub.add_parser("model-catalog")
    model_catalog.add_argument("selector", nargs="?")
    model_catalog.add_argument("--json", action="store_true", dest="json")

    status = sub.add_parser("status")
    status.set_defaults(command="status")

    health = sub.add_parser("health")
    health.set_defaults(command="health")

    memory = sub.add_parser("memory")
    memory.set_defaults(command="memory")

    daemon_status = sub.add_parser("daemon-status")
    daemon_status.set_defaults(command="daemon-status")

    canonical_status = sub.add_parser("canonical-status")
    canonical_status.add_argument("--json", action="store_true", dest="json")


def _dispatch_known_command(argv: Sequence[str]) -> bool:
    if not argv:
        return False

    command = argv[0]
    cli = _legacy_cli()

    if command == "status":
        _invoke(cli.cmd_status)
        return True

    if command == "runtime-status":
        parser = argparse.ArgumentParser(prog="dgc runtime-status", add_help=False)
        parser.add_argument("--limit", type=int, default=5)
        parser.add_argument("--db-path")
        args = parser.parse_args(list(argv[1:]))
        _invoke(cli.cmd_runtime_status, limit=args.limit, db_path=args.db_path)
        return True

    if command == "mission-status":
        parser = argparse.ArgumentParser(prog="dgc mission-status", add_help=False)
        parser.add_argument("--json", action="store_true", dest="as_json")
        parser.add_argument("--strict-core", action="store_true")
        parser.add_argument("--require-tracked", action="store_true")
        parser.add_argument("--profile")
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_mission_status,
            as_json=args.as_json,
            strict_core=args.strict_core,
            require_tracked=args.require_tracked,
            profile=args.profile,
        )
        return True

    if command == "mission-brief":
        parser = argparse.ArgumentParser(prog="dgc mission-brief", add_help=False)
        parser.add_argument("--path")
        parser.add_argument("--state-dir")
        parser.add_argument("--json", action="store_true", dest="as_json")
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_mission_brief,
            path=args.path,
            state_dir=args.state_dir,
            as_json=args.as_json,
        )
        return True

    if command == "campaign-brief":
        parser = argparse.ArgumentParser(prog="dgc campaign-brief", add_help=False)
        parser.add_argument("--path")
        parser.add_argument("--state-dir")
        parser.add_argument("--json", action="store_true", dest="as_json")
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_campaign_brief,
            path=args.path,
            state_dir=args.state_dir,
            as_json=args.as_json,
        )
        return True

    if command == "canonical-status":
        parser = argparse.ArgumentParser(prog="dgc canonical-status", add_help=False)
        parser.add_argument("--json", action="store_true", dest="as_json")
        args = parser.parse_args(list(argv[1:]))
        _invoke(cli.cmd_canonical_status, as_json=args.as_json)
        return True

    if command == "health":
        _invoke(cli.cmd_health)
        return True

    if command == "memory":
        _invoke(cli.cmd_memory)
        return True

    if command == "daemon-status":
        _invoke(cli.cmd_daemon_status)
        return True

    if command == "chat":
        parser = argparse.ArgumentParser(prog="dgc chat", add_help=False)
        parser.add_argument("--continue", action="store_true", dest="continue_last")
        parser.add_argument("--offline", action="store_true")
        parser.add_argument("--model")
        parser.add_argument("--effort")
        parser.add_argument("--no-context", action="store_false", dest="include_context")
        parser.set_defaults(include_context=True)
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_chat,
            continue_last=args.continue_last,
            offline=args.offline,
            model=args.model,
            effort=args.effort,
            include_context=args.include_context,
        )
        return True

    if command in {"dashboard", "tui"}:
        _invoke(cli.cmd_tui)
        return True

    if command == "ui":
        parser = argparse.ArgumentParser(prog="dgc ui", add_help=False)
        parser.add_argument("surface", nargs="?", default="list")
        args = parser.parse_args(list(argv[1:]))
        _invoke(cli.cmd_ui, args.surface)
        return True

    if command == "doctor":
        parser = argparse.ArgumentParser(prog="dgc doctor", add_help=False)
        sub = parser.add_subparsers(dest="doctor_cmd")
        schedule = sub.add_parser("schedule")
        schedule.add_argument("--schedule", default="every 6h")
        schedule.add_argument("--quick", action="store_true")
        watch = sub.add_parser("watch")
        watch.add_argument("--interval-sec", type=float, default=1800.0)
        watch.add_argument("--max-runs", type=int)
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_doctor,
            doctor_cmd=args.doctor_cmd or "run",
            schedule=getattr(args, "schedule", "every 6h"),
            quick=getattr(args, "quick", False),
            interval_sec=getattr(args, "interval_sec", 1800.0),
            max_runs=getattr(args, "max_runs", None),
        )
        return True

    if command == "pulse":
        _invoke(cli.cmd_pulse)
        return True

    if command == "semantic":
        return _dispatch_semantic(argv[1:])

    if command == "cron":
        return _dispatch_cron(argv[1:])

    if command == "rag":
        return _dispatch_rag(argv[1:])

    if command == "flywheel":
        return _dispatch_flywheel(argv[1:])

    if command == "reciprocity":
        return _dispatch_reciprocity(argv[1:])

    if command == "ouroboros":
        return _dispatch_ouroboros(argv[1:])

    if command == "xray":
        parser = argparse.ArgumentParser(prog="dgc xray", add_help=False)
        parser.add_argument("repo_path")
        parser.add_argument("--output")
        parser.add_argument("--json", action="store_true", dest="as_json")
        parser.add_argument("--exclude", action="append")
        parser.add_argument("--packet", action="store_true")
        parser.add_argument("--buyer", default="CTO or founder under shipping pressure")
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_xray,
            repo_path=args.repo_path,
            output=args.output,
            as_json=args.as_json,
            exclude=args.exclude,
            packet=args.packet,
            buyer=args.buyer,
        )
        return True

    if command == "ledger":
        parser = argparse.ArgumentParser(prog="dgc ledger", add_help=False)
        sub = parser.add_subparsers(dest="ledger_cmd")
        search = sub.add_parser("search")
        search.add_argument("query_terms", nargs="+")
        search.add_argument("--session")
        search.add_argument("--kind", default="all")
        search.add_argument("--db-path")
        search.add_argument("--no-sync-ledgers", action="store_false", dest="sync_ledgers")
        search.add_argument("--limit-sessions", type=int)
        search.add_argument("-n", type=int, default=20)
        search.set_defaults(sync_ledgers=True)
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_ledger,
            ledger_cmd=args.ledger_cmd,
            n=getattr(args, "n", 20),
            session=getattr(args, "session", None),
            kind=getattr(args, "kind", "all"),
            query=" ".join(getattr(args, "query_terms", [])),
            db_path=getattr(args, "db_path", None),
            sync_ledgers=getattr(args, "sync_ledgers", True),
            limit_sessions=getattr(args, "limit_sessions", None),
        )
        return True

    if command == "forge":
        parser = argparse.ArgumentParser(prog="dgc forge", add_help=False)
        parser.add_argument("path", nargs="?")
        parser.add_argument("--batch")
        parser.add_argument("--plan", action="store_true")
        parser.add_argument("--run", action="store_true")
        parser.add_argument("--status", action="store_true")
        parser.add_argument("--receipt", action="store_true")
        parser.add_argument("--state-dir")
        parser.add_argument("--run-id")
        parser.add_argument("--deficit-id")
        parser.add_argument("--title")
        parser.add_argument("--deficit-class", default="failing_test")
        parser.add_argument("--summary", default="")
        parser.add_argument("--file-ref", action="append", dest="file_refs")
        parser.add_argument("--test-ref", action="append", dest="test_refs")
        parser.add_argument("--changed-file", action="append", dest="changed_files")
        parser.add_argument("--dry-run", action="store_true")
        args = parser.parse_args(list(argv[1:]))
        from dharma_swarm.dgc.commands import dharma_ops

        _invoke(
            dharma_ops.cmd_forge,
            path=args.path,
            batch=args.batch,
            plan=args.plan,
            run=args.run,
            status=args.status,
            receipt=args.receipt,
            state_dir=args.state_dir,
            run_id=args.run_id,
            deficit_id=args.deficit_id,
            title=args.title,
            deficit_class=args.deficit_class,
            summary=args.summary,
            file_refs=args.file_refs or [],
            test_refs=args.test_refs or [],
            changed_files=args.changed_files or [],
            dry_run=args.dry_run,
        )
        return True

    if command == "stress":
        parser = argparse.ArgumentParser(prog="dgc stress", add_help=False)
        parser.add_argument("--profile", default="quick")
        parser.add_argument("--state-dir", default=str(_legacy_cli().DHARMA_STATE))
        parser.add_argument("--provider-mode", default="mock")
        parser.add_argument("--agents", type=int, default=2)
        parser.add_argument("--tasks", type=int, default=2)
        parser.add_argument("--evolutions", type=int, default=2)
        parser.add_argument("--evolution-concurrency", type=int, default=1)
        parser.add_argument("--cli-rounds", type=int, default=1)
        parser.add_argument("--cli-concurrency", type=int, default=1)
        parser.add_argument("--orchestration-timeout-sec", type=int, default=120)
        parser.add_argument("--external-research", action="store_true")
        parser.add_argument("--external-timeout-sec", type=int, default=120)
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_stress,
            profile=args.profile,
            state_dir=args.state_dir,
            provider_mode=args.provider_mode,
            agents=args.agents,
            tasks=args.tasks,
            evolutions=args.evolutions,
            evolution_concurrency=args.evolution_concurrency,
            cli_rounds=args.cli_rounds,
            cli_concurrency=args.cli_concurrency,
            orchestration_timeout_sec=args.orchestration_timeout_sec,
            external_research=args.external_research,
            external_timeout_sec=args.external_timeout_sec,
        )
        return True

    if command == "provider-matrix":
        parser = argparse.ArgumentParser(prog="dgc provider-matrix", add_help=False)
        parser.add_argument("--profile", default="quick")
        parser.add_argument("--corpus", default="deployment")
        parser.add_argument("--max-targets", type=int)
        parser.add_argument("--max-prompts", type=int)
        parser.add_argument("--timeout-seconds", type=float, default=20.0)
        parser.add_argument("--concurrency", type=int, default=4)
        parser.add_argument("--budget-units", type=int)
        parser.add_argument("--artifact-dir")
        parser.add_argument("--include-unavailable", action="store_true")
        parser.add_argument("--write-artifacts", action="store_true")
        parser.add_argument("--json", action="store_true", dest="as_json")
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_provider_matrix,
            profile=args.profile,
            corpus=args.corpus,
            max_targets=args.max_targets,
            max_prompts=args.max_prompts,
            timeout_seconds=args.timeout_seconds,
            concurrency=args.concurrency,
            budget_units=args.budget_units,
            artifact_dir=args.artifact_dir,
            include_unavailable=args.include_unavailable,
            write_artifacts=args.write_artifacts,
            as_json=args.as_json,
        )
        return True

    if command == "full-power-probe":
        parser = argparse.ArgumentParser(prog="dgc full-power-probe", add_help=False)
        parser.add_argument("--route-task", default="Route a representative task.")
        parser.add_argument("--context-search-query", default="system health")
        parser.add_argument("--compose-task", default="Compose a brief.")
        parser.add_argument("--autonomy-action", default="Approve a safe action.")
        parser.add_argument("--skip-sprint-probe", action="store_true")
        parser.add_argument("--skip-stress", action="store_true")
        parser.add_argument("--skip-pytest", action="store_true")
        args = parser.parse_args(list(argv[1:]))
        _invoke(
            cli.cmd_full_power_probe,
            route_task=args.route_task,
            context_search_query=args.context_search_query,
            compose_task=args.compose_task,
            autonomy_action=args.autonomy_action,
            skip_sprint_probe=args.skip_sprint_probe,
            skip_stress=args.skip_stress,
            skip_pytest=args.skip_pytest,
        )
        return True

    return False


def _dispatch_semantic(argv: Sequence[str]) -> bool:
    cli = _legacy_cli()
    parser = argparse.ArgumentParser(prog="dgc semantic", add_help=False)
    sub = parser.add_subparsers(dest="semantic_cmd")
    ingest = sub.add_parser("ingest")
    ingest_sub = ingest.add_subparsers(dest="ingest_cmd")

    for name in ("status", "register-defaults", "bootstrap"):
        simple = ingest_sub.add_parser(name)
        simple.add_argument("--state-dir")

    search = ingest_sub.add_parser("search")
    search.add_argument("query_terms", nargs="+")
    search.add_argument("--limit", type=int, default=10)
    search.add_argument("--state-dir")

    args = parser.parse_args(list(argv))
    if args.semantic_cmd != "ingest":
        return False

    kwargs = {
        "state_dir": getattr(args, "state_dir", None),
    }
    if args.ingest_cmd == "search":
        kwargs["query"] = " ".join(args.query_terms)
        kwargs["limit"] = args.limit
    _invoke(cli.cmd_semantic_ingest, args.ingest_cmd, **kwargs)
    return True


def _dispatch_cron(argv: Sequence[str]) -> bool:
    cli = _legacy_cli()
    parser = argparse.ArgumentParser(prog="dgc cron", add_help=False)
    sub = parser.add_subparsers(dest="cron_cmd")
    sub.add_parser("tick")
    daemon = sub.add_parser("daemon")
    daemon.add_argument("--interval-sec", type=float, default=60.0)
    daemon.add_argument("--max-loops", type=int)
    daemon.add_argument("--no-run-immediately", action="store_false", dest="run_immediately")
    daemon.set_defaults(run_immediately=True)
    args = parser.parse_args(list(argv))
    _invoke(
        cli.cmd_cron,
        cron_cmd=args.cron_cmd,
        interval_sec=getattr(args, "interval_sec", 60.0),
        max_loops=getattr(args, "max_loops", None),
        run_immediately=getattr(args, "run_immediately", True),
    )
    return True


def _dispatch_rag(argv: Sequence[str]) -> bool:
    cli = _legacy_cli()
    parser = argparse.ArgumentParser(prog="dgc rag", add_help=False)
    sub = parser.add_subparsers(dest="rag_cmd")
    health = sub.add_parser("health")
    health.add_argument("--service", default="rag")
    health.add_argument("--no-check-dependencies", action="store_false", dest="check_dependencies")
    health.set_defaults(check_dependencies=True)
    search = sub.add_parser("search")
    search.add_argument("query")
    search.add_argument("--top-k", type=int, default=5)
    search.add_argument("--collection")
    chat = sub.add_parser("chat")
    chat.add_argument("prompt")
    chat.add_argument("--model")
    args = parser.parse_args(list(argv))

    try:
        match args.rag_cmd:
            case "health":
                _invoke(cli.cmd_rag_health, service=args.service, check_dependencies=args.check_dependencies)
            case "search":
                _invoke(cli.cmd_rag_search, query=args.query, top_k=args.top_k, collection=args.collection)
            case "chat":
                _invoke(cli.cmd_rag_chat, prompt=args.prompt, model=args.model)
            case _:
                return False
    except SystemExit:
        raise
    except Exception as exc:
        print(f"RAG command failed: {exc}")
        raise SystemExit(2) from exc
    return True


def _dispatch_flywheel(argv: Sequence[str]) -> bool:
    cli = _legacy_cli()
    parser = argparse.ArgumentParser(prog="dgc flywheel", add_help=False)
    sub = parser.add_subparsers(dest="flywheel_cmd")
    sub.add_parser("jobs")

    start = sub.add_parser("start")
    start.add_argument("--workload-id", required=True)
    start.add_argument("--client-id", required=True)
    start.add_argument("--eval-size", type=int, default=200)
    start.add_argument("--val-ratio", type=float, default=0.2)
    start.add_argument("--min-total-records", type=int, default=1000)
    start.add_argument("--limit", type=int, default=1000)
    start.add_argument("--run-id")
    start.add_argument("--trace-id")
    start.add_argument("--db-path")
    start.add_argument("--event-log-dir")
    start.add_argument("--export-root")

    export = sub.add_parser("export")
    export.add_argument("--run-id", required=True)
    export.add_argument("--workload-id", required=True)
    export.add_argument("--client-id", required=True)
    export.add_argument("--trace-id")
    export.add_argument("--db-path")
    export.add_argument("--event-log-dir")
    export.add_argument("--export-root")

    record = sub.add_parser("record")
    record.add_argument("job_id")
    record.add_argument("--workload-id")
    record.add_argument("--client-id")
    record.add_argument("--run-id")
    record.add_argument("--session-id")
    record.add_argument("--task-id")
    record.add_argument("--trace-id")
    record.add_argument("--db-path")
    record.add_argument("--event-log-dir")
    record.add_argument("--workspace-root")
    record.add_argument("--provenance-root")

    args = parser.parse_args(list(argv))
    try:
        match args.flywheel_cmd:
            case "jobs":
                _invoke(cli.cmd_flywheel_jobs)
            case "start":
                _invoke(
                    cli.cmd_flywheel_start,
                    workload_id=args.workload_id,
                    client_id=args.client_id,
                    eval_size=args.eval_size,
                    val_ratio=args.val_ratio,
                    min_total_records=args.min_total_records,
                    limit=args.limit,
                    run_id=args.run_id,
                    trace_id=args.trace_id,
                    db_path=args.db_path,
                    event_log_dir=args.event_log_dir,
                    export_root=args.export_root,
                )
            case "export":
                _invoke(
                    cli.cmd_flywheel_export,
                    run_id=args.run_id,
                    workload_id=args.workload_id,
                    client_id=args.client_id,
                    trace_id=args.trace_id,
                    db_path=args.db_path,
                    event_log_dir=args.event_log_dir,
                    export_root=args.export_root,
                )
            case "record":
                _invoke(
                    cli.cmd_flywheel_record,
                    job_id=args.job_id,
                    workload_id=args.workload_id,
                    client_id=args.client_id,
                    run_id=args.run_id,
                    session_id=args.session_id,
                    task_id=args.task_id,
                    trace_id=args.trace_id,
                    db_path=args.db_path,
                    event_log_dir=args.event_log_dir,
                    workspace_root=args.workspace_root,
                    provenance_root=args.provenance_root,
                )
            case _:
                return False
    except SystemExit:
        raise
    except Exception as exc:
        print(f"Flywheel command failed: {exc}")
        raise SystemExit(2) from exc
    return True


def _dispatch_reciprocity(argv: Sequence[str]) -> bool:
    cli = _legacy_cli()
    parser = argparse.ArgumentParser(prog="dgc reciprocity", add_help=False)
    sub = parser.add_subparsers(dest="reciprocity_cmd")
    sub.add_parser("health")
    sub.add_parser("summary")

    record = sub.add_parser("record")
    record.add_argument("--run-id")
    record.add_argument("--session-id")
    record.add_argument("--task-id")
    record.add_argument("--trace-id")
    record.add_argument("--summary-type", default="ledger_summary")
    record.add_argument("--json", dest="json_payload")
    record.add_argument("--file", dest="file_path")
    record.add_argument("--db-path")
    record.add_argument("--event-log-dir")
    record.add_argument("--workspace-root")
    record.add_argument("--provenance-root")

    publish = sub.add_parser("publish")
    publish.add_argument("record_type")
    publish.add_argument("--json", dest="json_payload")
    publish.add_argument("--file", dest="file_path")

    args = parser.parse_args(list(argv))
    try:
        match args.reciprocity_cmd:
            case "health":
                _invoke(cli.cmd_reciprocity_health)
            case "summary":
                _invoke(cli.cmd_reciprocity_summary)
            case "record":
                _invoke(
                    cli.cmd_reciprocity_record,
                    run_id=args.run_id,
                    session_id=args.session_id,
                    task_id=args.task_id,
                    trace_id=args.trace_id,
                    summary_type=args.summary_type,
                    json_payload=args.json_payload,
                    file_path=args.file_path,
                    db_path=args.db_path,
                    event_log_dir=args.event_log_dir,
                    workspace_root=args.workspace_root,
                    provenance_root=args.provenance_root,
                )
            case "publish":
                _invoke(
                    cli.cmd_reciprocity_publish,
                    record_type=args.record_type,
                    json_payload=args.json_payload,
                    file_path=args.file_path,
                )
            case _:
                return False
    except SystemExit:
        raise
    except Exception as exc:
        print(f"Reciprocity command failed: {exc}")
        raise SystemExit(2) from exc
    return True


def _dispatch_ouroboros(argv: Sequence[str]) -> bool:
    cli = _legacy_cli()
    parser = argparse.ArgumentParser(prog="dgc ouroboros", add_help=False)
    sub = parser.add_subparsers(dest="ouroboros_cmd")
    connections = sub.add_parser("connections")
    connections.add_argument("--package-dir")
    connections.add_argument("--threshold", type=float, default=0.08)
    connections.add_argument("--disagreement-threshold", type=float, default=0.1)
    connections.add_argument("--min-text-length", type=int, default=50)
    connections.add_argument("--limit", type=int, default=15)
    connections.add_argument("--json", action="store_true", dest="as_json")

    record = sub.add_parser("record")
    record.add_argument("--run-id")
    record.add_argument("--session-id")
    record.add_argument("--task-id")
    record.add_argument("--trace-id")
    record.add_argument("--log-path")
    record.add_argument("--cycle-id")
    record.add_argument("--json", dest="json_payload")
    record.add_argument("--file", dest="file_path")
    record.add_argument("--db-path")
    record.add_argument("--event-log-dir")
    record.add_argument("--workspace-root")
    record.add_argument("--provenance-root")

    args = parser.parse_args(list(argv))
    try:
        match args.ouroboros_cmd:
            case "connections":
                _invoke(
                    cli.cmd_ouroboros_connections,
                    package_dir=args.package_dir,
                    threshold=args.threshold,
                    disagreement_threshold=args.disagreement_threshold,
                    min_text_length=args.min_text_length,
                    limit=args.limit,
                    as_json=args.as_json,
                )
            case "record":
                _invoke(
                    cli.cmd_ouroboros_record,
                    run_id=args.run_id,
                    session_id=args.session_id,
                    task_id=args.task_id,
                    trace_id=args.trace_id,
                    log_path=args.log_path,
                    cycle_id=args.cycle_id,
                    json_payload=args.json_payload,
                    file_path=args.file_path,
                    db_path=args.db_path,
                    event_log_dir=args.event_log_dir,
                    workspace_root=args.workspace_root,
                    provenance_root=args.provenance_root,
                )
            case _:
                return False
    except SystemExit:
        raise
    except Exception as exc:
        print(f"Ouroboros command failed: {exc}")
        raise SystemExit(2) from exc
    return True


def _invoke(fn, /, *args, **kwargs) -> None:
    result = fn(*args, **kwargs)
    if isinstance(result, int) and result != 0:
        raise SystemExit(result)
