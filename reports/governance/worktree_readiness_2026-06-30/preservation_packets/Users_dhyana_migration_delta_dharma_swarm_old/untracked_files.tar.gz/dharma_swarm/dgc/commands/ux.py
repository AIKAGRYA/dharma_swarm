"""UX-facing command shims for the modular DGC package."""

from __future__ import annotations

from pathlib import Path


def _build_chat_context_snapshot(
    *,
    state_dir: str | Path,
    home: str | Path,
) -> str:
    """Build a concise operator chat snapshot from canonical context sources."""
    from dharma_swarm.context import read_latent_gold_overview, read_memory_context

    state_root = Path(state_dir).expanduser()
    home_path = Path(home).expanduser()

    memory_text = read_memory_context(
        state_dir=state_root,
        home=home_path,
    ).strip()
    latent_text = read_latent_gold_overview(
        state_dir=state_root,
        limit=5,
    ).strip()

    lines: list[str] = ["Recent memory:"]
    lines.append(memory_text if memory_text else "  (none)")
    lines.append("")
    lines.append("Latent gold:")
    lines.append(latent_text if latent_text else "  (none)")
    return "\n".join(lines)


def cmd_tui() -> None:
    """Print the canonical operator endpoints when the rich TUI is unavailable."""
    print("DGC operator surfaces:")
    print("  SwarmLens: http://127.0.0.1:8080")
    print("  Next dashboard: http://127.0.0.1:3000/dashboard")


def cmd_ui(surface: str = "list") -> None:
    """Print the operator surface map."""
    normalized = (surface or "list").strip().lower()
    if normalized == "lens":
        print("SwarmLens: http://127.0.0.1:8080")
        return
    if normalized == "dashboard":
        print("Next dashboard: http://127.0.0.1:3000/dashboard")
        return

    print("Canonical operator surfaces:")
    print("  SwarmLens: http://127.0.0.1:8080")
    print("  Next dashboard: http://127.0.0.1:3000/dashboard")


def cmd_chat(
    *,
    continue_last: bool = False,
    offline: bool = False,
    model: str | None = None,
    effort: str | None = None,
    include_context: bool = True,
) -> None:
    """Best-effort native chat shim."""
    from dharma_swarm import dgc_cli

    print("DGC chat")
    print(f"  continue_last={continue_last}")
    print(f"  offline={offline}")
    if model:
        print(f"  model={model}")
    if effort:
        print(f"  effort={effort}")
    if include_context:
        print("")
        print(
            _build_chat_context_snapshot(
                state_dir=dgc_cli.DHARMA_STATE,
                home=dgc_cli.HOME,
            )
        )
