"""Compatibility package for the modular DGC CLI surface."""

from .main import main

__all__ = ["main"]
