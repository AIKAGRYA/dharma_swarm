"""Lightweight runtime context for the modular DGC surface."""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path


@dataclass(frozen=True)
class DGCContext:
    home: Path
    repo_root: Path
    state_root: Path
    legacy_core_root: Path
    env: dict[str, str]


def _read_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}

    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def build_context(
    *,
    home: str | Path | None = None,
    env: dict[str, str] | None = None,
) -> DGCContext:
    """Resolve canonical DGC paths and merged env without mutating process env."""
    home_path = Path(home).expanduser() if home is not None else Path.home()
    repo_root = home_path / "dharma_swarm"
    state_root = home_path / ".dharma"
    legacy_core_root = home_path / "dgc-core"

    merged_env = dict(os.environ)
    merged_env.update(_read_env_file(repo_root / ".env"))
    merged_env.update(_read_env_file(state_root / "env" / "nvidia_remote.env"))
    merged_env.update(dict(env or {}))

    return DGCContext(
        home=home_path,
        repo_root=repo_root,
        state_root=state_root,
        legacy_core_root=legacy_core_root,
        env=merged_env,
    )
