# LangGraph Parity Operator Runbook

This harness is deterministic and local. It proves the control semantics for
LangGraph-style swarm and supervisor modes without invoking paid providers.

## Swarm Mode

```bash
./.venv/bin/python -m pytest -q tests/test_langgraph_parity_swarm.py --tb=short
```

Covered: default active agent, persisted `active_agent`, `transfer_to_<agent>`
handoff tools, next-turn resume, direct active subagent response, transfer back,
invalid transfer rejection, and checkpoint reload.

## Supervisor Mode

```bash
./.venv/bin/python -m pytest -q tests/test_langgraph_parity_supervisor.py --tb=short
```

Covered: supervisor entry, delegation to subagents, subagent return to
supervisor, supervisor-only final visibility, exact `forward_message`
behavior, handoff-message suppression, and `output_mode` history control.

## Isolation And Benchmark

```bash
./.venv/bin/python -m pytest -q tests/test_langgraph_parity_isolation_benchmark.py --tb=short

./.venv/bin/python -m dharma_swarm.langgraph_parity.benchmark \
  --output-dir reports/langgraph_parity/benchmark \
  --mission-id langgraph-swarm-supervisor-parity-to-10-10
```

The benchmark command records canonical runtime claim, run, artifact, receipt,
and idempotency records by default. Use `--runtime-db <path>` for an isolated
runtime store during verification, or `--no-runtime-receipt` only when
intentionally generating artifacts without runtime truth evidence.

Artifacts:

- `reports/langgraph_parity/benchmark/benchmark_report.json`
- `reports/langgraph_parity/benchmark/benchmark_report.md`
- `reports/langgraph_parity/benchmark/benchmark_receipt.json`
- `/Users/dhyana/.dharma/state/runtime.db` receipt `rr_langgraph_parity_benchmark_250ea999acb52eb2`
- `/Users/dhyana/.dharma/state/runtime.db` run `run_langgraph_parity_benchmark_250ea999acb52eb2`

## Readiness Probes

```bash
make onboard
./.venv/bin/python scripts/runtime/live_ops_census.py --write
./.venv/bin/python scripts/governance/runtime_receipt_coverage_report.py --json
./.venv/bin/python scripts/governance/spine_dispatch_mode_report.py --json
./.venv/bin/python scripts/governance/check_a2a_readiness.py

./.venv/bin/python -m dharma_swarm.langgraph_parity.readiness \
  --output-dir reports/langgraph_parity/readiness
```

Current mission status is not 10/10 until runtime receipt coverage and A2A
readiness are green. When A2A is degraded, inspect `blocker_task_ids` and
`blocker_task_id_coverage_complete` in the JSON output; every remaining queue
blocker should have an explicit task ID before treating the degraded state as
actionable.

Readiness artifacts:

- `reports/langgraph_parity/readiness/mission_readiness_report.json`
- `reports/langgraph_parity/readiness/mission_readiness_report.md`

The readiness command exits zero by default even when the mission is red so it
can be used as a ledger generator. Add `--strict` when a CI or release gate
should fail unless every A-E gate is green.
