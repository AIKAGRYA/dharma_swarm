# LangGraph Parity Mission Report

Date: 2026-06-30
Mission id: `langgraph-swarm-supervisor-parity-to-10-10`

## Overall Score

| Category | Status | Evidence |
| --- | --- | --- |
| A. Swarm parity | GREEN local harness | `tests/test_langgraph_parity_swarm.py` |
| B. Supervisor parity | GREEN local harness | `tests/test_langgraph_parity_supervisor.py` |
| C. Context/tool isolation | GREEN local harness | `tests/test_langgraph_parity_isolation_benchmark.py` |
| D. Benchmark | GREEN local harness | `reports/langgraph_parity/benchmark/benchmark_report.json`; runtime receipt `rr_langgraph_parity_benchmark_250ea999acb52eb2` |
| E. Runtime truth | RED | `reports/langgraph_parity/readiness/mission_readiness_report.json` has 8 gates, 15 blockers, and `ten_out_of_ten=false` |

Overall: not 10/10. The deterministic local parity substrate is implemented and
verified, and the current live runtime head now carries the parity mission ID.
Operational readiness is still blocked by global historical runtime debt and
live A2A/live-ops state.

## Agents Used

- Lovelace: parity contract and task graph.
- Socrates: current LangGraph docs requirements map.
- Copernicus: deterministic swarm runtime and tests.
- Boyle: deterministic supervisor runtime and tests.
- Aristotle: isolation policy, benchmark harness, benchmark report.
- Cicero: adversarial verifier matrix and command receipts.

## Commands Run

- `make onboard` -> passed; latest captured run reports dirty files `184` and latest runtime truth head has `mission_id=langgraph-swarm-supervisor-parity-to-10-10`.
- `./.venv/bin/python -m compileall -q dharma_swarm/langgraph_parity` -> passed.
- `./.venv/bin/python -m compileall -q dharma_swarm/langgraph_parity dharma_swarm/runtime_lifecycle.py dharma_swarm/orchestrator.py dharma_swarm/operator_core/runtime_truth.py` -> passed.
- `./.venv/bin/python -m pytest -q tests/test_langgraph_parity_readiness.py tests/test_langgraph_parity_swarm.py tests/test_langgraph_parity_supervisor.py tests/test_langgraph_parity_isolation_benchmark.py tests/test_a2a_readiness_gate.py tests/test_runtime_lifecycle.py tests/test_runtime_truth_projection_fields.py tests/test_runtime_lifecycle_receipt_probe.py --tb=short` -> `54 passed`.
- `./.venv/bin/python -m dharma_swarm.langgraph_parity.benchmark --output-dir reports/langgraph_parity/benchmark --mission-id langgraph-swarm-supervisor-parity-to-10-10` -> wrote benchmark report, sidecar receipt, canonical runtime receipt `rr_langgraph_parity_benchmark_250ea999acb52eb2`, run `run_langgraph_parity_benchmark_250ea999acb52eb2`, and linked runtime claim/run/artifact records.
- `./.venv/bin/python scripts/runtime/runtime_lifecycle_receipt_probe.py --producer orchestrator-spine --allow-live --mission-id langgraph-swarm-supervisor-parity-to-10-10 --run-id run_lgp_runtime_mission_proof_20260629T1625Z --task-id task_lgp_runtime_mission_proof_20260629T1625Z --claim-id claim_lgp_runtime_mission_proof_20260629T1625Z --trace-id trace_lgp_runtime_mission_proof_20260629T1625Z --correlation-id corr_lgp_runtime_mission_proof_20260629T1625Z --session-id sess_lgp_runtime_mission_proof_20260629T1625Z --agent-id lgp-runtime-proof-agent --topology fan-out --no-preseed-artifact --no-provider-execution --no-provider-model-reason langgraph_parity_runtime_truth_zero_cost_probe --json` -> wrote fresh zero-cost canonical runtime proof with mission-linked task claim, delegation run, task-result artifact, and artifact-written receipt.
- `./.venv/bin/python scripts/governance/runtime_receipt_coverage_report.py --run-id run_lgp_runtime_mission_proof_20260629T1625Z --json` -> exit 0, scoped `score_gate_70_to_75=true`, `runtime_receipts_total=14`, `major_task_receipts_total=2`, `mission_coverage_complete=true`.
- `./.venv/bin/python -m dharma_swarm.langgraph_parity.readiness --output-dir reports/langgraph_parity/readiness` -> wrote mission readiness JSON/Markdown; overall `red`, 8 gates, 15 blockers, `ten_out_of_ten=false`.
- `./.venv/bin/python scripts/runtime/live_ops_census.py --write` -> refreshed `/Users/dhyana/.dharma/ops/live_process_census.json`.
- `./.venv/bin/python scripts/governance/runtime_receipt_coverage_report.py --json` -> exit 0, global `score_gate_70_to_75=false`.
- `./.venv/bin/python scripts/governance/runtime_receipt_coverage_report.py --since-created-at 2026-06-29T09:48:00+00:00 --json` -> exit 0, scoped `score_gate_70_to_75=true`, `runtime_receipts_total=141`, `major_task_receipts_total=18`, `mission_coverage_complete=true`.
- `./.venv/bin/python scripts/governance/spine_dispatch_mode_report.py --json` -> exit 0, `score_gate_65_to_70=true`, live census has 5 proof-gap surfaces.
- `./.venv/bin/python scripts/governance/check_a2a_readiness.py` -> exit 0, `ready=false`, `gate_status=DEGRADED`, `blocker_task_id_coverage_complete=true`.
- `./.venv/bin/python -m pytest -q tests/test_a2a_readiness_gate.py --tb=short` -> `5 passed`.

## Receipt And Artifact Paths

- `/Users/dhyana/.dharma/ds_goals/langgraph-swarm-supervisor-parity-to-10-10/mission.json`
- `/Users/dhyana/.dharma/ds_goals/langgraph-swarm-supervisor-parity-to-10-10/receipts.jsonl`
- `reports/langgraph_parity/benchmark/benchmark_report.json`
- `reports/langgraph_parity/benchmark/benchmark_report.md`
- `reports/langgraph_parity/benchmark/benchmark_receipt.json`
- Canonical runtime receipt: `rr_langgraph_parity_benchmark_250ea999acb52eb2` in `/Users/dhyana/.dharma/state/runtime.db`
- Canonical runtime run: `run_langgraph_parity_benchmark_250ea999acb52eb2`.
- Fresh mission-linked runtime proof run: `run_lgp_runtime_mission_proof_20260629T1625Z`.
- Fresh mission-linked runtime proof latest receipt: `rr_run_lgp_runtime_mission_proof_20260629T1625Z_artifact_task_result_task_lgp_runtime_mission_proof_20260629T1625Z_artifact_written`.
- `reports/langgraph_parity/receipts/gate_C_runtime_mission_proof_run_20260629T1625Z.json`
- `reports/langgraph_parity/readiness/mission_readiness_report.json`
- `reports/langgraph_parity/readiness/mission_readiness_report.md`
- `reports/langgraph_parity/VERIFIER_MATRIX.md`
- `reports/langgraph_parity/receipts/`

## Remaining Blockers

- Global runtime receipt coverage gate fails: `score_gate_70_to_75=false`, `runtime_receipts_total=70213`, `major_task_receipts_total=11197`, core fields incomplete, and idempotency joins incomplete. Major receipts have `with_matching_idempotency_record=6993/11197`.
- Runtime gap queue is older historical debt, not fresh-head debt: `older_historical_missing=11718`, `active_head_missing=0`. Top actions are ds-goal wrapper repair/quarantine (`40`), orchestrator error repair/quarantine (`5061`), fan-out success inspection (`2091`), fixture quarantine (`3834`), dropoff historical quarantine (`648`), claim-timeout historical quarantine (`32`), and long-timeout historical quarantine (`12`). Several require explicit operator quarantine or historical DB repair; they are not safe to hide behind this parity mission.
- The latest runtime truth packet no longer has a missing `mission_id`: current onboard points at the mission-linked proof receipt above, with `artifact_refs=1` and no `Missing machine fields` line.
- A2A readiness is degraded: `ready=false`, `gate_status=DEGRADED`, `open_tasks=19`, `unverified_closed_tasks=19`, `unknown_status_tasks=2`, but `blocker_task_id_coverage_complete=true`.
- Spine dispatch is only partially proven: `score_gate_65_to_70=true`, persistent daemon launch spec is spine-enabled, but current-process orchestrator default remains legacy and live census has `live_census_proof_gap_surfaces=5`.
- Mission readiness ledger maps these into stable blocker IDs: 7 runtime blockers, 3 A2A blockers, and 5 live-ops blockers.
- Upstream `langgraph-swarm` and `langgraph-supervisor` packages are documented and mapped, but not installed or exercised in the repo.
- Worktree remains heavily dirty with unrelated user/worktree changes; no unrelated changes were reverted.
