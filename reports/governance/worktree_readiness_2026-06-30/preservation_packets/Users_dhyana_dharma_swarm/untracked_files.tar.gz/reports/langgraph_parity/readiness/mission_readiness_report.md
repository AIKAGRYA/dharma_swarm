# LangGraph Parity Mission Readiness

Mission id: `langgraph-swarm-supervisor-parity-to-10-10`
Overall status: **RED**
10/10: `false`

## Gates

| Gate | Status | Summary | Blockers |
| --- | --- | --- | ---: |
| `A.swarm_parity` | green | local deterministic swarm parity exercised in focused tests | 0 |
| `B.supervisor_parity` | green | local deterministic supervisor parity exercised in focused tests | 0 |
| `C.context_tool_isolation` | green | distractor benchmark includes hard domain/tool isolation evidence | 0 |
| `D.benchmark` | green | single-agent, swarm, and supervisor benchmark report is present | 0 |
| `E1.runtime_receipt_coverage` | red | global runtime receipt gate remains red; fresh slice is tracked separately | 7 |
| `E2.a2a_readiness` | amber | A2A degraded, but blocker task-id coverage is complete | 3 |
| `E3.spine_live_ops` | amber | spine dispatch gate passes, but live ops proof gaps remain | 5 |
| `E.runtime_truth` | red | runtime truth still has global coverage, A2A, or live-ops blockers | 15 |

## Blockers

| ID | Source | Task ID | Missing | Operator Decision | Summary |
| --- | --- | --- | ---: | --- | --- |
| `runtime.ds-goal-wrapper` | `runtime_receipt_coverage` | `lgp-runtime-ds-goal-wrapper` | 40 | true | operator-approved wrapper convergence, target hardening, or explicit quarantine plus fresh default receipt proof |
| `runtime.orchestrator-error` | `runtime_receipt_coverage` | `lgp-runtime-orchestrator-error` | 5061 | true | historical execution_error debt still needs repair or operator-approved quarantine |
| `runtime.fanout-success` | `runtime_receipt_coverage` | `lgp-runtime-fanout-success` | 2091 | false | historical fanout_success debt still needs repair or operator-approved quarantine |
| `runtime.fixture-quarantine` | `runtime_receipt_coverage` | `lgp-runtime-fixture-quarantine` | 3834 | true | operator quarantine acceptance plus proof fixture-shaped rows cannot recur in live runtime |
| `runtime.dropoff-fresh-proof` | `runtime_receipt_coverage` | `lgp-runtime-dropoff-fresh-proof` | 648 | true | historical dispatch_dropoff debt still needs repair or operator-approved quarantine |
| `runtime.claim-timeout-proof` | `runtime_receipt_coverage` | `lgp-runtime-claim-timeout-proof` | 32 | true | historical claim_timeout debt still needs repair or operator-approved quarantine |
| `runtime.long-timeout-proof` | `runtime_receipt_coverage` | `lgp-runtime-long-timeout-proof` | 12 | true | historical long_timeout debt still needs repair or operator-approved quarantine |
| `a2a.open-or-claimed-tasks-present` | `a2a_readiness` | `lgp-a2a-open-or-claimed-tasks-present` | 19 | false | 19 A2A task(s) block readiness for open_or_claimed_tasks_present |
| `a2a.unknown-status-tasks-present` | `a2a_readiness` | `lgp-a2a-unknown-status-tasks-present` | 2 | false | 2 A2A task(s) block readiness for unknown_status_tasks_present |
| `a2a.unverified-closed-tasks-present` | `a2a_readiness` | `lgp-a2a-unverified-closed-tasks-present` | 19 | false | 19 A2A task(s) block readiness for unverified_closed_tasks_present |
| `live_ops.substrate-dharma-daemon` | `live_ops_census` | `lgp-live-substrate-dharma-daemon` | 2 | false | substrate.dharma_daemon has 2 proof gap(s) |
| `live_ops.holon-codex-composer-l4` | `live_ops_census` | `lgp-live-holon-codex-composer-l4` | 5 | false | holon.codex_composer_l4 has 5 proof gap(s) |
| `live_ops.evidence-nats-receipts` | `live_ops_census` | `lgp-live-evidence-nats-receipts` | 1 | false | evidence.nats_receipts has 1 proof gap(s) |
| `live_ops.tmux-cockpit` | `live_ops_census` | `lgp-live-tmux-cockpit` | 1 | false | tmux.cockpit has 1 proof gap(s) |
| `live_ops.remote-agni` | `live_ops_census` | `lgp-live-remote-agni` | 1 | false | remote.agni has 1 proof gap(s) |
