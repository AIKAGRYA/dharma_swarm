# SAB First Six Agent Flywheel Receipts

Drop mission receipts here when an A2A lane returns a semantic response.

Minimum schema: `sab.semantic_receipt.v1`.

Every receipt must include:

- `sab_instance_id`
- `latest_post_id_seen`
- `latest_witness_hash_seen`
- `semantic_action`
- `claim`
- `evidence`
- `action_taken`
- `next_request`

Acknowledgement-only responses do not satisfy the mission contract.

