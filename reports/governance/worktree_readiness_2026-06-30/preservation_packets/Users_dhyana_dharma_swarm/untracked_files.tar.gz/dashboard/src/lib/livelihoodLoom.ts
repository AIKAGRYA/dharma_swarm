import fs from "node:fs";
import path from "node:path";

type JsonRecord = Record<string, unknown>;

export interface LivelihoodLoomCandidate {
  rank: number;
  source_rank: number;
  name: string;
  country: string;
  domain: string;
  prioritization_score: number;
  wedge_label: string;
  safety_status?: string;
}

export interface LivelihoodLoomDashboard {
  status: string;
  receiptId: string;
  generatedAt: string;
  providerStatus: "red" | "green" | "unknown";
  providerGreen: boolean;
  topCount: number;
  candidateCount: number;
  topCandidates: LivelihoodLoomCandidate[];
  wedges: Array<{
    rank: number;
    wedge_id: string;
    label: string;
    roi_score: number;
    candidate_count_in_top_50: number;
    roi_thesis: string;
  }>;
  safety: {
    allowed: number;
    needs_review: number;
    blocked: number;
    total: number;
    flag_counts: Record<string, number>;
  };
  packets: {
    packet_count: number;
    packets: Array<{ packet_id: string; json: string; md: string }>;
  };
  demand: {
    draft_only: boolean;
    sent: boolean;
    external_action_status: string;
    first_paid_offer: string;
    sponsor_briefs: string[];
  };
  promotion: {
    present: boolean;
    sponsorTarget: string;
    outreachStatus: string;
    actedReceiptStatus: string;
    providerGateStatus: string;
    sponsorOnePager: string;
    reviewPacket: string;
  };
  files: Record<string, string>;
}

export function loadLivelihoodLoomDashboard(reportRoot?: string): LivelihoodLoomDashboard {
  const root = reportRoot ?? livelihoodReportRoot();
  const cycle = readJson(path.join(root, "cycles/latest.json"));
  const top50 = readJson(path.join(root, "cultivation/top_50.json"));
  const wedges = readJson(path.join(root, "cultivation/wedges.json"));
  const safety = readJson(path.join(root, "safety/top_50_safety_review.json"));
  const packets = readJson(path.join(root, "enablement_packets/index.json"));
  const demand = readJson(path.join(root, "demand/index.json"));
  const promotion = readOptionalJson(path.join(root, "promotion/latest.json"));
  const actedGate = readOptionalJson(
    path.join(root, "promotion/external_acted_receipt_gate.json"),
  );
  const providerGate = readOptionalJson(
    path.join(root, "promotion/provider_readiness_gate.json"),
  );

  const safetyByName = new Map<string, string>();
  asArray(safety.reviews).forEach((item) => {
    const record = item as JsonRecord;
    safetyByName.set(String(record.name ?? ""), String(record.safety_status ?? ""));
  });

  const candidates = asArray(top50.candidates).slice(0, 8).map((item) => {
    const record = item as JsonRecord;
    const name = String(record.name ?? "");
    return {
      rank: Number(record.rank ?? 0),
      source_rank: Number(record.source_rank ?? 0),
      name,
      country: String(record.country ?? "unknown"),
      domain: String(record.domain ?? "unknown"),
      prioritization_score: Number(record.prioritization_score ?? 0),
      wedge_label: String(record.wedge_label ?? ""),
      safety_status: safetyByName.get(name) ?? "unknown",
    };
  });

  const promotionSteps = (promotion.steps as JsonRecord | undefined) ?? {};
  const sponsorTarget = (promotionSteps["5_first_sponsor_target"] as JsonRecord | undefined) ?? {};
  const promotionArtifacts = (promotion.artifacts as JsonRecord | undefined) ?? {};
  const promotionBoundary = (promotion.safety_boundary as JsonRecord | undefined) ?? {};

  return {
    status: String(cycle.status ?? "missing"),
    receiptId: String(cycle.receipt_id ?? ""),
    generatedAt: String(cycle.created_at ?? cycle.generated_at ?? ""),
    providerStatus: providerStatus(cycle, providerGate),
    providerGreen: Boolean(cycle.provider_green ?? false),
    topCount: asArray(top50.candidates).length,
    candidateCount: Number(top50.candidate_count ?? 0),
    topCandidates: candidates,
    wedges: asArray(wedges.wedges).map((item) => {
      const record = item as JsonRecord;
      return {
        rank: Number(record.rank ?? 0),
        wedge_id: String(record.wedge_id ?? ""),
        label: String(record.label ?? ""),
        roi_score: Number(record.roi_score ?? 0),
        candidate_count_in_top_50: Number(record.candidate_count_in_top_50 ?? 0),
        roi_thesis: String(record.roi_thesis ?? ""),
      };
    }),
    safety: {
      allowed: Number((safety.summary as JsonRecord | undefined)?.allowed ?? 0),
      needs_review: Number((safety.summary as JsonRecord | undefined)?.needs_review ?? 0),
      blocked: Number((safety.summary as JsonRecord | undefined)?.blocked ?? 0),
      total: Number((safety.summary as JsonRecord | undefined)?.total ?? 0),
      flag_counts: ((safety.summary as JsonRecord | undefined)?.flag_counts ??
        {}) as Record<string, number>,
    },
    packets: {
      packet_count: Number(packets.packet_count ?? 0),
      packets: asArray(packets.packets).map((item) => {
        const record = item as JsonRecord;
        return {
          packet_id: String(record.packet_id ?? ""),
          json: String(record.json ?? ""),
          md: String(record.md ?? ""),
        };
      }),
    },
    demand: {
      draft_only: Boolean(demand.draft_only ?? true),
      sent: Boolean(demand.sent ?? false),
      external_action_status: String(demand.external_action_status ?? "missing"),
      first_paid_offer: String(demand.first_paid_offer ?? ""),
      sponsor_briefs: asArray(demand.sponsor_briefs).map(String),
    },
    promotion: {
      present: Object.keys(promotion).length > 0,
      sponsorTarget: String(sponsorTarget.name ?? "pending"),
      outreachStatus: String(promotionBoundary.outreach_action_status ?? "not_drafted"),
      actedReceiptStatus: String(actedGate.status ?? "missing"),
      providerGateStatus: String(providerGate.status ?? "red"),
      sponsorOnePager: String(promotionArtifacts.sponsor_one_pager ?? ""),
      reviewPacket: String(promotionArtifacts.human_review_packet ?? ""),
    },
    files: {
      cycle: path.join(root, "cycles/latest.json"),
      top50: path.join(root, "cultivation/top_50.json"),
      wedges: path.join(root, "cultivation/wedges.json"),
      safety: path.join(root, "safety/top_50_safety_review.json"),
      packets: path.join(root, "enablement_packets/index.json"),
      demand: path.join(root, "demand/index.json"),
      promotion: path.join(root, "promotion/latest.json"),
    },
  };
}

export function livelihoodReportRoot(): string {
  const cwd = process.cwd();
  const local = path.join(cwd, "reports/livelihood_loom");
  if (fs.existsSync(local)) return local;
  return path.join(cwd, "..", "reports/livelihood_loom");
}

function readJson(filePath: string): JsonRecord {
  return JSON.parse(fs.readFileSync(filePath, "utf8")) as JsonRecord;
}

function readOptionalJson(filePath: string): JsonRecord {
  if (!fs.existsSync(filePath)) return {};
  return readJson(filePath);
}

function asArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function providerStatus(cycle: JsonRecord, providerGate: JsonRecord): "red" | "green" | "unknown" {
  if (cycle.provider_green === true) return "green";
  if (providerGate.status === "red") return "red";
  const gap = cycle.provider_readiness_gap as JsonRecord | undefined;
  if (gap?.status === "red") return "red";
  return "unknown";
}
