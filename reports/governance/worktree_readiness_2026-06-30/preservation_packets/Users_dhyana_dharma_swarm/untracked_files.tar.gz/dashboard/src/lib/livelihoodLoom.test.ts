import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { loadLivelihoodLoomDashboard } from "./livelihoodLoom.ts";

test("loadLivelihoodLoomDashboard projects local receipts without provider-green inflation", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "livelihood-loom-dashboard-"));
  writeJson(path.join(root, "cycles/latest.json"), {
    receipt_id: "cycle_1",
    created_at: "2026-06-29T00:00:00Z",
    status: "cultivation_ready_provider_blocked",
    provider_green: false,
    provider_readiness_gap: { status: "red" },
  });
  writeJson(path.join(root, "cultivation/top_50.json"), {
    candidate_count: 1000,
    candidates: [
      {
        rank: 1,
        source_rank: 4,
        name: "Zeta Pay",
        country: "India",
        domain: "finance_rails",
        prioritization_score: 0.98,
        wedge_label: "Payment acceptance",
      },
    ],
  });
  writeJson(path.join(root, "cultivation/wedges.json"), {
    wedge_count: 1,
    wedges: [
      {
        rank: 1,
        wedge_id: "payment_acceptance_cashflow",
        label: "Payment acceptance",
        roi_score: 1.1,
        candidate_count_in_top_50: 12,
        roi_thesis: "Cashflow rails help merchants.",
      },
    ],
  });
  writeJson(path.join(root, "safety/top_50_safety_review.json"), {
    summary: {
      allowed: 1,
      needs_review: 0,
      blocked: 0,
      total: 1,
      flag_counts: { high_fee_lending: 0 },
    },
    reviews: [
      {
        name: "Zeta Pay",
        safety_status: "allowed",
      },
    ],
  });
  writeJson(path.join(root, "enablement_packets/index.json"), {
    packet_count: 5,
    packets: [{ packet_id: "packet_01", json: "packet_01.json", md: "packet_01.md" }],
  });
  writeJson(path.join(root, "demand/index.json"), {
    draft_only: true,
    sent: false,
    external_action_status: "risk_reviewed",
    first_paid_offer: "first_paid_offer.md",
    sponsor_briefs: ["sponsor_brief_01.md"],
  });
  writeJson(path.join(root, "promotion/latest.json"), {
    steps: { "5_first_sponsor_target": { name: "Accion" } },
    artifacts: {
      sponsor_one_pager: "sponsor_one_pager.md",
      human_review_packet: "human_review_packet.json",
    },
    safety_boundary: {
      outreach_action_status: "risk_reviewed",
    },
  });
  writeJson(path.join(root, "promotion/external_acted_receipt_gate.json"), {
    status: "blocked_pending_human_governor_approval_and_external_act",
  });
  writeJson(path.join(root, "promotion/provider_readiness_gate.json"), {
    status: "red",
  });

  const dashboard = loadLivelihoodLoomDashboard(root);

  assert.equal(dashboard.status, "cultivation_ready_provider_blocked");
  assert.equal(dashboard.providerStatus, "red");
  assert.equal(dashboard.providerGreen, false);
  assert.equal(dashboard.topCandidates[0]?.safety_status, "allowed");
  assert.equal(dashboard.promotion.sponsorTarget, "Accion");
  assert.equal(
    dashboard.promotion.actedReceiptStatus,
    "blocked_pending_human_governor_approval_and_external_act",
  );
});

function writeJson(filePath: string, payload: unknown) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(payload)}\n`, "utf8");
}

