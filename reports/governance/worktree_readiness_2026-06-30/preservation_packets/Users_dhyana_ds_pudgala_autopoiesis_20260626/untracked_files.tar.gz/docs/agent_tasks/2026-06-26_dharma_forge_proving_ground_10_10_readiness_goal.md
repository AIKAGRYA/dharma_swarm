# Dharma Forge Proving Ground 10/10 Readiness Goal

Date: 2026-06-26
Status: longrun goal handoff spec
Intended runner: Codex `/goal` or `/longrun`
Primary mode: persistent implementation, verification, and evidence loop

## Pasteable Goal Envelope

```text
/longrun /goal Codex: follow docs/agent_tasks/2026-06-26_dharma_forge_proving_ground_10_10_readiness_goal.md. Mission: make Dharma Forge Proving Ground reach an honest 10/10 readiness grade for a one-command, 100-iteration, real-benchmark swarm evolution run. Do not stop at analysis, partial scaffolding, green prose, or blocked narrative. Keep implementing, testing, repairing, and regrading until the machine-produced readiness grader returns 10/10. Persistence rule: if a blocker needs operator authority, credentials, funds, external service access, or destructive action approval, record NEEDS_OPERATOR_AUTHORITY with exact command/evidence, continue all adjacent safe work, and re-run the readiness grader after each repair. Truth rule: every readiness point must come from fresh command output or machine-readable artifact from this run. Authority: no public benchmark submission, external outreach, paid action, production router mutation, archive-fitness mutation, trusted-memory promotion, self-merge, or protected identity mutation without explicit current operator lease. Close only when readiness=10/10 with receipts, or when the operator explicitly stops the run.
```

## Mission

Build the repo-owned control loop that makes this command possible and honest:

```bash
make forge-proving-ground-100
```

The command must run a real Dharma Forge Proving Ground loop: benchmark task
selection, swarm execution, control-arm comparison, autoresearch mutation,
verification, rollback or keep decision, receipt writing, and readiness
regrading. It must not rely on narrative claims, stale packet paths, or manual
artifact stitching.

The target is not "many agents ran." The target is a reproducible, budgeted,
contamination-controlled feedback loop that can improve the swarm only when
fresh measured evidence justifies the change.

## Correct Naming

Use these names consistently:

- `Dharma Forge Proving Ground`: canonical umbrella system for external swarm
  evolution and hardening through measured reality.
- `Forge Proving Ground`: short operator phrase.
- `Dharma Forge`: legacy/root machinery alias for reward forge, Hydra lineage,
  receipt scoring, and historical Forge mechanisms.
- `Forge Arena`: internal or local competitive/collaborative task arena.
- `Forge Swarm Evolution Arena v0`: current synthetic sealed microtask
  measurement family.
- `Pudgala Autopoiesis Protostar`: separate anti-slop governance/evidence
  mechanism. Never call this Forge.

Before edits, read:

- `docs/governance/FORGE_NAMING_BOUNDARY.md`
- `docs/ontology/SEMANTIC_COMMONS.md`
- `docs/ontology/semantic_objects.yaml`
- `docs/ontology/semantic_aliases.yaml`

If the Semantic Commons lacks the canonical object, add:

```yaml
DharmaForgeProvingGround:
  kind: evolution_proving_ground
  owner: docs/governance/FORGE_NAMING_BOUNDARY.md
  description: Canonical external swarm evolution and benchmark-hardening system.
```

Alias suggestions:

```yaml
forge_proving_ground:
  canonical: DharmaForgeProvingGround
  kind: system_alias
dharma_forge:
  canonical: DharmaForgeProvingGround
  kind: legacy_alias
```

## Non-Negotiable Honesty Rules

1. A readiness grade is valid only if produced by a script in this repo.
2. A readiness point is valid only if backed by a fresh command result or
   machine-readable artifact from the current run.
3. A synthetic Forge Arena result is Tier 1 training signal only.
4. A real benchmark result is still Tier 1 training signal unless it is
   externally submitted or independently countersigned under an explicit lease.
5. Archive fitness, production routing, trusted memory, public claims, and
   external action stay unchanged until a separate authority lease exists.
6. A blocked state is not completion. It is a receipt plus next safe action.
7. Do not delete or weaken tests to pass the readiness grader.
8. Do not silently rebaseline any governance or benchmark threshold.
9. If a provider, benchmark, or runner fails, classify the failure and either
   repair it or downgrade readiness. Do not substitute prose.
10. Never claim 10/10 unless the readiness grader prints 10/10.

## Current Baseline To Treat As Hypothesis

The last audit found this state. Re-verify it at the start; do not trust it as
current truth without command output.

- Current readiness: 2/10 for the 100-iteration real-benchmark goal.
- Forge v0 scripts compile.
- Focused Forge/autoresearch/benchmark-registry tests pass locally.
- A fresh synthetic taskpack can reach green preflight.
- The canonical default Forge run directory cited by old docs is incomplete.
- The measurement runner blocked correctly when live-repaired roster had fewer
  than 3 providers.
- `benchmarks/gauntlet.py --tier 1` previously passed only 2/4 tasks.
- `dkeys test` previously failed in the shell because `httpx` was unavailable.
- Cached provider truth showed only a partial live roster.
- Real benchmark adapters for SWE-bench, GAIA, MultiAgentBench, AgentRace, and
  DGM evolution were documented as not implemented.
- `dharma_swarm/autoresearch_loop.py` exists, but it is not yet fused with real
  external benchmark measurement.

## First Reads

Read these before planning edits:

- `docs/ops/DHARMA_FORGE_HYDRA_ARCHAEOLOGY_2026-06-11.md`
- `docs/agent_tasks/2026-06-12_forge_rehydration_benchmark_evolution_goal.md`
- `docs/specs/forge_packets/FORGE_SWARM_EVOLUTION_ARENA_V0_MEASUREMENT_10H_LAUNCH.md`
- `docs/LOOP_PROTOCOL.md`
- `docs/research/VERIFIED_EXPERIMENT_LOOP_RFC.md`
- `docs/reports/BENCHMARK_SUMMARY.md`
- `docs/reports/BENCHMARK_RESEARCH_2026.md`
- `docs/ops/CODEX_TOOLBELT_ONBOARDING.md`
- `benchmarks/README.md`
- `benchmarks/gauntlet.py`
- `dharma_swarm/benchmark_registry.py`
- `dharma_swarm/autoresearch_loop.py`
- `tests/test_autoresearch_loop.py`
- `scripts/runtime/forge_swarm_evolution_arena_v0_taskpack_builder.py`
- `scripts/runtime/forge_swarm_evolution_arena_v0_preflight.py`
- `scripts/runtime/forge_swarm_evolution_arena_v0_measurement_runner.py`
- `tests/test_forge_swarm_evolution_arena_v0_taskpack_builder.py`
- `tests/test_forge_swarm_evolution_arena_v0_preflight.py`
- `tests/test_forge_swarm_evolution_arena_v0_measurement_runner.py`
- `tests/test_benchmark_registry.py`

Also inspect `Makefile` before adding targets.

## Autoresearch Principles To Implement

The longrun must move beyond a simple "LLM edits code and tests pass" loop.
Implement the stronger autoresearch pattern:

1. Frozen environment: benchmark task, scorer, hidden labels, budget, and
   allowed files are immutable for a run.
2. Mutable target: only a declared patch surface may change in a mutation
   iteration.
3. Single-edit trials: one mutation per iteration unless the planner records a
   multi-file dependency and the verifier accepts it before execution.
4. Control arms: compare full swarm against best-single-full-budget and
   same-budget Self-MoA before crediting swarm lift.
5. Reseeded confirmation: a candidate improvement must survive a second run
   with changed seed or fresh task draw where the benchmark supports it.
6. Leave-one-out pruning: if a mutation claims improvement, rerun with the
   mutation removed or isolated to prove the improvement depends on the edit.
7. Failure archive: failed mutations are preserved as receipts and can become
   regression tests, but they do not remain applied.
8. Exploration policy: do not repeat the same hypothesis, task, intervention,
   and next action three times. Change search strategy or stop that branch.
9. Outer-loop meta-search: if 10 iterations produce no accepted improvement,
   modify the search policy, not only the target module. Examples: rotate
   benchmark family, change mutation granularity, add classical optimizer state,
   or target a different subsystem named by failure receipts.
10. Statistical humility: positive lift below the run's uncertainty threshold
    is candidate evidence, not a win.

## Readiness Grader

Build a machine-owned grader:

```text
scripts/runtime/forge_proving_ground_readiness.py
tests/test_forge_proving_ground_readiness.py
```

Command:

```bash
python3 scripts/runtime/forge_proving_ground_readiness.py --json --strict
```

The script prints:

```json
{
  "schema_version": "forge_proving_ground_readiness.v1",
  "score": 0,
  "max_score": 10,
  "readiness": "0/10",
  "items": [],
  "blockers": [],
  "next_actions": []
}
```

Each item must include:

```json
{
  "id": "FPG-R1",
  "name": "one-command target exists",
  "points": 1,
  "status": "pass|fail|blocked",
  "evidence": {
    "command": "...",
    "artifact": "...",
    "summary": "..."
  }
}
```

The strict command exits 0 only at 10/10. Below 10 it exits nonzero and prints
the exact blockers and next actions.

## 10/10 Readiness Rubric

Each item is worth 1 point. All 10 must pass from fresh evidence.

### FPG-R1: One Command Exists

Required command:

```bash
make forge-proving-ground-100
```

The target must call a repo-owned script, not a pasted shell chain.

Target files:

- `Makefile`
- `scripts/runtime/forge_proving_ground_run.py`
- `tests/test_forge_proving_ground_run.py`

Pass evidence:

- `make -n forge-proving-ground-100`
- CLI help for the runner
- unit test proving args for 1, 10, 25, and 100 iterations

### FPG-R2: Provider Oracle Is Fresh And Usable

The runner must perform a non-secret provider readiness probe and reject stale
or partial provider truth.

Target files:

- `scripts/runtime/forge_provider_oracle.py`
- `tests/test_forge_provider_oracle.py`
- optional fix to the `dkeys` invocation path if needed

Minimum pass:

- at least 3 decorrelated live provider roles, or an explicit
  `blocked_provider_roster_below_minimum` readiness failure.
- no secret values printed.
- provider status age recorded.

If `dkeys test` cannot run because `httpx` is missing, repair the execution
environment or implement a safe fallback that reads the cache and marks it
stale/non-authoritative rather than green.

### FPG-R3: Real Benchmark Adapter Smoke

At least one real benchmark adapter must run end-to-end in smoke mode.

Preferred first adapter:

- Terminal-Bench-compatible local task if available without external submission.

Fallback adapter:

- SWE-bench lite or verified sample task through official harness if dependencies
  and time allow.

Target files:

- `benchmarks/forge_real_benchmark_adapter.py`
- `tests/test_forge_real_benchmark_adapter.py`
- optional benchmark-specific adapter under `benchmarks/`

Pass evidence:

- adapter loads a real benchmark task definition.
- candidate-visible files are separated from hidden/scorer files.
- scorer runs on a deterministic local submission.
- artifact hashes are recorded.

Do not count synthetic Forge Arena microtasks for this point.

### FPG-R4: Synthetic Forge Arena Still Green

The existing Forge v0 sealed taskpack path must stay green.

Required commands:

```bash
python3 scripts/runtime/forge_swarm_evolution_arena_v0_taskpack_builder.py --output-dir /tmp/forge-fpg-smoke --overwrite --json
python3 scripts/runtime/forge_swarm_evolution_arena_v0_preflight.py --run-dir /tmp/forge-fpg-smoke --json --strict-exit
python3 -m pytest -q tests/test_forge_swarm_evolution_arena_v0_taskpack_builder.py tests/test_forge_swarm_evolution_arena_v0_preflight.py tests/test_forge_swarm_evolution_arena_v0_measurement_runner.py --tb=short
```

Pass evidence:

- task pack gate green.
- roster gate green from fresh provider oracle or explicitly mocked only in unit
  tests, never in readiness.
- ROI governor green.

### FPG-R5: Autoresearch Mutation Loop Is Wired To Benchmarks

The existing `AutoResearchLoop` must not remain isolated from the proving
ground. Add a bridge that consumes benchmark failure receipts and proposes a
single scoped mutation.

Target files:

- `scripts/runtime/forge_proving_ground_autoresearch.py`
- `tests/test_forge_proving_ground_autoresearch.py`
- `dharma_swarm/autoresearch_loop.py` only if a narrow interface extension is
  required

Pass evidence:

- given a benchmark failure receipt, it selects a target module and proposed
  patch surface.
- immutable files and directories are enforced.
- dry-run mode produces a plan without writing.
- live mode writes only inside an isolated worktree or explicitly declared patch
  scope.

### FPG-R6: Keep/Revert Is Proven

Each mutation iteration must prove:

- baseline tests before mutation.
- mutation applied.
- relevant tests and benchmark smoke after mutation.
- keep only if measured score improves and tests pass.
- revert if tests fail, score regresses, or verification is inconclusive.

Target files:

- `scripts/runtime/forge_proving_ground_patch_sandbox.py`
- `tests/test_forge_proving_ground_patch_sandbox.py`

Pass evidence:

- one accepted synthetic fixture mutation.
- one rejected mutation that reverts cleanly.
- git diff after rejected mutation is clean for the target file.

### FPG-R7: Independent Verification Exists

The builder cannot mark its own mutation verified.

Minimum implementation:

- a verifier process/function reruns the relevant command set from a fresh
  process.
- verifier writes `verified=true|false` into a receipt.
- builder can set status only to `candidate`.

Target files:

- `scripts/runtime/forge_proving_ground_verifier.py`
- `tests/test_forge_proving_ground_verifier.py`

Pass evidence:

- verifier rejects missing artifact.
- verifier rejects stale command output.
- verifier accepts a fresh passing smoke fixture.

### FPG-R8: 1-10-25-100 Scaling Gates Exist

The runner must not jump directly to 100 real iterations.

Required gates:

1. `--iterations 1 --mode smoke`
2. `--iterations 10 --mode bounded`
3. `--iterations 25 --mode soak`
4. `--iterations 100 --mode full`

The 100 mode is allowed only if the previous gates pass in the same run or a
fresh receipt bundle proves they passed under the same commit, provider roster,
and benchmark pack hash.

Pass evidence:

- CLI validates illegal jumps.
- unit tests cover gate transitions.
- receipts include commit SHA, run id, provider roster hash, benchmark pack hash,
  and budget cap.

### FPG-R9: Receipts Are Complete And Replayable

Each iteration writes JSONL receipts under:

```text
reports/forge/proving_ground/<run_id>/
```

Required files:

- `RUN_MANIFEST.json`
- `readiness.json`
- `provider_roster.json`
- `benchmark_pack.json`
- `iteration_receipts.jsonl`
- `mutation_receipts.jsonl`
- `verification_receipts.jsonl`
- `budget_ledger.jsonl`
- `decision_packet.md`
- `failure_harvest.md`

Each iteration receipt must include:

- run id
- iteration number
- commit SHA
- task id
- benchmark family
- candidate-visible artifact hashes
- hidden/scorer artifact hashes
- provider roster hash
- arm scores
- swarm lift
- uncertainty or low-power warning
- proposed mutation id
- keep/revert decision
- verifier receipt id
- authority fields, all false unless explicitly leased

### FPG-R10: CI And Local Verification Pass

The final 10/10 state must pass:

```bash
python3 -m py_compile scripts/runtime/forge_proving_ground_readiness.py scripts/runtime/forge_proving_ground_run.py
python3 -m pytest -q tests/test_forge_proving_ground_readiness.py tests/test_forge_proving_ground_run.py tests/test_forge_proving_ground_autoresearch.py tests/test_forge_proving_ground_verifier.py --tb=short
python3 scripts/runtime/forge_proving_ground_readiness.py --json --strict
git diff --check
```

If the implementation touches existing Forge files, also run:

```bash
python3 -m pytest -q tests/test_forge_swarm_evolution_arena_v0_taskpack_builder.py tests/test_forge_swarm_evolution_arena_v0_preflight.py tests/test_forge_swarm_evolution_arena_v0_measurement_runner.py tests/test_autoresearch_loop.py tests/test_benchmark_registry.py --tb=short
```

## Longrun Persistence Contract

This goal must not end just because readiness is below 10. The runner should
cycle through:

1. grade readiness;
2. pick the highest-leverage failing readiness item;
3. implement the smallest repair;
4. run focused tests;
5. re-run readiness;
6. write a receipt;
7. repeat.

Valid longrun states:

- `working`
- `repairing`
- `verifying`
- `blocked_needs_operator_authority`
- `blocked_external_service`
- `blocked_provider_roster`
- `blocked_dependency_install`
- `ready_10_of_10`

Only `ready_10_of_10` is completion.

If blocked:

- write the exact blocker;
- write the exact command that failed;
- write what authority or dependency is needed;
- continue all safe adjacent tasks;
- do not claim completion;
- do not erase the blocker.

## Implementation Phases

### Phase 0: Baseline Receipt

Run:

```bash
make onboard
git status --short --branch
git log --oneline -5
python3 -m py_compile scripts/runtime/forge_swarm_evolution_arena_v0_taskpack_builder.py scripts/runtime/forge_swarm_evolution_arena_v0_preflight.py scripts/runtime/forge_swarm_evolution_arena_v0_measurement_runner.py dharma_swarm/autoresearch_loop.py benchmarks/gauntlet.py
python3 -m pytest -q tests/test_forge_swarm_evolution_arena_v0_taskpack_builder.py tests/test_forge_swarm_evolution_arena_v0_preflight.py tests/test_forge_swarm_evolution_arena_v0_measurement_runner.py tests/test_autoresearch_loop.py tests/test_benchmark_registry.py --tb=short
python3 benchmarks/gauntlet.py --tier 1
```

Try provider status without printing secrets:

```bash
/Users/dhyana/.dharma/bin/dkeys test
python3 -m dharma_swarm.api_key_audit --no-agentic
curl -s http://127.0.0.1:8420/api/chat/status
```

If a command is missing or unsafe, record that exactly.

Write:

```text
reports/forge/proving_ground/<run_id>/BASELINE.md
reports/forge/proving_ground/<run_id>/baseline.json
```

### Phase 1: Grader First

Implement `forge_proving_ground_readiness.py` before any large runner. The
grader is the control loop sensor. Without it, the longrun can drift.

The first grader run should honestly return below 10. That is expected.

### Phase 2: One-Command Skeleton

Add:

```bash
make forge-proving-ground-readiness
make forge-proving-ground-smoke
make forge-proving-ground-100
```

`forge-proving-ground-100` may initially fail because the grader is below 10,
but it must fail with a useful receipt and next action.

### Phase 3: Provider Oracle

Make provider truth fresh and non-secret. Prefer the local `dkeys` helper, but
do not depend on shell PATH. Use `/Users/dhyana/.dharma/bin/dkeys` when present.

If `httpx` is missing, either:

- run through the repo venv if it has `httpx`;
- add `httpx` to the correct dev dependency if appropriate;
- or mark provider proof as stale and keep readiness below 10.

Do not print key values.

### Phase 4: Real Benchmark Smoke

Implement one real benchmark smoke adapter. Keep it tiny but true.

Minimum acceptable real-benchmark adapter:

- loads a task from an external benchmark package or checked-in benchmark
  fixture whose source is documented;
- enforces candidate-visible vs hidden/scorer separation;
- can score a deterministic baseline submission;
- writes hashes and a benchmark receipt.

Do not count the synthetic Forge microtask pack as the real benchmark point.

### Phase 5: Autoresearch Bridge

Bridge benchmark failures into `AutoResearchLoop` or a wrapper around it.

Do not let the loop mutate the benchmark, scorer, hidden labels, tests, models,
telos gates, or the readiness grader itself.

Mutation target selection should be evidence-driven:

- provider failure targets provider/runtime path;
- JSON parse failure targets response normalization;
- benchmark failure targets solver/planner/handoff logic;
- contamination failure targets taskpack/adapter boundary;
- repeated no-lift targets search policy, not random churn.

### Phase 6: Sandbox Keep/Revert

Run mutations in an isolated worktree or a clearly backed-up patch scope. A
failed mutation must leave the working tree clean except for receipts.

Do not use destructive git commands without explicit operator approval.

### Phase 7: Smoke To 1 Iteration

Run:

```bash
python3 scripts/runtime/forge_proving_ground_run.py --iterations 1 --mode smoke --json
python3 scripts/runtime/forge_proving_ground_readiness.py --json --strict
```

Expected outcome before 10/10 may be nonzero. Keep repairing until the
readiness item for one-iteration smoke passes.

### Phase 8: Scale To 10, Then 25, Then 100

Only unlock the next scale after the previous receipt is verified.

Use hard budgets:

- max wall time per iteration;
- max provider calls per arm;
- max total spend if the provider exposes usage;
- max repeated blocker count of 3;
- max artifact size per run.

If a run hits a budget cap, close that branch as `blocked_with_evidence`, grade
readiness accordingly, and continue safe repairs.

### Phase 9: Final 10/10 Closeout

The final closeout must include:

- readiness grader output showing 10/10;
- command that ran 100-mode or proved it is launchable with all gates green;
- provider roster proof;
- benchmark pack proof;
- mutation keep/revert proof;
- verifier proof;
- receipt directory path;
- local tests;
- `git status --short`;
- explicit authority statement.

Authority statement must say:

```text
archive_fitness_mutated=false
production_router_mutated=false
trusted_memory_promoted=false
public_submission_performed=false
external_action_performed=false
```

Unless the operator gave a current explicit lease and the receipt proves it.

## Suggested File Plan

Add:

- `scripts/runtime/forge_proving_ground_readiness.py`
- `scripts/runtime/forge_proving_ground_run.py`
- `scripts/runtime/forge_provider_oracle.py`
- `scripts/runtime/forge_real_benchmark_adapter.py`
- `scripts/runtime/forge_proving_ground_autoresearch.py`
- `scripts/runtime/forge_proving_ground_patch_sandbox.py`
- `scripts/runtime/forge_proving_ground_verifier.py`
- `tests/test_forge_proving_ground_readiness.py`
- `tests/test_forge_proving_ground_run.py`
- `tests/test_forge_provider_oracle.py`
- `tests/test_forge_real_benchmark_adapter.py`
- `tests/test_forge_proving_ground_autoresearch.py`
- `tests/test_forge_proving_ground_patch_sandbox.py`
- `tests/test_forge_proving_ground_verifier.py`

Modify only if needed:

- `Makefile`
- `docs/governance/FORGE_NAMING_BOUNDARY.md`
- `docs/governance/CANONICAL_DOC_STACK.md`
- `docs/docops/assertions.yaml`
- `docs/ontology/SEMANTIC_COMMONS.md`
- `docs/ontology/semantic_objects.yaml`
- `docs/ontology/semantic_aliases.yaml`
- `dharma_swarm/autoresearch_loop.py`
- `scripts/runtime/forge_swarm_evolution_arena_v0_measurement_runner.py`

Avoid unless explicitly necessary:

- `runtime_state.py`
- production router files
- archive fitness mutation paths
- protected identity files
- benchmark hidden labels/scorers after results exist

## Fresh Instance Operating Instructions

1. Start from a clean branch or worktree.
2. Run baseline commands.
3. Implement the readiness grader first.
4. Keep all work tied to readiness items.
5. Re-run the grader after every repair.
6. Prefer small commits by readiness item if committing is allowed.
7. Never self-merge.
8. If the operator interrupts with a newer instruction, obey the newer
   instruction and record how it changes readiness.
9. If context compacts, read this file, latest `readiness.json`, and latest
   `decision_packet.md`; do not restart from scratch.
10. Do not send a final success message until 10/10 is produced by the grader.

## Final Report Shape

```text
Outcome:
Readiness:
Command:
Changed files:
Verification:
Receipts:
Provider roster:
Benchmark coverage:
Autoresearch mutations:
Accepted/reverted:
Remaining authority boundaries:
Next admissible run:
```

If readiness is not 10/10, the report must start with:

```text
Not complete. Current readiness is X/10.
```

