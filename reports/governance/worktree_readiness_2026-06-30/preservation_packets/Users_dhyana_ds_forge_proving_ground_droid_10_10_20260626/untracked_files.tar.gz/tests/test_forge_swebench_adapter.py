"""Tests for the SWE-bench Verified proving-ground adapter.

The Docker harness subprocess is mocked throughout so tests are fast and need no
Docker. A tiny fake dataset cache file is used to avoid any network download.
"""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

import scripts.runtime.forge_swebench_adapter as adapter
from scripts.runtime.forge_proving_ground_common import CUSTODY_DRY_RUN_ONLY
from scripts.runtime.forge_swebench_adapter import (
    DATASET_NAME,
    DATASET_SPLIT,
    EMPTY_MODEL_NAME,
    GOLD_MODEL_NAME,
    ExternalityRefused,
    build_harness_command,
    load_dataset_cached,
    parse_report_dir,
    run_swebench,
    select_instances,
    write_predictions,
)


# --- fixtures -----------------------------------------------------------------

GOLD_PATCH = (
    "--- a/foo.py\n+++ b/foo.py\n@@ -1 +1 @@\n-bug\n+fix\n"
)
ROW_A = {
    "instance_id": "scikit-learn__scikit-learn-10297",
    "patch": GOLD_PATCH,
    "repo": "scikit-learn/scikit-learn",
    "base_commit": "abc123",
    "fail_to_pass": ["test_a::test_fail"],
    "pass_to_pass": ["test_a::test_pass"],
}
ROW_B = {
    "instance_id": "django__django-11099",
    "patch": "--- a/b.py\n+++ b/b.py\n@@ -1 +1 @@\n-x\n+y\n",
    "repo": "django/django",
    "base_commit": "def456",
    "fail_to_pass": ["test_b::test_fail"],
    "pass_to_pass": ["test_b::test_pass"],
}


def _write_fake_cache(tmp_path: Path) -> Path:
    cache = tmp_path / "swebench_dataset_cache.jsonl"
    cache.parent.mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(r, sort_keys=True) for r in (ROW_A, ROW_B)]
    cache.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cache


# --- dataset cache load -------------------------------------------------------

def test_dataset_cache_load_no_network(tmp_path):
    cache = _write_fake_cache(tmp_path)
    rows = load_dataset_cached(cache_path=cache)
    assert len(rows) == 2
    assert rows[0].instance_id == ROW_A["instance_id"]
    assert rows[0].patch == GOLD_PATCH
    assert rows[0].fail_to_pass == ROW_A["fail_to_pass"]
    assert rows[1].pass_to_pass == ROW_B["pass_to_pass"]


def test_dataset_cache_missing_file_raises_without_network(tmp_path, monkeypatch):
    # If the cache is missing, load_dataset_cached would try to download. Patch
    # ``datasets`` import to fail so we prove no silent network path is taken.
    import builtins

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "datasets":
            raise ImportError("datasets must not be imported when cache is absent in tests")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    with pytest.raises(ImportError):
        load_dataset_cached(cache_path=tmp_path / "does_not_exist.jsonl")


# --- selection ----------------------------------------------------------------

def test_select_instances_by_n():
    rows = load_dataset_cached(cache_path=_write_fake_cache(Path("/tmp/forge_swebench_test_rows")))
    selected = select_instances(rows, n=1)
    assert len(selected) == 1
    assert selected[0].instance_id == ROW_A["instance_id"]


def test_select_instances_by_explicit_ids():
    rows = load_dataset_cached(cache_path=_write_fake_cache(Path("/tmp/forge_swebench_test_rows2")))
    selected = select_instances(rows, instance_ids=[ROW_B["instance_id"]])
    assert len(selected) == 1
    assert selected[0].instance_id == ROW_B["instance_id"]


def test_select_instances_unknown_id_raises():
    rows = load_dataset_cached(cache_path=_write_fake_cache(Path("/tmp/forge_swebench_test_rows3")))
    with pytest.raises(KeyError):
        select_instances(rows, instance_ids=["nope__nope-1"])


# --- predictions JSONL --------------------------------------------------------

def test_predictions_gold_writes_dataset_patch_verbatim(tmp_path):
    rows = load_dataset_cached(cache_path=_write_fake_cache(tmp_path))
    preds_path = tmp_path / "preds.jsonl"
    write_predictions(rows, preds_path, gold=True)
    objs = [json.loads(line) for line in preds_path.read_text().strip().splitlines()]
    assert len(objs) == 2
    for obj, row in zip(objs, [ROW_A, ROW_B]):
        assert set(obj.keys()) == {"instance_id", "model_name_or_path", "model_patch"}
        assert obj["instance_id"] == row["instance_id"]
        assert obj["model_name_or_path"] == GOLD_MODEL_NAME
        assert obj["model_patch"] == row["patch"]  # verbatim gold patch


def test_predictions_non_gold_writes_empty_patch(tmp_path):
    rows = load_dataset_cached(cache_path=_write_fake_cache(tmp_path))
    preds_path = tmp_path / "preds.jsonl"
    write_predictions(rows, preds_path, gold=False)
    objs = [json.loads(line) for line in preds_path.read_text().strip().splitlines()]
    for obj in objs:
        assert obj["model_patch"] == ""
        assert obj["model_name_or_path"] == EMPTY_MODEL_NAME


# --- lease refusal -------------------------------------------------------------

def test_run_refused_without_lease(tmp_path):
    cache = _write_fake_cache(tmp_path)
    with pytest.raises(ExternalityRefused):
        run_swebench(
            n=1,
            lease=None,
            dataset_cache=cache,
            report_dir=tmp_path / "rd",
        )


def test_dry_run_check_does_not_require_lease(tmp_path):
    cache = _write_fake_cache(tmp_path)
    receipt = run_swebench(
        n=1,
        lease=None,
        dry_run_check=True,
        dataset_cache=cache,
        report_dir=tmp_path / "rd",
    )
    assert receipt.externality_level == "public_benchmark"
    assert receipt.custody_label == CUSTODY_DRY_RUN_ONLY
    assert receipt.harness["returncode"] == -1  # harness not invoked


# --- harness command ----------------------------------------------------------

def test_harness_command_shape(tmp_path):
    cmd = build_harness_command(
        instance_ids=["a-1", "b-2"],
        predictions_path=tmp_path / "p.jsonl",
        run_id="rid",
        report_dir=tmp_path / "rd",
        max_workers=2,
        timeout=900,
    )
    assert cmd[0:3] == [__import__("sys").executable, "-m", "swebench.harness.run_evaluation"]
    assert "-d" in cmd and DATASET_NAME in cmd
    assert "-s" in cmd and DATASET_SPLIT in cmd
    assert "-i" in cmd and "a-1" in cmd and "b-2" in cmd
    assert "-p" in cmd
    assert "-id" in cmd and "rid" in cmd
    assert "--report_dir" in cmd
    assert "--max_workers" in cmd and "2" in cmd
    assert "--timeout" in cmd and "900" in cmd
    assert "--cache_level" in cmd and "instance" in cmd


# --- report parsing from a fake report dir ------------------------------------

def _write_fake_report(report_dir: Path, *, resolved_a: bool, resolved_b: bool) -> None:
    """Mimic the official swebench report-dir layout.

    Per-instance report.json files live under
    ``logs/run_evaluation/<run_id>/<model>/<instance_id>/report.json`` and have
    the shape ``{<instance_id>: {resolved, tests_status: {pass_to_pass, fail_to_pass}}}``.
    A summary ``<model>.<run_id>.json`` sits at the report_dir root.
    """

    model = "forge-pg-gold"
    run_id = "rid"
    per_dir = report_dir / "logs" / "run_evaluation" / run_id / model
    per_dir.mkdir(parents=True, exist_ok=True)
    for row, resolved in ((ROW_A, resolved_a), (ROW_B, resolved_b)):
        inst_dir = per_dir / row["instance_id"]
        inst_dir.mkdir(parents=True, exist_ok=True)
        report_obj = {
            row["instance_id"]: {
                "patch_is_None": False,
                "patch_exists": True,
                "patch_successfully_applied": True,
                "resolved": resolved,
                "tests_status": {
                    "pass_to_pass": {t: "PASSED" for t in row["pass_to_pass"]},
                    "fail_to_pass": {t: ("PASSED" if resolved else "FAILED") for t in row["fail_to_pass"]},
                },
            }
        }
        (inst_dir / "report.json").write_text(json.dumps(report_obj), encoding="utf-8")

    summary = {
        "total_instances": 2,
        "submitted_instances": 2,
        "completed_instances": 2,
        "resolved_instances": int(resolved_a) + int(resolved_b),
        "unresolved_instances": 2 - (int(resolved_a) + int(resolved_b)),
        "empty_patch_instances": 0,
        "error_instances": 0,
        "completed_ids": [ROW_A["instance_id"], ROW_B["instance_id"]],
        "incomplete_ids": [],
        "empty_patch_ids": [],
        "submitted_ids": [ROW_A["instance_id"], ROW_B["instance_id"]],
        "resolved_ids": [r["instance_id"] for r, ok in ((ROW_A, resolved_a), (ROW_B, resolved_b)) if ok],
        "unresolved_ids": [r["instance_id"] for r, ok in ((ROW_A, resolved_a), (ROW_B, resolved_b)) if not ok],
        "error_ids": [],
        "schema_version": 2,
    }
    (report_dir / f"{model}.{run_id}.json").write_text(json.dumps(summary, indent=4), encoding="utf-8")


def test_parse_report_resolved_classification(tmp_path):
    report_dir = tmp_path / "rd"
    _write_fake_report(report_dir, resolved_a=True, resolved_b=False)
    parsed = parse_report_dir(report_dir)
    by_id = {i.instance_id: i for i in parsed.instances}
    assert by_id[ROW_A["instance_id"]].resolved is True
    assert by_id[ROW_B["instance_id"]].resolved is False
    # pass_to_pass / fail_to_pass surfaced from tests_status
    assert by_id[ROW_A["instance_id"]].fail_to_pass == {"test_a::test_fail": "PASSED"}
    assert by_id[ROW_B["instance_id"]].fail_to_pass == {"test_b::test_fail": "FAILED"}
    # aggregate taken from the summary
    assert parsed.aggregate.n == 2
    assert parsed.aggregate.resolved_count == 1
    assert parsed.aggregate.unresolved_count == 1
    assert parsed.summary_path is not None


def test_parse_report_falls_back_when_no_summary(tmp_path):
    report_dir = tmp_path / "rd"
    _write_fake_report(report_dir, resolved_a=True, resolved_b=True)
    # remove the summary so the roll-up fallback is exercised
    for p in report_dir.glob("*.json"):
        p.unlink()
    parsed = parse_report_dir(report_dir)
    assert parsed.aggregate.n == 2
    assert parsed.aggregate.resolved_count == 2
    assert parsed.aggregate.unresolved_count == 0
    assert parsed.summary_path is None


def test_parse_report_missing_dir_is_empty(tmp_path):
    parsed = parse_report_dir(tmp_path / "nope")
    assert parsed.instances == []
    assert parsed.aggregate.n == 0


# --- end-to-end run with mocked subprocess ------------------------------------

class _FakeProc:
    def __init__(self, returncode: int = 0):
        self.returncode = returncode
        self.stdout = "fake harness stdout"
        self.stderr = "fake harness stderr"


def test_run_with_lease_and_mocked_harness(tmp_path, monkeypatch):
    cache = _write_fake_cache(tmp_path)
    report_dir = tmp_path / "rd"
    captured: dict = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = list(cmd)
        captured["cwd"] = kwargs.get("cwd")
        # Simulate the harness writing the report dir.
        _write_fake_report(report_dir, resolved_a=True, resolved_b=False)
        return _FakeProc(returncode=0)

    receipt = run_swebench(
        n=2,
        gold=True,
        lease="operator-lease-xyz",
        run_id="rid",
        report_dir=report_dir,
        dataset_cache=cache,
        runner=fake_run,
    )
    # Harness was invoked with the official module and the lease-gated run id.
    assert captured["cmd"][1:3] == ["-m", "swebench.harness.run_evaluation"]
    assert "-id" in captured["cmd"] and "rid" in captured["cmd"]
    assert captured["cwd"] == str(report_dir)
    # Receipt is honest.
    assert receipt.schema == "forge_swebench_receipt.v1"
    assert receipt.externality_level == "public_benchmark"
    assert receipt.lease == "operator-lease-xyz"
    assert receipt.custody_label == CUSTODY_DRY_RUN_ONLY
    assert receipt.gold_mode is True
    assert receipt.run_id == "rid"
    assert receipt.harness["returncode"] == 0
    # Report parsed from the fake report dir.
    assert receipt.report["aggregate"]["resolved_count"] == 1
    assert receipt.report["aggregate"]["unresolved_count"] == 1
    ids = {i["instance_id"] for i in receipt.report["instances"]}
    assert ids == {ROW_A["instance_id"], ROW_B["instance_id"]}
    # Receipt was written to disk.
    assert (report_dir / "swebench_receipt.json").exists()


def test_authority_attestation_all_false(tmp_path):
    cache = _write_fake_cache(tmp_path)
    receipt = run_swebench(
        n=1,
        gold=True,
        lease="operator-lease-xyz",
        report_dir=tmp_path / "rd",
        dataset_cache=cache,
        runner=lambda cmd, **kw: _FakeProc(0),
    )
    att = receipt.authority_attestation
    for forbidden, value in att["forbidden_actions"].items():
        assert value == "not_taken"
    assert att["public_submission_performed"] is False
    assert att["archive_fitness_mutated"] is False
    assert att["live_model_call_performed"] is False
    assert att["lease"] == "operator-lease-xyz"
    # No live model / no public submission recorded on the receipt either.
    assert receipt.network_calls == 0


def test_gold_predictions_written_verbatim_in_full_run(tmp_path):
    cache = _write_fake_cache(tmp_path)
    report_dir = tmp_path / "rd"
    receipt = run_swebench(
        n=1,
        gold=True,
        lease="operator-lease-xyz",
        report_dir=report_dir,
        dataset_cache=cache,
        runner=lambda cmd, **kw: _FakeProc(0),
    )
    preds_path = Path(receipt.predictions_path)
    objs = [json.loads(line) for line in preds_path.read_text().strip().splitlines()]
    assert len(objs) == 1
    assert objs[0]["model_patch"] == GOLD_PATCH
    assert objs[0]["model_name_or_path"] == GOLD_MODEL_NAME


# --- CLI lease refusal --------------------------------------------------------

def test_cli_refused_without_lease(capsys, tmp_path):
    cache = _write_fake_cache(tmp_path)
    rc = adapter.main([
        "--n", "1",
        "--dataset-cache", str(cache),
        "--report-dir", str(tmp_path / "rd"),
    ])
    assert rc == 4
    out = json.loads(capsys.readouterr().out)
    assert out["status"] == "refused"


def test_cli_dry_run_check_emits_receipt(tmp_path, capsys):
    cache = _write_fake_cache(tmp_path)
    rc = adapter.main([
        "--dry-run-check",
        "--gold",
        "--n", "1",
        "--dataset-cache", str(cache),
        "--report-dir", str(tmp_path / "rd"),
        "--json",
    ])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["schema"] == "forge_swebench_receipt.v1"
    assert out["externality_level"] == "public_benchmark"
    assert out["gold_mode"] is True
    assert out["harness"]["returncode"] == -1


# --- real Docker harness (skipped) --------------------------------------------

@pytest.mark.skip(reason="needs Docker + swebench images; run manually")
def test_real_harness_gold_smoke(tmp_path):
    # Exercises the real official harness end-to-end. Requires Docker, the
    # swebench env images, and a network path to the HuggingFace dataset.
    cache = _write_fake_cache(tmp_path)
    run_swebench(
        n=1,
        gold=True,
        lease="operator-manual-lease",
        report_dir=tmp_path / "real_rd",
        dataset_cache=cache,
    )
