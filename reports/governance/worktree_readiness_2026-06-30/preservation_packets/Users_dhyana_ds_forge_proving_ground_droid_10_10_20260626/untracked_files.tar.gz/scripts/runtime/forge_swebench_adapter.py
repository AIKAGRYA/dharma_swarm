#!/usr/bin/env python3
"""SWE-bench Verified adapter for the Dharma Forge Proving Ground.

Integrates the OFFICIAL swebench Docker harness (``swebench.harness.run_evaluation``)
as a public-benchmark externality. The adapter is stop-safe and idempotent, makes
NO live LLM calls, and performs NO public submission. It only:

  1. loads the SWE-bench Verified dataset (cached locally as JSONL),
  2. writes an official-format predictions JSONL file (gold patch dry-run, or
     empty-patch smoke when no model is supplied -- never a faked model patch),
  3. invokes the official harness via subprocess (Docker), and
  4. parses the harness report dir into an honest receipt.

Externality is honestly labeled ``public_benchmark`` and the adapter REFUSES to
run unless an explicit operator ``lease`` string is supplied. The receipt records
the lease and the ``CUSTODY_DRY_RUN_ONLY`` custody label: run + measure, not
submitted. Authority attestation fields reuse ``FORBIDDEN_ACTIONS``.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from scripts.runtime.forge_proving_ground_common import (  # noqa: E402
    CUSTODY_DRY_RUN_ONLY,
    FORBIDDEN_ACTIONS,
    PUBLIC_BENCHMARK,
    PROVING_GROUND_ROOT,
    iso,
    new_run_identity,
    sha256_text,
    utc_now,
    write_json,
)

DATASET_NAME = "princeton-nlp/SWE-bench_Verified"
DATASET_SPLIT = "test"
DATASET_CACHE = PROVING_GROUND_ROOT / "swebench_dataset_cache.jsonl"

GOLD_MODEL_NAME = "forge-pg-gold"
EMPTY_MODEL_NAME = "forge-pg-empty-patch"

DEFAULT_MAX_WORKERS = 1
DEFAULT_TIMEOUT = 1800

# Injectable runner type alias (kept simple to avoid typing import noise).
CallableLikeRunner = Callable[..., Any]


class ExternalityRefused(PermissionError):
    """Raised when a gated externality level is requested without a lease."""


@dataclass(frozen=True)
class DatasetRow:
    """Subset of a SWE-bench Verified instance used by this adapter."""

    instance_id: str
    patch: str
    repo: str
    base_commit: str
    fail_to_pass: list[str]
    pass_to_pass: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def _row_from_dataset(item: dict) -> DatasetRow:
    """Coerce a HuggingFace dataset row (Mapping) into a plain DatasetRow."""

    def _as_list(value: object) -> list[str]:
        if value is None:
            return []
        if isinstance(value, str):
            # swebench stores test lists as JSON-encoded strings in some splits.
            try:
                decoded = json.loads(value)
                if isinstance(decoded, list):
                    return [str(x) for x in decoded]
            except (json.JSONDecodeError, TypeError):
                pass
            return [value]
        try:
            return [str(x) for x in list(value)]
        except TypeError:
            return []

    return DatasetRow(
        instance_id=str(item["instance_id"]),
        patch=str(item.get("patch", "") or ""),
        repo=str(item.get("repo", "") or ""),
        base_commit=str(item.get("base_commit", "") or ""),
        fail_to_pass=_as_list(item.get("FAIL_TO_PASS", item.get("fail_to_pass", []))),
        pass_to_pass=_as_list(item.get("PASS_TO_PASS", item.get("pass_to_pass", []))),
    )


def load_dataset_cached(cache_path: Path = DATASET_CACHE) -> list[DatasetRow]:
    """Load the SWE-bench Verified test split, caching it locally as JSONL.

    If the cache file already exists and is non-empty, it is read back without
    any network access. Otherwise the ``datasets`` library is used to download
    the split once, and every row is appended to the cache.
    """

    cache_path = Path(cache_path)
    if cache_path.exists() and cache_path.stat().st_size > 0:
        rows: list[DatasetRow] = []
        for line in cache_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            rows.append(
                DatasetRow(
                    instance_id=obj["instance_id"],
                    patch=obj.get("patch", "") or "",
                    repo=obj.get("repo", "") or "",
                    base_commit=obj.get("base_commit", "") or "",
                    fail_to_pass=list(obj.get("fail_to_pass", []) or []),
                    pass_to_pass=list(obj.get("pass_to_pass", []) or []),
                )
            )
        if rows:
            return rows

    # Cache miss: download via the official datasets library.
    import datasets  # local import: keeps the module importable without datasets.

    ds = datasets.load_dataset(DATASET_NAME, split=DATASET_SPLIT)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    rendered_rows: list[DatasetRow] = []
    with cache_path.open("w", encoding="utf-8") as fh:
        for item in ds:
            row = _row_from_dataset(item)
            rendered_rows.append(row)
            fh.write(json.dumps(row.to_dict(), sort_keys=True) + "\n")
    return rendered_rows


def select_instances(
    rows: list[DatasetRow],
    *,
    n: int = 1,
    instance_ids: list[str] | None = None,
) -> list[DatasetRow]:
    """Select a bounded slice of instances by explicit ids or the first ``n``."""

    if instance_ids:
        wanted = list(instance_ids)
        by_id = {r.instance_id: r for r in rows}
        missing = [i for i in wanted if i not in by_id]
        if missing:
            raise KeyError(f"instance_ids not in dataset: {missing}")
        return [by_id[i] for i in wanted]
    if n < 0:
        raise ValueError("n must be >= 0")
    return rows[:n]


def write_predictions(
    rows: list[DatasetRow],
    predictions_path: Path,
    *,
    gold: bool,
    model_name: str | None = None,
) -> Path:
    """Write predictions JSONL in the official swebench format.

    One JSON object per line: ``{"instance_id", "model_name_or_path", "model_patch"}``.
    In gold mode ``model_patch`` is the dataset's gold ``patch`` verbatim; otherwise
    it is an empty string (an honest no-model smoke patch, never a faked model diff).
    """

    predictions_path = Path(predictions_path)
    predictions_path.parent.mkdir(parents=True, exist_ok=True)
    name = model_name or (GOLD_MODEL_NAME if gold else EMPTY_MODEL_NAME)
    lines: list[str] = []
    for row in rows:
        patch = row.patch if gold else ""
        obj = {
            "instance_id": row.instance_id,
            "model_name_or_path": name,
            "model_patch": patch,
        }
        lines.append(json.dumps(obj, sort_keys=True))
    predictions_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return predictions_path


def build_harness_command(
    *,
    instance_ids: list[str],
    predictions_path: Path,
    run_id: str,
    report_dir: Path,
    max_workers: int = DEFAULT_MAX_WORKERS,
    timeout: int = DEFAULT_TIMEOUT,
    dataset_name: str = DATASET_NAME,
    split: str = DATASET_SPLIT,
) -> list[str]:
    """Build the official ``swebench.harness.run_evaluation`` subprocess argv."""

    return [
        sys.executable,
        "-m",
        "swebench.harness.run_evaluation",
        "-d",
        dataset_name,
        "-s",
        split,
        "-i",
        *instance_ids,
        "-p",
        str(predictions_path),
        "-id",
        run_id,
        "--report_dir",
        str(report_dir),
        "--max_workers",
        str(max_workers),
        "--timeout",
        str(timeout),
        "--cache_level",
        "instance",
    ]


@dataclass
class HarnessResult:
    command: list[str]
    returncode: int
    stdout: str
    stderr: str

    def to_dict(self) -> dict:
        return asdict(self)


def run_harness(
    *,
    instance_ids: list[str],
    predictions_path: Path,
    run_id: str,
    report_dir: Path,
    max_workers: int = DEFAULT_MAX_WORKERS,
    timeout: int = DEFAULT_TIMEOUT,
    cwd: Path | None = None,
    runner: CallableLikeRunner | None = None,
) -> HarnessResult:
    """Invoke the official harness. ``runner`` is injectable for tests.

    By default this uses ``subprocess.run``. The harness writes per-instance
    ``report.json`` files under ``logs/run_evaluation/<run_id>/...`` relative to
    its cwd, plus a summary ``<model>.<run_id>.json`` in ``report_dir``. We run
    with ``cwd=report_dir`` so the whole tree lands under ``report_dir`` and the
    parser can glob it.
    """

    command = build_harness_command(
        instance_ids=instance_ids,
        predictions_path=predictions_path,
        run_id=run_id,
        report_dir=report_dir,
        max_workers=max_workers,
        timeout=timeout,
    )
    run = runner or subprocess.run
    proc = run(
        command,
        cwd=str(cwd or report_dir),
        capture_output=True,
        text=True,
    )
    return HarnessResult(
        command=command,
        returncode=int(proc.returncode),
        stdout=(proc.stdout or ""),
        stderr=(proc.stderr or ""),
    )


@dataclass
class InstanceResult:
    instance_id: str
    resolved: bool
    pass_to_pass: dict
    fail_to_pass: dict

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class AggregateResult:
    n: int
    resolved_count: int
    unresolved_count: int

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ParsedReport:
    instances: list[InstanceResult] = field(default_factory=list)
    aggregate: AggregateResult = field(
        default_factory=lambda: AggregateResult(n=0, resolved_count=0, unresolved_count=0)
    )
    summary_path: str | None = None
    per_instance_paths: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "instances": [i.to_dict() for i in self.instances],
            "aggregate": self.aggregate.to_dict(),
            "summary_path": self.summary_path,
            "per_instance_paths": list(self.per_instance_paths),
        }


def _is_summary_report(obj: dict) -> bool:
    return "resolved_instances" in obj or "total_instances" in obj


def _extract_per_instance(obj: dict) -> list[tuple[str, dict]]:
    """Yield (instance_id, record) pairs from a per-instance report.json object.

    A per-instance report.json has the shape ``{<instance_id>: {resolved, ...}}``.
    """

    out: list[tuple[str, dict]] = []
    for key, value in obj.items():
        if not isinstance(value, dict) or "resolved" not in value:
            continue
        out.append((str(key), value))
    return out


def parse_report_dir(report_dir: Path) -> ParsedReport:
    """Parse the harness report dir into a receipt, defensively.

    Globs ``**/*.json`` under ``report_dir`` and classifies each file by content:
      * summary report -> dict with ``resolved_instances`` / ``total_instances``
      * per-instance report -> dict mapping instance_id -> ``{resolved, ...}``
    """

    report_dir = Path(report_dir)
    parsed = ParsedReport()
    if not report_dir.exists():
        return parsed

    summary_obj: dict | None = None
    per_instance_records: list[tuple[str, dict]] = []

    for path in sorted(report_dir.rglob("*.json")):
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(obj, dict):
            continue
        if _is_summary_report(obj):
            summary_obj = obj
            parsed.summary_path = str(path)
            continue
        pairs = _extract_per_instance(obj)
        if pairs:
            per_instance_records.extend(pairs)
            parsed.per_instance_paths.append(str(path))

    # Build per-instance results.
    seen: set[str] = set()
    for instance_id, record in per_instance_records:
        if instance_id in seen:
            continue
        seen.add(instance_id)
        tests_status = record.get("tests_status", {}) or {}
        parsed.instances.append(
            InstanceResult(
                instance_id=instance_id,
                resolved=bool(record.get("resolved", False)),
                pass_to_pass=dict(tests_status.get("pass_to_pass", {}) or {}),
                fail_to_pass=dict(tests_status.get("fail_to_pass", {}) or {}),
            )
        )

    # Aggregate: prefer the summary counts, fall back to per-instance roll-up.
    if summary_obj is not None:
        resolved_count = int(summary_obj.get("resolved_instances", 0))
        unresolved_count = int(summary_obj.get("unresolved_instances", 0))
        n = int(summary_obj.get("submitted_instances", resolved_count + unresolved_count))
        parsed.aggregate = AggregateResult(
            n=n,
            resolved_count=resolved_count,
            unresolved_count=unresolved_count,
        )
    else:
        resolved_count = sum(1 for i in parsed.instances if i.resolved)
        parsed.aggregate = AggregateResult(
            n=len(parsed.instances),
            resolved_count=resolved_count,
            unresolved_count=len(parsed.instances) - resolved_count,
        )

    return parsed


@dataclass
class SwebenchReceipt:
    schema: str
    identity: dict
    generated_at: str
    externality_level: str
    lease: str
    custody_label: str
    dataset_name: str
    dataset_split: str
    dataset_cache_path: str
    predictions_path: str
    run_id: str
    report_dir: str
    gold_mode: bool
    model_name_or_path: str
    instance_ids: list[str]
    harness: dict
    report: dict
    authority_attestation: dict
    network_calls: int

    def to_dict(self) -> dict:
        return asdict(self)


def build_authority_attestation(*, lease: str) -> dict:
    return {
        "forbidden_actions": {name: "not_taken" for name in FORBIDDEN_ACTIONS},
        "public_submission_performed": False,
        "archive_fitness_mutated": False,
        "external_outreach_performed": False,
        "paid_action_performed": False,
        "production_router_mutation": False,
        "trusted_memory_promoted": False,
        "self_merge": False,
        "protected_identity_mutation": False,
        "live_model_call_performed": False,
        "lease": lease,
    }


def run_swebench(
    *,
    n: int = 1,
    instance_ids: list[str] | None = None,
    gold: bool = False,
    model_name: str | None = None,
    run_id: str | None = None,
    report_dir: Path | None = None,
    lease: str | None = None,
    max_workers: int = DEFAULT_MAX_WORKERS,
    timeout: int = DEFAULT_TIMEOUT,
    dataset_cache: Path = DATASET_CACHE,
    dry_run_check: bool = False,
    runner: CallableLikeRunner | None = None,
    now: datetime | None = None,
) -> SwebenchReceipt:
    """Full adapter run: load dataset, write predictions, (optionally) run harness.

    When ``dry_run_check`` is True the harness subprocess is NOT invoked: only the
    dataset is loaded and predictions are written. This is the no-Docker smoke path.
    """

    if not lease and not dry_run_check:
        raise ExternalityRefused(
            f"externality level {PUBLIC_BENCHMARK!r} requires an explicit operator lease"
        )

    now = now or utc_now()
    identity = new_run_identity(task_id="forge_swebench", agent_id="forge_pg_swebench")
    effective_run_id = run_id or identity["run_id"]

    rows = load_dataset_cached(cache_path=dataset_cache)
    selected = select_instances(rows, n=n, instance_ids=instance_ids)
    if not selected:
        raise ValueError("no instances selected (n=0 and no instance_ids)")

    effective_model = model_name or (GOLD_MODEL_NAME if gold else EMPTY_MODEL_NAME)
    report_dir = Path(report_dir) if report_dir else (
        PROVING_GROUND_ROOT / f"swebench-{effective_run_id}"
    )
    report_dir.mkdir(parents=True, exist_ok=True)
    predictions_path = report_dir / "predictions.jsonl"
    write_predictions(
        selected,
        predictions_path,
        gold=gold,
        model_name=effective_model,
    )

    ids = [r.instance_id for r in selected]

    if dry_run_check:
        harness = HarnessResult(
            command=[],
            returncode=-1,
            stdout="",
            stderr="dry_run_check: harness not invoked",
        )
        report = ParsedReport(
            instances=[
                InstanceResult(
                    instance_id=r.instance_id,
                    resolved=False,
                    pass_to_pass={},
                    fail_to_pass={},
                )
                for r in selected
            ],
            aggregate=AggregateResult(n=len(ids), resolved_count=0, unresolved_count=len(ids)),
        )
    else:
        harness = run_harness(
            instance_ids=ids,
            predictions_path=predictions_path,
            run_id=effective_run_id,
            report_dir=report_dir,
            max_workers=max_workers,
            timeout=timeout,
            runner=runner,
        )
        report = parse_report_dir(report_dir)

    receipt = SwebenchReceipt(
        schema="forge_swebench_receipt.v1",
        identity=identity,
        generated_at=iso(now),
        externality_level=PUBLIC_BENCHMARK,
        lease=lease or "",
        custody_label=CUSTODY_DRY_RUN_ONLY,
        dataset_name=DATASET_NAME,
        dataset_split=DATASET_SPLIT,
        dataset_cache_path=str(dataset_cache),
        predictions_path=str(predictions_path),
        run_id=effective_run_id,
        report_dir=str(report_dir),
        gold_mode=bool(gold),
        model_name_or_path=effective_model,
        instance_ids=ids,
        harness=harness.to_dict(),
        report=report.to_dict(),
        authority_attestation=build_authority_attestation(lease=lease or ""),
        network_calls=0,
    )
    write_json(report_dir / "swebench_receipt.json", receipt.to_dict())
    return receipt


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gold", action="store_true", help="use the dataset gold patch as model_patch")
    parser.add_argument("--instance-ids", nargs="+", default=None)
    parser.add_argument("--n", type=int, default=1, help="number of instances (smoke default 1)")
    parser.add_argument("--run-id", default=None)
    parser.add_argument("--report-dir", type=Path, default=None)
    parser.add_argument(
        "--lease",
        default=None,
        help="explicit operator lease (required unless --dry-run-check)",
    )
    parser.add_argument("--model-name", default=None)
    parser.add_argument("--max-workers", type=int, default=DEFAULT_MAX_WORKERS)
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument(
        "--dataset-cache",
        type=Path,
        default=DATASET_CACHE,
    )
    parser.add_argument(
        "--dry-run-check",
        action="store_true",
        help="load dataset + write predictions only; do NOT invoke the Docker harness",
    )
    parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        receipt = run_swebench(
            n=args.n,
            instance_ids=args.instance_ids,
            gold=args.gold,
            model_name=args.model_name,
            run_id=args.run_id,
            report_dir=args.report_dir,
            lease=args.lease,
            max_workers=args.max_workers,
            timeout=args.timeout,
            dataset_cache=args.dataset_cache,
            dry_run_check=args.dry_run_check,
        )
    except ExternalityRefused as exc:
        print(json.dumps({"status": "refused", "reason": str(exc)}, indent=2, sort_keys=True))
        return 4
    payload = receipt.to_dict()
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
