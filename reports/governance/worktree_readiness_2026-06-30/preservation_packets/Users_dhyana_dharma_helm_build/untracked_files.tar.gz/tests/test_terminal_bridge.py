"""Tests for the Bun terminal bridge."""

from __future__ import annotations

import asyncio
import json

from dharma_swarm.operator_core.session_store import SessionStore
from dharma_swarm.terminal_bridge import TerminalBridge, system_commands_module
from dharma_swarm.tui.engine.events import SessionEnd, ToolCallComplete, ToolResult


def test_terminal_bridge_loads_tui_command_surface() -> None:
    assert system_commands_module is not None


def test_terminal_bridge_bootstraps_commands_and_adapters() -> None:
    bridge = TerminalBridge()
    try:
        assert bridge._commands is not None
        assert {"claude", "codex", "openrouter"} <= set(bridge._adapters)
        assert bridge._completion_request_cls is not None
    finally:
        asyncio.run(bridge.close())


def test_terminal_bridge_routes_tool_work_to_agent_lane() -> None:
    bridge = TerminalBridge()
    try:
        intent = bridge._resolve_prompt_intent(
            "read terminal/src/app.tsx and tell me where session.start is sent"
        )
        assert intent["kind"] == "agent"
        assert intent["reason"] == "tool-capable repo work request"

        test_intent = bridge._resolve_prompt_intent("run tests for the terminal tui")
        assert test_intent["kind"] == "agent"

        chat_intent = bridge._resolve_prompt_intent("what do you think about the helm UI?")
        assert chat_intent["kind"] == "chat"
    finally:
        asyncio.run(bridge.close())


def test_session_start_creates_store_entry_before_tool_permissions(tmp_path, capsys) -> None:
    class FakeProfile:
        model_id = "gpt-5.4"

    class FakeCompletionRequest:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class FakeAdapter:
        def get_profile(self, model):
            return FakeProfile()

        async def close(self):
            return None

        async def stream(self, completion, *, session_id):
            yield ToolCallComplete(
                provider_id="codex",
                session_id=session_id,
                tool_call_id="tool-1",
                tool_name="shell",
                arguments="pwd",
                provider_options={"requires_confirmation": True},
            )
            yield ToolResult(
                provider_id="codex",
                session_id=session_id,
                tool_call_id="tool-1",
                tool_name="shell",
                content="/Users/dhyana/dharma_helm_build",
            )
            yield SessionEnd(provider_id="codex", session_id=session_id, success=True)

    bridge = TerminalBridge()
    bridge._session_store = SessionStore(root=tmp_path)
    bridge._adapters = {"codex": FakeAdapter()}
    bridge._completion_request_cls = FakeCompletionRequest

    try:
        asyncio.run(
            bridge._handle_session_start(
                "req-1",
                {
                    "provider": "codex",
                    "model": "gpt-5.4",
                    "prompt": "run pwd with the shell tool",
                },
            )
        )
    finally:
        asyncio.run(bridge.close())

    emitted = [json.loads(line) for line in capsys.readouterr().out.splitlines() if line.strip()]
    ack = next(event for event in emitted if event["type"] == "session.ack")
    session_id = ack["session_id"]

    assert (tmp_path / session_id / "transcript.jsonl").exists()
    assert any(event["type"] == "permission.decision" for event in emitted)
    assert any(event["type"] == "tool_call_complete" for event in emitted)
    assert any(event["type"] == "tool_result" for event in emitted)
    assert any(event.type == "permission_decision" for event in bridge._session_store.load_transcript(session_id))


def test_claude_agent_turn_scrubs_metered_keys_by_default(tmp_path) -> None:
    captured: dict[str, object] = {}

    class FakeProfile:
        model_id = "claude-opus-4-8"

    class FakeCompletionRequest:
        def __init__(self, **kwargs):
            captured["kwargs"] = kwargs

    class FakeAdapter:
        def get_profile(self, model):
            return FakeProfile()

        async def close(self):
            return None

        async def stream(self, completion, *, session_id):
            yield SessionEnd(provider_id="claude", session_id=session_id, success=True)

    bridge = TerminalBridge()
    bridge._session_store = SessionStore(root=tmp_path)
    bridge._adapters = {"claude": FakeAdapter()}
    bridge._completion_request_cls = FakeCompletionRequest

    try:
        asyncio.run(
            bridge._handle_session_start(
                "req-claude",
                {
                    "provider": "claude",
                    "model": "claude-opus-4-8",
                    "prompt": "read terminal/src/bridge.ts",
                    "bootstrap": {"intent": {"kind": "agent"}},
                },
            )
        )
    finally:
        asyncio.run(bridge.close())

    kwargs = captured["kwargs"]
    assert isinstance(kwargs, dict)
    assert kwargs["provider_options"]["scrub_metered_keys"] is True
