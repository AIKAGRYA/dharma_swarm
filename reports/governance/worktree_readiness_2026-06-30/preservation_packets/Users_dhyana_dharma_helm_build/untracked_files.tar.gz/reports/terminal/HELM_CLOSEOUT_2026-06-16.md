# Helm Worldclass TUI — Closeout Packet (2026-06-16)

**Track:** `helm-worldclass-terminal-2026-06` (next-item #1: *"collect the Helm branch diff into a closeout packet with exact tests and screenshots/terminal captures"*).
**Branch:** `helm/worldclass-20260612` @ `fa7f0cc8e` · **Canonical target:** `~/dharma_swarm/terminal/` (main).
**Author of this packet:** opus_composer (Opus 4.8). Verified firsthand, not from memory.

---

## State: green and world-class, but STRANDED

The full world-class Helm — zen/cockpit/deck/scroll faces, the F-163 fill-law fix,
chat memory + latency (F-174), scenic Hokusai wave — lives on the branch and is
**NOT in main's `terminal/`**. The old build worktree (`~/dharma_helm_build`) had
been deleted, so `ds tui` (which defaults there) was **dark**. Restored this session.

- **Diff vs main (`terminal/`):** 113 files, **+6,641 / −2,460**, **42 commits ahead**.
- **Main's `terminal/` lacks** `uiIntents.ts`, `layoutMode`, the zen faces — confirmed.
- **Dormant 3 days** (last commit 2026-06-13); clean tree, no active agent.

## Verification (firsthand, 2026-06-16)

| Gate | Result |
|---|---|
| `bun test` | **576 pass / 0 fail** (18 files, 2.49s) |
| `bun run typecheck` (`tsc --noEmit`) | **0 errors** |
| `scripts/boot_smoke.sh` | **OK** |
| Hermetic tmux boot (120×40, offline) | clean zen frame, **no garble / no off-screen / no overflow** |

Captured zen-default frame (the $900-flunk bug — conversation off-screen — is gone):
```
 Dharma Terminal
 Type a message below · F2 opens the cockpit
╭────────────────────────────────────────────────────────────╮
│ >   Type a message · / commands · ? keys                   │
╰────────────────────────────────────────────────────────────╯
 zen  ·  codex:gpt-5.4  ·  offline  ·  F2 cockpit · /tour
```

## What landed on this branch (post-flunk, the fixes that matter)

- **F-163 fill-law** — root `height={terminalHeight}`, clip-don't-squeeze wrappers; the off-screen-conversation bug (the flunk cause) fixed and live-verified.
- **F-174 / `7b07f5491`** — chat turns answer in seconds with conversation memory (lightweight no-tools `_run_chat_turn` lane; root-cause fix: claude child `stdin=DEVNULL` hang). Live-verified hello 13–15s, codeword recall across 3 route switches.
- **Zen cluster** — `/zen //cockpit //deck`, NL pane-by-voice router (`uiIntents.ts`, operator phrases are unit tests), F2 toggle, zen-pure one-row chrome.
- **FACE design pass** — FACE-1 zen-pure + repaint, FACE-2 Command Post (Hokusai truecolor cockpit), FACE-3 The Scroll (`/scroll` reading-first face), scenic pixel-art wave.

## Merge recommendation

This is a **coherent feature branch** (the faces, zen reducer, `uiIntents`, chat lane
interlock) — splitting into small PRs would be artificial. The track sanctions the
alternative: **one large-diff-exception PR with this packet as the receipt.**

**Path to land:**
1. **Operator live-use gate first** — run `ds tui`, use it (real backend, a few turns, F2 cockpit, /tour), grade it. The gate is live use, not this doc.
2. If it passes: open `helm/worldclass-20260612 → main` as a large-diff-exception PR, this packet as the receipt; codex independent review (triad); operator merges.
3. **Merge dry-run — VERIFIED CLEAN (2026-06-16):** ran `git merge main` in the worktree. Only **5 conflicts**, all resolved correctly and re-verified, then aborted (the actual land is the operator's PR step):
   - `terminal/src/protocol.ts` → **kept HEAD's table-driven `commandTargetTab`** (F-158 registry refactor) over main's if-ladder; confirmed the registry maps `help: "chat"` (commandRegistry.ts:14) so main's `help`/`status`/`dashboard` behavior is preserved — proven by `protocol.test.ts` **117 pass / 0 fail**.
   - `terminal/tests/app.test.ts` → **kept HEAD's assertions** (F-172: `^T` toggles trace so reach control via `^Y`+`^T`; FACE-1: waiting row is `… thinking ·`, not `bootstrapping`) — they match the Helm's actual code; main's auto-merged new tests retained.
   - `.gitignore` → union of both. `AUTO_INVENTORY.md` / `SOVEREIGN_MANIFEST.md` → regenerate (docops `--write-auto-sections` + manifest count reconcile; note: merging main brings ~911 files, so md/bridge/adapter counts shift to the merged totals: 1033 md / 241,511 lines / 26 bridge / 25 adapter).
   - **Post-merge gates all GREEN:** `bun test` **576 pass / 0 fail**, `tsc --noEmit` 0 errors, `boot_smoke OK`. The merge is sound; the resolution above is deterministic and ready to re-apply at PR time.
4. After merge: repoint `ds tui` durably at `~/dharma_swarm` (`DS_TUI_ROOT` or update `~/bin/ds`) so the door survives worktree churn.

**Door restored now:** `~/dharma_helm_build` worktree recreated + `bun install` done, so `ds tui` works this minute against the branch.
